#!/usr/bin/env python3
"""Offline V8 policy tests. No UDP, GPIO, kiosk, payment, stock or motor writes."""
from __future__ import annotations
import copy
import tempfile
from pathlib import Path
from unittest.mock import patch
import wa_r3_fault_watchdog_v8 as wd
import wa_r3_purchase_recovery_v8 as purchase
def sample(code, *, pending=0, global_fault=False):
    d={k:False for k in wd.BLOCK_FLAGS}
    d.update(position=1,boot_id=54321,firmware='FutureTest R3 V8.3.8',
        idle_enabled=True,motor_hardware_ready=True,tmc_both_configured=True,
        pending_wait_open_mask=pending,pending_wait_close_mask=0,
        motors=[dict(motor=n,door_closed_verified=True,door_cycle_pending=bool(pending and n==7),
            step_output_active=bool(n==10),fault_latched=bool(n==7),fault_reason=code if n==7 else 0,
            enn_disabled_verified=bool(n==7),auto_recovery_budget_exhausted=False,
            encoder_valid=True,tmc_drv_status=0x00110000,tmc_gstat=0,
            enn_readback_available=True,enn_iodir_output=True,enn_olat_high=True,
            enn_gpio_high=True,enn_readback_error=0,stop_reason_code=5,
            stop_reason_age_s=20.0) for n in (7,10)])
    d['global_fault']=global_fault
    return d
def test_watchdog():
    with tempfile.TemporaryDirectory() as t:
        wd.LOCK=Path(t)/'lock';wd.STATE=Path(t)/'budget.json';wd.LOG=Path(t)/'log.jsonl'
        for code in range(1,8):
            wd.STATE.unlink(missing_ok=True)
            writes=[]
            d=sample(code)
            with patch.object(wd,'endpoint',return_value=('pi','esp',48556,'auth')), \
                 patch.object(wd,'status',return_value=d), \
                 patch.object(wd,'kiosk_idle',return_value=(True,'ready')), \
                 patch.object(wd,'rpc',side_effect=lambda *a,**kw:writes.append((a,kw)) or dict(ok=False,error='test_rejection')), \
                 patch.object(wd.time,'sleep',return_value=None):
                assert wd.once(auto=True,extended_auto=True)==0
            assert len(writes)==1,(code,writes)
            assert writes[0][0][1]=='remote_motor_recover'
            assert writes[0][1]['inspected'] is False
            assert writes[0][1]['motor']==7
            # Same fault cannot trigger a second command in the hour
            with patch.object(wd,'endpoint',return_value=('pi','esp',48556,'auth')), \
                 patch.object(wd,'status',return_value=d), \
                 patch.object(wd,'kiosk_idle',return_value=(True,'ready')), \
                 patch.object(wd,'rpc',side_effect=AssertionError('duplicate command')):
                assert wd.once(auto=True,extended_auto=True)==0
        for variant in (sample(4,pending=1),sample(4,global_fault=True)):
            with patch.object(wd,'endpoint',return_value=('pi','esp',48556,'auth')), \
                 patch.object(wd,'status',return_value=variant), \
                 patch.object(wd,'kiosk_idle',return_value=(True,'ready')), \
                 patch.object(wd,'rpc',side_effect=AssertionError('unsafe command')):
                assert wd.once(auto=True,extended_auto=True)==0
    print('PASS: V8 watchdog faults 1–7 one guarded attempt without inspection flag, no duplicate, global/pending blocked')
def test_purchase():
    with tempfile.TemporaryDirectory() as t:
        wd.LOCK=Path(t)/'lock';wd.STATE=Path(t)/'budget.json';wd.LOG=Path(t)/'log.jsonl'
        for code in (2,4,6,7):
            wd.STATE.unlink(missing_ok=True)
            before=sample(code)
            healed=sample(code)
            healed['motors'][0].update(step_output_active=True,enn_disabled_verified=False,
                fault_latched=False,fault_reason=0,rotation_verified_after_recovery=True,
                recovery_verification='encoder_motion_verified')
            calls=[]
            statuses=[before,before,healed]
            with patch.object(wd,'endpoint',return_value=('pi','esp',48556,'auth')), \
                 patch.object(wd,'status',side_effect=lambda ep:statuses.pop(0) if statuses else healed), \
                 patch.object(wd,'rpc',side_effect=lambda *a,**kw:calls.append((a,kw)) or dict(ok=True)), \
                 patch.object(purchase.time,'sleep',return_value=None):
                ok,reason=purchase.pre_retry_gate(5)
            assert ok,(code,reason)
            assert len(calls)==1 and calls[0][1]['inspected'] is False
        blocked=sample(4,pending=1)
        with patch.object(wd,'endpoint',return_value=('pi','esp',48556,'auth')), \
             patch.object(wd,'status',return_value=blocked), \
             patch.object(wd,'rpc',side_effect=AssertionError('unsafe command')):
            ok,reason=purchase.pre_retry_gate(5)
            assert not ok and 'pending' in reason
        assert purchase.classify_purchase({'type':'remote_purchase_ack',
              'warning':'at_least_one_revolver_door_never_opened; verify_delivery'},5)=='post_pulse_access_unconfirmed'
    print('PASS: purchased-item recovery 2/4/6/7 after known PRE-pulse failure; pending and post-pulse not treated as safe retry')
if __name__=='__main__':
    test_watchdog()
    test_purchase()
