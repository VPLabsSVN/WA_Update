#!/usr/bin/env python3
"""Install V8 R3 purchase helper on top of V7/V3 guarded retry wrapper.

Preserves the five-attempt purchased-item policy, backend exception and
post-pulse no-retry rules. No POS/FURS changes. --check is read-only.
"""
from __future__ import annotations
import argparse, ast, datetime, os, shutil, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PANEL=ROOT/'Panel.py'
B='# WA_R3_SINGLE_FLIGHT_V1_BEGIN'
E='# WA_R3_SINGLE_FLIGHT_V1_END'
V3='# WA_R3_POSITION_RETRY5_GUARDED_V3'
V7='# WA_R3_POSITION_RETRY5_FAULT_TRIAGE_V7'
V8='# WA_R3_POSITION_RETRY5_FAULT_RECOVERY_V8'

def transform(src):
    if src.count(B)!=1 or src.count(E)!=1: raise ValueError('Missing/ambiguous single-flight block')
    a=src.index(B); z=src.index(E,a)
    block=src[a:z]
    if block.count(V8)==1:return src,'already_installed'
    if V7 not in block:
        if block.count(V3)!=1:raise ValueError('Requires installed V3 or V7 five-attempt purchase wrapper')
        from wa_r3_purchase_retry5_v7_patch import transform as to_v7
        src,state=to_v7(src)
        a=src.index(B);z=src.index(E,a);block=src[a:z]
        if state!='ready' or V7 not in block:raise ValueError('Could not transform V3 to V7 safely')
    if block.count(V7)!=1 or block.count('from wa_r3_purchase_recovery_v7 import pre_retry_gate')!=1 or block.count('from wa_r3_purchase_recovery_v7 import purchase_triage')!=1:
        raise ValueError('Installed V7 source differs from verified structure')
    updated=block.replace(V7,V8)
    updated=updated.replace('from wa_r3_purchase_recovery_v7 import pre_retry_gate', 'from wa_r3_purchase_recovery_v8 import pre_retry_gate')
    updated=updated.replace('from wa_r3_purchase_recovery_v7 import purchase_triage', 'from wa_r3_purchase_recovery_v8 import purchase_triage')
    updated=updated.replace('pi_purchase_triage_v7','pi_purchase_triage_v8')
    updated=updated.replace('[R3 RETRY5 V7]', '[R3 RETRY5 V8]')
    result=src[:a]+updated+src[z:]
    ast.parse(result,filename=str(PANEL));compile(result,str(PANEL),'exec')
    return result,'ready'

def main():
    p=argparse.ArgumentParser(description=__doc__)
    g=p.add_mutually_exclusive_group(required=True)
    for flag in ('check','apply','self-test'):g.add_argument('--'+flag,action='store_true')
    args=p.parse_args()
    if args.self_test:
        import wa_r3_purchase_retry5_v7_patch as old
        from wa_r3_open_retry5_guarded_v3 import REPLACEMENT
        base='\n'+B+'\n'+old.replacement()+'\n'+E+'\n'
        output,state=transform(base)
        assert state=='ready' and V8 in output and 'wa_r3_purchase_recovery_v8' in output
        assert 'max_attempts' in output and 'pi_delivery_needs_attention' in output
        assert transform(output)[1]=='already_installed'
        print('PASS: V7-to-V8 structure, idempotency, five-attempt and paid-exception preserved')
        return 0
    if not PANEL.is_file():p.error('Panel.py not found')
    for name in ('wa_r3_purchase_recovery_v8.py','wa_r3_fault_watchdog_v8.py','wa_r3_purchase_retry5_v7_patch.py', 'wa_r3_open_retry5_guarded_v3.py'):
        if not (ROOT/name).is_file():p.error('Missing '+name)
    new,state=transform(PANEL.read_text(encoding='utf-8'))
    if state=='already_installed':print('ALREADY INSTALLED: V8 purchase helper');return
    if args.check:
        print('PASS: V8 Panel.py transformation parses/compiles (read-only)');return
    folder=ROOT/'wa_ui_patch_backups'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    folder.mkdir(parents=True,exist_ok=False)
    backup=folder/'Panel.py';shutil.copy2(PANEL,backup)
    fd,tmp=tempfile.mkstemp(prefix='.Panel_v8_',suffix='.py',dir=str(ROOT))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:f.write(new);f.flush();os.fsync(f.fileno())
        shutil.copymode(PANEL,tmp);os.replace(tmp,PANEL)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    print('SUCCESS: V8 purchase helper installed; five-attempt pre-pulse retries preserved')
    print('BACKUP:',backup)
    print('NO CHANGE: POS, fiscalization, post-pulse retry prohibition, pending/global fault protection')

if __name__=='__main__':main()
