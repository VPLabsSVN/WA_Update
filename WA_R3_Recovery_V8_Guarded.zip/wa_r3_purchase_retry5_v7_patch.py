#!/usr/bin/env python3
"""Update installed WA R3 five-attempt purchase wrapper with V7 fault triage.

Only modifies its existing marked function in Panel.py; never touches fiscal,
POS, ESP, item mapping, or the 150-second watchdog. Can be checked offline.
"""
from __future__ import annotations
import argparse,ast,datetime,os,shutil,tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
PANEL=HERE/'Panel.py'
START='# WA_R3_SINGLE_FLIGHT_V1_BEGIN'
END='# WA_R3_SINGLE_FLIGHT_V1_END'
OLD='# WA_R3_POSITION_RETRY5_GUARDED_V3'
NEW='# WA_R3_POSITION_RETRY5_FAULT_TRIAGE_V7'
HEADER='def _wa_r3_send_with_single_flight(self, position, payload, timeout_s=None):'
TAIL='\ndef _wa_r3_set_reopen_buttons(self, disabled):'


def replacement():
    from wa_r3_open_retry5_guarded_v3 import REPLACEMENT
    out=REPLACEMENT
    assert out.count(OLD)==1
    out=out.replace(OLD,NEW)
    out=out.replace('from wa_r3_purchase_recovery_safe_v1 import pre_retry_gate as _wa_r3_safe_gate',
                    'from wa_r3_purchase_recovery_v7 import pre_retry_gate as _wa_r3_safe_gate')
    assert out.count('from wa_r3_purchase_recovery_v7 import pre_retry_gate')==1
    out=out.replace('        attempts = 0\n', '        attempts = 0\n        blocked_reason = None\n',1)
    old='''                if not allowed:
                    print("[R3 RETRY5] stopped safely;", "panel=", pos, "item=", retry_id,
                          "reason=", reason)
                    break'''
    new='''                if not allowed:
                    blocked_reason = str(reason)
                    print("[R3 RETRY5 V7] stopped safely;", "panel=", pos, "item=", retry_id,
                          "reason=", reason)
                    break'''
    assert out.count(old)==1
    out=out.replace(old,new)
    old='''                    print("[R3 RETRY5] stopped: read-only controller readiness check refused;",
                          "panel=", pos, "item=", retry_id,
                          "reason=", status.get("error") if isinstance(status, dict) else "invalid reply")
                    break'''
    new='''                    blocked_reason = "ESP relay readiness not confirmed: " + (
                        str(status.get("error")) if isinstance(status, dict) else "invalid reply")
                    print("[R3 RETRY5 V7] stopped: ",blocked_reason,
                          "panel=", pos, "item=", retry_id)
                    break'''
    assert out.count(old)==1
    out=out.replace(old,new)
    # Keep durable paid exception + backend operator event on EVERY confirmed
    # unfulfilled pre-lock sale, but only disable physical ESP inventory once
    # ALL FIVE attempts definitively failed before the pulse.
    old='''            ack = _call({"type": "remote_update_item",
                         "item": {"id": retry_id, "enabled": False}}, 15.0)
            disabled = (isinstance(ack, dict) and
                        ack.get("type") == "remote_update_item_ack" and
                        ack.get("ok") is True and
                        isinstance(ack.get("item"), dict) and
                        ack["item"].get("enabled") is False)'''
    new='''            if attempts == max_attempts:
                ack = _call({"type": "remote_update_item",
                             "item": {"id": retry_id, "enabled": False}}, 15.0)
                disabled = (isinstance(ack, dict) and
                            ack.get("type") == "remote_update_item_ack" and
                            ack.get("ok") is True and
                            isinstance(ack.get("item"), dict) and
                            ack["item"].get("enabled") is False)
            else:
                disabled = False
                response["pi_recovery_blocked_reason"] = blocked_reason or "safety guard blocked further retries"
                print("[R3 RETRY5 V7] ended before five attempts; inventory NOT modified;",
                      "manual paid-order reconciliation required", "item=", retry_id)'''
    assert out.count(old)==1
    out=out.replace(old,new)
    anchor='''        is_matching_ack = isinstance(response, dict) and response.get("type") == expected'''
    audit='''        # V7: inspect fresh controller fault AND pending-cycle state for every
        # paid single-item revolver purchase after the final ESP reply.
        # READ ONLY; never use an after-pulse status to infer non-delivery.
        if paid_purchase and retry_id is not None and isinstance(response, dict):
            try:
                from wa_r3_purchase_recovery_v7 import purchase_triage as _wa_r3_purchase_triage
                triage = _wa_r3_purchase_triage(retry_id, response, attempts, blocked_reason)
                response["pi_purchase_triage_v7"] = triage
                if triage.get("requires_reconciliation"):
                    response["pi_delivery_needs_attention"] = True
                    print("[R3 RETRY5 V7] paid purchase needs reconciliation", triage)
                    sender = getattr(self, "backend_post_event_async", None)
                    if callable(sender):
                        sender("r3_purchase_status_needs_attention", severity="error",
                               payload={"panel_position": pos, "item_id": retry_id,
                                        "attempts": attempts,
                                        "invoice_number": str((payload or {}).get("invoice_number") or ""),
                                        "category": triage.get("category"),
                                        "global_fault": triage.get("global_fault"),
                                        "pending_wait_open_mask": triage.get("pending_wait_open_mask"),
                                        "pending_wait_close_mask": triage.get("pending_wait_close_mask"),
                                        "active_faults": triage.get("active_faults", []),
                                        "blocked_reason": blocked_reason or ""})
            except Exception as exc:
                print("[R3 RETRY5 V7] read-only purchase fault audit failed:", repr(exc))

'''
    assert out.count(anchor)==1
    out=out.replace(anchor,audit+anchor)
    ast.parse(out)
    return out


def transform(src):
    if src.count(START)!=1 or src.count(END)!=1:
        raise ValueError('Exactly one installed R3 single-flight block is required')
    first,last=src.index(START),src.index(END)
    block=src[first:last]
    if NEW in block: return src,'already_installed'
    if block.count(OLD)!=1 or block.count(HEADER)!=1 or block.count(TAIL)!=1:
        raise ValueError('V3 5-attempt function not found; do not patch unknown Panel.py')
    begin=src.index(HEADER,first,last)
    end=src.index(TAIL,begin,last)
    current=src[begin:end]
    for s in ('from wa_r3_purchase_recovery_safe_v1','[R3 RETRY5]','_wa_r3_inflight','remote_update_item'):
        if s not in current:raise ValueError('Installed purchase wrapper differs: missing '+s)
    updated=src[:begin]+replacement()+src[end:]
    ast.parse(updated, filename=str(PANEL))
    compile(updated,str(PANEL),'exec')
    return updated,'ready'


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    modes=p.add_mutually_exclusive_group(required=True)
    modes.add_argument('--check',action='store_true')
    modes.add_argument('--apply',action='store_true')
    modes.add_argument('--self-test',action='store_true')
    a=p.parse_args(argv)
    if a.self_test:
        rep=replacement()
        assert NEW in rep
        assert 'wa_r3_purchase_recovery_v7' in rep
        assert 'if attempts == max_attempts:' in rep
        assert 'pi_purchase_triage_v7' in rep
        print('PASS: V7 replacement AST/inspection helper/exhaustion/triage')
        return 0
    if not PANEL.is_file():p.error('Panel.py missing in current directory')
    if not (HERE/'wa_r3_purchase_recovery_v7.py').is_file():p.error('V7 purchase helper missing')
    updated,state=transform(PANEL.read_text(encoding='utf-8'))
    if state=='already_installed':print('ALREADY INSTALLED: V7 R3 purchase triage');return 0
    if a.check:
        print('PASS: V3 installed, V7 updated Panel.py parses/compiles')
        print('READ ONLY: no files changed, no motor/ESP commands sent')
        return 0
    backupdir=HERE/'wa_ui_patch_backups'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backupdir.mkdir(parents=True,exist_ok=False)
    backup=backupdir/'Panel.py'
    shutil.copy2(PANEL,backup)
    fd,tmp=tempfile.mkstemp(prefix='.Panel_v7_',suffix='.py',dir=str(HERE))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            f.write(updated);f.flush();os.fsync(f.fileno())
        shutil.copymode(PANEL,tmp)
        os.replace(tmp,PANEL)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    print('SUCCESS: Updated R3 paid purchase diagnostics and fault-aware 5-attempt wrapper')
    print('BACKUP:',backup)
    print('UNCHANGED: existing watchdog, POS, FURS, ESP, global-fault and pending-cycle safety interlocks')

if __name__=='__main__':
    raise SystemExit(main())
