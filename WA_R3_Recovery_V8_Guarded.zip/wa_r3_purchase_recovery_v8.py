#!/usr/bin/env python3
"""WA R3 V8 purchase-time controller-authorized fault recovery (existing authenticated protocol).

Called ONLY between confirmed final, pre-lock positioning failures by the
installed Panel.py single-flight wrapper. No automatic clearing of pending
customer access; no repeated lock pulse after an ambiguous/post-pulse result.
The 150-second watchdog's shared lock, shared recovery budget and lock are reused to prevent competing motor maintenance.
"""
from __future__ import annotations
import fcntl
import json
import os
import time
from pathlib import Path

import wa_r3_fault_watchdog_v8 as wd

ROOT=Path(__file__).resolve().parent
TRIAGE=ROOT/'wa_r3_purchase_triage_v8.jsonl'
ALL_CODES=frozenset(range(1,8))


def _row(d, motor):
    return wd.motor_map(d)[motor]


def _assess(d,motor):
    blocker=wd.safe_snapshot(d)
    if blocker:
        return False, blocker, None
    row=_row(d,motor)
    if row.get('fault_latched') is True:
        code=row.get('fault_reason')
        if type(code) is not int or code not in ALL_CODES:
            return False,'unrecognized motor fault; service required',None
        if row.get('enn_disabled_verified') is not True or row.get('step_output_active') is not False:
            return False,'faulted motor has no verified ENN-HIGH/STEP-off state',None
        if code in wd.EXTENDED_CODES:
            allowed,why=wd.extended_fault_telemetry_safe(d,motor,code)
            if not allowed:
                return False,'fault %d: %s'%(code,why),None
        return True,'R%d fault %d eligible for controlled recovery request'%(motor,code),('recover',code)
    if row.get('fault_latched') is not False or row.get('fault_reason') not in (0,None):
        return False,'fault status ambiguous',None
    if d.get('idle_enabled') is not True or row.get('step_output_active') is not True:
        return False,'motor idle running state not positively verified',None
    return True,'motor healthy and ready',('ready',0)


def pre_retry_gate(item):
    """Return (allowed, reason). Called after final pre-lock positioning-failure ACK.

    Important: caller must ensure no lock pulse occurred (an ESP positioning
    error is the sole accepted proof available on this firmware).
    """
    try:
        motor=7 if 5<=int(item)<=11 else 10 if 12<=int(item)<=21 else None
    except (ValueError,TypeError):
        motor=None
    if motor is None:return False,'invalid revolver item'
    with wd.LOCK.open('a+') as l:
        try:fcntl.flock(l.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return False,'watchdog or maintenance command in progress'
        try:
            ep=wd.endpoint()
            # Final ACK can precede network worker exit. Wait only for that
            # completed job to release ownership; never wait out a pending door.
            first=None
            for _ in range(8):
                first=wd.status(ep)
                if first.get('network_job_active') is False:break
                time.sleep(0.7)
            else:return False,'previous customer job still active'
            ok,why,state=_assess(first,motor)
            if not ok:return False,why
            if state==('ready',0):return True,'verified safe R%d normal idle'%motor
            code=state[1]
            # V8 never claims a new physical inspection for a fault. It may
            # issue one bounded attempt after controller/hardware verification;
            # an older ESP will refuse reasons 2/4/6/7 if inspection required.
            allowed,history,used=wd.limit_allowed(motor,first['boot_id'],time.time())
            if not allowed:return False,'R%d recovery limit 1/hour and 2/day'%motor
            time.sleep(0.6)
            second=wd.status(ep)
            if not wd.same_status(first,second,motor,code):
                return False,'fresh controller fault/door/boot status changed'
            # Reserve budget before UDP. A missing ACK means UNKNOWN outcome
            # and must never trigger an automatic resend.
            wd.consume_budget(motor,history,used,time.time())
            wd.stamp('PURCHASE_RECOVERY_REQUEST',motor=motor,fault_reason=code,
                     inspected_hardware=False,source='confirmed_pre_pulse_failure')
            ack=wd.rpc(ep,'remote_motor_recover',motor=motor,timeout=35.0,inspected=False)
            if ack.get('ok') is not True:
                return False,'ESP rejected motor recovery: '+str(ack.get('error') or 'unknown')
            for _ in range(8):
                time.sleep(1.2)
                post=wd.status(ep)
                if post.get('boot_id')!=first['boot_id']:
                    return False,'ESP rebooted during recovery'
                good,why,state=_assess(post,motor)
                if good and state==('ready',0):
                    row=_row(post,motor)
                    if (row.get('rotation_verified_after_recovery') is True and
                        row.get('recovery_verification')=='encoder_motion_verified'):
                        return True,'R%d fault %d cleared, encoder rotation verified'%(motor,code)
                if post.get('global_fault') is True or post.get('guard_latched') is True or \
                        post.get('pending_wait_open_mask') != 0 or post.get('pending_wait_close_mask') != 0:
                    return False,'new global/guard/pending lockout after recovery'
            return False,'recovery ACK received but rotation not verified'
        except Exception as exc:
            return False,'%s: %s'%(type(exc).__name__,str(exc)[:160])


def classify_purchase(reply, item):
    if not isinstance(reply,dict):return 'uncertain_ack'
    if reply.get('type') != 'remote_purchase_ack':return 'uncertain_ack'
    if reply.get('warning')=='at_least_one_revolver_door_never_opened; verify_delivery':
        return 'post_pulse_access_unconfirmed'
    res=reply.get('results')
    if isinstance(res,list):
        for x in res:
            if isinstance(x,dict) and x.get('access_unconfirmed') is True:
                return 'post_pulse_access_unconfirmed'
        if len(res)==1 and isinstance(res[0],dict) and res[0].get('ok') is False:
            if res[0].get('error') in ('revolver positioning failed','revolver_positioning_failed'):
                return 'confirmed_pre_pulse_position_failure'
        if reply.get('ok') is True:return 'esp_completed_ack'
        return 'other_final_failure_check_fulfilment'
    return 'no_final_item_result'


def purchase_triage(item, reply, attempts, blocked_reason=None, *, snapshot=None):
    """Read-only status audit after an R3 sale (success OR failed delivery).

    Return status for UI/logging; no motor, inventory, invoice or unlock command.
    """
    kind=classify_purchase(reply,item)
    result={'category':kind,'attempts':int(attempts),'item':int(item),
            'blocked_reason':str(blocked_reason or '')[:200],
            'requires_reconciliation':kind!='esp_completed_ack'}
    try:
        d=snapshot if snapshot is not None else wd.status(wd.endpoint())
        m=7 if 5<=int(item)<=11 else 10
        rows=wd.motor_map(d)
        result.update(boot_id=d.get('boot_id'),global_fault=d.get('global_fault'),
                      pending_wait_open_mask=d.get('pending_wait_open_mask'),
                      pending_wait_close_mask=d.get('pending_wait_close_mask'),
                      active_faults=[{'motor':x,'fault_reason':rows[x].get('fault_reason')}
                                    for x in (7,10) if rows[x].get('fault_latched') is True],
                      selected_motor=m,selected_door_cycle_pending=rows[m].get('door_cycle_pending'))
        if (result['global_fault'] is True or result['pending_wait_open_mask']!=0 or
            result['pending_wait_close_mask']!=0 or result['active_faults']):
            result['requires_reconciliation']=True
    except Exception as exc:
        result.update(status_unavailable=type(exc).__name__+': '+str(exc)[:120],
                      requires_reconciliation=True)
    try:
        fd=os.open(str(TRIAGE),os.O_CREAT|os.O_WRONLY|os.O_APPEND,0o600)
        with os.fdopen(fd,'a',encoding='utf-8') as f:
            f.write(json.dumps({'at':time.strftime('%Y-%m-%dT%H:%M:%S%z'),**result},sort_keys=True)+'\n')
            f.flush();os.fsync(f.fileno())
    except OSError:
        pass
    return result


def self_test():
    d={x:False for x in wd.BLOCK_FLAGS}
    d.update(position=1,boot_id=17,firmware='V4.9.72 R3 V8.3.7 V7HW AFTER_INSPECTION',
             idle_enabled=True,motor_hardware_ready=True,tmc_both_configured=True,
             pending_wait_open_mask=0,pending_wait_close_mask=0,
             motors=[dict(motor=i,door_closed_verified=True,door_cycle_pending=False,
                         step_output_active=True,fault_latched=False,fault_reason=0,
                         auto_recovery_budget_exhausted=False,encoder_valid=True)
                     for i in (7,10)])
    assert _assess(d,7)[2]==('ready',0)
    for x in (1,3,5):
        r=json.loads(json.dumps(d));r['motors'][0].update(fault_latched=True,fault_reason=x,
                          step_output_active=False,enn_disabled_verified=True)
        assert _assess(r,7)[2]==('recover',x)
    for x in (2,4,6,7):
        r=json.loads(json.dumps(d));r['motors'][0].update(fault_latched=True,fault_reason=x,
                          step_output_active=False,enn_disabled_verified=True,
                          tmc_drv_status=0x00110000,tmc_gstat=0,enn_readback_available=True,
                          enn_iodir_output=True,enn_olat_high=True,enn_gpio_high=True,
                          enn_readback_error=0)
        assert _assess(r,7)[2]==('recover',x),x
    for k in ('global_fault','guard_latched'):
        r=json.loads(json.dumps(d));r[k]=True;assert not _assess(r,7)[0]
    r=json.loads(json.dumps(d));r['pending_wait_open_mask']=1
    assert not _assess(r,7)[0]
    assert classify_purchase({'type':'remote_purchase_ack','warning':'at_least_one_revolver_door_never_opened; verify_delivery'},5)=='post_pulse_access_unconfirmed'
    assert classify_purchase({'type':'remote_purchase_ack','results':[{'id':5,'ok':False,'error':'revolver positioning failed'}]},5)=='confirmed_pre_pulse_position_failure'
    assert classify_purchase({'type':'remote_purchase_ack','ok':True,'results':[{'id':5,'ok':True}]},5)=='esp_completed_ack'
    print('PASS: all 7 fault classes recognized; pending and global blocked; ACK classification')
    print('PASS: existing recover command; no fake inspection, shared watchdog budget/lock')
    return 0

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument('--self-test',action='store_true')
    p.add_argument('--check',action='store_true')
    args=p.parse_args()
    if args.self_test:self_test()
    elif args.check:
        wd.endpoint();print('PASS: configured R3 authenticated endpoint can be loaded (no command sent)')
    else: p.print_help()
