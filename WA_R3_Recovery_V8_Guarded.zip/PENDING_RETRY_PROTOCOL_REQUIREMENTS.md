# Customer unfinished door cycle: minimum safe automation contract

The currently inspected V8.3.7 V7HW firmware exposes `remote_motor_clear_pending_cycle`, but **that command is attended maintenance**: it requires physical inspection, customer-access completion and no active order attestations, and it does not itself reopen the purchased compartment. Do not have a timer forge those attestations.

## Why a `door never opened` message alone is insufficient

The supplied ESP32 code can send `at_least_one_revolver_door_never_opened; verify_delivery` **after the relay pulse and inventory commit**. Therefore the product might already have been accessible, even if a door switch did not register the motion. A Pi resend may cause an unauthorized second opening, interfere with another purchase, or misstate the stock/paid-fulfillment record.

## Future idempotent transaction-specific firmware change

Before unattended pending recovery is permitted, the ESP should persistently correlate a unique Pi paid transaction/fulfilment ID to the actual motor, physical item, and lock-pulse state. An authenticated new **read-only** status or final ACK must distinguish `positioning_failed_before_lock_pulse` (safe to evaluate for retry), `lock_pulse_sent` (do **not** retry without new independent access proof), and `access_outcome_unknown` (do **not** retry). The ESP needs to atomically verify current boot, pending mask, selected door closed, both motor stop/ENN protections, lock outputs off, no active order, no other pending customer access and freshness/uniqueness of the attempt ID.

The controller, not the Pi, must enforce **at most one effective unlock per unique attempt** and reject stale/duplicate/out-of-order retries after a reboot. A retry permit must be one-use, bound to the exact paid transaction, and invalidated as soon as the physical lock output could have energized. Never replace a failed/unknown write ACK with a new opening request unless the controller can deduplicate it against durable attempt state.

For cases where an unlock pulse occurred but door-open feedback was not observed, that feedback alone is not proof of no access. Keep the cycle pending and route to the operator for paid-fulfillment reconciliation. Do not alter the original invoice or blindly replenish inventory.

**Current V8 Pi package deliberately does not implement unattended pending clear or post-pulse reopening.** The new ESP source/ACK would need to implement this protocol and be tested under real door-switch and communication-failure conditions.
