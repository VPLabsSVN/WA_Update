#!/usr/bin/env python3
"""WA R3 WATCHDOG V8: guarded controller-authorized recovery (no fake inspection).

Extends unattended *attempts* for latched faults 1..7 using authenticated
existing V8.3.x status, 2 matching snapshots, existing ESP recovery opcode,
closed-door/idle/global-fault guards and fault-specific readback checks.

Never claims physical inspection. Sends a normal remote_motor_recover request
with inspected_hardware OMITTED for 1..7 if user explicitly enables extended
mode. ESP remains authoritative and may reject
recovery for faults requiring inspected hardware; an ACK alone is not proof of
safe motion. Fault 4 may represent a mechanical jam, so attempts are strictly
rate limited, with no retry after ambiguous ACK. Do not use unattended
operation without supervised commissioning of your new firmware.

No automatic global-fault clear, pending-cycle clear, door pulse, payment,
refiscalization or inventory changes. Existing five-attempt purchase guard
is separate and unchanged. Attended inspection and pending clear are in wa_r3_v6_attended.py.
V8 unattended recovery does not use physical-inspection grants; the attended V6 tool is separate. 150s timer and existing kiosk heartbeat are reused.

Usage: --self-test | --check | --hook-status | --once [--auto-recover] |
       --policy-status. Existing idle-hook install/remove commands supported.
"""
from __future__ import annotations
import argparse
import fcntl
import json
import os
import re
import socket
import sys
import tempfile
import time
import uuid
from pathlib import Path

APP = Path(__file__).resolve().parent
BACKEND = APP / 'Panel_backend_merged.py'
CONFIG = APP / 'pi_recovery_endpoints.json'
HEARTBEAT = APP / 'wa_r3_kiosk_idle.json'
STATE = APP / 'wa_r3_watchdog_state.json'
LOCK = APP / 'wa_r3_watchdog.lock'
LOG = APP / 'wa_r3_watchdog.jsonl'
GRANT = APP / 'wa_r3_v6_inspection_grant.json'
GRANT_TTL_SECONDS = 240
START = '# WA_R3_IDLE_CERT_V1_BEGIN'
END = '# WA_R3_IDLE_CERT_V1_END'
ELIGIBLE_CODES = frozenset({1, 3, 5})
EXTENDED_CODES = frozenset({2, 4, 6, 7})
BLOCK_FLAGS = (
    'global_fault', 'unsafe_maintenance_stop', 'guard_latched',
    'guard_owner_conflict', 'network_job_active', 'network_job_stalled',
    'order_stall_latched', 'service_busy', 'service_stalled',
    'maintenance_busy', 'idle_worker_stalled',
)

# Written into the Kivy backend so the watchdog can prove idle state without
# guessing based on UI logs or just the ESP's hardware ownership flags.
HOOK = r'''# WA_R3_IDLE_CERT_V1_BEGIN
import json as _wa_r3_cert_json
import os as _wa_r3_cert_os
import tempfile as _wa_r3_cert_tempfile
import time as _wa_r3_cert_time
from kivy.core.window import Window as _wa_r3_cert_Window
_WA_R3_IDLE_CERT_PATH = _wa_r3_cert_os.path.join(_wa_r3_cert_os.path.dirname(__file__), 'wa_r3_kiosk_idle.json')
_WA_R3_IDLE_CERT_OLD_START = PanelBackendReservationApp.on_start
_WA_R3_IDLE_CERT_OLD_STOP = PanelBackendReservationApp.on_stop

def _wa_r3_cert_touch(self, window, touch):
    self._wa_r3_last_touch_time = _wa_r3_cert_time.time()
    return False

def _wa_r3_cert_write(self, dt):
    try:
        now = _wa_r3_cert_time.time()
        if not getattr(self, 'root', None):
            return
        base_mod = __import__('Panel')
        inflight = getattr(base_mod, '_wa_r3_inflight', {})
        remote_busy = bool(inflight) or bool(getattr(self, '_wa_r3_reopen_busy', False)) or bool(getattr(self, '_wa_r3_admin_worker_busy', False))
        checkout = bool(getattr(self, '_checkout_in_progress', True))
        admin_busy = bool(getattr(self, '_admin_door_pending_ids', set()))
        screen = str(self.root.current or '')
        last_touch = float(getattr(self, '_wa_r3_last_touch_time', now))
        last_purchase = float(getattr(self, '_wa_r3_last_purchase_time', now))
        info = {
            'version': 1, 'ts': now, 'pid': _wa_r3_cert_os.getpid(),
            'screen': screen, 'last_touch': last_touch,
            'last_purchase': last_purchase,
            'checkout_busy': checkout, 'remote_busy': remote_busy,
            'admin_door_busy': admin_busy,
        }
        parent = _wa_r3_cert_os.path.dirname(_WA_R3_IDLE_CERT_PATH)
        fd, temp = _wa_r3_cert_tempfile.mkstemp(prefix='.wa_r3_idle_', dir=parent)
        try:
            with _wa_r3_cert_os.fdopen(fd, 'w', encoding='utf-8') as out:
                _wa_r3_cert_json.dump(info, out, separators=(',', ':'))
                out.flush()
                _wa_r3_cert_os.fsync(out.fileno())
            _wa_r3_cert_os.chmod(temp, 0o600)
            _wa_r3_cert_os.replace(temp, _WA_R3_IDLE_CERT_PATH)
        finally:
            if _wa_r3_cert_os.path.exists(temp):
                _wa_r3_cert_os.unlink(temp)
    except Exception as exc:
        print('[R3 IDLE CERT] unable to write:', type(exc).__name__, str(exc)[:120])

def _wa_r3_cert_on_start(self):
    result = _WA_R3_IDLE_CERT_OLD_START(self)
    self._wa_r3_last_touch_time = _wa_r3_cert_time.time()
    self._wa_r3_last_purchase_time = _wa_r3_cert_time.time()
    try:
        _wa_r3_cert_Window.bind(on_touch_down=self._wa_r3_cert_touch)
        self._wa_r3_cert_event = Clock.schedule_interval(self._wa_r3_cert_write, 5.0)
        self._wa_r3_cert_write(0)
    except Exception as exc:
        print('[R3 IDLE CERT] startup warning:', repr(exc))
    return result

def _wa_r3_cert_on_stop(self):
    try:
        _wa_r3_cert_Window.unbind(on_touch_down=self._wa_r3_cert_touch)
        event = getattr(self, '_wa_r3_cert_event', None)
        if event is not None:
            event.cancel()
        _wa_r3_cert_os.unlink(_WA_R3_IDLE_CERT_PATH)
    except OSError:
        pass
    except Exception as exc:
        print('[R3 IDLE CERT] shutdown warning:', repr(exc))
    return _WA_R3_IDLE_CERT_OLD_STOP(self)

_WA_R3_IDLE_CERT_OLD_COMPLETE = PanelBackendReservationApp._complete_successful_purchase

def _wa_r3_cert_complete_purchase(self, *args, **kwargs):
    self._wa_r3_last_purchase_time = _wa_r3_cert_time.time()
    return _WA_R3_IDLE_CERT_OLD_COMPLETE(self, *args, **kwargs)

PanelBackendReservationApp._wa_r3_cert_touch = _wa_r3_cert_touch
PanelBackendReservationApp._wa_r3_cert_write = _wa_r3_cert_write
PanelBackendReservationApp.on_start = _wa_r3_cert_on_start
PanelBackendReservationApp.on_stop = _wa_r3_cert_on_stop
PanelBackendReservationApp._complete_successful_purchase = _wa_r3_cert_complete_purchase
# WA_R3_IDLE_CERT_V1_END
'''


def stamp(msg, **fields):
    line = {'at': time.strftime('%Y-%m-%dT%H:%M:%S%z'), 'event': msg, **fields}
    print('[R3 WATCHDOG]', json.dumps(line, ensure_ascii=True, sort_keys=True), flush=True)
    try:
        with LOG.open('a', encoding='utf-8') as log:
            log.write(json.dumps(line, ensure_ascii=True, sort_keys=True) + '\n')
    except OSError:
        pass


def endpoint():
    cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    ctrl = cfg['controllers']['r3']
    if ctrl.get('protocol') != 'r3_motor_recovery':
        raise ValueError('R3 endpoint protocol mismatch')
    if ctrl.get('ip') != '192.168.1.201':
        raise ValueError('Unexpected R3 IP (expected 192.168.1.201); refusing')
    if int(ctrl.get('port', 0)) != 48556:
        raise ValueError('Unexpected R3 port; refusing')
    token = ctrl['token']
    if not isinstance(token, str) or len(token) < 24:
        raise ValueError('Missing/invalid R3 token')
    return cfg['pi_ip'], ctrl['ip'], int(ctrl['port']), token


def rpc(ep, action, motor=None, timeout=12.0, *, inspected=False):
    source, dest, port, token = ep
    rid = 'r3wd-' + uuid.uuid4().hex
    payload = {'type': action, 'request_id': rid, 'token': token}
    if motor is not None:
        payload['motor'] = int(motor)
    if inspected:
        if action != 'remote_motor_recover' or motor not in (7,10):
            raise ValueError('Inspection flag allowed only for specified motor recovery')
        payload['inspected_hardware'] = True
    expect = 'remote_motor_ack' if action.startswith('remote_motor_') else 'recovery_ack'
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.bind((source, 0))
        sock.settimeout(timeout)
        sock.sendto(json.dumps(payload, separators=(',', ':')).encode('utf-8'), (dest, port))
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            sock.settimeout(max(0.05, deadline - time.monotonic()))
            raw, addr = sock.recvfrom(65535)
            if addr[0] != dest or addr[1] != port:
                continue
            try:
                data = json.loads(raw.decode('utf-8'))
            except (ValueError, UnicodeDecodeError):
                continue
            if isinstance(data, dict) and data.get('type') == expect and data.get('request_id') == rid:
                return data
    raise TimeoutError('R3 did not provide a correlated final ACK')


def status(ep):
    data = rpc(ep, 'remote_motor_status')
    if data.get('ok') is not True or not isinstance(data.get('motors'), list):
        raise ValueError('R3 motor status incomplete/refused')
    # V8.3.7 remote_motor_status intentionally omits firmware string.
    # Authenticated read-only remote_recovery_status adds that string.
    # Both statuses MUST come from the same firmware boot.
    ident = rpc(ep, 'remote_recovery_status')
    if (ident.get('ok') is not True or
            type(ident.get('firmware')) is not str or
            type(data.get('boot_id')) is not int or
            ident.get('boot_id') != data['boot_id']):
        raise ValueError('Firmware identity unavailable or controller rebooted')
    data['firmware'] = ident['firmware']
    return data


def kiosk_idle(path=HEARTBEAT, now=None):
    now = time.time() if now is None else now
    try:
        cert = json.loads(path.read_text(encoding='utf-8'))
    except (ValueError, OSError):
        return False, 'missing idle heartbeat'
    if cert.get('version') != 1:
        return False, 'unsupported idle heartbeat'
    if not isinstance(cert.get('ts'), (int, float)) or not 0 <= now - cert['ts'] <= 12.0:
        return False, 'stale/invalid kiosk heartbeat'
    pid = cert.get('pid')
    if type(pid) is not int or pid < 2 or not Path('/proc', str(pid)).exists():
        return False, 'kiosk process not alive'
    if cert.get('screen') != 'menu':
        return False, 'kiosk not on customer Home'
    if any(cert.get(k) is not False for k in ('checkout_busy', 'remote_busy', 'admin_door_busy')):
        return False, 'checkout/remote/admin operation not proven idle'
    if not isinstance(cert.get('last_touch'), (int, float)) or now - cert['last_touch'] < 180.0:
        return False, 'recent touchscreen interaction'
    if not isinstance(cert.get('last_purchase'), (int, float)) or now - cert['last_purchase'] < 600.0:
        return False, 'recent paid transaction'
    return True, 'kiosk Home idle >180s and no paid purchase for >600s'


def motor_map(d):
    motors = d.get('motors')
    if not isinstance(motors, list):
        raise ValueError('Missing motors')
    lookup = {m.get('motor'): m for m in motors if isinstance(m, dict)}
    if set(lookup) != {7, 10}:
        raise ValueError('Missing R7/R10 status rows')
    return lookup


def safe_snapshot(d):
    if type(d.get('boot_id')) is not int:
        return 'missing boot_id'
    if d.get('position') not in (None, 1):
        return 'unexpected R3 position'
    fw = str(d.get('firmware') or '')
    # Accept version progression while refusing missing/unknown identities.
    # The verified, authenticated status contract must still match every field.
    versions = re.findall(r'\bV(\d+)\.(\d+)(?:\.(\d+))?\b', fw)
    if not any((int(a),int(b),int(c or 0)) >= (8,3,7) for a,b,c in versions):
        return 'firmware not confirmed V8.3.7+; monitoring only'
    for key in BLOCK_FLAGS:
        if d.get(key) is not False:
            return f'{key} not explicitly false'
    for key in ('pending_wait_open_mask', 'pending_wait_close_mask'):
        if d.get(key) != 0:
            return f'{key} pending/unknown'
    if d.get('motor_hardware_ready') is not True:
        return 'motor_hardware_ready not true'
    mm = motor_map(d)
    for motor, m in mm.items():
        if m.get('door_closed_verified') is not True or m.get('door_cycle_pending') is not False:
            return f'R{motor} door/pending cannot be verified safe'
        if m.get('auto_recovery_budget_exhausted') is not False:
            return f'R{motor} firmware recovery budget not confirmed available'
    return None


def extended_fault_telemetry_safe(d, motor, reason):
    """Existing fields, NO proposed capability bits and NO invented inspection.

    This is only preflight eligibility to REQUEST a recovery. The ESP can
    refuse it; current old V8.3.7 refuses faults 2/4/6/7 without inspection.
    Status cannot prove absence of a hidden mechanical obstruction (fault 4).
    """
    if type(reason) is not int or reason not in EXTENDED_CODES:
        return False, 'not an extended fault'
    try:
        row = motor_map(d)[motor]
    except (ValueError, KeyError):
        return False, 'missing verified motor row'
    # These must be true in current, authenticated controller telemetry.
    if d.get('tmc_both_configured') is not True:
        return False, 'TMC configuration is not verified'
    if row.get('encoder_valid') is not True:
        return False, 'AS5600 encoder not verified healthy'
    if row.get('enn_disabled_verified') is not True or row.get('step_output_active') is not False:
        return False, 'motor must be provably ENN disabled and STEP stopped'
    if row.get('door_closed_verified') is not True or row.get('door_cycle_pending') is not False:
        return False, 'door closed and no pending access must be verified'
    if reason == 2:
        # A historical disable failure can clear only after real ENN HIGH proof.
        if not all(row.get(k) is True for k in
                   ('enn_readback_available', 'enn_iodir_output',
                    'enn_olat_high', 'enn_gpio_high')) or row.get('enn_readback_error') != 0:
            return False, 'fault 2: ENN direction/latch/physical readback not verified high'
    if reason in (4, 6, 7):
        # Confirm live driver electrical safety; never treat a diagnostic
        # communication failure as a cleared electrical condition.
        drv, gs = row.get('tmc_drv_status'), row.get('tmc_gstat')
        if type(drv) is not int or type(gs) is not int:
            return False, f'fault {reason}: TMC DRV_STATUS/GSTAT missing'
        if drv & 0x3F or gs & 0x6:
            return False, f'fault {reason}: live electrical fault still present'
    if reason == 4:
        return True, 'single bounded stall-recovery request; ESP must reject if obstruction persists'
    if reason == 6:
        return True, 'STEP/PWM recovery requested; controller preflight remains authoritative'
    if reason == 7:
        return True, 'TMC live electrical fault bits clear; controller must recheck'
    return True, 'ENN disable readback independently verified'


def fault_review(d):
    """Report every fault including those intentionally blocked from actuation."""
    result=[]
    try:
        rows=motor_map(d)
    except ValueError:
        return [{'problem':'motor status incomplete'}]
    for motor in (7,10):
        m=rows[motor]
        if m.get('fault_latched') is not True:
            continue
        code=m.get('fault_reason')
        if code in EXTENDED_CODES:
            allowed,why=extended_fault_telemetry_safe(d,motor,code)
        elif code in ELIGIBLE_CODES:
            allowed,why=True,'legacy guarded software fault'
        else:
            allowed,why=False,'unknown fault'
        result.append({'motor':motor,'reason':code,'telemetry_eligible':allowed,'explanation':why})
    for mask,kind in (('pending_wait_open_mask','wait_open'),('pending_wait_close_mask','wait_close')):
        value=d.get(mask)
        if type(value) is int and value:
            result.append({'kind':kind,'mask':value,'action':'report_only_customer_reconciliation_required'})
    return result


def candidates(d):
    unsafe = safe_snapshot(d)
    if unsafe:
        return [], unsafe
    mm = motor_map(d)
    found = []
    for motor in (7,10):
        row = mm[motor]
        if row.get('fault_latched') is not True:
            continue
        reason = row.get('fault_reason')
        if type(reason) is not int:
            continue
        eligible = reason in ELIGIBLE_CODES
        if reason in EXTENDED_CODES:
            eligible = extended_fault_telemetry_safe(d,motor,reason)[0]
        if eligible and row.get('enn_disabled_verified') is True and row.get('step_output_active') is False:
            found.append((motor, reason))
    return found, None


def same_status(a,b,motor,reason):
    if a.get('boot_id') != b.get('boot_id'):
        return False
    if safe_snapshot(a) or safe_snapshot(b):
        return False
    ma, mb = motor_map(a)[motor], motor_map(b)[motor]
    return (all(ma.get(k) == mb.get(k) for k in
               ('fault_latched','fault_reason','door_closed_verified','door_cycle_pending',
                'enn_disabled_verified','step_output_active')) and
            mb.get('fault_latched') is True and mb.get('fault_reason') == reason and
            mb.get('enn_disabled_verified') is True and mb.get('step_output_active') is False and
            (reason in ELIGIBLE_CODES or
             (extended_fault_telemetry_safe(a,motor,reason)[0] and
              extended_fault_telemetry_safe(b,motor,reason)[0])))


def limit_allowed(motor, boot_id, now):
    try:
        st = json.loads(STATE.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        st = {}
    history = st.get(str(motor), [])
    if not isinstance(history,list):history=[]
    # Retry budget is shared across reboots: no repeated fault-clearing loops.
    history = [v for v in history if isinstance(v, (int,float)) and 0 <= now - v < 86400]
    recent = [v for v in history if now - v < 3600]
    return len(recent) < 1 and len(history) < 2, st, history


def consume_budget(motor, st, history, now):
    st[str(motor)] = history + [now]
    fd,tmp = tempfile.mkstemp(prefix='.wa_r3_budget_',dir=str(APP))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(st,f)
            f.flush();os.fsync(f.fileno())
        os.chmod(tmp, 0o600)
        os.replace(tmp, STATE)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def stop_anchor(d, motor, now=None):
    """Approximate current STOP event from existing monotonic status age.

    This is an additional same-event check, not a hardware safety proof.
    Refuse when age is missing or the current stop reason is active motion.
    """
    now = time.time() if now is None else now
    row = motor_map(d)[motor]
    age = row.get('stop_reason_age_s')
    code = row.get('stop_reason_code')
    if type(code) is not int or type(age) not in (int, float) or not 0 <= age <= 31_536_000:
        return None
    if row.get('step_output_active') is not False:
        return None
    return {'code':code, 'epoch':now - float(age)}


def inspection_grant(d, motor, reason, *, now=None, path=None):
    """Use only a time-limited, single-use grant bound to the CURRENT fault.

    A past commissioning inspection is NOT a valid grant for a future fault.
    No grant means no unattended inspected recovery for reasons 2/4/6/7.
    """
    now = time.time() if now is None else now
    if path is None:
        path = GRANT
    if reason not in EXTENDED_CODES:
        return None, 'no inspection required by V6 for software faults'
    try:
        info = path.stat()
        if info.st_uid != os.getuid() or (info.st_mode & 0o077):
            return None, 'inspection grant file ownership/permissions invalid'
        g = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None, 'no valid recent physical inspection of this current fault'
    if type(g) is not dict or g.get('version') != 6 or g.get('inspected_current_fault') is not True:
        return None, 'inspection grant format invalid'
    if (g.get('motor') != motor or g.get('fault_reason') != reason or
            g.get('boot_id') != d.get('boot_id') or
            g.get('firmware') != d.get('firmware')):
        return None, 'inspection grant belongs to a different controller/fault'
    if not isinstance(g.get('grant_id'), str) or len(g['grant_id']) < 20:
        return None, 'missing grant ID'
    ts, expiry = g.get('issued_at'), g.get('expires_at')
    if (type(ts) not in (int,float) or type(expiry) not in (int,float) or
            ts > now or now >= expiry or expiry - ts > GRANT_TTL_SECONDS):
        return None, 'inspection grant expired or timing invalid'
    if not isinstance(g.get('note'), str) or len(g['note'].strip()) < 20:
        return None, 'inspection note missing'
    anchor = stop_anchor(d, motor, now)
    recorded = g.get('stop_anchor')
    if (anchor is None or not isinstance(recorded, dict) or
            recorded.get('code') != anchor['code'] or
            type(recorded.get('epoch')) not in (int,float) or
            abs(recorded['epoch'] - anchor['epoch']) > 6):
        return None, 'stop event changed or is unverified'
    return g, 'recent single-use inspection of current fault verified'


def consume_inspection_grant(g, path=None):
    """Mark grant as used BEFORE command. A lost ACK must not reuse it."""
    if path is None:
        path = GRANT
    existing = json.loads(path.read_text(encoding='utf-8'))
    if existing.get('grant_id') != g.get('grant_id'):
        raise ValueError('Inspection grant changed before use')
    os.unlink(path)
    stamp('INSPECTION_GRANT_CONSUMED', grant_id=g['grant_id'],
          motor=g['motor'],fault_reason=g['fault_reason'],
          note='single-use grant removed before motor command; no retries')


def once(auto=False, extended_auto=False):
    # flock stops overlapping timers, operator sessions of this watchdog, etc.
    with LOCK.open('a+') as lck:
        try:
            fcntl.flock(lck.fileno(),fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            stamp('SKIP',reason='another watchdog instance already running')
            return 2
        try:
            ep = endpoint()
            d = status(ep)
            safe_list, reason = candidates(d)
            stamp('STATUS', firmware=d.get('firmware'), boot_id=d.get('boot_id'),
                  global_fault=d.get('global_fault'), safe_software_faults=safe_list,
                  blocked=reason, pending=[d.get('pending_wait_open_mask'),d.get('pending_wait_close_mask')],
                  motor_faults=fault_review(d),
                  pending_policy='operator_only_customer_access_evidence_required',
                  extended_policy='existing_controller_preflight_without_inspection_attestation',
                  encoder_bus_errors=d.get('encoder_bus_errors'),
                  mutex_timeout_count=d.get('mutex_timeout_count'),
                  guard_latched=d.get('guard_latched'))
            if reason:
                return 0
            if not safe_list:
                return 0
            idle, idle_reason = kiosk_idle()
            if not idle:
                stamp('SKIP', reason=idle_reason)
                return 0
            if not auto:
                stamp('DRY_RUN', candidate=safe_list, reason='no --auto-recover; no commands sent')
                return 0
            # V8 can be staged before ESP upgrade: codes 1/3/5 remain
            # active, but 2/4/6/7 require separate explicit Pi opt-in AFTER
            # supervised commissioning of the newer controller firmware.
            active_list = [item for item in safe_list
                           if item[1] in ELIGIBLE_CODES or extended_auto]
            # V8: Codes 2/4/6/7 may be attempted like 1/3/5 using the
            # EXISTING command, but ONLY after verified telemetry and two
            # matching preflight snapshots. Never fabricate inspection.
            if not active_list:
                stamp('SKIP',reason='no eligible fault under current policy')
                return 0
            motor, fault_reason = active_list[0]  # one motor maximum per cycle
            permitted, st, history = limit_allowed(motor,d['boot_id'],time.time())
            if not permitted:
                stamp('SKIP',motor=motor,reason='per-motor cooldown 1/hour, 2/day')
                return 0
            time.sleep(0.6)
            idle2,why2 = kiosk_idle()
            if not idle2:
                stamp('SKIP',reason='kiosk became active: '+why2)
                return 0
            fresh = status(ep)
            if not same_status(d,fresh,motor,fault_reason):
                stamp('SKIP',reason='ESP changed across two verified snapshots',motor=motor)
                return 0
            # No inspection grant used or claimed. The ESP must perform all
            # live preflight checks and is free to refuse the operation.
            # Consume the attempt budget BEFORE UDP. A lost ACK must not
            # trigger a duplicate recovery command.
            consume_budget(motor,st,history,time.time())
            stamp('RECOVERY_ATTEMPT', motor=motor, fault_reason=fault_reason,
                  action='remote_motor_recover', inspected_hardware=False,
                  note='No inspection attestation. Controller must authorize safe recovery.')
            ack = rpc(ep, 'remote_motor_recover', motor=motor, timeout=35.0,
                      inspected=False)
            stamp('RECOVERY_ACK',motor=motor,ok=ack.get('ok'),error=ack.get('error'),
                  boot_id=ack.get('boot_id'))
            if ack.get('ok') is True:
                post = status(ep)
                row = motor_map(post)[motor]
                stamp('POST_STATUS',motor=motor,global_fault=post.get('global_fault'),
                      fault_latched=row.get('fault_latched'),fault_reason=row.get('fault_reason'),
                      recovery_verification=row.get('recovery_verification'),
                      rotation_verified_after_recovery=row.get('rotation_verified_after_recovery'),
                      note='final controller ACK does not establish physical access')
            return 0
        except Exception as exc:
            stamp('ERROR',kind=type(exc).__name__,details=str(exc)[:260],
                  warning='Outcome may be unknown; no automatic resend')
            return 3


def hook_transform(src, install=True):
    if install:
        if START in src and END in src:return src, 'already_installed'
        if START in src or END in src:raise ValueError('partial hook markers: refuse')
        if 'class PanelBackendReservationApp' not in src:
            raise ValueError('expected backend app class not found')
        if 'def _complete_successful_purchase' not in src:
            raise ValueError('purchase snapshot hook missing')
        hits = list(re.finditer(r'(?m)^if __name__\s*==\s*[\'\"]__main__[\'\"]\s*:', src))
        if not hits:raise ValueError('Cannot locate application entrypoint')
        at=hits[-1].start()
        result=src[:at] + HOOK + '\n' + src[at:]
        compile(result,str(BACKEND),'exec')
        return result,'ready'
    if src.count(START)!=1 or src.count(END)!=1:
        raise ValueError('Idle hook not found or corrupt')
    i=src.index(START);j=src.index(END,i)+len(END)
    result=src[:i]+src[j:]
    compile(result,str(BACKEND),'exec')
    return result,'ready'


def edit_hook(install=True,dry=True):
    src=BACKEND.read_text(encoding='utf-8')
    newer,state=hook_transform(src,install=install)
    if state=='already_installed':
        print('ALREADY INSTALLED: kiosk idle heartbeat hook')
        return
    print('PASS: proposed backend parses and compiles; no POS/FURS/motor code edited')
    if dry:return
    backup_dir=APP/'wa_ui_patch_backups'/(time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
    backup_dir.mkdir(parents=True,exist_ok=True)
    import shutil
    shutil.copy2(BACKEND,backup_dir/'Panel_backend_merged.py')
    fd,temp=tempfile.mkstemp(prefix='.Panel_backend_idle_',dir=str(APP))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            f.write(newer);f.flush();os.fsync(f.fileno())
        os.chmod(temp,BACKEND.stat().st_mode & 0o777)
        os.replace(temp,BACKEND)
    finally:
        if os.path.exists(temp):os.unlink(temp)
    print('SUCCESS:', 'installed' if install else 'removed','kiosk idle heartbeat hook')
    print('BACKUP:',backup_dir/'Panel_backend_merged.py')


def self_test():
    import copy
    def sample(code):
        d={k:False for k in BLOCK_FLAGS}
        d.update(boot_id=42, firmware='V4.9.72 R3 V8.3.7 V7HW AFTER_INSPECTION',
          position=1,pending_wait_open_mask=0,pending_wait_close_mask=0,
          motor_hardware_ready=True,tmc_both_configured=True,
          motors=[{'motor':n, 'door_closed_verified':True,'door_cycle_pending':False,
            'fault_latched':n==7,'fault_reason':code if n==7 else 0,
            'enn_disabled_verified':True,'step_output_active':False,
            'auto_recovery_budget_exhausted':False,'encoder_valid':True,
            'enn_readback_available':True,'enn_iodir_output':True,
            'enn_olat_high':True,'enn_gpio_high':True,'enn_readback_error':0,
            'tmc_drv_status':0x110000,'tmc_gstat':1} for n in (7,10)])
        return d
    for reason in (1,2,3,4,5,6,7):
        d=sample(reason)
        assert candidates(d)[0]==[(7,reason)],(reason,candidates(d))
        assert same_status(d,copy.deepcopy(d),7,reason),reason
        for key in BLOCK_FLAGS:
            b=copy.deepcopy(d);b[key]=True
            assert candidates(b)[0]==[],(reason,key)
        for key in ('pending_wait_open_mask','pending_wait_close_mask'):
            b=copy.deepcopy(d);b[key]=1
            assert candidates(b)[0]==[],(reason,key)
        for key,value in [('door_closed_verified',False),('door_cycle_pending',True),
                          ('enn_disabled_verified',False),('step_output_active',True),
                          ('auto_recovery_budget_exhausted',True)]:
            b=copy.deepcopy(d);b['motors'][0][key]=value
            assert candidates(b)[0]==[],(reason,key)
        if reason in EXTENDED_CODES:
            for key,value in [('encoder_valid',False),('tmc_both_configured',False)]:
                b=copy.deepcopy(d)
                if key=='tmc_both_configured':b[key]=value
                else:b['motors'][0][key]=value
                assert candidates(b)[0]==[],(reason,key)
        if reason == 2:
            for key in ('enn_readback_available','enn_iodir_output','enn_olat_high','enn_gpio_high'):
                b=copy.deepcopy(d);b['motors'][0][key]=False
                assert candidates(b)[0]==[],key
        if reason in (4,6,7):
            for key,value in [('tmc_drv_status',None),('tmc_drv_status',0x1),
                              ('tmc_gstat',0x2),('tmc_gstat',None)]:
                b=copy.deepcopy(d);b['motors'][0][key]=value
                assert candidates(b)[0]==[],(reason,key,value)
        b=copy.deepcopy(d);b['boot_id']=43
        assert not same_status(d,b,7,reason)
    for reason in (0,8,99):
        assert candidates(sample(reason))[0]==[]
    # No proposed authorization bits are ever needed.
    d=sample(4)
    assert 'unattended_recovery_authorized' not in d['motors'][0]
    assert candidates(d)[0]==[(7,4)]
    # Never invoke the prior operator-grant code from the unattended path.
    import inspect
    body = inspect.getsource(once)
    assert 'inspection_grant(' not in body
    assert 'consume_inspection_grant(' not in body
    assert "inspected=False" in body
    assert "remote_motor_clear_pending_cycle" not in body
    assert "remote_motor_clear_global" not in body
    print('PASS: all seven faults evaluated with ENN/TMC/door/ownership checks')
    print('PASS: automatic path never claims inspection or clears pending/global')


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    opt=ap.add_mutually_exclusive_group(required=True)
    for o in ('check','install-idle-hook','hook-status','remove-idle-hook','once','loop','contract-status','policy-status','self-test'):
        opt.add_argument('--'+o,action='store_true')
    ap.add_argument('--auto-recover',action='store_true',help='send guarded recovery for 1/3/5')
    ap.add_argument('--extended-auto',action='store_true',help='Try 2/4/6/7 without false inspection attestation, subject to all status/hardware checks and ESP authorization')
    args=ap.parse_args(argv)
    if args.auto_recover and not (args.once or args.loop):ap.error('--auto-recover only with --once or --loop')
    if args.extended_auto and not args.auto_recover:ap.error('--extended-auto requires --auto-recover')
    if args.self_test:return self_test()
    if args.check:
        print('CONFIG:',CONFIG.exists(),'APP:',APP,'BACKEND:',BACKEND.exists())
        try:
            ep=endpoint()
            print('PASS: local authenticated R3 config parsed, target=',ep[1],':',ep[2])
        except Exception as exc:
            print('WARN: R3 config:',str(exc))
        if BACKEND.exists():edit_hook(install=True,dry=True)
        print('No commands sent and no files changed')
        return 0
    if args.hook_status:
        src=BACKEND.read_text(encoding='utf-8')
        print('HOOK:', 'installed' if START in src and END in src else 'not installed')
        print('HEARTBEAT:', kiosk_idle()[1])
        return 0
    if args.install_idle_hook:return edit_hook(install=True,dry=False)
    if args.remove_idle_hook:return edit_hook(install=False,dry=False)
    if args.contract_status or args.policy_status:
        try:
            d=status(endpoint())
            eligible, blocker=candidates(d)
            overview={
                'firmware':d.get('firmware'),'boot_id':d.get('boot_id'),
                'global_fault':d.get('global_fault'),
                'pending_masks':[d.get('pending_wait_open_mask'),d.get('pending_wait_close_mask')],
                'telemetry_candidates':eligible,
                'inspection_grant_required_for_extended':False,
                'inspection_grant_present':GRANT.is_file(), # attended path only
                'blocked':blocker,
                'faults':fault_review(d),
                'policy':'faults 1/3/5 guarded unattended; 2/4/6/7 gated by --extended-auto, ENN/door/driver proof and controller acceptance (no inspection claim)',
                'excluded':'global faults, pending customer cycle, unclear hardware, purchases/door pulses',
                'encoder_bus_errors':d.get('encoder_bus_errors'),
                'mutex_timeout_count':d.get('mutex_timeout_count'),
                'note':'READ ONLY; no recovery command transmitted',
            }
            print(json.dumps(overview,indent=2,sort_keys=True))
            return 0
        except Exception as e:
            print('POLICY STATUS UNAVAILABLE:',type(e).__name__,str(e)[:240])
            return 3
    if args.once:return once(args.auto_recover,args.extended_auto)
    if args.loop:
        stamp('START',interval_seconds=150,automatic_recovery=args.auto_recover,
              extended_auto=args.extended_auto,
              excluded='global faults, door-cycle pending, unverifiable hardware, payment, item disabling')
        while True:
            once(args.auto_recover,args.extended_auto)
            time.sleep(150)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
