# WA R3 V8: Guarded motor recovery for codes 1–7

## Scope and known limitation

V8 expands the **Pi-side eligibility** for motor fault codes 2, 4, 6, 7 to match codes 1, 3, 5, using the existing authenticated `remote_motor_recover` command with no new per-fault fields. It **does not** send `inspected_hardware=true` automatically. The firmware remains authoritative and **may reject** the recovery request; the supplied V8.3.7 firmware requires inspection for codes 2/4/6/7. The newer firmware has not been supplied, so acceptance on it is unverified. V8 does not and cannot clear all actual hardware/electrical failures merely by resetting flags.

V8 retains the 150s timer, existing kiosk idle heartbeat, same-boot fresh double-status checks, both door-closed checks, motor disable/STEP validation, controller ownership guards, TMC checks, per-motor maximum one automatic recovery request per hour and two per day. No retries after ambiguous controller acknowledgment.

It keeps the **five total purchase opening attempts** for confirmed pre-lock positioning failures only, and the original paid-fulfilment exception/availability notification behavior. Codes 2/4/6/7 are now eligible for one bounded **purchase-time** recovery request without a Pi inspection grant, provided all controller-readback checks pass. ESP refusal stops the attempt.

### Unfinished customer door cycle

The existing V8.3.7 firmware's `at_least_one_revolver_door_never_opened` warning is emitted **after the relay may have pulsed** and after inventory may already be decremented. It does **not** prove non-delivery. `remote_motor_clear_pending_cycle` in the supplied firmware is operator-only and requires `inspected_hardware`, `customer_access_finished_confirmed`, `no_active_customer_transaction_confirmed`, a specific inspection note, and the exact `boot_id`/pending masks. Pi does not have evidence to truthfully make these attestations automatically. Therefore V8 **detects and reports** pending masks and blocks re-opening after an uncertain post-pulse result. Do not automate false attestations.

To permit safe **unattended** pending recovery with the future firmware, implement a transaction-specific, controller-validated, idempotent retry handshake which verifies the same paid order, whether the lock output was actually pulsed, door open/close state, ownership and absence of another pending fulfilment. It must not issue a second unlock when the first one may have happened. This functionality is **not in this ZIP**.

## Files

- `wa_r3_fault_watchdog_v8.py`: status and watchdog (extends V6, no false grants).
- `wa_r3_purchase_recovery_v8.py`: guarded purchase-time motor recovery and triage.
- `wa_r3_purchase_retry5_v8_patch.py`: updates verified V3/V7 installed purchase wrapper in `Panel.py`; backup created.
- `wa_r3_open_retry5_guarded_v3.py`, `wa_r3_purchase_retry5_v7_patch.py`: exact inspected earlier patch dependencies.
- `wa_r3_v8_activate.sh`: timer service activation, staged or expanded, and rollback.
- `test_wa_r3_v8_sim.py`: offline simulation; no ESP access.

## Pi installation

Copy/unzip all files into `/home/wa_stopshop_mb/WA/Main_program/Fis`.

```
cd /home/wa_stopshop_mb/WA/Main_program/Fis
./venv/bin/python wa_r3_fault_watchdog_v8.py --self-test
./venv/bin/python wa_r3_purchase_recovery_v8.py --self-test
./venv/bin/python wa_r3_purchase_retry5_v8_patch.py --self-test
./venv/bin/python test_wa_r3_v8_sim.py
./venv/bin/python wa_r3_fault_watchdog_v8.py --check
./venv/bin/python wa_r3_purchase_retry5_v8_patch.py --check
```

Apply the purchase patch **only when kiosk has no active payment or access**:

```
systemctl --user stop bouquetmat.service
./venv/bin/python wa_r3_purchase_retry5_v8_patch.py --apply
systemctl --user start bouquetmat.service
systemctl --user is-active bouquetmat.service
```

Stage watchdog with 1/3/5 enabled, 2/4/6/7 detected:

```
bash ./wa_r3_v8_activate.sh --stage
```

**After** flashing, commissioning and verifying the new ESP32, explicitly enable attempts for 2/4/6/7:

```
./venv/bin/python wa_r3_fault_watchdog_v8.py --policy-status
bash ./wa_r3_v8_activate.sh --enable-extended
```

Enable-extended refuses the known old V8.3.7 firmware. A newer firmware identifier is not confirmation of acceptance or electrical safety: supervise tests and check readbacks.

## Observe/rollback

```
systemctl --user list-timers --all wa-r3-watchdog.timer
journalctl --user -u wa-r3-watchdog.service --since '30 minutes ago' --no-pager -l | tail -80
journalctl --user -u bouquetmat.service --since '60 minutes ago' --no-pager -l | grep -E 'R3 RETRY5|R3 PURCHASE RECOVERY|R3 SINGLE FLIGHT' | tail -80
```

Rollback watchdog: `bash ./wa_r3_v8_activate.sh --rollback`. Purchase wrapper backups are under `wa_ui_patch_backups/YYYYMMDD_HHMMSS.../Panel.py`. Restore **only while kiosk is idle/stopped**, preserving the currently installed compatible backend sources. No fiscalization, POS, ESP firmware or tax/invoice files are edited in this package.
