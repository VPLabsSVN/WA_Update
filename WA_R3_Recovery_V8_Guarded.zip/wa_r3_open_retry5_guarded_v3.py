#!/usr/bin/env python3
"""Upgrade installed WA R3 single-flight retry V2 to transaction-aware V3.

--check / --apply / --status; modifies only the existing R3 send wrapper in
Panel.py, preserving ESP, kiosk billing, FURS, all other screen handling.
V3 adds up to 5 purchase attempts (3 for Admin/reopen), gated by authenticated
read-only status and optional guarded software recovery for fault 1/3/5.
If EVERY attempted purchase ended before lock pulse, records a durable paid
fulfilment exception and marks that item unavailable through ESP remote_update_item.
Never retries post-pulse/open-unconfirmed outcomes, never clears customer cycles
or global fault, never claims motor physical inspection.
"""
from __future__ import annotations
import argparse, ast, datetime, os, re, shutil, tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
PANEL = HERE / 'Panel.py'
HELPER = HERE / 'wa_r3_purchase_recovery_safe_v1.py'
START = '# WA_R3_SINGLE_FLIGHT_V1_BEGIN'
END = '# WA_R3_SINGLE_FLIGHT_V1_END'
MARK_OLD = '# WA_R3_POSITION_RETRY3_V2'
MARK_NEW = '# WA_R3_POSITION_RETRY5_GUARDED_V3'
HEADER = 'def _wa_r3_send_with_single_flight(self, position, payload, timeout_s=None):'
TAIL = '\ndef _wa_r3_set_reopen_buttons(self, disabled):'
REPLACEMENT = r'''def _wa_r3_send_with_single_flight(self, position, payload, timeout_s=None):
    # WA_R3_POSITION_RETRY5_GUARDED_V3
    # Five TOTAL purchase attempts; reopen/admin remain at 3. Exact pre-pulse
    # positioning failure only. All other responses retain V1 behavior.
    action = str((payload or {}).get("type", ""))
    pos = int(position)
    if action not in _wa_r3_types or not _wa_r3_is_panel(self, pos):
        if timeout_s is None:
            return _wa_r3_original_send(self, position, payload)
        return _wa_r3_original_send(self, position, payload, timeout_s=timeout_s)

    key = _wa_r3_key(self, pos)
    with _wa_r3_mutex:
        if key in _wa_r3_inflight:
            print("[R3 SINGLE FLIGHT] ignored duplicate", pos, action,
                  "existing=", _wa_r3_inflight[key]["action"])
            return {"ok": False, "suppressed": True,
                    "error": "r3_open_already_in_progress_no_command_sent"}
        _wa_r3_inflight[key] = {"action": action, "uncertain": False}

    try:
        import time as _wa_r3_retry_time
        items = (payload or {}).get("items") or []
        minimum = 300.0 if len(items) <= 1 else min(1200.0, 300.0 * len(items))
        requested = float(timeout_s) if timeout_s is not None else 0.0
        deadline_seconds = max(minimum, requested)
        expected = _wa_r3_ack_names[action]
        retry_id = None
        if len(items) == 1:
            try:
                candidate = items[0]
                retry_id = int(candidate.get("id") if isinstance(candidate, dict) else candidate)
                if retry_id < 5 or retry_id > 21:
                    retry_id = None
            except (TypeError, ValueError, AttributeError):
                retry_id = None

        def _call(command, seconds):
            try:
                return _wa_r3_original_send(self, pos, command, timeout_s=seconds)
            except Exception as exc:
                return {"ok": False, "error": type(exc).__name__ + ": " + str(exc)}

        def _is_retryable_position_failure(reply):
            if retry_id is None or not isinstance(reply, dict):
                return False
            if reply.get("type") != expected or reply.get("warning") or reply.get("error"):
                return False
            results = reply.get("results")
            if not isinstance(results, list) or len(results) != 1:
                return False
            result = results[0]
            if not isinstance(result, dict) or result.get("ok") is not False:
                return False
            try:
                if int(result.get("id", -1)) != retry_id:
                    return False
            except (ValueError, TypeError):
                return False
            # These are emitted by the ESP *before* the lock pulse.
            return str(result.get("error", "")).strip() in (
                "revolver positioning failed",
                "revolver_positioning_failed",
            )

        response = None
        attempts = 0
        paid_purchase = (action == "remote_purchase" and
                         bool(str((payload or {}).get("invoice_number") or "").strip()) and
                         bool(str((payload or {}).get("issue_datetime_iso") or "").strip()))
        max_attempts = 5 if paid_purchase else 3
        for attempt in range(1, max_attempts + 1):
            if attempt > 1:
                # Never resend after an unknown outcome or post-pulse problem.
                # The authenticated guard may recover ONLY fault 1/3/5.
                # Fault 2/4/6/7, global or customer pending STOP immediately.
                try:
                    from wa_r3_purchase_recovery_safe_v1 import pre_retry_gate as _wa_r3_safe_gate
                    allowed, reason = _wa_r3_safe_gate(retry_id)
                except Exception as exc:
                    allowed, reason = False, "pre-retry guard unavailable: " + repr(exc)
                if not allowed:
                    print("[R3 RETRY5] stopped safely;", "panel=", pos, "item=", retry_id,
                          "reason=", reason)
                    break
                _wa_r3_retry_time.sleep(1.0)
                status = _call({"type": "remote_relay_status", "items": [retry_id]}, 8.0)
                if not (isinstance(status, dict)
                        and status.get("type") == "remote_relay_status_ack"
                        and status.get("ok") is True
                        and status.get("relay_ok") is True
                        and not status.get("error")):
                    print("[R3 RETRY5] stopped: read-only controller readiness check refused;",
                          "panel=", pos, "item=", retry_id,
                          "reason=", status.get("error") if isinstance(status, dict) else "invalid reply")
                    break
                print("[R3 RETRY5] controller readiness OK; retrying positioning",
                      "panel=", pos, "item=", retry_id, "attempt=", attempt, "/", max_attempts)
            attempts = attempt
            response = _call(payload, deadline_seconds)
            if not _is_retryable_position_failure(response):
                break
            if attempt < max_attempts:
                print("[R3 RETRY5] ESP confirmed positioning failure BEFORE lock pulse;",
                      "panel=", pos, "item=", retry_id, "attempt=", attempt, "/", max_attempts)
            else:
                print("[R3 RETRY5] all", max_attempts,
                      "attempts ended in confirmed pre-pulse positioning failure")

        # Reservation collection also uses remote_purchase, without an invoice.
        # It remains at 3 attempts and never gets falsely recorded as a paid sale.
        # After a paid purchase with CONFIRMED pre-lock failure, fail closed:
        # update ESP inventory (and thus panel_update/backend sync) exactly once.
        # Do NOT change inventory on uncertain ACK or any post-pulse error.
        if paid_purchase and _is_retryable_position_failure(response):
            import json as _wa_r3_delivery_json
            import os as _wa_r3_delivery_os
            from pathlib import Path as _wa_r3_delivery_Path
            from datetime import datetime as _wa_r3_delivery_datetime
            info = {
                    "at": _wa_r3_delivery_datetime.now().astimezone().isoformat(),
                    "panel_position": pos,
                    "item_id": retry_id,
                    "attempts": attempts,
                    "invoice_number": str((payload or {}).get("invoice_number") or ""),
                    "outcome": "paid_purchase_not_delivered_pre_lock_positioning_failed",
                    "needs_human_fulfilment_or_refund_review": True,
                }
            try:
                log_path = _wa_r3_delivery_Path(__file__).resolve().parent / "wa_r3_delivery_exceptions.jsonl"
                descriptor = _wa_r3_delivery_os.open(
                    str(log_path), _wa_r3_delivery_os.O_WRONLY | _wa_r3_delivery_os.O_CREAT | _wa_r3_delivery_os.O_APPEND, 0o600)
                with _wa_r3_delivery_os.fdopen(descriptor, "a", encoding="utf-8") as out:
                    out.write(_wa_r3_delivery_json.dumps(info, separators=(",", ":")) + "\n")
                    out.flush()
                    _wa_r3_delivery_os.fsync(out.fileno())
                print("[R3 RETRY5] durable paid-fulfilment exception recorded", info)
            except Exception as exc:
                print("[R3 RETRY5] CRITICAL: unable to persist delivery exception:", repr(exc))
            ack = _call({"type": "remote_update_item",
                         "item": {"id": retry_id, "enabled": False}}, 15.0)
            disabled = (isinstance(ack, dict) and
                        ack.get("type") == "remote_update_item_ack" and
                        ack.get("ok") is True and
                        isinstance(ack.get("item"), dict) and
                        ack["item"].get("enabled") is False)
            response["pi_marked_item_unavailable"] = bool(disabled)
            response["pi_delivery_needs_attention"] = True
            print("[R3 RETRY5] paid item availability:",
                  "ESP acknowledged unavailable" if disabled else "NOT CONFIRMED; OPERATOR REQUIRED",
                  "panel=", pos, "item=", retry_id)
            try:
                sender = getattr(self, "backend_post_event_async", None)
                if callable(sender):
                    sender("r3_paid_fulfilment_failed", severity="error",
                           payload={"panel_position": pos, "item_id": retry_id,
                                    "attempts": attempts, "invoice_number": info.get("invoice_number", ""),
                                    "item_unavailable_verified": disabled,
                                    "requires_operator_reconciliation": True})
            except Exception as exc:
                print("[R3 RETRY5] backend alert failed:", repr(exc))

        # Physical access could be unconfirmed AFTER a successful lock pulse.
        # Do not resend or clear its pending door-cycle; inventory may already
        # have been committed by the ESP. Emit a reconciliation-only alert.
        if paid_purchase and isinstance(response, dict) and (
                response.get("warning") == "at_least_one_revolver_door_never_opened; verify_delivery"
                or any(isinstance(r, dict) and r.get("access_unconfirmed") is True
                       for r in (response.get("results") or []) if isinstance(response.get("results"), list))):
            response["pi_delivery_needs_attention"] = True
            print("[R3 RETRY5] customer access unconfirmed AFTER potential lock pulse;"
                  " no automatic retry or customer pending clear", "item=", retry_id)
            try:
                sender = getattr(self, "backend_post_event_async", None)
                if callable(sender):
                    sender("r3_paid_access_unconfirmed", severity="error",
                           payload={"panel_position": pos, "item_id": retry_id,
                                    "attempts": attempts,
                                    "invoice_number": str((payload or {}).get("invoice_number") or ""),
                                    "requires_operator_reconciliation": True})
            except Exception as exc:
                print("[R3 RETRY5] backend delivery warning failed:", repr(exc))

        is_matching_ack = isinstance(response, dict) and response.get("type") == expected
        has_final_results = is_matching_ack and isinstance(response.get("results"), list)
        rejected_before_execution = (
            is_matching_ack
            and isinstance(response.get("error"), str)
            and bool(response.get("error"))
            and response["error"] != "previous_order_in_progress_wait_for_final_ack"
        )
        is_terminal = has_final_results or rejected_before_execution
        with _wa_r3_mutex:
            if is_terminal:
                _wa_r3_inflight.pop(key, None)
            elif key in _wa_r3_inflight:
                _wa_r3_inflight[key]["uncertain"] = True

        print("[R3 SINGLE FLIGHT]", action, "panel", pos,
              "terminal_ack=", is_terminal, "attempts=", attempts,
              "ok=", bool(response.get("ok")) if isinstance(response, dict) else False)
        if not is_terminal:
            print("[R3 SINGLE FLIGHT] NO FINAL ACK: new R3 opens remain blocked;"
                  " inspect ESP status before restarting kiosk")
        if isinstance(response, dict):
            response["pi_open_attempts"] = attempts
        return response
    except Exception as exc:
        # Never release the guard after an unexpected exception: the UDP
        # command might have reached the controller with an unknown outcome.
        print("[R3 SINGLE FLIGHT] unexpected wrapper error:", repr(exc),
              "R3 operations remain blocked")
        with _wa_r3_mutex:
            if key in _wa_r3_inflight:
                _wa_r3_inflight[key]["uncertain"] = True
        return {"ok": False, "error": "r3_open_outcome_uncertain", "details": str(exc)}
'''


def transform(src):
    if src.count(START)!=1 or src.count(END)!=1:
        raise ValueError('Expected exactly one complete V1 single-flight block')
    begin,end=src.index(START),src.index(END)
    block=src[begin:end]
    if MARK_NEW in block:return src,'already_installed'
    if block.count(HEADER)!=1 or block.count(TAIL)!=1 or block.count(MARK_OLD)!=1:
        raise ValueError('Expected installed V2 retry3 implementation; refusing unknown source')
    head=src.index(HEADER,begin,end)
    tail=src.index(TAIL,head,end)
    old=src[head:tail]
    for needle in ('_wa_r3_original_send','[R3 RETRY3]','_wa_r3_inflight','rejected_before_execution'):
        if needle not in old:raise ValueError('V2 code differs; missing '+needle)
    new=src[:head]+REPLACEMENT+src[tail:]
    ast.parse(new,filename=str(PANEL));compile(new,str(PANEL),'exec')
    return new,'ready'


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    g=ap.add_mutually_exclusive_group(required=True)
    for name in ('check','apply','status'):
        g.add_argument('--'+name,action='store_true')
    args=ap.parse_args()
    if not PANEL.is_file():ap.error('Panel.py is missing')
    if not HELPER.is_file():ap.error('Place wa_r3_purchase_recovery_safe_v1.py beside this patch')
    try:
        source=PANEL.read_text(encoding='utf-8')
        output,state=transform(source)
    except Exception as exc:
        ap.error(str(exc))
    if state=='already_installed':
        print('ALREADY INSTALLED: R3 retry5 guarded purchase V3')
        return
    print('PASS: Installed V2 located; updated Panel.py parses and compiles')
    print('PASS: Purchases max 5, reopen/admin max 3, confirmed pre-pulse only')
    print('PASS: Global/pending/inspection-required faults cannot auto clear')
    print('PASS: Paid fulfilment exception and ESP inventory disable on confirmed failure')
    if args.check or args.status:
        print('READ ONLY: no files modified')
        return
    directory=PANEL.parent/'wa_ui_patch_backups'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    directory.mkdir(parents=True,exist_ok=False)
    backup=directory/'Panel.py'
    shutil.copy2(PANEL,backup)
    fd,tmp=tempfile.mkstemp(prefix='.Panel_r3_retry5_',suffix='.py',dir=str(PANEL.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as fp:
            fp.write(output);fp.flush();os.fsync(fp.fileno())
        shutil.copymode(PANEL,tmp)
        os.replace(tmp,PANEL)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    print('SUCCESS: R3 purchase max 5 attempts with guarded recovery')
    print('BACKUP:',backup)
    print('UNCHANGED: POS, FURS, ESP, tax/invoice processing and all other screens')


if __name__=='__main__':main()
