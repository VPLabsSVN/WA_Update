#!/usr/bin/env bash
# R3 V8 independent watchdog rollout. Preserves timer period and kiosk.
set -euo pipefail
APP=/home/wa_stopshop_mb/WA/Main_program/Fis
DIR="$HOME/.config/systemd/user/wa-r3-watchdog.service.d"
TARGET="$DIR/auto.conf"
BACKUP="$DIR/auto.conf.before_v8"
MODE="${1:---stage}"
case "$MODE" in --stage|--enable-extended|--rollback) ;; *) echo 'Usage: bash wa_r3_v8_activate.sh --stage|--enable-extended|--rollback' >&2; exit 2;; esac
cd "$APP"
mkdir -p "$DIR"
if [ "$MODE" != --rollback ]; then
    "$APP/venv/bin/python" -m py_compile wa_r3_fault_watchdog_v8.py wa_r3_purchase_recovery_v8.py wa_r3_purchase_retry5_v8_patch.py
    "$APP/venv/bin/python" wa_r3_fault_watchdog_v8.py --self-test
    "$APP/venv/bin/python" wa_r3_purchase_recovery_v8.py --self-test
    "$APP/venv/bin/python" test_wa_r3_v8_sim.py >/dev/null
    "$APP/venv/bin/python" wa_r3_fault_watchdog_v8.py --check
fi
systemctl --user stop wa-r3-watchdog.timer
resume(){ systemctl --user start wa-r3-watchdog.timer || true; }
trap resume EXIT
if [ "$(systemctl --user show -p ActiveState --value wa-r3-watchdog.service)" != "inactive" ]; then
    echo 'STOP: a watchdog check is still running' >&2; exit 3
fi
if [ "$MODE" = --rollback ]; then
    test -f "$BACKUP" || { echo "STOP: rollback backup missing: $BACKUP" >&2; exit 4; }
    cp -p "$BACKUP" "$TARGET"
    echo 'RESTORED: previous watchdog override'
else
    if [ ! -f "$BACKUP" ]; then
        if [ -f "$TARGET" ]; then cp -p "$TARGET" "$BACKUP"
        else printf '[Service]\n' > "$BACKUP"; fi
        chmod 600 "$BACKUP"
    fi
    ARGS='--once --auto-recover'
    if [ "$MODE" = --enable-extended ]; then
        # Must not enable on the supplied 8.3.7 firmware; it rejects faults
        # 2/4/6/7 without a real inspected-hardware declaration.
        "$APP/venv/bin/python" - <<'PY'
import sys
import wa_r3_fault_watchdog_v8 as w
try:
    d=w.status(w.endpoint())
except Exception as e:
    sys.exit('STOP: cannot verify live controller: '+str(e))
fw=str(d.get('firmware') or '')
if 'V8.3.7' in fw:
    sys.exit('STOP: old V8.3.7 detected. Do not enable extended until new inspected/commissioned firmware installed.')
print('Controller identifies as:',fw)
print('Firmware identity alone does NOT prove it accepts unattended inspected-fault recovery.')
PY
        ARGS="$ARGS --extended-auto"
    fi
    TMP=$(mktemp "$DIR/.wa_r3_v8.XXXXXX")
    trap 'rm -f "$TMP"; resume' EXIT
    printf '[Service]\nExecStart=\nExecStart=%s %s %s\nTimeoutStartSec=130\n' \
        "$APP/venv/bin/python" "$APP/wa_r3_fault_watchdog_v8.py" "$ARGS" > "$TMP"
    chmod 600 "$TMP"
    mv "$TMP" "$TARGET"
    trap resume EXIT
fi
systemctl --user daemon-reload
resume
trap - EXIT
echo 'WATCHDOG (150-second timer unchanged):'
systemctl --user show -p ExecStart -p TimeoutStartUSec wa-r3-watchdog.service
systemctl --user list-timers --all wa-r3-watchdog.timer
