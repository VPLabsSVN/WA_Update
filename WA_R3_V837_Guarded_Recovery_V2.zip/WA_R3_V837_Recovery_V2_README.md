# WA R3 V8.3.7 V7HW — Guarded Raspberry Pi Recovery V2

**Status:** source-audited against `R3_V8_3_7_V7HW_2026-11-24.zip`, Python compiled and simulator-tested. **Not tested on the physical kiosk/ESP32.** This is a candidate update and should first be installed during supervised maintenance.

## Exact firmware findings

- `remote_motor_status` ACK uses `remote_motor_ack` and **does not include `firmware`**. Read-only `remote_recovery_status` uses `recovery_ack` and **does include firmware**. The V2 watchdog compares authenticated status boot IDs before enabling automatic software-fault recovery.
- Fault codes **1/3/5** support gated `remote_motor_recover` without `inspected_hardware`. Codes **2/4/6/7** support supervised recovery but firmware requires `inspected_hardware=true` (real human inspection). **This package never fakes that flag**.
- `remote_motor_clear_pending_cycle` requires **physical inspection**, two customer/transaction attestations, the exact boot ID, pending masks and physical safety checks; it does **not** run automatically here.
- `remote_purchase_ack` result `revolver positioning failed` is generated BEFORE lock pulse. Only that definitive result can be retried.
- `access_unconfirmed` / `at_least_one_revolver_door_never_opened` can occur AFTER a pulse and inventory commit. **No automatic retry or pending clear** in this situation.
- On a **paid, single-item** delivery failure confirmed BEFORE the pulse, V3 logs the unresolved paid purchase and sends an idempotent `remote_update_item` to set `enabled=false`, then checks the ESP ACK. It also attempts to post a backend event; operator must arrange refund or fulfilment.

## Package files

1. `wa_r3_fault_watchdog_v2.py`: 150-second read-only monitor; opt-in automatic recovery for 1,3,5 *only*, with kiosk idle certificate (Home idle 180s and no purchase 600s), cross-process lock and one recovery per motor per hour (max 2/day).
2. `wa_r3_purchase_recovery_safe_v1.py`: shared recovery preflight for paid R3 purchase retries. Requires two fresh authenticated statuses before a software-fault recovery. Never claims inspected hardware.
3. `wa_r3_open_retry5_guarded_v3.py`: upgrades installed V1/V2 retry wrapper in `Panel.py`; paid single-item purchases 5 total attempts; customer/admin reopening and reservation collection 3 total as before. Known pre-pulse failures only. Fails closed on ambiguous ACK or post-pulse error.
4. `wa-r3-watchdog.service` and `wa-r3-watchdog.timer`: read-only systemd monitor, every 150s.

## 0. Preconditions

- Existing `wa_r3_open_single_flight_v1.py` and `wa_r3_open_retry3_v2.py` patches must already be installed in `Panel.py`.
- Authenticated `pi_recovery_endpoints.json` configured for ESP `192.168.1.201:48556` on private Pi LAN; keep the token private.
- Do not run two different watchdog timers concurrently.
- Operator physically confirms safe conditions before enabling unattended software-fault recovery. Test both R7/R10 door switches and ENN disable checks.
- Archive the current Pi files before production change (patch tools also make timestamped backups).

## 1. Upload / extract

From `Fis`, upload the ZIP (via existing GitHub raw workflow or SCP), then:

```bash
cd /home/wa_stopshop_mb/WA/Main_program/Fis
unzip -o WA_R3_V837_Guarded_Recovery_V2.zip
./venv/bin/python wa_r3_fault_watchdog_v2.py --self-test
./venv/bin/python wa_r3_purchase_recovery_safe_v1.py
./venv/bin/python wa_r3_fault_watchdog_v2.py --check
./venv/bin/python wa_r3_fault_watchdog_v2.py --once
./venv/bin/python wa_r3_open_retry5_guarded_v3.py --check
```

**These checks do not clear faults, start motors, open doors or update inventory.** `--once` still queries controller status.

## 2. Install after safe offline checks, only when kiosk is fully idle

```bash
cd /home/wa_stopshop_mb/WA/Main_program/Fis
systemctl --user stop bouquetmat.service
./venv/bin/python wa_r3_fault_watchdog_v2.py --install-idle-hook
./venv/bin/python wa_r3_open_retry5_guarded_v3.py --apply
systemctl --user start bouquetmat.service
systemctl --user is-active bouquetmat.service
./venv/bin/python wa_r3_fault_watchdog_v2.py --hook-status
./venv/bin/python wa_r3_open_retry5_guarded_v3.py --status
```

If a command fails, **start `bouquetmat.service` again**, inspect the backup path printed by the patch and investigate before further changes. Avoid stopping kiosk during an active payment/order. V3 modifies `Panel.py` only; idle heartbeat changes `Panel_backend_merged.py` only. Neither changes POS/FURS or ESP firmware.

## 3. Read-only 150-second systemd timer (recommended pilot)

```bash
mkdir -p ~/.config/systemd/user
cp wa-r3-watchdog.service wa-r3-watchdog.timer ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now wa-r3-watchdog.timer
systemctl --user list-timers wa-r3-watchdog.timer
journalctl --user -u wa-r3-watchdog.service --since '30 minutes ago' --no-pager
```

**The service ships read-only.** The verified code can *optionally* run `--once --auto-recover` (codes 1,3,5 only) after physical commissioning. Do not set that flag if hardware readiness is unverified. Automatically clearing pending, global faults, or fault 2/4/6/7 is not supported by this firmware protocol.

To opt into guarded software-fault auto recovery **after independent physical verification**:

```bash
mkdir -p ~/.config/systemd/user/wa-r3-watchdog.service.d
cat > ~/.config/systemd/user/wa-r3-watchdog.service.d/auto.conf <<'EOF_AUTO'
[Service]
ExecStart=
ExecStart=/home/wa_stopshop_mb/WA/Main_program/Fis/venv/bin/python /home/wa_stopshop_mb/WA/Main_program/Fis/wa_r3_fault_watchdog_v2.py --once --auto-recover
EOF_AUTO
systemctl --user daemon-reload
```

The timer remains 150 seconds. Remove the `auto.conf` file and run `daemon-reload` to return to read-only mode. Note the package *does not auto-install* this opt-in.

## 4. Observe paid purchase attempts

```bash
journalctl --user -u bouquetmat.service --since '60 minutes ago' --no-pager \
 | grep -E 'R3 RETRY5|R3 PURCHASE RECOVERY|R3 SINGLE FLIGHT|r3_paid_fulfilment_failed|r3_paid_access_unconfirmed' | tail -100
```

For unresolved **confirmed pre-pulse** failures, inspect private local `wa_r3_delivery_exceptions.jsonl`. This file includes invoice ID and should remain on the kiosk; do not publish it. Successful `remote_update_item_ack` verifies unavailable status on the ESP. If the ACK is missing, unavailable status is **not confirmed** and operator must act. Refund/fulfilment is never automated.

Important: only paid *single-item* R3 orders gain five attempts. Multi-item batches are unchanged because pulse/door states and partially fulfilled orders cannot safely be replayed as a single batch. Customer/admin reopen stays at three. The ESP cannot always prove customer physically retrieved the product from a *single* opened door.

## 5. Inspect events, stop monitoring or roll back

```bash
systemctl --user disable --now wa-r3-watchdog.timer
journalctl --user -u wa-r3-watchdog.service --since '1 hour ago' --no-pager
```

To remove **only** the idle hook, stop the kiosk when idle, run `./venv/bin/python wa_r3_fault_watchdog_v2.py --remove-idle-hook`, and restart kiosk. To roll back V3, restore the `Panel.py` from the timestamped `wa_ui_patch_backups/.../Panel.py` printed by V3, **only if no subsequent Panel.py edits were made**, then restart kiosk. If later patches exist, do not overwrite them with an old backup; instead review a narrow diff.

## Notes for operator-inspected faults

Faults 2,4,6,7 are NOT rejected by the firmware universally; they require genuinely inspected, verified hardware. The existing attended `wa_maintenance_cli.py` can perform recovery with `--inspected-hardware` and an actual inspection note after checking doors, lock output, TMC/ENN, and that no customer transaction/access is outstanding. Never insert an automatic or fictitious inspection note. A persistent or global fault requires site inspection and cause correction.
