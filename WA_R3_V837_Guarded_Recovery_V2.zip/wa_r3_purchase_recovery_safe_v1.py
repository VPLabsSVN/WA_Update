#!/usr/bin/env python3
"""Read-only R3 purchase status gate with narrowly bounded software-fault recovery.

This module is called ONLY after a final ESP remote_purchase_ack/remote_reopen_ack
confirmed a revolver positioning error BEFORE any lock pulse. It never clears
pending cycles, never asserts physical inspection, never clears global faults,
and never overrides mechanical/electrical faults 2,4,6,7. All mutations use
existing authenticated local Pi recovery endpoint and require fresh controller
safety status. No public networking or service process.
"""
from __future__ import annotations
import fcntl
import json
import os
from pathlib import Path
import socket
import tempfile
import time
import uuid

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / 'pi_recovery_endpoints.json'
LOCK = ROOT / 'wa_r3_watchdog.lock'  # Shared with the 150 s idle watchdog.
BUDGET = ROOT / 'wa_r3_watchdog_state.json'
SAFE = frozenset((1, 3, 5))
BLOCKERS = ('global_fault', 'unsafe_maintenance_stop', 'guard_latched',
            'guard_owner_conflict', 'network_job_active', 'network_job_stalled',
            'order_stall_latched', 'service_busy', 'service_stalled',
            'maintenance_busy', 'idle_worker_stalled')


def endpoint():
    d = json.loads(CONFIG.read_text(encoding='utf-8'))
    entry = d['controllers']['r3']
    if (entry.get('protocol') != 'r3_motor_recovery' or
            entry.get('ip') != '192.168.1.201' or
            int(entry.get('port', 0)) != 48556 or
            not isinstance(entry.get('token'), str) or len(entry['token']) < 24):
        raise ValueError('R3 recovery endpoint not an authorized configured V7HW controller')
    pi_ip = d.get('pi_ip')
    if not isinstance(pi_ip, str):
        raise ValueError('Missing Pi recovery bind IP')
    return pi_ip, entry['ip'], 48556, entry['token']


def rpc(ep, action, motor=None, timeout=9.0):
    source, dest, port, token = ep
    rid = 'r3-pi-'+uuid.uuid4().hex
    payload = {'type': action, 'request_id': rid, 'token': token}
    if motor is not None:
        payload['motor'] = motor
    expected = 'remote_motor_ack'
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.bind((source, 0))
        s.settimeout(timeout)
        s.sendto(json.dumps(payload, separators=(',', ':')).encode(), (dest, port))
        deadline = time.monotonic() + timeout
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                break
            s.settimeout(left)
            try:
                raw, sender = s.recvfrom(65535)
            except socket.timeout:
                break
            if sender != (dest, port):
                continue
            try:
                ack = json.loads(raw.decode('utf-8'))
            except (ValueError, UnicodeDecodeError):
                continue
            if (isinstance(ack, dict) and ack.get('type') == expected and
                    ack.get('request_id') == rid):
                return ack
    raise TimeoutError('No matching final R3 maintenance ACK; recovery outcome unknown')


def get_status(ep):
    d = rpc(ep, 'remote_motor_status')
    if d.get('ok') is not True:
        raise ValueError('ESP refused motor status: '+str(d.get('error')))
    if type(d.get('boot_id')) is not int or type(d.get('motors')) is not list:
        raise ValueError('Missing boot identity or motor status')
    return d


def motor_for_item(item):
    if type(item) is not int or item < 5 or item > 21:
        raise ValueError('Not a revolver slot')
    return 7 if item <= 11 else 10


def assess(d, motor):
    if d.get('position') not in (None, 1):
        return 'unexpected controller position', None
    for k in BLOCKERS:
        if d.get(k) is not False:
            return k+' active or not verified false', None
    if d.get('pending_wait_open_mask') != 0 or d.get('pending_wait_close_mask') != 0:
        return 'pending customer door cycle; manual reconciliation required', None
    if d.get('motor_hardware_ready') is not True or d.get('tmc_both_configured') is not True:
        return 'motor hardware/drivers not confirmed ready', None
    rows = {m.get('motor'): m for m in d['motors'] if isinstance(m, dict)}
    if set(rows) != {7, 10}:
        return 'missing or duplicate motor rows', None
    for n, m in rows.items():
        if m.get('door_closed_verified') is not True or m.get('door_cycle_pending') is not False:
            return 'R%d door not confirmed closed or pending access'%n, None
        if m.get('auto_recovery_budget_exhausted') is True:
            return 'firmware recovery budget exhausted on R%d'%n, None
    target = rows[motor]
    if target.get('fault_latched') is True:
        fault = target.get('fault_reason')
        if type(fault) is not int or fault not in SAFE:
            return 'R%d fault %s needs attended service'%(motor, fault), None
        if target.get('enn_disabled_verified') is not True or target.get('step_output_active') is not False:
            return 'R%d is not verified stopped/disabled for recovery'%motor, None
        return None, ('recover', fault)
    if target.get('fault_latched') is not False:
        return 'target fault status unknown', None
    if target.get('fault_reason') not in (0, None):
        return 'fault reason reported without latch', None
    if d.get('idle_enabled') is not True or target.get('step_output_active') is not True:
        return 'healthy motor has no verified active idle output', None
    return None, ('ready', 0)


def equivalent(a, b, motor, fault):
    if a.get('boot_id') != b.get('boot_id'):
        return False
    x, one = assess(a, motor)
    y, two = assess(b, motor)
    return not x and not y and one == two == ('recover', fault)


def consume_budget(motor):
    now = time.time()
    try:
        d = json.loads(BUDGET.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        d = {}
    if type(d) is not dict:
        raise ValueError('Invalid recovery budget')
    recent = [v for v in d.get(str(motor), []) if isinstance(v, (int, float)) and 0 <= now-v < 86400]
    if sum(now-v < 3600 for v in recent) >= 1 or len(recent) >= 2:
        return False
    d[str(motor)] = recent + [now]  # reserve before UDP, unknown ACK still counts
    fd, temp = tempfile.mkstemp(prefix='.r3budget_', dir=str(ROOT))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(d, f); f.flush(); os.fsync(f.fileno())
        os.chmod(temp, 0o600)
        os.replace(temp, BUDGET)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return True


def pre_retry_gate(item: int, *, allow_software_recovery=True):
    """Return (bool ready, reason); read-only except verified 1/3/5 recover.

    Lock is shared with idle watchdog to prevent two Pi recovery owners.
    A purchase already holds the Panel.py single-flight guard for this R3.
    """
    motor = motor_for_item(item)
    with LOCK.open('a+') as handle:
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return False, 'idle watchdog owns recovery lock'
        try:
            ep = endpoint()
            # Final purchase ACK precedes network_job_active -> false; wait
            # briefly for the original ESP worker to relinquish ownership.
            first = None
            why = 'controller did not become idle after final ACK'
            for i in range(8):
                first = get_status(ep)
                why, state = assess(first, motor)
                if not why:
                    break
                if first.get('network_job_active') is not True:
                    return False, why
                time.sleep(0.7)
            else:
                return False, why
            if state[0] == 'ready':
                return True, 'healthy motor and no pending access'
            if not allow_software_recovery:
                return False, 'R%d fault %d present; recovery disabled'%(motor, state[1])
            fault = state[1]
            time.sleep(0.7)
            second = get_status(ep)
            if not equivalent(first, second, motor, fault):
                return False, 'motor/fault state changed between two fresh status reads'
            if not consume_budget(motor):
                return False, 'rate limit 1/hour and 2/day for R%d'%motor
            print('[R3 PURCHASE RECOVERY] guarded recovery R%d fault=%d (no inspection flag)'%(motor,fault), flush=True)
            ack = rpc(ep, 'remote_motor_recover', motor=motor, timeout=35.0)
            if ack.get('ok') is not True:
                return False, 'ESP refused guarded recovery: '+str(ack.get('error') or 'unknown')
            boot = first['boot_id']
            for _ in range(8):
                time.sleep(1.2)
                post = get_status(ep)
                if post.get('boot_id') != boot:
                    return False, 'controller rebooted during recovery'
                reason, state = assess(post, motor)
                if not reason and state == ('ready', 0):
                    row = next(m for m in post['motors'] if m.get('motor') == motor)
                    if (row.get('rotation_verified_after_recovery') is True and
                            row.get('recovery_verification') == 'encoder_motion_verified'):
                        return True, 'R%d verified encoder rotation after software recovery'%motor
                if reason and any(x in reason for x in ('global_fault', 'guard_latched', 'pending', 'unsafe_maintenance_stop')):
                    return False, reason
            return False, 'recovery acknowledged but sustained encoder rotation not verified'
        except Exception as exc:
            return False, type(exc).__name__+': '+str(exc)[:220]


def self_test():
    b = {k:False for k in BLOCKERS}
    b.update(position=1, boot_id=13, idle_enabled=True, motor_hardware_ready=True,
             tmc_both_configured=True, pending_wait_open_mask=0, pending_wait_close_mask=0,
             motors=[{'motor':m,'door_closed_verified':True,'door_cycle_pending':False,
                      'fault_latched':False,'fault_reason':0,'step_output_active':True,
                      'enn_disabled_verified':False,'auto_recovery_budget_exhausted':False}
                     for m in (7,10)])
    assert assess(b,7) == (None,('ready',0))
    assert motor_for_item(5)==7 and motor_for_item(11)==7 and motor_for_item(12)==10
    for k in BLOCKERS:
        d=json.loads(json.dumps(b)); d[k]=True
        assert assess(d,7)[0]
    for code in (1,2,3,4,5,6,7):
        d=json.loads(json.dumps(b)); d['motors'][0].update(fault_latched=True, fault_reason=code,
                                      enn_disabled_verified=True, step_output_active=False)
        w,state=assess(d,7)
        assert ((w is None and state == ('recover',code)) if code in SAFE else bool(w))
    d=json.loads(json.dumps(b)); d['pending_wait_open_mask']=1
    assert assess(d,7)[0]
    print('PASS: healthy, global/guard/pending, R7/R10 and 7 fault classes')


if __name__=='__main__':
    self_test()
