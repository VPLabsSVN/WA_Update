#!/usr/bin/env python3
"""Register Jagodic business premises independently, without any sale.
Use --check for OFFLINE audit; --register makes ONE LIVE production FURS BP request.
This does NOT enable payments or invoice fiscalization, send an invoice, or open doors.
"""
import argparse
from pathlib import Path
ROOT=Path('/home/wa_stopshop_mb/WA/Main_program/Fis')

def validate(tax):
    sent,allowed=tax.read_state()
    if allowed!=0:raise RuntimeError('Stop: allowed must be 0 during registration')
    if sent:raise RuntimeError('Business premises are already marked registered; do not resubmit')
    if str(tax.TAX_NUMBER)!='75196212':raise RuntimeError('Wrong seller tax ID')
    if str(tax.BUSINESS_PREMISE_ID)!='WAF260003':raise RuntimeError('Wrong BP identifier')
    if str(tax.BASE_URL).rstrip('/')!='https://blagajne.fu.gov.si:9003':raise RuntimeError('Wrong FURS environment')
    outer=tax.build_bp_payload()
    bp=outer['BusinessPremiseRequest']['BusinessPremise']
    if str(bp['TaxNumber'])!='75196212' or bp['BusinessPremiseID']!='WAF260003':
        raise RuntimeError('Incorrect BP payload taxpayer or identifier')
    bi=bp['BPIdentifier']
    kinds=[k for k in ('RealEstateBP','VendingMachine','PremiseType') if k in bi]
    if len(kinds)!=1:raise RuntimeError('Invalid BPIdentifier category')
    print('Premises type:',kinds[0]);print('Premises ID:',bp['BusinessPremiseID'])
    if kinds[0]=='RealEstateBP':
        loc=bi['RealEstateBP'];prop=loc['PropertyID'];addr=loc['Address']
        if int(prop.get('CadastralNumber',0))!=1176:
            raise RuntimeError('Expected Negonje cadastral number 1176')
        if int(prop.get('BuildingNumber',0))<=0:
            raise RuntimeError('BuildingNumber is missing or 0. Verify the real number before registering.')
        if 'BuildingSectionNumber' not in prop:raise RuntimeError('Missing BuildingSectionNumber')
        if not all(addr.get(k) for k in ('Street','HouseNumber','Community','City','PostalCode')):
            raise RuntimeError('Real-estate address incomplete')
        print('Location:',addr.get('Street'),addr.get('HouseNumber'),addr.get('HouseNumberAdditional',''),addr.get('PostalCode'))
        print('Cadastral property:',prop)
    elif kinds[0]=='VendingMachine':
        vm=bi['VendingMachine']
        if vm.get('VPremiseType') not in ('D','E','F'):raise RuntimeError('Vending subtype must be D/E/F')
        if ('Address' in vm)==('Geolocation' in vm):raise RuntimeError('Expected exactly one vending location mode')
        if 'Address' in vm:
            addr=vm['Address']
            if not all(addr.get(k) for k in ('Street','HouseNumber','Community','City','PostalCode')):
                raise RuntimeError('Vending address incomplete')
            print('Location:',addr.get('Street'),addr.get('HouseNumber'),addr.get('HouseNumberAdditional',''),addr.get('PostalCode'))
        else: print('Location: registered by geolocation (verify GPS accuracy)')
    else:
        raise RuntimeError('PremiseType without fixed address is not appropriate for this machine without further review')
    if not bp.get('ValidityDate') or not bp.get('SoftwareSupplier'):
        raise RuntimeError('ValidityDate or SoftwareSupplier missing')
    for filename in ('client_cert.pem','client_key.p8.pem','si-trust-root.pem'):
        if not (ROOT/filename).is_file():raise RuntimeError('Missing '+filename)
    return outer

def main():
    pa=argparse.ArgumentParser(description=__doc__);g=pa.add_mutually_exclusive_group(required=True)
    g.add_argument('--check',action='store_true');g.add_argument('--register',action='store_true')
    args=pa.parse_args()
    import sys
    sys.path.insert(0,str(ROOT))
    import Fiscalisation as tax
    validate(tax)
    if args.check:
        print('PASS: Offline registration payload checks passed; no FURS request sent')
        return
    import requests
    with requests.Session() as session:
        resp=tax.send_bp_once(session)
    payload=resp.get('decoded_payload') if isinstance(resp,dict) else None
    bp_response=payload.get('BusinessPremiseResponse') if isinstance(payload,dict) else None
    valid=(
        isinstance(resp,dict) and resp.get('http')==200 and
        isinstance(bp_response,dict) and isinstance(bp_response.get('Header'),dict) and
        not bp_response.get('Error')
    )
    if not valid:
        print('FAILED: FURS business-premises response did not confirm acceptance')
        print('HTTP:',resp.get('http') if isinstance(resp,dict) else 'unknown')
        print('FURS Error:',bp_response.get('Error') if isinstance(bp_response,dict) else 'No valid decoded BusinessPremiseResponse')
        raise SystemExit(2)
    tax.write_state(bp_sent=True,allowed=0)
    print('PASS: FURS accepted WAF260003; bp_sent=1 and allowed=0')
    print('No sale/invoice/payment was initiated')

if __name__=='__main__': main()
