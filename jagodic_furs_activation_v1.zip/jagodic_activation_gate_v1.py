#!/usr/bin/env python3
"""Jagodic live POS+FURS activation gate.
Usage: python3 jagodic_activation_gate_v1.py --check
       python3 jagodic_activation_gate_v1.py --activate
Does not send any payment, invoice, premises registration or printer bytes.
Activation changes ONLY Panel.py PAYMENT_ENABLED and bp_sent.txt allowed.
"""
import argparse, ast, os, re, shutil, socket, stat, tempfile
from pathlib import Path
from datetime import datetime
ROOT=Path('/home/wa_stopshop_mb/WA/Main_program/Fis')
PANEL=ROOT/'Panel.py';BP=ROOT/'bp_sent.txt';FISCAL=ROOT/'Fiscalisation.py'

def check():
    failures=[]
    def verify(ok,desc):
        print(('PASS' if ok else 'BLOCK')+': '+desc)
        if not ok:failures.append(desc)
    p=PANEL.read_text(encoding='utf-8');b=BP.read_text(encoding='utf-8');f=FISCAL.read_text(encoding='utf-8')
    try:ast.parse(p);ast.parse(f)
    except SyntaxError as e: failures.append('Python syntax: '+str(e))
    verify(bool(re.search(r'(?m)^PAYMENT_ENABLED\s*=\s*False\b',p)),'Payments currently OFF')
    verify(bool(re.search(r'(?m)^allowed\s*=\s*0\s*$',b)),'FURS currently OFF')
    verify(bool(re.search(r'(?m)^bp_sent\s*=\s*1\s*$',b)),'FURS business premises already registered and recorded (bp_sent=1)')
    verify('JAGODIC_FURS_RESPONSE_V1' in f,'FURS response/ZOI validation patch installed')
    verify('self._lock = threading.RLock()' in (ROOT/'payment_terminal_service.py').read_text(), 'Payment deadlock fix installed')
    verify('PAYMENT_POS_ID = "25688418"' in p,'POS ID 25688418 configured')
    verify('PAYMENT_TERMINAL_IP = "192.168.1.150"' in p and 'PAYMENT_TERMINAL_PORT = 7784' in p,'Terminal address configured')
    verify((Path('/home/wa_stopshop_mb/WA/RaspberryPI/64Bit/libtimapi.so.3.40.0-7489')).is_file(),'TIM library present')
    for fn in ('client_cert.pem','client_key.p8.pem','si-trust-root.pem'):
        verify((ROOT/fn).is_file() and (ROOT/fn).stat().st_size>0,'FURS certificate/key/trust material: '+fn)
    try:
        import sys
        sys.path.insert(0,str(ROOT))
        import Fiscalisation as tax
        verify(str(tax.TAX_NUMBER)=='75196212','Seller tax number 75196212')
        verify(str(tax.BUSINESS_PREMISE_ID)=='WAF260003','Business premise WAF260003')
        verify(str(tax.ELECTRONIC_DEVICE_ID)=='FLORA0003','Electronic device FLORA0003')
        verify('blagajne.fu.gov.si:9003' in str(tax.BASE_URL),'FURS production endpoint configured')
        req=tax.build_bp_payload()['BusinessPremiseRequest']['BusinessPremise']
        verify(str(req.get('TaxNumber'))=='75196212' and req.get('BusinessPremiseID')=='WAF260003','Business premises payload identity')
        identifier=req.get('BPIdentifier',{})
        kinds=[x for x in ('RealEstateBP','PremiseType','VendingMachine') if x in identifier]
        verify(len(kinds)==1,'Business premises payload has exactly one recognized location type')
        if kinds:
            k=kinds[0]
            print('INFO: Business-premises type:',k)
            if k=='VendingMachine':
                vending=identifier[k]
                verify(vending.get('VPremiseType') in ('D','E','F'),'Vending subtype D/E/F')
                verify(('Address' in vending) != ('Geolocation' in vending),'Vending address or geolocation present')
            if k=='RealEstateBP':
                real=identifier[k]
                prop=real.get('PropertyID',{})
                verify(all(x in prop for x in ('CadastralNumber','BuildingNumber','BuildingSectionNumber')), 'Cadastral, building and section numbers present')
                verify(bool(real.get('Address')), 'Premises address present')
        verify(bool(req.get('ValidityDate')) and bool(req.get('SoftwareSupplier')),'Business-premises date and supplier supplied')
        pending=tax.read_failed_invoices()
        verify(isinstance(pending,list) and len(pending)==0,'No older pending FURS invoices to resend before registering premises')
    except Exception as e:
        verify(False,'Unable to build/audit FURS payload: '+type(e).__name__+': '+str(e))
    try:
        from receipt_printer import _choose_usb_device
        device=_choose_usb_device('/dev/usb/lp0')
        verify(Path(device).exists() and stat.S_ISCHR(Path(device).stat().st_mode),'SANEI USB receipt printer detected')
    except Exception as e:
        verify(False,'Receipt printer not available: '+str(e))
    try:
        with socket.create_connection(('192.168.1.150',7784),timeout=3):pass
        verify(True,'TIM terminal TCP reachable (no login/payment attempted)')
    except OSError as e:verify(False,'TIM terminal TCP unreachable: '+type(e).__name__)
    return failures

def replace_file(path,text):
    fd,tmp=tempfile.mkstemp(prefix='.jagodic_activation_',dir=str(ROOT))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as w:w.write(text);w.flush();os.fsync(w.fileno())
        shutil.copymode(path,tmp);os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--check',action='store_true');g.add_argument('--activate',action='store_true')
    args=ap.parse_args();failures=check()
    if failures:raise SystemExit('NOT ACTIVATED: '+str(len(failures))+' check(s) blocked activation')
    if args.check:print('READY: Activation checks passed, no settings changed');return
    panel=PANEL.read_text();bp=BP.read_text()
    newpanel,n=re.subn(r'(?m)^(PAYMENT_ENABLED\s*=\s*)False\b',r'\g<1>True',panel,count=1)
    newbp,m=re.subn(r'(?m)^(allowed\s*=\s*)0\s*$',r'\g<1>1',bp,count=1)
    if n!=1 or m!=1:raise SystemExit('ABORT: activation setting count unexpected')
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
    for path in (PANEL,BP):shutil.copy2(path,path.with_name(path.name+'.before_activation_'+stamp))
    replace_file(PANEL,newpanel)
    try:replace_file(BP,newbp)
    except Exception:
        replace_file(PANEL,panel)
        raise
    print('ACTIVATED: PAYMENT_ENABLED=True; allowed=1')
    print('Business premises already registered; no automatic first-sale re-registration needed.')
    print('Restart kiosk when idle: systemctl --user restart bouquetmat.service')

if __name__=='__main__': main()
