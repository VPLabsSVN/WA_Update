#!/usr/bin/env python3
"""Prepare/patch Jagodic FURS response handling without network activity.
Usage: python3 jagodic_furs_response_patch_v1.py --check | --apply
Does not change bp_sent, allowed, POS, the premises registration flow, or printer.
"""
import argparse, ast, os, re, shutil, tempfile
from pathlib import Path
from datetime import datetime
from types import SimpleNamespace
from typing import Any, Dict, List, Tuple

ROOT=Path('/home/wa_stopshop_mb/WA/Main_program/Fis')
PATH=ROOT/'Fiscalisation.py'
OLD='''        details: Dict[str, Any] = {"http": inv_resp.status_code, "text": inv_resp.text[:200]}
        try:
            inv_data = inv_resp.json()
            if "token" in inv_data:
                _, payload = decode_jws(inv_data["token"])
                details["decoded_payload"] = payload
        except Exception:
            pass

        return (inv_resp.status_code == 200), details'''
NEW='''        # JAGODIC_FURS_RESPONSE_V1: preserve the signed request's ZOI.
        details: Dict[str, Any] = {
            "http": inv_resp.status_code,
            "text": inv_resp.text[:200],
            "zoi": str(inv_payload["InvoiceRequest"]["Invoice"]["ProtectedID"]),
        }
        try:
            inv_data = inv_resp.json()
            if isinstance(inv_data, dict) and inv_data.get("token"):
                _, payload = decode_jws(inv_data["token"])
                if isinstance(payload, dict):
                    details["decoded_payload"] = payload
        except Exception as exc:
            details["response_parse_error"] = type(exc).__name__

        decoded = details.get("decoded_payload")
        response = decoded.get("InvoiceResponse") if isinstance(decoded, dict) else None
        response = response if isinstance(response, dict) else {}
        eor = str(response.get("UniqueInvoiceID") or "").strip()
        from uuid import UUID as _UUID
        try:
            valid_eor = bool(eor and str(_UUID(eor)) == eor.lower())
        except (ValueError, TypeError, AttributeError):
            valid_eor = False
        accepted = (
            inv_resp.status_code == 200
            and isinstance(response.get("Header"), dict)
            and not response.get("Error")
            and valid_eor
        )
        if accepted:
            details["eor"] = eor
        else:
            details["furs_confirmed"] = False
            details["reason"] = "missing or invalid FURS confirmation"
            if response.get("Error"):
                details["furs_error"] = response["Error"]
        return accepted, details'''

def get_method(src):
    nodes=[n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=='send_one_invoice']
    if len(nodes)!=1: raise RuntimeError('Expected exactly one send_one_invoice')
    return nodes[0]

def transform(src):
    if 'JAGODIC_FURS_RESPONSE_V1' in src: raise RuntimeError('Patch already installed')
    n=get_method(src); ls=src.splitlines(keepends=True); method=''.join(ls[n.lineno-1:n.end_lineno])
    if method.count(OLD)!=1: raise RuntimeError('Function differs from audited source; no change made')
    out=''.join(ls[:n.lineno-1])+method.replace(OLD,NEW,1)+''.join(ls[n.end_lineno:])
    ast.parse(out)
    for s in ('if allowed == 0:', 'send_bp_flag = 0 if bp_sent else 1'):
        if src.count(s)!=out.count(s): raise RuntimeError('Unexpected change to FURS switch or registration')
    return out

def test_offline(src):
    n=get_method(src); module=ast.fix_missing_locations(ast.Module(body=[n],type_ignores=[]))
    eor='11111111-2222-4333-8444-555555555555'
    class Resp:
        status_code=200
        text='offline'
        payload={'InvoiceResponse':{'Header':{'MessageID':'offline'},'UniqueInvoiceID':eor}}
        def json(self): return {'token':self.payload}
    resp=Resp()
    ns={'requests':SimpleNamespace(Session=object),'Any':Any,'Dict':Dict,'List':List,'Tuple':Tuple,
        'build_invoice_payload':lambda *a:{'InvoiceRequest':{'Invoice':{'ProtectedID':'a'*32}}},
        'build_jws_token':lambda *a:'offline','post_token':lambda *a:resp,
        'decode_jws':lambda token:({},token),'INVOICE_PATH':'/offline'}
    exec(compile(module,'<offline>','exec'),ns)
    f=ns['send_one_invoice']; call=lambda:f(None,'1','2026-11-23T12:00:00',12.50,[])
    ok,d=call();assert ok and d['eor']==eor and d['zoi']=='a'*32
    print('PASS: Confirmed response retains EOR and request ZOI')
    resp.payload={'InvoiceResponse':{'Header':{}}}; assert call()[0] is False
    print('PASS: HTTP 200 without EOR rejected')
    resp.payload={'InvoiceResponse':{'Header':{},'UniqueInvoiceID':eor,'Error':{'ErrorCode':'S001'}}}
    assert call()[0] is False
    print('PASS: FURS Error rejected')
    resp.status_code=500;resp.payload={'InvoiceResponse':{'Header':{},'UniqueInvoiceID':eor}}
    assert call()[0] is False
    print('PASS: HTTP 500 rejected; no network or payment calls')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--check',action='store_true');g.add_argument('--apply',action='store_true')
    args=p.parse_args();src=PATH.read_text(encoding='utf-8');new=transform(src);test_offline(new)
    if args.check:
        print('PASS: Patch compatible; no files modified');return
    bp=(ROOT/'bp_sent.txt').read_text();panel=(ROOT/'Panel.py').read_text()
    if not re.search(r'(?m)^allowed\s*=\s*0\s*$',bp): raise SystemExit('ABORT: FURS must remain off during update')
    if not re.search(r'(?m)^PAYMENT_ENABLED\s*=\s*False\b',panel): raise SystemExit('ABORT: payments must remain off during update')
    backup=PATH.with_name('Fiscalisation.py.before_response_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    shutil.copy2(PATH,backup);fd,tmp=tempfile.mkstemp(prefix='.furs_pending_',dir=ROOT)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f: f.write(new);f.flush();os.fsync(f.fileno())
        shutil.copymode(PATH,tmp);os.replace(tmp,PATH)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
    print('PASS: Installed; BP first-transaction logic unchanged. Backup:',backup.name)

if __name__=='__main__':main()
