Fin Performance V1 — source-only patch
======================================
Target machine: Fin, Raspberry Pi 5, 4GB, Bookworm, machine ID Fin
Original files (from SHA-256 verified decrypted source):
  Panel.py:                8fcb2f4f0858583205d24935a56e5197bfe92a7d46bb4c0d86b09c5804d8a4f5
  Panel_backend_merged.py: 2b408cea669f68d91f19b79129e0ae9ecac16cd3f37ba6081d9db64c03e3889e

Changes:
  1. Avoid full UI tree recoloring every 0.2 seconds; check every 5 seconds only on relevant text-input screens.
  2. Limit button tree-wide repaint passes after each touch from four to two.
  3. For unchanged server config: retain reservation code updates but skip redundant local items JSON writes and all customer/admin grid rebuilds.
  4. For unchanged remote-panel state: refresh remote panel liveness without triggering redundant full UI rebuild, disk write, or backend item sync.
  5. Coalesce bursts of backend item sync requests into a single sequential background worker with latest-state semantics.

NOT CHANGED:
  Payment/checkout, fiscalisation, POS startup and retry, receipt printer,
  invoice format, UDP ports, ESP32 command/response protocols,
  door opening code, admin permissions, backend auth configuration,
  remote motor recovery, advertising system, backend_client.py, Ads.py.

IMPORTANT:
  * First run while Fin is operating: bash fin_performance_v1_apply.sh --check
  * When kiosk is idle: bash fin_performance_v1_apply.sh --apply
  * It checks original SHA-256 and refuses if files have been changed.
  * It backs up the actual two files locally with owner-only permissions.
  * It does NOT restart the app. Restart manually in a maintenance window after making sure no payment or vending operation is active.
  * No hardware test has been performed. Static syntax and simulated config/sync tests passed, but a live controlled test and extended uptime observation remain necessary.
  * The historical XIO/display-session error may be a separate compositor/touchscreen problem that this patch cannot fully resolve.
  * The original backend includes a hard-coded SMTP password; rotate and relocate this secret. Never upload unencrypted production code to public GitHub.

File layout on Pi:
  Put Fin_Performance_V1.patch and fin_performance_v1_apply.sh in the same directory, e.g. /home/pi/fin_performance_v1/
  Then:
    cd /home/pi/fin_performance_v1
    bash fin_performance_v1_apply.sh --check
    # review output
    bash fin_performance_v1_apply.sh --apply

Validation checklist after maintenance restart:
  [ ] kiosk starts, touch registers on first interaction
  [ ] selection and price-check grids, side-panel switching
  [ ] administrator login, editor, reservation input keyboard
  [ ] backend config change (price/enable) applies, unchanged config does not thrash
  [ ] ESP32 online status / events, item-door controls, recoverability
  [ ] POS readiness, payment purchase and receipt printer (controlled tests)
  [ ] remote item changes and module status, fiscalisation (if enabled)
  [ ] 24–48 hour uptime + touchscreen response observation (recommended)
