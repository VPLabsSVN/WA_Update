#!/usr/bin/env bash
# Fin Performance V1 — guarded staged patch for live Pi.
# DEFAULT (or --check) is read-only and checks syntax and expected file versions.
# --apply is an explicit, no-restart installation. Schedule while kiosk idle.
set -euo pipefail
umask 077

MODE="${1:---check}"
APPDIR="${APPDIR:-/home/wa_stopshop_mb/WA/Main_program/Fis}"
PATCH_FILE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/Fin_Performance_V1.patch"
PANEL_SHA="8fcb2f4f0858583205d24935a56e5197bfe92a7d46bb4c0d86b09c5804d8a4f5"
BACKEND_SHA="2b408cea669f68d91f19b79129e0ae9ecac16cd3f37ba6081d9db64c03e3889e"
PATCH_SHA="daa8c4d4d966017777852efd339d3726f3c3ad5ada485391aeecfa6617acf66f"

if [[ "$MODE" != "--check" && "$MODE" != "--apply" ]]; then
  echo "Usage: bash $0 [--check|--apply]" >&2
  exit 2
fi
command -v git >/dev/null 2>&1 || { echo "git command missing"; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "python3 command missing"; exit 1; }
[[ -f "$PATCH_FILE" ]] || { echo "Patch file missing: $PATCH_FILE"; exit 1; }
[[ -f "$APPDIR/Panel.py" && -f "$APPDIR/Panel_backend_merged.py" ]] || {
  echo "Live source file(s) missing in $APPDIR"; exit 1; }

echo "$PATCH_SHA  $PATCH_FILE" | sha256sum -c --status || {
  echo "Patch checksum mismatch; aborting"; exit 1;
}
echo "$PANEL_SHA  $APPDIR/Panel.py" | sha256sum -c --status || {
  echo "Panel.py differs from original Fin snapshot; do not patch blindly"; exit 1;
}
echo "$BACKEND_SHA  $APPDIR/Panel_backend_merged.py" | sha256sum -c --status || {
  echo "Panel_backend_merged.py differs from original Fin snapshot; do not patch blindly"; exit 1;
}
TMP="$(mktemp -d "$HOME/.fin_patch_check.XXXXXXXX")"
trap 'rm -rf -- "$TMP"' EXIT
cp -- "$APPDIR/Panel.py" "$APPDIR/Panel_backend_merged.py" "$TMP/"
(cd "$TMP" && git apply --check "$PATCH_FILE" && git apply "$PATCH_FILE")
python3 - "$TMP" <<'PY'
import ast
import pathlib
import sys
for name in ("Panel.py", "Panel_backend_merged.py"):
    path = pathlib.Path(sys.argv[1]) / name
    ast.parse(path.read_text(encoding="utf-8"), filename=name)
    print(f"Python syntax verified: {name}")
PY
echo "Version checks, patch applicability, and Python syntax: PASS"

if [[ "$MODE" == "--check" ]]; then
  echo "DRY RUN complete. Nothing on Fin has changed."
  exit 0
fi

[[ -w "$APPDIR" && -w "$APPDIR/Panel.py" && -w "$APPDIR/Panel_backend_merged.py" ]] || {
  echo "No write permission for app files. Nothing changed."; exit 1;
}
echo
echo "You requested --apply. This updates TWO production Python files."
echo "It will NOT restart the kiosk, payments, ESP32, or remote recovery."
echo "Proceed only when Fin is idle (no customer checkout in progress)."
read -r -p 'Type APPLY-FIN-V1 to continue: ' ANSWER
[[ "$ANSWER" == "APPLY-FIN-V1" ]] || { echo "Cancelled"; exit 1; }

STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$HOME/fin_performance_backups/$STAMP"
mkdir -p -- "$BACKUP"
chmod 700 "$HOME/fin_performance_backups" "$BACKUP"
cp -p -- "$APPDIR/Panel.py" "$APPDIR/Panel_backend_merged.py" "$BACKUP/"
printf 'Pre-update backup: %s\n' "$BACKUP"

# Prepare both replacement files on same filesystem for atomic per-file rename.
PANEL_STAGE="$APPDIR/.Panel.py.fin-v1.$$"
BACKEND_STAGE="$APPDIR/.Panel_backend_merged.py.fin-v1.$$"
trap 'rm -f -- "$PANEL_STAGE" "$BACKEND_STAGE"; rm -rf -- "$TMP"' EXIT
cp -- "$TMP/Panel.py" "$PANEL_STAGE"
cp -- "$TMP/Panel_backend_merged.py" "$BACKEND_STAGE"
chmod --reference="$APPDIR/Panel.py" "$PANEL_STAGE"
chmod --reference="$APPDIR/Panel_backend_merged.py" "$BACKEND_STAGE"
# No running process is restarted; running Python retains imported code until next launch.
mv -f -- "$PANEL_STAGE" "$APPDIR/Panel.py"
mv -f -- "$BACKEND_STAGE" "$APPDIR/Panel_backend_merged.py"
echo "PATCH APPLIED; neither program nor service was restarted."
echo "Backup path: $BACKUP"
echo
echo "Review the logs, then schedule a maintenance restart when safe:"
echo "  systemctl --user restart bouquetmat.service"
echo "If rollback is required, copy both backup files back before restarting:"
echo "  cp -p '$BACKUP/Panel.py' '$APPDIR/Panel.py'"
echo "  cp -p '$BACKUP/Panel_backend_merged.py' '$APPDIR/Panel_backend_merged.py'"
echo "  systemctl --user restart bouquetmat.service"
