#!/usr/bin/env python3
"""Offline tests: no network or ESP mutation."""
import tempfile
import time
import json
from pathlib import Path
import wa_majoska_r3_v13 as v13
import wa_majoska_bridge_overlay_v13 as overlay
import wa_majoska_r3_watchdog_v13 as wd


def sample():
    m={'type':'remote_motor_ack','ok':True,'boot_id':88,'global_fault':False,
       'pending_wait_open_mask':0,'pending_wait_close_mask':0,'motors':[
       {'motor':10,'fault_latched':False,'fault_reason':0,'tmc_drv_status':0x110000,'encoder_deg':54},
       {'motor':7,'fault_latched':True,'fault_reason':4,'tmc_drv_status':0x110000,'encoder_deg':123.2}]}
    r={'type':'recovery_ack','ok':True,'boot_id':88,'firmware':'old-label-retained',
       'encoder_bus_errors':6825,'mutex_timeout_count':0,'token':'should_never_leak',
       'motor_hardware_ready':True}
    return m,r


def run():
    m,r=sample()
    root=Path(tempfile.mkdtemp(prefix='test_majoska_v13_'))
    v13.POLL=root/'poll.json';v13.GOOD=root/'good.json';v13.EVENTS=root/'events.jsonl'
    oldendpoint,oldrpc=wd.endpoint,wd.rpc
    wd.endpoint=lambda:('pi','ip',48556,'private')
    wd.rpc=lambda ep,action: dict(m if action=='remote_motor_status' else r)
    old_once=v13.pending.once
    v13.pending.once=lambda **kwargs:None
    try:
        t=v13.poll()
        assert t['ok'] and t['summary']['motor_rows'][1]['fault_reason']==4
        raw=json.loads(v13.GOOD.read_text())
        assert raw['motor_status']['motors'][1]['encoder_deg']==123.2
        assert raw['recovery_status']['encoder_bus_errors']==6825
        assert raw['recovery_status']['token']=='[REDACTED]'
        health={'1':{'issues':[],'sensors_online':2}}
        out=overlay.enrich(health, poll=raw, good=raw, now=raw['at_epoch']+1)
        assert out['1']['r3_motors_full'][1]['fault_reason']==4
        assert any(x['code']=='R3_MOTOR_7_FAULT_4' for x in out['1']['issues'])
        # An unresolved customer cycle must warn; never trigger a door action.
        t2=json.loads(json.dumps(raw));t2['summary']['pending_wait_open_mask']=1
        out=overlay.enrich({'1':{'issues':[]}},poll=t2,good=t2,now=t2['at_epoch']+1)
        assert any(x['code']=='R3_WAIT_OPEN' for x in out['1']['issues'])
        # Firmware label and all readback flags are independent: incomplete old telemetry fails closed.
        assert wd.safe_snapshot({'firmware':'old-label-retained','boot_id':88}) is not None
        assert wd.candidates({'firmware':'old-label-retained','boot_id':88,'motors':[{'motor':7},{'motor':10}]})[0]==[]
        # Poll still preserves received data if firmware does not expose an identity field.
        r.pop('firmware');t=v13.poll()
        assert t['ok'] and t['summary']['recovery_status_contract_complete'] is False
        assert json.loads(v13.GOOD.read_text())['recovery_status']['encoder_bus_errors']==6825
        r['boot_id']=99;t=v13.poll()
        assert not t['ok'];assert v13.POLL.exists()
        print('PASS: full telemetry R7/R10 + bridge issue output + pending + old firmware label + secret redaction')
        print('PASS: missing firmware retained for reporting but blocked from safe recovery')
        print('PASS: boot mismatch rejected; no remote recovery/door/pending clear executed')
    finally:
        wd.endpoint,wd.rpc=oldendpoint,oldrpc
        v13.pending.once=old_once

if __name__=='__main__':run()
