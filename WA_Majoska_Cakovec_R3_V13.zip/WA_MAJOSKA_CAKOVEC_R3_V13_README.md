# WA Majoska / Čakovec R3 V13 — full bridge reporting and guarded watchdog

## Scope

**Only** Majoska/Cakovec Raspberry Pi, panel ID `Majoska`, panel name `Cakovec`,
Pi 192.168.1.100, R3 ESP 192.168.1.201:48556, UDP status broadcasts 48557,
root `/home/wa_stopshop_mb/WA/Main_program/Fis`. The original bridge's SHT3x
listener, other controllers, remote operator recovery, purchase screen, payment,
Croatian fiscalization and inventory code are preserved.

This builds on the V12 guarded 1–7 fault watchdog (it uses the existing recovery
opcode) and adds an **authenticated full-status polling sidecar** for the older
Majoska `wa_module_health_bridge.py`. It does NOT copy the other machine's
entire `Panel.py` or replace Majoska's hardware mapping.

## What gets reported

Every ~150 seconds a correlated pair of authenticated `remote_motor_status` and
`remote_recovery_status` replies is requested. The full sanitized responses are
stored locally in:

- `wa_majoska_r3_v13_latest_poll.json`: latest attempt, including failures.
- `wa_majoska_r3_v13_latest_good.json`: last successful matched-boot pair.
- `wa_majoska_r3_v13_events.jsonl`: bounded summary/event history.
- `wa_majoska_r3_pending_v13_state.json` and `_events.jsonl`: pending-cycle history.

A small wrapper attached to the existing `ModuleHealthBridge.heartbeat_health()`
adds full controller and motor diagnostics under the existing module position
`"1"`. The underlying `wa_module_health_bridge.py` sensor and recovery functions
are not overwritten. New fields include `r3_controller_status_full`,
`r3_recovery_controller_full`, `r3_motors_full`, `r3_boot_id`, `r3_firmware`,
`r3_global_fault`, `r3_pending_wait_open_mask`, `r3_pending_wait_close_mask`,
`r3_encoder_bus_errors`, `r3_mutex_timeout_count`, and issue descriptions.
Other module positions remain unchanged.

This makes all fields exposed by the ESP's **existing** status replies available
in the local snapshot and backend `component_statuses.module_health["1"]`.
It does NOT invent fields that older ESP firmware never sends. The backend or
Android app may need a separate schema/UI update to display every new key.

## Recovery policy

`--install` starts MONITOR ONLY. `--enable-extended` switches to guarded automatic
recovery **requests** for latched faults 1,2,3,4,5,6,7, using the existing
`remote_motor_recover` command.

All automatic commands are gated by: correlated fresh status and two matching
snapshots, an actual idle kiosk heartbeat (Home >180s, paid sale >600s),
no payments/admin activity, no global fault, no pending access, closed doors,
verified ENN disabled and STEP stopped, readback and TMC safety by fault class,
no exhaustion of ESP recovery budget, and persistent Pi rate limiting of **at most
one attempt/hour and two attempts/day per motor**. Failed/ambiguous ACK does not
cause a second command in the same attempt. The ESP can still reject the action.

The V13 compatibility check is **firmware-label independent** (the complete
hardware/status contract must still be present). Older ESP firmware may lack
required fields or demand physical inspection for faults 2/4/6/7; in either
case V13 will **monitor** but not falsely claim those faults cleared. The Pi
never sets `inspected_hardware=true` for a new fault without a real inspection.

**Global faults never clear automatically.** Unfinished WAIT_OPEN/WAIT_CLOSE
cycles are watched and reported with reboot/age escalation; no Pi-side pending
clear and no post-pulse re-opening. The ESP's existing verified expiry logic
may clear fresh pending states. A closed-door switch or timeout is not proof
that a prior customer unlock never occurred.

Purchase-time 5-try logic is **not part of this package**; Majoska's installed
purchase logic is unchanged. This package is independent from POS/FURS.

## Installation: preparation (do not skip the read-only check)

Upload ZIP `WA_Majoska_Cakovec_R3_V13.zip` to the `VPLabsSVN/WA_Update` repo,
branch main, then on **MAJOSKA** Raspberry Pi:

```bash
cd /home/wa_stopshop_mb/WA/Main_program/Fis
curl -fL --retry 3 'https://raw.githubusercontent.com/VPLabsSVN/WA_Update/main/WA_Majoska_Cakovec_R3_V13.zip' -o WA_Majoska_Cakovec_R3_V13.zip
unzip -o WA_Majoska_Cakovec_R3_V13.zip
./venv/bin/python wa_majoska_r3_watchdog_v13.py --self-test
./venv/bin/python wa_majoska_r3_pending_v13.py --self-test
./venv/bin/python wa_majoska_r3_v13.py --self-test
./venv/bin/python wa_majoska_v13_install.py --self-test
./venv/bin/python test_majoska_r3_v13.py
./venv/bin/python wa_majoska_v13_install.py --check
```

If `--check` refuses a site identity or code anchor, STOP: do not copy another
machine's bridge or bypass this check. V13 must preserve your existing private
`pi_recovery_endpoints.json`; this ZIP contains no tokens.

## Install bridge and read-only timer (during a quiet maintenance window)

Wait until the kiosk has no active customer payment, purchase, or open door.
Then:

```bash
systemctl --user stop bouquetmat.service
./venv/bin/python wa_majoska_v13_install.py --install
systemctl --user start bouquetmat.service
systemctl --user is-active bouquetmat.service
```

`--install` saves exact bridge and backend backups under
`wa_majoska_v13_backups/YYYYMMDD_HHMMSS/`, applies a tiny bridge wrapper and the
same idle heartbeat used in V12, and installs **new, separate** systemd units
`wa-majoska-r3-v13.service` and `.timer`. It refuses to install if an existing
`wa-r3-watchdog.timer` is active, preventing competing automatic recovery.
No code is changed in `Panel.py`, fiscalization, POS or receipt processing.

## Read-only telemetry verification

```bash
./venv/bin/python wa_majoska_r3_v13.py --once
./venv/bin/python wa_majoska_v13_install.py --status
./venv/bin/python wa_majoska_r3_v13.py --last
systemctl --user list-timers --all wa-majoska-r3-v13.timer
journalctl --user -u wa-majoska-r3-v13.service --since '30 minutes ago' --no-pager -l | tail -80
```

Check `wa_majoska_r3_v13_latest_good.json` for the *actual* ESP fields. The
status query should not require physical inspection.

## Enable fault 1..7 watchdog

After kiosk startup, let Home be idle >180s with no paid sale for >600s, then:

```bash
./venv/bin/python wa_majoska_v13_install.py --enable-extended
systemctl --user show -p ExecStart wa-majoska-r3-v13.service
```

This must show `wa_majoska_r3_v13.py --once --auto-recover --extended-auto`.
The enable script tests fresh authenticated status + actual idle heartbeat +
all controller safety fields. If the machine still runs older firmware with
missing readback fields, **do not remove those checks**: read-only monitoring
still works and logs why recovery is unavailable.

For monitor-only mode:

```bash
./venv/bin/python wa_majoska_v13_install.py --stage
```

## Roll back

Wait for all customer/POS activity to finish; stop the kiosk first:

```bash
systemctl --user stop bouquetmat.service
./venv/bin/python wa_majoska_v13_install.py --rollback
systemctl --user start bouquetmat.service
```

The rollback refuses to overwrite bridge/backend files if another change was
made after installation. Review the saved backup first in that case.

## Testing limits

The included Python tests are offline simulations, not proof of actual motor
recovery or of controller safety. No command was sent to Majoska during package
creation. Confirm that the older ESP supports both authenticated status
commands; if it does not, V13 records the error and refuses motor recovery.
