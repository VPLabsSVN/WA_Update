#!/usr/bin/env python3
"""Non-invasive Majoska bridge enhancement: pass complete latest R3 telemetry.

Appends one wrapper to ModuleHealthBridge.heartbeat_health. It does not
replace existing SHT3x listeners or remote maintenance/recovery methods.
"""
from __future__ import annotations
import json
import time
from pathlib import Path

HERE=Path(__file__).resolve().parent
POLL=HERE/'wa_majoska_r3_v13_latest_poll.json'
GOOD=HERE/'wa_majoska_r3_v13_latest_good.json'
MARK='WA_MAJOSKA_V13_BRIDGE_APPLIED'


def load(p):
    try:return json.loads(p.read_text(encoding='utf-8'))
    except (OSError,ValueError):return None


def enrich(health, poll=None, good=None, now=None):
    if not isinstance(health,dict):return health
    now=time.time() if now is None else now
    poll=load(POLL) if poll is None else poll
    good=load(GOOD) if good is None else good
    row=health.get('1',health.get(1))
    if not isinstance(row,dict):return health
    issues=row.get('issues')
    if not isinstance(issues,list):issues=[];row['issues']=issues
    existing={x.get('code') for x in issues if isinstance(x,dict)}
    def issue(code,title,detail,sev='warning'):
        if code not in existing:
            issues.append({'code':code,'title':title,'description':detail,
                           'severity':sev,'requires_inspection':False})
            existing.add(code)
    if not isinstance(poll,dict):
        issue('R3_POLL_NOT_STARTED','R3 diagnostic poll unavailable','The full recovery watchdog has not yet written a status snapshot.')
        return health
    age=now-float(poll.get('at_epoch',0))
    row['r3_last_poll_age_s']=round(age,1)
    row['r3_poll_ok']=poll.get('ok') is True and 0<=age<=360
    if not row['r3_poll_ok']:
        issue('R3_POLL_STALE','Full R3 diagnostics unavailable','Last authenticated poll missing, failed or more than 6 minutes old.')
    if not isinstance(good,dict):return health
    good_age=now-float(good.get('at_epoch',0))
    if good.get('ok') is not True or not 0<=good_age<=360:return health
    summary=good.get('summary') or {}
    row['r3_full_status_at']=good.get('at_epoch')
    row['r3_full_status_age_s']=round(good_age,1)
    row['r3_firmware']=summary.get('firmware')
    row['r3_boot_id']=summary.get('boot_id')
    row['r3_global_fault']=summary.get('global_fault')
    row['r3_pending_wait_open_mask']=summary.get('pending_wait_open_mask')
    row['r3_pending_wait_close_mask']=summary.get('pending_wait_close_mask')
    row['r3_encoder_bus_errors']=summary.get('encoder_bus_errors')
    row['r3_mutex_timeout_count']=summary.get('mutex_timeout_count')
    row['r3_motors_full']=good.get('motor_status',{}).get('motors',[])
    row['r3_recovery_controller_full']=good.get('recovery_status',{})
    row['r3_controller_status_full']=good.get('motor_status',{})
    if summary.get('global_fault') is True:
        issue('R3_GLOBAL_FAULT','R3 global fault','Automatic recovery is disabled during a global fault.','error')
    for key,label in (('pending_wait_open_mask','WAIT_OPEN'),('pending_wait_close_mask','WAIT_CLOSE')):
        val=summary.get(key)
        if type(val) is int and val:
            issue('R3_'+label,'Customer door cycle unfinished',f'{label} mask={val}; delivery must be reconciled before another unlock.','error')
    for m in summary.get('motor_rows',[]):
        code=m.get('fault_reason')
        if m.get('fault_latched') is True:
            issue('R3_MOTOR_%s_FAULT_%s'%(m.get('motor'),code),
                  'R%s motor fault %s'%(m.get('motor'),code),
                  'R3 motor fault latched; watchdog may request controller-authorized recovery when safe.','error')
    return health


def install_bridge_overlay(cls):
    if getattr(cls,MARK,False):return
    previous=cls.heartbeat_health
    def heartbeat_health(self,*args,**kwargs):
        original=previous(self,*args,**kwargs)
        try:return enrich(original)
        except Exception as exc:
            print('[MAJOSKA R3 V13] health overlay warning:',type(exc).__name__,str(exc)[:120])
            return original
    cls.heartbeat_health=heartbeat_health
    setattr(cls,MARK,True)
