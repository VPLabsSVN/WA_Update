#!/usr/bin/env python3
"""Majoska/Cakovec-only guarded R3 telemetry/watchdog installer.

--check: offline compatibility and exact site identity, no modification
--install: requires kiosk stopped; backs up bridge/backend; adds status overlay,
           installs idle hook and monitor-only 150s timer; never edits payments.
--enable-extended: requires fresh safe authenticated status + verified kiosk idle,
                   then enables watchdog attempts for fault codes 1..7.
--stage: monitor-only timer (disable all unattended recovery requests)
--rollback: stop V13 timer and restore original bridge/backend and unit files.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
import wa_majoska_r3_watchdog_v13 as wd

ROOT=Path(__file__).resolve().parent
BRIDGE=ROOT/'wa_module_health_bridge.py'
BACKEND=ROOT/'Panel_backend_merged.py'
CONFIG=ROOT/'pi_recovery_endpoints.json'
PYTHON=ROOT/'venv/bin/python'
STATE=ROOT/'wa_majoska_r3_v13_install_state.json'
HOME=Path.home()
USER_UNITS=HOME/'.config/systemd/user'
UNIT='wa-majoska-r3-v13.service'
TIMER='wa-majoska-r3-v13.timer'
OVERRIDE=USER_UNITS/(UNIT+'.d')/'auto.conf'
B_MARK_START='# WA_MAJOSKA_V13_BRIDGE_BEGIN'
B_MARK_END='# WA_MAJOSKA_V13_BRIDGE_END'
PATCH='''# WA_MAJOSKA_V13_BRIDGE_BEGIN
from wa_majoska_bridge_overlay_v13 import install_bridge_overlay as _wa_majoska_v13_install_overlay
_wa_majoska_v13_install_overlay(ModuleHealthBridge)
# WA_MAJOSKA_V13_BRIDGE_END
'''


def systemctl(*args,check=True):
    p=subprocess.run(['systemctl','--user',*args],capture_output=True,text=True)
    if check and p.returncode:
        raise RuntimeError('systemctl '+ ' '.join(args)+': '+(p.stderr or p.stdout)[:200])
    return (p.stdout or '').strip()


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def write_atomic(p,data,mode=0o600):
    p.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.majoska_install_',dir=str(p.parent))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data if isinstance(data,bytes) else data.encode('utf-8'))
            f.flush();os.fsync(f.fileno())
        os.chmod(tmp,mode);os.replace(tmp,p)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def require_site():
    for p in (BRIDGE,BACKEND,CONFIG,PYTHON,ROOT/'wa_majoska_r3_v13.py',ROOT/'wa_majoska_bridge_overlay_v13.py',ROOT/'wa_majoska_r3_pending_v13.py',ROOT/'wa_majoska_r3_watchdog_v13.py'):
        if not p.is_file():raise RuntimeError('Required file missing: '+str(p))
    src=BACKEND.read_text(encoding='utf-8')
    # Reject operating on the separate newly deployed machine.
    if not ('BACKEND_PANEL_ID_OVERRIDE = "Majoska"' in src and
            'BACKEND_PANEL_NAME_OVERRIDE = "Cakovec"' in src):
        raise RuntimeError('This is not the verified Majoska/Cakovec backend identity; no changes made')
    cfg=json.loads(CONFIG.read_text(encoding='utf-8'))
    if cfg.get('pi_ip')!='192.168.1.100':
        raise RuntimeError('Incorrect Pi management source for Majoska')
    ep=cfg.get('controllers',{}).get('r3',{})
    if (ep.get('ip')!='192.168.1.201' or ep.get('protocol')!='r3_motor_recovery'
        or int(ep.get('port') or 0)!=48556 or
        not isinstance(ep.get('token'),str) or len(ep['token'])<24):
        raise RuntimeError('R3 config incomplete/wrong target; preserve existing private token')
    source=BRIDGE.read_text(encoding='utf-8')
    if 'class ModuleHealthBridge' not in source or 'def heartbeat_health' not in source:
        raise RuntimeError('Cannot identify old module health bridge')
    if (B_MARK_START in source)!=(B_MARK_END in source):
        raise RuntimeError('Bridge marker partially installed; manual review required')
    # Confirm safe transformation can parse/compile before applying.
    proposed=bridge_transform(source)
    ast.parse(proposed);compile(proposed,str(BRIDGE),'exec')
    if not (wd.START in src and wd.END in src):
        wd.hook_transform(src,install=True)
    else:
        if src.count(wd.START)!=1 or src.count(wd.END)!=1:
            raise RuntimeError('Partial idle hook; manual review required')
    return {'pi_ip':cfg['pi_ip'],'r3':ep['ip']+':'+str(ep['port']),
            'bridge_patch':'already' if B_MARK_START in source else 'ready',
            'idle_hook':'already' if wd.START in src else 'ready'}


def bridge_transform(source):
    if B_MARK_START in source and B_MARK_END in source:return source
    # Append only; no replacement of the bridge's listeners or recovery methods.
    return source.rstrip()+'\n\n'+PATCH


def install():
    info=require_site()
    if STATE.exists():
        raise RuntimeError('V13 installation state exists; use --status or --rollback')
    if systemctl('is-active','bouquetmat.service',check=False)=='active':
        raise RuntimeError('Stop bouquetmat.service AFTER the last payment/door operation before --install')
    if systemctl('is-active','wa-r3-watchdog.timer',check=False)=='active':
        raise RuntimeError('Another R3 watchdog is active. Stop/resolve it to avoid competing recovery')
    for filename in (UNIT,TIMER):
        if (USER_UNITS/filename).exists():
            raise RuntimeError('V13 unit already exists without installation record: '+filename)
    orig_bridge=BRIDGE.read_bytes();orig_backend=BACKEND.read_bytes()
    new_bridge=bridge_transform(orig_bridge.decode('utf-8'))
    new_backend,_=wd.hook_transform(orig_backend.decode('utf-8'),install=True)
    compile(new_backend,str(BACKEND),'exec')
    folder=ROOT/'wa_majoska_v13_backups'/time.strftime('%Y%m%d_%H%M%S')
    folder.mkdir(parents=True,exist_ok=False)
    shutil.copy2(BRIDGE,folder/BRIDGE.name)
    shutil.copy2(BACKEND,folder/BACKEND.name)
    state={'version':13,'backup':str(folder),'original_bridge_sha256':hashlib.sha256(orig_bridge).hexdigest(),
           'original_backend_sha256':hashlib.sha256(orig_backend).hexdigest(),
           'previous_timer_active':False}
    try:
        write_atomic(BRIDGE,new_bridge,BRIDGE.stat().st_mode & 0o777)
        write_atomic(BACKEND,new_backend,BACKEND.stat().st_mode & 0o777)
        subprocess.run([str(PYTHON),'-m','py_compile',str(BRIDGE),str(BACKEND)],check=True)
        state['installed_bridge_sha256']=sha(BRIDGE)
        state['installed_backend_sha256']=sha(BACKEND)
        USER_UNITS.mkdir(parents=True,exist_ok=True)
        for filename in (UNIT,TIMER):
            shutil.copy2(ROOT/filename,USER_UNITS/filename)
        write_atomic(OVERRIDE,make_override(False))
        systemctl('daemon-reload')
        systemctl('enable','--now',TIMER)
        write_atomic(STATE,json.dumps(state,indent=2))
    except Exception:
        shutil.copy2(folder/BRIDGE.name,BRIDGE)
        shutil.copy2(folder/BACKEND.name,BACKEND)
        for filename in (UNIT,TIMER):
            (USER_UNITS/filename).unlink(missing_ok=True)
        OVERRIDE.unlink(missing_ok=True)
        systemctl('daemon-reload',check=False)
        raise
    print('INSTALLED: Majoska/Cakovec V13 bridge overlay + safe idle hook')
    print('BACKUP:',folder)
    print('TIMER: active, MONITOR ONLY; next reboot of kiosk loads bridge change')
    print('NEXT: systemctl --user start bouquetmat.service (verify kiosk and heartbeat)')
    return 0


def make_override(extended):
    args='--once'+(' --auto-recover --extended-auto' if extended else '')
    return ('[Service]\nExecStart=\n'
        f'ExecStart={PYTHON} {ROOT/"wa_majoska_r3_v13.py"} {args}\n'
        'TimeoutStartSec=125\n')


def change(extended):
    require_site()
    if not STATE.exists():raise RuntimeError('V13 is not installed')
    if extended:
        info=wd.status(wd.endpoint())
        unsafe=wd.safe_snapshot(info)
        if unsafe:raise RuntimeError('ESP status not safe/complete; extended recovery refused: '+unsafe)
        idle,reason=wd.kiosk_idle()
        if not idle:raise RuntimeError('Kiosk is not positively idle: '+reason)
        print('VERIFIED: correlated ESP state and positive idle kiosk; version label not used as authorization')
    systemctl('stop',TIMER)
    if systemctl('show','-p','ActiveState','--value',UNIT) not in ('inactive','failed'):
        systemctl('start',TIMER,check=False)
        raise RuntimeError('Watchdog still active; try after it completes')
    write_atomic(OVERRIDE,make_override(extended))
    systemctl('daemon-reload')
    systemctl('start',TIMER)
    print('UPDATED:', 'guarded auto-recovery faults 1..7' if extended else 'monitor-only', '(ESP may reject)')
    print('ExecStart:',systemctl('show','-p','ExecStart','--value',UNIT))
    return 0


def rollback():
    if not STATE.is_file():raise RuntimeError('No V13 installation state found')
    info=json.loads(STATE.read_text(encoding='utf-8'));folder=Path(info['backup'])
    for p in (folder/BRIDGE.name,folder/BACKEND.name):
        if not p.is_file():raise RuntimeError('Backup incomplete: '+str(p))
    if systemctl('is-active','bouquetmat.service',check=False)=='active':
        raise RuntimeError('Stop bouquetmat.service when idle before restoring old bridge')
    systemctl('disable','--now',TIMER,check=False)
    systemctl('stop',UNIT,check=False)
    for target,key in ((BRIDGE,'installed_bridge_sha256'),(BACKEND,'installed_backend_sha256')):
        if target.is_file() and sha(target)!=info[key]:
            raise RuntimeError('File changed after V13 install; refusing to overwrite: '+str(target))
    shutil.copy2(folder/BRIDGE.name,BRIDGE)
    shutil.copy2(folder/BACKEND.name,BACKEND)
    for file in (USER_UNITS/UNIT,USER_UNITS/TIMER,OVERRIDE):file.unlink(missing_ok=True)
    systemctl('daemon-reload')
    STATE.unlink()
    print('ROLLED BACK bridge/backend and V13 timer; restart bouquetmat.service manually')
    return 0


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    g=p.add_mutually_exclusive_group(required=True)
    for name in ('check','install','enable-extended','stage','rollback','status','self-test'):
        g.add_argument('--'+name,action='store_true')
    a=p.parse_args(argv)
    try:
        if a.self_test:
            src='class ModuleHealthBridge:\n    def heartbeat_health(self): return {"1": {"issues": []}}\n'
            assert bridge_transform(bridge_transform(src))==bridge_transform(src)
            ast.parse(bridge_transform(src))
            assert '--extended-auto' in make_override(True)
            assert '--auto-recover' not in make_override(False)
            print('PASS: bridge append is idempotent; full telemetry wrapper; read-only default; guarded extended mode')
            return 0
        if a.check:
            print('SITE/FILES:',json.dumps(require_site(),indent=2))
            print('READ-ONLY: no changes or network actions; reboot/paid flow unaffected')
            return 0
        if a.install:return install()
        if a.enable_extended:return change(True)
        if a.stage:return change(False)
        if a.rollback:return rollback()
        if a.status:
            print('CONFIG:',json.dumps(require_site(),indent=2))
            print('INSTALLED:',STATE.exists(),'TIMER:',systemctl('is-active',TIMER,check=False))
            print('SERVICE:',systemctl('show','-p','ExecStart','--value',UNIT,check=False))
            print('IDLE:',wd.kiosk_idle()[1])
            return 0
    except (OSError,ValueError,RuntimeError,subprocess.CalledProcessError,TimeoutError) as exc:
        print('STOP:',type(exc).__name__,str(exc),file=sys.stderr)
        return 3

if __name__=='__main__':raise SystemExit(main())
