#!/usr/bin/env python3
"""Majoska/Cakovec V14 bridge + continuous UDP V8.1 telemetry + V13 watchdog.

--install installs both telemetry paths and starts the 150s timer with
--auto-recover --extended-auto ALREADY enabled. This does not bypass the
watchdog's positive idle requirement, ESP interlocks, controller refusals,
per-motor limits, or global/pending/customer safeguards.

Keep the original Pi recovery token, module mappings, payment, FURS, inventory,
ESP source and other modules untouched. No network operations during install.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
import wa_majoska_r3_watchdog_v14 as wd

ROOT=Path(__file__).resolve().parent
BRIDGE=ROOT/'wa_module_health_bridge.py'
BACKEND=ROOT/'Panel_backend_merged.py'
CONFIG=ROOT/'pi_recovery_endpoints.json'
PYTHON=ROOT/'venv/bin/python'
STATE=ROOT/'wa_majoska_r3_v14_install_state.json'
PREV_STATE=ROOT/'wa_majoska_r3_v13_install_state.json'
UNIT='wa-majoska-r3-v14.service'
TIMER='wa-majoska-r3-v14.timer'
USER_UNITS=Path.home()/'.config/systemd/user'
OVERRIDE=USER_UNITS/(UNIT+'.d')/'policy.conf'
BRIDGE_START='# WA_MAJOSKA_V14_BRIDGE_BEGIN'
BRIDGE_END='# WA_MAJOSKA_V14_BRIDGE_END'
UDP_START='# WA_MAJOSKA_V14_UDP_BEGIN'
UDP_END='# WA_MAJOSKA_V14_UDP_END'
APPEND='''# WA_MAJOSKA_V14_BRIDGE_BEGIN
from wa_majoska_bridge_overlay_v14 import install_bridge_overlay as _wa_majoska_v14_install_overlay
_wa_majoska_v14_install_overlay(ModuleHealthBridge)
# WA_MAJOSKA_V14_BRIDGE_END
'''


def systemctl(*args,check=True):
    p=subprocess.run(['systemctl','--user',*args],capture_output=True,text=True)
    if check and p.returncode:
        raise RuntimeError('systemctl '+' '.join(args)+': '+(p.stderr or p.stdout)[:200])
    return (p.stdout or '').strip()


def atomic_write(p,data,mode=0o600):
    p.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.majoska_v14_',dir=str(p.parent))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data if isinstance(data,bytes) else data.encode('utf-8'))
            f.flush();os.fsync(f.fileno())
        os.chmod(tmp,mode);os.replace(tmp,p)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def bridge_transform(source):
    markers=[BRIDGE_START,BRIDGE_END,UDP_START,UDP_END]
    counts=[source.count(x) for x in markers]
    if counts==[1,1,1,1]:return source
    if counts != [0,0,0,0]:
        raise RuntimeError('Bridge contains partial/duplicate V14 markers; no changes made')
    if '# WA_MAJOSKA_V13_BRIDGE_BEGIN' in source:
        raise RuntimeError('V13 bridge overlay present; rollback V13 before installing V14')
    tree=ast.parse(source)
    classes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ModuleHealthBridge']
    if len(classes)!=1:raise RuntimeError('Exactly one ModuleHealthBridge required')
    listeners=[n for n in classes[0].body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name=='_status_listener']
    if len(listeners)!=1:raise RuntimeError('Cannot find one existing _status_listener; refuses to create competing UDP 48557 socket')
    nodes=[n for n in ast.walk(listeners[0]) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ptype' for t in n.targets)]
    if len(nodes)!=1 or nodes[0].lineno is None or nodes[0].end_lineno is None:
        raise RuntimeError('Cannot identify verified r3_motor_status packet classification')
    line=node_line=source.splitlines(keepends=True)[nodes[0].lineno-1]
    if not ('ptype' in line and 'packet' in line):
        raise RuntimeError('Packet classification differs from supported Majoska bridge')
    # The existing listener must validate source and module position BEFORE
    # forwarding. Never introduce a second UDP listener or accept unknown IPs.
    method_src=''.join(source.splitlines(keepends=True)[listeners[0].lineno-1:listeners[0].end_lineno])
    if ('position_for_ip' not in method_src or 'packet_pos' not in method_src
        or 'expected_pos' not in method_src or 'r3_motor_status' not in method_src):
        raise RuntimeError('Verified IP/position filters missing; refuse UDP forwarding injection')
    indent=re.match(r'\s*',line).group(0)
    chunk=(f'{indent}{UDP_START}\n'
           f'{indent}try:\n'
           f'{indent}    self._wa_majoska_v14_udp_capture(ip, packet)\n'
           f'{indent}except Exception as _wa_v14_exc:\n'
           f'{indent}    print("[MAJOSKA V14] UDP forwarding warning:", type(_wa_v14_exc).__name__)\n'
           f'{indent}{UDP_END}\n')
    lines=source.splitlines(keepends=True)
    lines.insert(nodes[0].end_lineno,chunk)
    result=''.join(lines).rstrip()+'\n\n'+APPEND
    ast.parse(result)
    compile(result,str(BRIDGE),'exec')
    return result


def require_site():
    for p in (BRIDGE,BACKEND,CONFIG,PYTHON,
              ROOT/'wa_majoska_r3_v14.py',ROOT/'wa_majoska_r3_watchdog_v14.py',
              ROOT/'wa_majoska_r3_pending_v14.py',ROOT/'wa_majoska_bridge_overlay_v14.py',
              ROOT/'wa_majoska_bridge_overlay_v14_poll.py',ROOT/UNIT,ROOT/TIMER):
        if not p.is_file():raise RuntimeError('Missing required file: '+str(p))
    if PREV_STATE.exists():
        raise RuntimeError('V13 appears installed: rollback V13 with its installer before installing V14')
    src=BACKEND.read_text(encoding='utf-8')
    if ('BACKEND_PANEL_ID_OVERRIDE = "Majoska"' not in src or
        'BACKEND_PANEL_NAME_OVERRIDE = "Cakovec"' not in src):
        raise RuntimeError('Not verified Majoska/Cakovec panel identity; no modifications')
    cfg=json.loads(CONFIG.read_text(encoding='utf-8'))
    if cfg.get('pi_ip')!='192.168.1.100':
        raise RuntimeError('Wrong Majoska Pi management IP')
    ep=cfg.get('controllers',{}).get('r3',{})
    if (ep.get('ip')!='192.168.1.201' or ep.get('protocol')!='r3_motor_recovery'
        or int(ep.get('port') or 0)!=48556
        or not isinstance(ep.get('token'),str) or len(ep['token'])<24):
        raise RuntimeError('Existing private R3 endpoint token/config missing or wrong')
    source=BRIDGE.read_text(encoding='utf-8')
    new_bridge=bridge_transform(source)
    new_backend,_=wd.hook_transform(src,install=True)
    compile(new_backend,str(BACKEND),'exec')
    # Do NOT print the recovery token or serialise the config in any report.
    return {'panel':'Majoska/Cakovec','controller':'192.168.1.201:48556',
            'token_configured':True,
            'bridge_patch':'installed' if BRIDGE_START in source else 'ready',
            'backend_idle_hook':'installed' if wd.START in src else 'ready',
            'verified_new_bridge_compiles':bool(new_bridge)}


def install():
    info=require_site()
    if STATE.exists():raise RuntimeError('V14 already installed; use --status or --rollback')
    if systemctl('is-active','bouquetmat.service',check=False)=='active':
        raise RuntimeError('Stop bouquetmat.service while idle first; never interrupt customer payment')
    for other in ('wa-r3-watchdog.timer','wa-majoska-r3-v13.timer'):
        if systemctl('is-active',other,check=False)=='active':
            raise RuntimeError('Competing watchdog '+other+' active; stop/resolve before installing')
    for filename in (UNIT,TIMER):
        if (USER_UNITS/filename).exists():
            raise RuntimeError('V14 unit exists but no installation state; manual review required: '+filename)
    old_bridge=BRIDGE.read_bytes();old_backend=BACKEND.read_bytes()
    new_bridge=bridge_transform(old_bridge.decode('utf-8'))
    new_backend,_=wd.hook_transform(old_backend.decode('utf-8'),install=True)
    stamp=time.strftime('%Y%m%d_%H%M%S')
    folder=ROOT/'wa_majoska_v14_backups'/stamp
    folder.mkdir(parents=True,exist_ok=False)
    shutil.copy2(BRIDGE,folder/BRIDGE.name)
    shutil.copy2(BACKEND,folder/BACKEND.name)
    state={'version':14,'backup':str(folder),
           'original_bridge_sha256':hashlib.sha256(old_bridge).hexdigest(),
           'original_backend_sha256':hashlib.sha256(old_backend).hexdigest(),
           'installed_bridge_sha256':None,'installed_backend_sha256':None,
           'extended_recovery_configured_on_install':True}
    try:
        atomic_write(BRIDGE,new_bridge,BRIDGE.stat().st_mode & 0o777)
        atomic_write(BACKEND,new_backend,BACKEND.stat().st_mode & 0o777)
        subprocess.run([str(PYTHON),'-m','py_compile',str(BRIDGE),str(BACKEND)],check=True)
        state['installed_bridge_sha256']=digest(BRIDGE)
        state['installed_backend_sha256']=digest(BACKEND)
        USER_UNITS.mkdir(parents=True,exist_ok=True)
        for name in (UNIT,TIMER):shutil.copy2(ROOT/name,USER_UNITS/name)
        systemctl('daemon-reload')
        systemctl('enable','--now',TIMER)
        atomic_write(STATE,json.dumps(state,indent=2))
    except Exception:
        systemctl('disable','--now',TIMER,check=False)
        systemctl('stop',UNIT,check=False)
        shutil.copy2(folder/BRIDGE.name,BRIDGE)
        shutil.copy2(folder/BACKEND.name,BACKEND)
        for name in (UNIT,TIMER):(USER_UNITS/name).unlink(missing_ok=True)
        systemctl('daemon-reload',check=False)
        raise
    print('INSTALLED: Majoska V14 continuous V8.1 compatible UDP forwarding + full status bridge')
    print('BACKUP:',folder)
    print('WATCHDOG: timer enabled, 150 seconds; recovery 1..7 ALREADY CONFIGURED')
    print('POLICY: fresh idle/safety required for actions, no global/pending clear, no false physical inspection')
    print('NEXT: systemctl --user start bouquetmat.service')
    return 0


def policy(extended):
    if not STATE.exists():raise RuntimeError('V14 is not installed')
    systemctl('stop',TIMER)
    if systemctl('is-active',UNIT,check=False)=='active':
        systemctl('start',TIMER,check=False)
        raise RuntimeError('Running watchdog; change policy only after the current check completes')
    if extended:
        OVERRIDE.unlink(missing_ok=True)
    else:
        text=(f'[Service]\nExecStart=\nExecStart={PYTHON} {ROOT/"wa_majoska_r3_v14.py"} --once\n')
        atomic_write(OVERRIDE,text,0o644)
    systemctl('daemon-reload')
    systemctl('start',TIMER)
    print('POLICY:', 'guarded recovery 1..7 active' if extended else 'monitor-only active')
    print('ExecStart:',systemctl('show','-p','ExecStart','--value',UNIT))
    return 0


def rollback():
    if not STATE.exists():raise RuntimeError('V14 installation state not found')
    if systemctl('is-active','bouquetmat.service',check=False)=='active':
        raise RuntimeError('Stop bouquetmat.service when idle before restoring old bridge')
    st=json.loads(STATE.read_text(encoding='utf-8'))
    folder=Path(st['backup'])
    for n in (BRIDGE.name,BACKEND.name):
        if not (folder/n).is_file():raise RuntimeError('Missing rollback file: '+str(folder/n))
    for target,key in ((BRIDGE,'installed_bridge_sha256'),(BACKEND,'installed_backend_sha256')):
        if target.is_file() and digest(target)!=st[key]:
            raise RuntimeError('File changed since installation; refusing overwrite: '+str(target))
    systemctl('disable','--now',TIMER,check=False)
    systemctl('stop',UNIT,check=False)
    shutil.copy2(folder/BRIDGE.name,BRIDGE)
    shutil.copy2(folder/BACKEND.name,BACKEND)
    for p in (USER_UNITS/UNIT,USER_UNITS/TIMER,OVERRIDE):p.unlink(missing_ok=True)
    systemctl('daemon-reload')
    STATE.unlink()
    print('ROLLED BACK bridge and backend; stopped V14 timer; start kiosk manually')
    return 0


def self_test():
    sample='''class ModuleHealthBridge:
    def _status_listener(self):
        if ip not in self.position_for_ip: return
        expected_pos = self.position_for_ip[ip]
        if packet_pos != expected_pos: return
        ptype = str(packet.get("type") or "")
        if ptype == "r3_motor_status":
            pass
    def heartbeat_health(self): return {"1":{"issues":[]}}
    def send_operator_recovery(self): return "unchanged"
'''
    result=bridge_transform(sample)
    assert bridge_transform(result)==result
    assert '_wa_majoska_v14_udp_capture(ip, packet)' in result
    assert 'send_operator_recovery(self): return "unchanged"' in result
    assert 'r3_motor_status' in result
    assert '--auto-recover --extended-auto' in (ROOT/UNIT).read_text()
    assert 'OnUnitInactiveSec=150s' in (ROOT/TIMER).read_text()
    assert 'inspected=False' in (ROOT/'wa_majoska_r3_watchdog_v14.py').read_text()
    print('PASS: V14 inserts one packet hook into existing filtered UDP listener, no extra socket')
    print('PASS: existing operator recovery untouched, no token changes; 150s extended policy set by default')
    return 0


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group(required=True)
    for mode in ('check','install','status','monitor-only','enable-extended','rollback','self-test'):
        group.add_argument('--'+mode,action='store_true')
    a=parser.parse_args(argv)
    try:
        if a.self_test:return self_test()
        if a.check:
            print('PASS:',json.dumps(require_site(),indent=2))
            print('READ-ONLY: no files changed; extended mode config already in unit file')
            return 0
        if a.install:return install()
        if a.monitor_only:return policy(False)
        if a.enable_extended:return policy(True)
        if a.rollback:return rollback()
        if a.status:
            print('SITE:',json.dumps(require_site(),indent=2))
            print('INSTALLED:',STATE.exists())
            print('TIMER:',systemctl('is-active',TIMER,check=False))
            print('SERVICE:',systemctl('show','-p','ExecStart','--value',UNIT,check=False))
            print('IDLE:',wd.kiosk_idle()[1])
            return 0
    except (OSError,ValueError,RuntimeError,subprocess.CalledProcessError,TimeoutError,SyntaxError) as exc:
        print('STOP:',type(exc).__name__,str(exc),file=sys.stderr)
        return 3

if __name__=='__main__':raise SystemExit(main())
