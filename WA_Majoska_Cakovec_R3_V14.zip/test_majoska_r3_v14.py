#!/usr/bin/env python3
"""Offline V14 integrated telemetry and watchdog tests; no external connections."""
import tempfile
import time
import json
from datetime import datetime
from pathlib import Path
import wa_majoska_bridge_overlay_v14 as bridge
import wa_majoska_bridge_overlay_v14_poll as poll_bridge
import wa_majoska_r3_v14 as main
import wa_majoska_r3_watchdog_v14 as wd
import wa_majoska_v14_install as installer


def test_udp():
    p={'type':'r3_motor_status','position':1,'boot_id':88,'global_fault':False,
        'idle_enabled':True,'pending_wait_open_mask':1,'token':'do not leak',
        'motors':[{'motor':7,'fault_latched':True,'fault_reason':4,'encoder_deg':112.3,
                   'door_closed_verified':True,'ignored_secret':'PRIVATE'},
                  {'motor':10,'fault_latched':False,'fault_reason':0},
                  {'motor':99,'fault_latched':True,'fault_reason':4}]}
    good=bridge.sanitize_udp(p)
    assert good['boot_id']==88 and len(good['motors'])==2
    assert good['pending_wait_open_mask']==1
    assert 'token' not in good and 'ignored_secret' not in str(good)
    assert bridge.sanitize_udp({**p,'position':0}) is None
    assert bridge.sanitize_udp({**p,'type':'remote_motor_recover'}) is None
    class Mock:
        pass
    obj=Mock()
    bridge.capture_udp(obj,'192.168.1.200',p)
    assert not hasattr(obj,'_wa_majoska_v14_udp')
    bridge.capture_udp(obj,'192.168.1.201',p)
    rec=obj._wa_majoska_v14_udp
    row={'1':{'issues':[]}}
    out=bridge.enrich_udp(row,rec,rec['at_epoch']+1)['1']
    assert out['r3_status']['motors'][0]['fault_reason']==4
    assert out['r3_udp_received_at']==rec['observed_utc']
    assert datetime.fromisoformat(out['r3_status_observed_at'])
    assert 'r3_status' not in bridge.enrich_udp({'1':{}},rec,rec['at_epoch']+99)['1']
    # Time must not be refreshed by a repeated heartbeat.
    a=bridge.enrich_udp({'1':{}},rec,rec['at_epoch']+4)['1']['r3_udp_received_at']
    b=bridge.enrich_udp({'1':{}},rec,rec['at_epoch']+7)['1']['r3_udp_received_at']
    assert a==b
    print('PASS: V8.1-compatible UDP allowlist, origin, timestamps, stale filtering and secret exclusion')


def test_polls():
    m={'type':'remote_motor_ack','ok':True,'boot_id':88,'global_fault':False,
       'pending_wait_open_mask':0,'pending_wait_close_mask':0,
       'motors':[{'motor':10,'fault_latched':False,'fault_reason':0,'encoder_deg':54},
                 {'motor':7,'fault_latched':True,'fault_reason':4,'encoder_deg':123.2}]}
    r={'type':'recovery_ack','ok':True,'boot_id':88,'firmware':'same-old-label',
       'encoder_bus_errors':6825,'mutex_timeout_count':0,'token':'secret',
       'motor_hardware_ready':True}
    with tempfile.TemporaryDirectory() as d:
        root=Path(d)
        original=(main.POLL,main.GOOD,main.EVENTS,wd.endpoint,wd.rpc,main.pending.once,
                  poll_bridge.POLL,poll_bridge.GOOD)
        main.POLL=root/'poll.json';main.GOOD=root/'good.json';main.EVENTS=root/'events.jsonl'
        poll_bridge.POLL=main.POLL;poll_bridge.GOOD=main.GOOD
        wd.endpoint=lambda:('pi','ip',48556,'private')
        wd.rpc=lambda ep,action: dict(m if action=='remote_motor_status' else r)
        main.pending.once=lambda **kwargs:None
        try:
            info=main.poll()
            assert info['ok'] and info['summary']['motor_rows'][1]['fault_reason']==4
            raw=json.loads(main.GOOD.read_text())
            assert raw['recovery_status']['encoder_bus_errors']==6825
            assert raw['recovery_status']['token']=='[REDACTED]'
            health={'1':{'issues':[],'sensors_online':2}}
            out=poll_bridge.enrich(health, poll=raw,good=raw,now=raw['at_epoch']+1)
            assert out['1']['r3_controller_status_full']['motors'][1]['encoder_deg']==123.2
            assert any(x['code']=='R3_MOTOR_7_FAULT_4' for x in out['1']['issues'])
            b=json.loads(json.dumps(raw));b['summary']['pending_wait_open_mask']=1
            out=poll_bridge.enrich({'1':{'issues':[]}},poll=b,good=b,now=b['at_epoch']+1)
            assert any(x['code']=='R3_WAIT_OPEN' for x in out['1']['issues'])
            r['boot_id']=99
            assert not main.poll()['ok']
        finally:
            main.POLL,main.GOOD,main.EVENTS,wd.endpoint,wd.rpc,main.pending.once,\
                poll_bridge.POLL,poll_bridge.GOOD=original
    print('PASS: full R7/R10 authenticated polling, backend overlay, pending alert, boot mismatch, redaction')


def test_watchdog():
    wd.self_test()
    assert '--auto-recover --extended-auto' in (installer.ROOT/installer.UNIT).read_text()
    assert 'remote_motor_clear_pending_cycle' not in __import__('inspect').getsource(wd.once)
    assert 'remote_motor_clear_global' not in __import__('inspect').getsource(wd.once)
    # Installer must leave existing Pi config out of the archive and code mutations.
    import inspect
    installer_src=inspect.getsource(installer.install)
    assert "atomic_write(CONFIG" not in installer_src
    assert "copy2(CONFIG" not in installer_src
    assert 'wa_majoska_v14_backups' in installer_src
    print('PASS: fault classes 1-7 guarded, auto extended configured, pending/global excluded, no credential overwrite')

if __name__=='__main__':
    installer.self_test();test_udp();test_polls();test_watchdog()
