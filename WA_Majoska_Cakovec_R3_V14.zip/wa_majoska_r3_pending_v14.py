#!/usr/bin/env python3
"""R3 V9 pending-cycle reconciler: READ-ONLY, same authenticated protocol as V8.

Detects unfinished R7/R10 access, separates WAIT_OPEN and WAIT_CLOSE, tracks
ESP-initiated clearing within one controller boot, and escalates after 10m or a
reboot. It never asserts physical inspection, clears a lockout, pulses a door,
replays a purchase, or changes inventory. It is intentionally safe on V8.3.7.

The V8.3.7 ESP already auto-expires *fresh* WAIT_OPEN only after timeout,
repeated door-closed samples, motor ENN disabled and relay OFF; WAIT_CLOSE
clears after confirmed door closure. A cleared pending mask is not delivery
proof. Future post-pulse reopening requires a transaction-specific, durable
ESP permit proving no prior effective unlock, not just a door-switch timeout.
"""
from __future__ import annotations
import argparse
import fcntl
import json
import os
import tempfile
import time
from pathlib import Path

HERE=Path(__file__).resolve().parent
STATE=HERE/'wa_majoska_r3_pending_v14_state.json'
LOG=HERE/'wa_majoska_r3_pending_v14_events.jsonl'
LOCK=HERE/'wa_majoska_r3_pending_v14.lock'
MAX_UNRESOLVED_SECONDS=600


def atomic_json(path, data):
    fd,tmp=tempfile.mkstemp(prefix='.r3_pending_v9_',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as out:
            json.dump(data,out,sort_keys=True)
            out.flush();os.fsync(out.fileno())
        os.chmod(tmp,0o600)
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def load_state(path=STATE):
    try:
        info=json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):return {'version':9,'groups':{},'unresolved_across_reboots':[]}
    if not isinstance(info,dict) or info.get('version')!=9:
        return {'version':9,'groups':{},'unresolved_across_reboots':[]}
    if not isinstance(info.get('groups'),dict):info['groups']={}
    if not isinstance(info.get('unresolved_across_reboots'),list):info['unresolved_across_reboots']=[]
    return info


def interpret(d, previous=None, now=None):
    """Pure classification. NEVER infer a delivered item from mask transitions."""
    now=time.time() if now is None else now
    prev=previous if isinstance(previous,dict) else load_state(Path('/dev/null'))
    boot=d.get('boot_id')
    if type(boot) is not int or boot<0:
        raise ValueError('Missing valid controller boot ID')
    if d.get('global_fault') is not False:
        raise ValueError('Global fault not positively false; no pending reconciliation permitted')
    if d.get('guard_latched') is not False:
        raise ValueError('Independent safety guard active/unknown')
    open_mask=d.get('pending_wait_open_mask');close_mask=d.get('pending_wait_close_mask')
    if type(open_mask) is not int or type(close_mask) is not int or not (0<=open_mask<=3 and 0<=close_mask<=3):
        raise ValueError('Pending masks missing or invalid')
    motors=d.get('motors')
    if not isinstance(motors,list):raise ValueError('Missing motor rows')
    rows={r.get('motor'):r for r in motors if isinstance(r,dict)}
    if set(rows)!={7,10}:raise ValueError('Incomplete R7/R10 motor status')
    old_groups=prev.get('groups') or {}
    boot_changed=prev.get('boot_id') is not None and prev.get('boot_id')!=boot
    unresolved=list(prev.get('unresolved_across_reboots') or [])[-20:]
    if boot_changed:
        for motor in ('7','10'):
            old=old_groups.get(motor) or {}
            if old.get('state') not in ('CLEAR','UNKNOWN',None):
                unresolved.append({'motor':int(motor),'old_boot_id':prev['boot_id'],
                                   'previous_state':old.get('state'),'seen_at':now,
                                   'note':'reboot while access unresolved; delivery outcome UNKNOWN'})
    result=[];groups={}
    for motor,bit in ((7,1),(10,2)):
        row=rows[motor]
        if (row.get('door_cycle_pending') is not (bool((open_mask|close_mask)&bit))):
            raise ValueError('Per-motor pending bit disagrees with pending masks')
        if open_mask&bit and close_mask&bit:
            kind='CONFLICT';detail='WAIT_OPEN and WAIT_CLOSE simultaneously: owner conflict'
        elif open_mask&bit:
            kind='WAIT_OPEN';detail='awaiting door-open; may expire ONLY by ESP verified closed/disabled/lock-off logic'
        elif close_mask&bit:
            kind='WAIT_CLOSE';detail='door opened; must observe real closure, NEVER force-clear'
        else:
            kind='CLEAR';detail='no pending lockout; this does NOT prove item was received'
        old={} if boot_changed else (old_groups.get(str(motor)) or {})
        since=float(old.get('first_seen',now)) if old.get('state')==kind else now
        elapsed=max(0.0,now-since)
        cleared_observed=(kind=='CLEAR' and old.get('state') in ('WAIT_OPEN','WAIT_CLOSE','CONFLICT'))
        alert=(kind=='CONFLICT' or (kind!='CLEAR' and elapsed>=MAX_UNRESOLVED_SECONDS) or
               (kind=='WAIT_OPEN' and row.get('door_closed_verified') is not True))
        # Do not log every healthy poll as an alert.
        event='ESCALATE' if alert else ('CLEARED_AT_CONTROLLER' if cleared_observed else 'OBSERVE')
        if kind!='CLEAR' and boot_changed:event='REBOOT_PENDING_UNRECONCILED'
        result.append({'motor':motor,'state':kind,'event':event,
                       'duration_seen_s':round(elapsed,1),'door_closed_verified':row.get('door_closed_verified'),
                       'last_firmware_pending_age_s':row.get('door_cycle_pending_observed_age_s'),
                       'delivery_confirmed':False, 'detail':detail})
        groups[str(motor)]={'state':kind,'first_seen':since,'last_seen':now}
    new={'version':9,'boot_id':boot,'seen_at':now,'groups':groups,
         'unresolved_across_reboots':unresolved[-20:]}
    return result,new


def once(*, data=None):
    import wa_majoska_r3_watchdog_v14 as wd
    with LOCK.open('a+') as handle:
        try:fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            print('R3 PENDING V9: previous monitor still running; skip');return 2
        try:
            d=wd.status(wd.endpoint()) if data is None else data
            result,new=interpret(d,load_state())
            atomic_json(STATE,new)
            log={'at':time.strftime('%Y-%m-%dT%H:%M:%S%z'), 'event':'PENDING_AUDIT',
                 'boot_id':new['boot_id'],'global_fault':d.get('global_fault'),
                 'pending_wait_open_mask':d.get('pending_wait_open_mask'),
                 'pending_wait_close_mask':d.get('pending_wait_close_mask'),
                 'groups':result,'reboot_unresolved_count':len(new['unresolved_across_reboots']),
                 'action':'READ_ONLY_NO_CLEAR_NO_UNLOCK_NO_INSPECTION_ATTESTATION'}
            print('[R3 PENDING V9]',json.dumps(log,sort_keys=True),flush=True)
            fd=os.open(LOG,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
            with os.fdopen(fd,'a',encoding='utf-8') as out:
                out.write(json.dumps(log,sort_keys=True)+'\n')
                out.flush();os.fsync(out.fileno())
            return 0
        except Exception as exc:
            print('R3 PENDING V9: status/reconciliation unavailable:',type(exc).__name__,str(exc)[:240])
            return 3


def sample(open_mask=0,close_mask=0,boot=45,door_closed=True,global_fault=False,guard=False):
    return {'boot_id':boot,'global_fault':global_fault,'guard_latched':guard,
            'pending_wait_open_mask':open_mask,'pending_wait_close_mask':close_mask,
            'motors':[{'motor':m,'door_cycle_pending':bool((open_mask|close_mask)&bit),
                       'door_closed_verified':door_closed,'door_cycle_pending_observed_age_s':30}
                      for m,bit in ((7,1),(10,2))]}


def self_test():
    r,s=interpret(sample(),now=1000)
    assert all(x['state']=='CLEAR' for x in r)
    r,s=interpret(sample(open_mask=1),s,now=1100)
    assert r[0]['state']=='WAIT_OPEN' and r[0]['event']=='OBSERVE'
    r,s=interpret(sample(open_mask=1),s,now=1801)
    assert r[0]['state']=='WAIT_OPEN' and r[0]['event']=='ESCALATE'
    r,s=interpret(sample(),s,now=1810)
    assert r[0]['event']=='CLEARED_AT_CONTROLLER' and r[0]['delivery_confirmed'] is False
    r,s=interpret(sample(close_mask=2),s,now=1900)
    assert r[1]['state']=='WAIT_CLOSE'
    r,s=interpret(sample(close_mask=2,boot=46),s,now=1920)
    assert r[1]['event']=='REBOOT_PENDING_UNRECONCILED' and s['unresolved_across_reboots']
    try:interpret(sample(open_mask=1,global_fault=True),s,now=1930)
    except ValueError:pass
    else:raise AssertionError('Global fault must block audit/recovery')
    try:interpret(sample(open_mask=1,guard=True),s,now=1930)
    except ValueError:pass
    else:raise AssertionError('Guard latch must block audit/recovery')
    bad=sample(open_mask=1);bad['motors'][0]['door_cycle_pending']=False
    try:interpret(bad,s,now=1930)
    except ValueError:pass
    else:raise AssertionError('Mismatched pending state must refuse')
    assert 'remote_motor_clear_pending_cycle' not in __doc__ or 'never' in __doc__.lower()
    print('PASS: V9 WAIT_OPEN/WAIT_CLOSE, old boot and stale pending escalation')
    print('PASS: no false delivery proof, no global/guard override, no motor or lock commands')


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--once',action='store_true');g.add_argument('--self-test',action='store_true')
    g.add_argument('--last',action='store_true')
    a=p.parse_args(argv)
    if a.self_test:self_test();return 0
    if a.last:print(json.dumps(load_state(),indent=2,sort_keys=True));return 0
    return once()

if __name__=='__main__':raise SystemExit(main())
