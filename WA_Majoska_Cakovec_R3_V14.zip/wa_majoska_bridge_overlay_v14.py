#!/usr/bin/env python3
"""Majoska V14: V8.1-compatible live UDP snapshot + V13 full polled health.

The existing ModuleHealthBridge owns UDP port 48557. This module NEVER binds
another socket; the installer adds an in-listener callback after source-IP and
position validation. Only allowlisted fields are exposed in r3_status.
"""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import math
import time
import wa_majoska_bridge_overlay_v14_poll as polling

_TOP_BOOL = frozenset((
    'global_fault','idle_enabled','motor_hardware_ready','tmc_both_configured',
    'maintenance_busy','network_job_active','service_busy',
    'idle_worker_stalled','unsafe_maintenance_stop','guard_latched',
    'relay_mcp_ready','feedback_mcp_ready','motor_mcp_ready',
    'encoder_mux_ready','panel_nvs_ready','led_ready','fan_pwm_ready',
))
_TOP_NUM = frozenset((
    'boot_id','motor_idle_task_count','udp_send_failures',
    'diagnostic_events_dropped','idle_worker_progress_age_s',
    'report_worker_progress_age_s','uptime_s',
    'pending_wait_open_mask','pending_wait_close_mask','encoder_bus_errors',
    'mutex_timeout_count',
))
_TOP_TEXT = frozenset(('firmware','reset_reason','event'))
_MOTOR_BOOL = frozenset((
    'fault_latched','door_closed_verified','door_cycle_pending',
    'step_output_active','encoder_valid','enn_disabled_verified',
    'rotation_verified_after_recovery','enn_readback_available',
))
_MOTOR_NUM = frozenset((
    'stop_reason_code','fault_reason','door_cycle_pending_observed_age_s',
    'last_rotation_proof_age_s','encoder_deg','tmc_drv_status','tmc_gstat',
    'enn_readback_error','auto_recovery_window_count',
))
_MOTOR_TEXT = frozenset(('stop_reason','recovery_verification'))
_APPLIED='_wa_majoska_v14_overlay_applied'


def _number(v):
    if type(v) not in (int,float) or not math.isfinite(v) or not -1e12 <= v <= 1e12:
        return None
    return v


def _pick_bool(source, fields, out):
    for key in fields:
        if type(source.get(key)) is bool:out[key]=source[key]


def _pick_num(source, fields, out):
    for key in fields:
        if key in source:
            val=_number(source[key])
            if val is not None:out[key]=val


def _pick_text(source, fields, out):
    for key in fields:
        if isinstance(source.get(key),str):out[key]=source[key][:128]


def sanitize_udp(packet):
    """Produce V8.1-compatible R3 heartbeat shape without secrets/raw strings."""
    if not isinstance(packet,dict) or packet.get('type')!='r3_motor_status':return None
    if packet.get('position',1) != 1:return None
    motors=packet.get('motors')
    if not isinstance(motors,list):return None
    result={'type':'r3_motor_status','position':1,'motors':[]}
    _pick_bool(packet,_TOP_BOOL,result)
    _pick_num(packet,_TOP_NUM,result)
    _pick_text(packet,_TOP_TEXT,result)
    seen=set()
    for motor in motors:
        if not isinstance(motor,dict) or type(motor.get('motor')) is not int:continue
        n=motor['motor']
        if n not in (7,10) or n in seen:continue
        seen.add(n)
        row={'motor':n}
        _pick_bool(motor,_MOTOR_BOOL,row)
        _pick_num(motor,_MOTOR_NUM,row)
        _pick_text(motor,_MOTOR_TEXT,row)
        result['motors'].append(row)
    if not result['motors']:return None
    return result


def capture_udp(self, source_ip, packet):
    """Invoked only after the bridge listener verified source IP and position."""
    if source_ip != '192.168.1.201':return
    clean=sanitize_udp(packet)
    if clean is None:return
    when=time.time()
    dt=datetime.fromtimestamp(when,timezone.utc).isoformat()
    # The receipt timestamp only changes on an actual UDP datagram.
    self._wa_majoska_v14_udp={'status':clean,'at_epoch':when,'observed_utc':dt}


def enrich_udp(health, last, now=None):
    if not isinstance(health,dict):return health
    row=health.get('1',health.get(1))
    if not isinstance(row,dict):return health
    now=time.time() if now is None else now
    if not isinstance(last,dict):return health
    ts=last.get('at_epoch')
    if not isinstance(ts,(int,float)):return health
    age=now-ts
    if age < 0 or age > 90:return health
    if not isinstance(last.get('status'),dict):return health
    # Compatible with the previous V8.1 backend ingestion contract.
    row['r3_status']=last['status']
    row['r3_status_observed_at']=last['observed_utc']
    row['r3_udp_received_at']=last['observed_utc']
    row['r3_udp_age_s']=round(age,1)
    return health


def install_bridge_overlay(cls):
    if getattr(cls,_APPLIED,False):return
    previous=cls.heartbeat_health
    def health(self,*args,**kwargs):
        original=previous(self,*args,**kwargs)
        # Forward live UDP immediately on the normal heartbeat; V13 polls are
        # independently authenticated and enrich the same position.
        try:
            with self.lock:
                udp=getattr(self,'_wa_majoska_v14_udp',None)
            enrich_udp(original,udp)
            return polling.enrich(original)
        except Exception as exc:
            print('[MAJOSKA R3 V14] heartbeat warning:',type(exc).__name__,str(exc)[:120])
            return original
    cls._wa_majoska_v14_udp_capture=capture_udp
    cls.heartbeat_health=health
    setattr(cls,_APPLIED,True)
