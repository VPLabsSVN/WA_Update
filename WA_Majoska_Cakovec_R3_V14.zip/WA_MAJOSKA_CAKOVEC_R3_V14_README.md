# WA Majoska / Čakovec R3 V14 — combined V8.1 UDP forwarding + V13 watchdog

## Scope and compatibility

This package is only for the **Majoska / Cakovec** Raspberry Pi at
`/home/wa_stopshop_mb/WA/Main_program/Fis`, using panel ID `Majoska`,
name `Cakovec`, Pi source IP `192.168.1.100`, authenticated ESP32 R3 at
`192.168.1.201:48556` and existing recovery endpoint settings in
`pi_recovery_endpoints.json`.

V14 is **not** an ESP32 firmware update. It does not replace the machine's
motor controller, payment, Croatian fiscalization, POS, kiosk purchase
code, inventory or remote recovery credentials. If the original bridge
changes structure significantly, `--check` will refuse rather than guess.

The exact earlier V8.1 helper implementation is not recopied; this package
implements the **same three heartbeat keys and allowlisted live-UDP
forwarding contract**, alongside V13 authenticated full polling. Existing
V8.1 bridge code, if present, is preserved and wrapped rather than replaced.

## What is active immediately after installation

- **V8.1-compatible live UDP forwarding:** the existing `ModuleHealthBridge`
  UDP listener at port 48557 receives packets from the configured R3
  controller. V14 injects a capture *inside* the existing source-IP and
  position filters. It does **not** bind a second UDP socket.
- `component_statuses.module_health["1"]` gets `r3_status`,
  `r3_status_observed_at` and `r3_udp_received_at` after an actual live
  `r3_motor_status` packet. Times are not advanced by cached heartbeats.
  The forwarded `r3_status` is allowlisted; it excludes credentials and
  arbitrary text fields.
- **Complete authenticated diagnostics** every 150 seconds via correlated
  `remote_motor_status` and `remote_recovery_status` replies, with separate
  full JSON snapshots and controller fault/event reporting.
- **Extended automatic fault recovery mode is ALREADY CONFIGURED** in the
  installed systemd service. No separate `--enable-extended` operation is
  needed after installation.
- ESP fault codes 1, 2, 3, 4, 5, 6, 7: one guarded `remote_motor_recover`
  attempt only on a latched and eligible motor fault, following two fresh
  matching ESP status snapshots and a positive kiosk-idle certificate.
  This is a recovery **request**, not a guarantee of acceptance or motion.
- Existing limits: at most one attempt per motor per hour, two per day;
  one motor per watchdog tick. No automatic resend after unknown ACK.
- Pending customer door-cycle masks and controller reboots are reported;
  unresolved customer access is never blindly cleared or re-opened.
- Global faults and unsafe/ambiguous hardware states always block recovery.

**Important:** V14 DOES NOT send `inspected_hardware=true` automatically. If
firmware requires incident-specific physical inspection for codes 2/4/6/7,
it can refuse those commands. There is no way for the Pi to prove a future
physical inspection from an earlier machine commissioning record.

### Why you may still see a delay after installation

"Extended enabled" means the service command already has
`--once --auto-recover --extended-auto`. It does **not** bypass the kiosk
safety gate: Home screen, no interaction for >180 seconds, no completed
purchase for >600 seconds, no busy operations, fresh heartbeat, both doors
closed, no pending access and safe ESP status. This prevents a recovery
from interrupting an active transaction. The timer checks every 150 sec.

## Files included

- `wa_majoska_r3_v14.py`: authenticated full status collector and watchdog runner
- `wa_majoska_bridge_overlay_v14.py`: live V8.1-compatible UDP forwarding
- `wa_majoska_bridge_overlay_v14_poll.py`: V13 full polled-status health overlay
- `wa_majoska_r3_watchdog_v14.py`: guarded 1–7 recovery and idle certificate
- `wa_majoska_r3_pending_v14.py`: pending customer door-cycle history
- `wa_majoska_v14_install.py`: compatibility, installation and rollback
- `wa-majoska-r3-v14.service`, `wa-majoska-r3-v14.timer`
- `test_majoska_r3_v14.py`: offline integration tests

## Step 1: Copy ZIP and check compatibility (NO ACTUATION)

Upload `WA_Majoska_Cakovec_R3_V14.zip` to your GitHub repository's `main`
branch and on the **Majoska Pi** run:

```bash
cd /home/wa_stopshop_mb/WA/Main_program/Fis
curl -fL --retry 3 \
  "https://raw.githubusercontent.com/VPLabsSVN/WA_Update/main/WA_Majoska_Cakovec_R3_V14.zip" \
  -o WA_Majoska_Cakovec_R3_V14.zip
unzip -o WA_Majoska_Cakovec_R3_V14.zip

./venv/bin/python wa_majoska_v14_install.py --self-test
./venv/bin/python wa_majoska_r3_v14.py --self-test
./venv/bin/python wa_majoska_r3_watchdog_v14.py --self-test
./venv/bin/python wa_majoska_r3_pending_v14.py --self-test
./venv/bin/python test_majoska_r3_v14.py
./venv/bin/python wa_majoska_v14_install.py --check
```

The `--check` command must succeed on your actual bridge. It verifies the
site identity, recovery config without printing the token, UDP listener
structure, compiled patch and idle hook before any changes.

If V13 **was already installed**, first roll it back with its original
installer after stopping kiosk service, then use V14. Do not run V13 and
V14 watchdog timers simultaneously.

## Step 2: Install (timer already extended)

During a confirmed quiet interval with **no payment/door operation**:

```bash
systemctl --user stop bouquetmat.service
./venv/bin/python wa_majoska_v14_install.py --install
systemctl --user start bouquetmat.service
systemctl --user is-active bouquetmat.service
```

No separate recovery-enable command is needed. The installer backs up the
original `wa_module_health_bridge.py` and `Panel_backend_merged.py`,
leaves `pi_recovery_endpoints.json` **untouched**, writes the bridge/idle
hook changes, and enables the V14 user-level systemd timer. It refuses
installation if another known R3 watchdog is already active. The first
watchdog recovery operation will wait until the **live** safety conditions
permit it.

## Step 3: Verify reporting and recovery configuration

```bash
cd /home/wa_stopshop_mb/WA/Main_program/Fis
./venv/bin/python wa_majoska_v14_install.py --status
systemctl --user list-timers --all wa-majoska-r3-v14.timer
systemctl --user show -p ExecStart wa-majoska-r3-v14.service

# Read-only one-time authenticated status request (does not move any motor)
./venv/bin/python wa_majoska_r3_v14.py --once
./venv/bin/python wa_majoska_r3_v14.py --last
./venv/bin/python wa_majoska_r3_pending_v14.py --last

journalctl --user -u wa-majoska-r3-v14.service \
  --since '30 minutes ago' --no-pager -l | tail -70
```

Expected service argument sequence:

```text
wa_majoska_r3_v14.py --once --auto-recover --extended-auto
```

### Where data is stored

- `wa_majoska_r3_v14_latest_poll.json`: latest attempt, including failures
- `wa_majoska_r3_v14_latest_good.json`: last correlated authenticated full replies
- `wa_majoska_r3_v14_events.jsonl`: bounded summary/event history
- `wa_majoska_r3_pending_v14_state.json`: pending-cycle history
- `wa_majoska_r3_pending_v14_events.jsonl`: pending-cycle events
- `wa_r3_watchdog.jsonl`: watchdog decisions, attempts and controller ACKs

The existing WA Connect backend may sanitize or strip raw fields in its API;
the complete authenticated raw status is available locally. Android may
need a separate UI update to display each new field.

## Emergency monitor-only option

This is **optional**, not required at installation:

```bash
./venv/bin/python wa_majoska_v14_install.py --monitor-only
```

It retains the 150s timer and full telemetry, but disables unattended
motor recovery. To restore guarded extended requests:

```bash
./venv/bin/python wa_majoska_v14_install.py --enable-extended
```

## Rollback

At an idle, payment-free interval:

```bash
systemctl --user stop bouquetmat.service
./venv/bin/python wa_majoska_v14_install.py --rollback
systemctl --user start bouquetmat.service
```

The rollback refuses to overwrite bridge/backend files if they have been
changed after V14 installation. It leaves the original private token file
alone. If a separate software change is made after V14, resolve the diff
manually using the timestamped backups.

## Validation and outstanding work

The package's offline tests cover the V8.1-style UDP heartbeat, origin and
position filtering, no token leakage, complete polled status, boot-ID
correlation, pending cycle alerts, 1–7 fault eligibility, blocking global
and ambiguous customer access, installer idempotence and backups. These
tests do **not** establish that the exact currently installed Majoska
bridge will match; the on-Pi `--check` does that. No live ESP32 motor
recovery was performed during package creation. Purchase-time five-attempt
retries are not installed or changed by this package.
