#!/usr/bin/env python3
"""Majoska/Čakovec R3 V14: full authenticated status poll + guarded fault watchdog.

Read-only is the default. --auto-recover --extended-auto requests fault recovery
for codes 1..7 ONLY when the legacy watchdog's complete safety preflight and
fresh idle certificate pass. It does NOT send inspected_hardware=true,
clear global faults, clear customer pending cycles, pulse doors or replay sales.
"""
from __future__ import annotations
import argparse
import json
import os
import tempfile
import time
from pathlib import Path
import wa_majoska_r3_watchdog_v14 as wd
import wa_majoska_r3_pending_v14 as pending

ROOT=Path(__file__).resolve().parent
POLL=ROOT/'wa_majoska_r3_v14_latest_poll.json'
GOOD=ROOT/'wa_majoska_r3_v14_latest_good.json'
EVENTS=ROOT/'wa_majoska_r3_v14_events.jsonl'
SENSITIVE={'token','auth_token','password','secret','private_key','api_key','authorization'}


def clean(x):
    if isinstance(x,dict):
        return {str(k):('[REDACTED]' if str(k).lower() in SENSITIVE else clean(v))
                for k,v in x.items()}
    if isinstance(x,list):return [clean(v) for v in x]
    if isinstance(x,(str,bool,int,float)) or x is None:return x
    return repr(x)[:200]


def atomic_json(path, obj):
    fd,tmp=tempfile.mkstemp(prefix='.majoska_v14_',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(clean(obj),f,ensure_ascii=True,sort_keys=True,separators=(',',':'))
            f.flush();os.fsync(f.fileno())
        os.chmod(tmp,0o600);os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def read_json(path):
    try:return json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):return None


def append_event(record):
    # bounded local diagnostic log; no secrets or unbounded status dumps
    try:
        if EVENTS.exists() and EVENTS.stat().st_size>4*1024*1024:
            archive=EVENTS.with_suffix('.jsonl.1')
            archive.unlink(missing_ok=True);EVENTS.rename(archive)
        with EVENTS.open('a',encoding='utf-8') as f:
            f.write(json.dumps(clean(record),ensure_ascii=True,sort_keys=True)+'\n')
        os.chmod(EVENTS,0o600)
    except OSError:pass


def get_all_status():
    ep=wd.endpoint()
    motors=wd.rpc(ep,'remote_motor_status')
    recovery=wd.rpc(ep,'remote_recovery_status')
    if not isinstance(motors,dict) or not isinstance(recovery,dict):
        raise ValueError('incomplete status reply')
    same_boot=(type(motors.get('boot_id')) is int and
               motors.get('boot_id')==recovery.get('boot_id'))
    accepted=(motors.get('ok') is True and recovery.get('ok') is True)
    merged=dict(motors)
    merged['firmware']=recovery.get('firmware')
    return motors,recovery,merged, bool(same_boot and accepted)


def summarize(m,rec,merged,correlated,prev):
    motors=m.get('motors') if isinstance(m.get('motors'),list) else []
    rows=[{'motor':r.get('motor'),'fault_latched':r.get('fault_latched'),
           'fault_reason':r.get('fault_reason'), 'door_cycle_pending':r.get('door_cycle_pending'),
           'door_closed_verified':r.get('door_closed_verified'),
           'encoder_valid':r.get('encoder_valid'),'enn_disabled_verified':r.get('enn_disabled_verified'),
           'step_output_active':r.get('step_output_active'),
           'tmc_drv_status':r.get('tmc_drv_status'), 'tmc_gstat':r.get('tmc_gstat'),
           'recovery_verification':r.get('recovery_verification')}
          for r in motors if isinstance(r,dict) and r.get('motor') in (7,10)]
    s={'correlated':correlated,'boot_id':merged.get('boot_id'),'firmware':merged.get('firmware'),
       'global_fault':merged.get('global_fault'),'guard_latched':merged.get('guard_latched'),
       'recovery_status_contract_complete': bool(correlated and isinstance(merged.get('firmware'),str)
           and merged.get('firmware')),
       'pending_wait_open_mask':merged.get('pending_wait_open_mask'),
       'pending_wait_close_mask':merged.get('pending_wait_close_mask'),
       'motor_hardware_ready':merged.get('motor_hardware_ready'),
       'idle_enabled':merged.get('idle_enabled'),'motor_rows':rows,
       'encoder_bus_errors':rec.get('encoder_bus_errors',m.get('encoder_bus_errors')),
       'mutex_timeout_count':rec.get('mutex_timeout_count',m.get('mutex_timeout_count'))}
    old=(prev or {}).get('summary',{})
    if old.get('boot_id')==s['boot_id']:
        for k in ('encoder_bus_errors','mutex_timeout_count'):
            a,b=old.get(k),s.get(k)
            if type(a) is int and type(b) is int and b>=a:s[k+'_since_last_poll']=b-a
    return s


def poll():
    at=time.time()
    previous=read_json(GOOD)
    try:
        motor, recovery, merged, correlated=get_all_status()
        summary=summarize(motor,recovery,merged,correlated,previous)
        info={'schema':14,'site':'Majoska','panel_name':'Cakovec','at_epoch':at,'ok':correlated,
              'summary':summary,'motor_status':motor,'recovery_status':recovery}
        atomic_json(POLL,info)
        if correlated:
            atomic_json(GOOD,info)
            # Time-series for pending customer cycles, never forced clearance.
            try:pending.once(data=merged)
            except Exception as exc:
                append_event({'at':at,'event':'PENDING_MONITOR_ERROR','error':str(exc)[:180]})
        else:
            append_event({'at':at,'event':'UNCORRELATED_REPLIES','summary':summary})
        append_event({'at':at,'event':'STATUS','summary':summary})
        return info
    except (OSError,ValueError,TimeoutError) as exc:
        info={'schema':14,'site':'Majoska','panel_name':'Cakovec','at_epoch':at,'ok':False,
              'error':type(exc).__name__+': '+str(exc)[:220]}
        atomic_json(POLL,info);append_event({'at':at,'event':'POLL_ERROR','error':info['error']})
        return info


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    mode=p.add_mutually_exclusive_group(required=True)
    for name in ('once','last','self-test'):
        mode.add_argument('--'+name,action='store_true')
    p.add_argument('--auto-recover',action='store_true')
    p.add_argument('--extended-auto',action='store_true')
    a=p.parse_args(argv)
    if a.extended_auto and not a.auto_recover:p.error('--extended-auto requires --auto-recover')
    if a.self_test:
        example={'boot_id':1,'motors':[{'motor':7,'fault_latched':True,'fault_reason':4}]}
        assert summarize(example,{'encoder_bus_errors':2},{**example,'firmware':'old'},False,None)['motor_rows'][0]['fault_reason']==4
        assert clean({'token':'PRIVATE','a':[{'password':'PRIVATE'}]})=={'token':'[REDACTED]','a':[{'password':'[REDACTED]'}]}
        print('PASS: V14 status forwarding, fields preserved, secrets redacted; no operations')
        return 0
    if a.last:
        print(json.dumps(read_json(POLL) or {'error':'no poll yet'},indent=2,sort_keys=True))
        return 0
    result=poll()
    print('[MAJOSKA R3 V14]',json.dumps({'ok':result['ok'],'summary':result.get('summary'),'error':result.get('error')},sort_keys=True),flush=True)
    if not a.auto_recover:return 0 if result['ok'] else 2
    if not result['ok']:
        print('[MAJOSKA R3 V14] No recovery: status is missing or uncorrelated')
        return 2
    # The existing V12 watchdog independently re-reads both snapshots, verifies
    # idle UI certificate, ENN/door/TMC interlocks and a persistent rate limit.
    return wd.once(auto=True,extended_auto=a.extended_auto)

if __name__=='__main__':raise SystemExit(main())
