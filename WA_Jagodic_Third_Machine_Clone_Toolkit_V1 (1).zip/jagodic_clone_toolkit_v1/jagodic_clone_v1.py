#!/usr/bin/env python3
"""Private, encrypted Jagodic WA application migration. No remote actions, no credentials printed."""
from __future__ import annotations
import argparse
import fnmatch
import getpass
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

VERSION = "WA-JAGODIC-CLONE-1.0"
USER_HOMES = (Path('/home/pi'), Path('/home/wa_stopshop_mb'))
REL_SYSTEMD_PREFIXES = ('bouquetmat', 'wa-', 'wa_', 'inverter', 'ads', 'kiosk', 'bb-', 'r3-', 'panel', 'restart-guard')
RESTORED_HOME_CONFIG_NAMES = ('systemd/user', 'labwc', 'lxsession', 'openbox', 'autostart', 'mpv', 'wayvnc', 'wayfire.ini')
PRIVATE_EXCLUSIONS = ('/.ssh/', '/.config/rpi-connect/', '/.config/raspberrypi-connect/', '/.config/Raspberry Pi Connect/', '/.local/share/rpi-connect/', '/.local/share/raspberrypi-connect/', '/.cache/', '/.local/state/', '/.config/chromium/', '/.config/google-chrome/', '/.mozilla/', '/.config/Code/', '/.config/discord/')
SNAPSHOT_ONLY = ('etc/hostname', 'etc/hosts', 'etc/NetworkManager', 'etc/wpa_supplicant', 'etc/ssh', 'etc/lightdm', 'etc/X11', 'etc/cups', 'etc/udev', 'etc/chrony', 'boot/')


def fatal(text: str):
    raise SystemExit('STOP: ' + text)


def source_file_candidates(source_root=Path('/')):
    """Return a narrow and explicit allowlist, still covering all WA-owned application data."""
    def inside(rel):
        return source_root / str(rel).lstrip('/')
    out = set()
    def add(rel):
        p = inside(rel)
        if p.exists() or p.is_symlink():
            key=str(rel).lstrip('/')
            if key.startswith(('etc/ssh/', 'home/pi/.ssh/', 'home/wa_stopshop_mb/.ssh/')):
                return
            out.add(key)
    for home in USER_HOMES:
        h = str(home).lstrip('/')
        for part in ('WA', 'bin', '.local/bin', '.local/share/applications'):
            add(f'{h}/{part}')
        for part in RESTORED_HOME_CONFIG_NAMES:
            add(f'{h}/.config/{part}')
        cfg = inside(f'{h}/.config')
        if cfg.is_dir():
            for entry in cfg.iterdir():
                if entry.is_file() and (entry.name.endswith('.env') or entry.name.endswith('.env.local') or entry.name.startswith(('bouquetmat-', 'wa-', 'inverter-'))):
                    add(f'{h}/.config/{entry.name}')
        for part in ('.xprofile', '.xinitrc', '.Xresources', '.bash_profile', '.cups'):
            add(f'{h}/{part}')
        # Jagodic has standalone recovery guards and display scripts in /home/pi.
        root_home=inside(h)
        if root_home.is_dir():
            for item in root_home.iterdir():
                if item.is_file() and not item.is_symlink() and item.suffix.lower() in ('.py','.sh','.service','.timer','.ini','.conf'):
                    add(f'{h}/{item.name}')
    for part in ('etc/systemd/system', 'etc/udev/rules.d', 'etc/cups', 'etc/NetworkManager/system-connections', 'etc/wpa_supplicant/wpa_supplicant.conf', 'etc/hostname', 'etc/hosts', 'etc/lightdm', 'etc/X11/xorg.conf.d', 'etc/chrony/chrony.conf', 'etc/cron.d', 'etc/crontab', 'usr/local/bin', 'boot/firmware/config.txt', 'boot/firmware/cmdline.txt', 'boot/config.txt', 'boot/cmdline.txt'):
        add(part)
    # Other app-specific configuration and keys under /etc are included but NOT applied automatically.
    for part in ('etc/wa', 'etc/bouquetmat', 'etc/stopshop', 'etc/wa-connect', 'etc/wa_stopshop_mb'):
        add(part)
    # Root-managed env files referenced by WA service units.
    service_dir = inside('etc/systemd/system')
    env_re = re.compile(r'^\s*EnvironmentFile\s*=\s*([^\n#]+)', re.M)
    if service_dir.exists():
        for item in service_dir.rglob('*'):
            if not item.is_file() or item.stat().st_size > 500000:
                continue
            if not (item.suffix in ('.service', '.timer', '.conf') and item.name.lower().startswith(REL_SYSTEMD_PREFIXES)):
                continue
            try:
                raw = item.read_text(encoding='utf-8', errors='replace')
            except OSError:
                continue
            for match in env_re.findall(raw):
                for val in match.split():
                    val = val.strip().lstrip('-').strip('"\'')
                    if val.startswith(('/etc/', '/home/', '/opt/')) and '${' not in val and '%' not in val and '*' not in val:
                        add(val)
    # Preserve known external cert locations if explicitly referenced in .env files.
    patterns = re.compile(r'^(?:HR_|SI_|FURS_|FISCAL_|POS_|PAYMENT_|SSL_).*(?:CERT|KEY|CA|P12|PFX|PATH|BUNDLE)\s*=\s*(.+)$', re.I)
    scanfiles = []
    for home in USER_HOMES:
        cfg = inside(f'{home}/.config')
        if cfg.is_dir():
            scanfiles.extend(f for f in cfg.iterdir() if f.is_file() and f.name.endswith('.env'))
    for cfg in scanfiles:
        try:
            for line in cfg.read_text(encoding='utf-8', errors='replace').splitlines():
                m = patterns.match(line.strip())
                if not m:
                    continue
                val = m.group(1).strip().strip('"\'')
                if val.startswith(('/home/', '/etc/', '/opt/')) and not any(c in val for c in ('$','%','*')) and Path(val).suffix.lower() in ('.p12','.pfx','.pem','.crt','.cer','.key','.p8','.bundle'):
                    add(val)
        except OSError:
            pass
    # App's existence required: either production path or direct /home/pi/WA installation.
    if not any(inside(x).exists() for x in ('home/wa_stopshop_mb/WA','home/pi/WA')):
        fatal('WA tree not found at /home/wa_stopshop_mb/WA or /home/pi/WA')
    return sorted(out)


def filtered(member: tarfile.TarInfo):
    path = '/' + member.name.strip('/') + '/'
    if any(ex in path for ex in PRIVATE_EXCLUSIONS):
        return None
    if member.name.rsplit('/',1)[-1] in ('core',) and member.size > 200000000:
        return None
    if member.issock() if hasattr(member, 'issock') else False:
        return None
    return member


def collect_system_metadata(paths):
    info = {'version': VERSION, 'created_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'hostname': os.uname().nodename,
            'paths': paths, 'secret_values_logged': False, 'source_user': os.environ.get('SUDO_USER') or os.environ.get('USER'),
            'note': 'Machine-specific IDs, private application keys and fiscal state copied. Never start duplicate without reconfiguration.'}
    try:
        info['os_release'] = Path('/etc/os-release').read_text(encoding='utf-8')[:2000]
    except OSError:
        info['os_release'] = None
    return info


def system_inventory():
    snippets=[]
    for title, cmd in (
        ('DPKG', ['dpkg-query','-W','-f=${Package} ${Version}\n']),
        ('APT_MANUAL', ['apt-mark','showmanual']),
        ('PI_GROUPS', ['id','pi']),
    ):
        try:
            r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,timeout=25)
            snippets.append(f'[{title}]\n'+r.stdout[:1000000])
        except (OSError, subprocess.TimeoutExpired):
            snippets.append(f'[{title}] unavailable\n')
    return '\n'.join(snippets).encode('utf-8')


def tool_check():
    for tool in ('gpg', 'rsync'):
        if not shutil.which(tool):
            fatal(f'Missing {tool}. Install the package on the Pi before proceeding.')


def passphrase_twice():
    a = getpass.getpass('Encryption passphrase (not stored): ')
    b = getpass.getpass('Repeat encryption passphrase: ')
    if len(a) < 14 or a != b:
        fatal('Passphrases must match and contain at least 14 characters')
    return a


def key_fd(password):
    r, w = os.pipe()
    os.write(w, (password + '\n').encode('utf-8'))
    os.close(w)
    return r


def encrypted_export(outdir):
    if os.geteuid() != 0:
        fatal('Export requires sudo to capture root-readable fiscal certificates and env files')
    tool_check()
    paths = source_file_candidates()
    print('Source path count:', len(paths))
    print('Includes application trees, selected user configs, systemd and device configuration.')
    print('Excludes Raspberry Pi Connect identity and SSH machine/user private keys.')
    if input('Kiosk stopped, payments idle, no pending invoice/door cycle? Type SNAPSHOT to continue: ').strip() != 'SNAPSHOT':
        fatal('Snapshot not authorized')
    password = passphrase_twice()
    outdir = Path(outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    outdir.chmod(0o700)
    ts = time.strftime('%Y%m%d_%H%M%S')
    outfile = outdir / f'Jagodic_Full_Clone_{ts}.tar.gz.gpg'
    tmp = outfile.with_suffix('.partial')
    r = key_fd(password)
    try:
        with tmp.open('wb') as encrypted:
            os.chmod(tmp, 0o600)
            proc = subprocess.Popen(['gpg','--batch','--yes','--pinentry-mode','loopback','--passphrase-fd',str(r),'--symmetric','--cipher-algo','AES256','--compress-algo','none','--output','-'],
                                    stdin=subprocess.PIPE, stdout=encrypted, stderr=subprocess.PIPE, pass_fds=(r,))
            os.close(r); r = -1
            try:
                assert proc.stdin is not None
                with tarfile.open(fileobj=proc.stdin, mode='w|gz', compresslevel=4, format=tarfile.PAX_FORMAT) as tar:
                    for rel in paths:
                        tar.add('/' + rel, arcname=rel, recursive=True, filter=filtered)
                    data = json.dumps(collect_system_metadata(paths), indent=2).encode()
                    m = tarfile.TarInfo('clone_metadata/source.json')
                    m.size=len(data); m.mode=0o600; m.mtime=int(time.time())
                    tar.addfile(m, io.BytesIO(data))
                    inv=system_inventory()
                    mi=tarfile.TarInfo('clone_metadata/os_packages.txt')
                    mi.size=len(inv); mi.mode=0o600; mi.mtime=int(time.time())
                    tar.addfile(mi,io.BytesIO(inv))
                proc.stdin.close()
                err = proc.stderr.read().decode('utf-8', 'replace') if proc.stderr else ''
                rc = proc.wait()
                if rc:
                    fatal(f'gpg encryption failed (exit {rc}): {err[-600:]}')
            except BaseException:
                try: proc.kill()
                except Exception: pass
                raise
        tmp.replace(outfile)
        outfile.chmod(0o600)
        h=hashlib.sha256()
        with outfile.open('rb') as f:
            for chunk in iter(lambda:f.read(1048576), b''): h.update(chunk)
        checksum = outfile.with_name(outfile.name + '.sha256')
        checksum.write_text(f'{h.hexdigest()}  {outfile.name}\n')
        checksum.chmod(0o600)
        # Allow the source pi operator to move the encrypted artifact, without changing archive confidentiality.
        sudo_user = os.environ.get('SUDO_USER')
        if sudo_user and sudo_user != 'root':
            import pwd
            u = pwd.getpwnam(sudo_user)
            for p in (outdir, outfile, checksum):
                os.chown(p, u.pw_uid, u.pw_gid)
        print('ENCRYPTED ARCHIVE:', outfile)
        print('SHA256:', checksum)
        print('Contains sensitive production tokens; transfer privately, NEVER GitHub/public cloud.')
    finally:
        if r >= 0: os.close(r)
        if tmp.exists(): tmp.unlink()


def check_archive(archive):
    archive=Path(archive)
    if not archive.is_file(): fatal('Encrypted archive not found')
    chk=archive.with_name(archive.name + '.sha256')
    if not chk.exists(): fatal('Missing SHA256 sidecar; transfer both files')
    expected=chk.read_text().strip().split()[0]
    if not re.fullmatch('[0-9a-f]{64}',expected): fatal('Invalid hash sidecar')
    h=hashlib.sha256()
    with archive.open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''): h.update(chunk)
    if h.hexdigest() != expected: fatal('Encrypted archive checksum mismatch')
    return archive


def safe_member_path(root:Path, name: str):
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or not p.parts:
        fatal('Unsafe archive path')
    if p.parts[0] not in ('home','etc','usr','boot','clone_metadata'):
        fatal('Unexpected archive root ' + p.parts[0])
    dest=root.joinpath(*p.parts)
    if not dest.parent.resolve(strict=False).is_relative_to(root.resolve()):
        fatal('Archive path through outside symlink')
    return dest


def decrypt_to_stage(archive, dest):
    if os.geteuid() != 0: fatal('Staging requires sudo')
    archive=check_archive(archive)
    dest=Path(dest).expanduser().resolve()
    if dest.exists(): fatal('Staging path already exists; choose a new directory')
    dest.mkdir(parents=True, mode=0o700)
    dest.chmod(0o700)
    password=getpass.getpass('Archive passphrase: ')
    r=key_fd(password)
    extracted=0
    try:
        proc=subprocess.Popen(['gpg','--batch','--yes','--pinentry-mode','loopback','--passphrase-fd',str(r),'--decrypt','--output','-',str(archive)],
                              stdout=subprocess.PIPE,stderr=subprocess.PIPE,pass_fds=(r,))
        os.close(r);r=-1
        try:
            assert proc.stdout is not None
            with tarfile.open(fileobj=proc.stdout, mode='r|gz') as tar:
                for m in tar:
                    destpath=safe_member_path(dest,m.name)
                    if m.isdev() or m.isfifo():
                        continue
                    # A symlink itself is allowed (virtualenvs contain symlinks), but never write through one.
                    if destpath.exists() and destpath.is_symlink() and m.isdir():
                        fatal('Existing symlink at archive directory path')
                    tar.extract(m, path=dest, numeric_owner=True)
                    extracted += 1
            proc.stdout.close()
            stderr=proc.stderr.read().decode('utf-8','replace') if proc.stderr else ''
            if proc.wait() != 0:
                fatal('Decryption failed. Wrong password or damaged archive. ' + stderr[-300:])
        except BaseException:
            try: proc.kill()
            except Exception: pass
            raise
        meta=dest/'clone_metadata/source.json'
        if not meta.is_file(): fatal('Missing source metadata')
        print('STAGED:',dest,'entries:',extracted)
        data=json.loads(meta.read_text())
        print('SOURCE HOST:',data['hostname'],'CREATED:',data['created_at_utc'])
        print('Nothing installed or started. Inspect stage before applying.')
    except BaseException:
        print('Staging was incomplete; delete the staging directory before retrying.', file=sys.stderr)
        raise
    finally:
        if r >= 0: os.close(r)


def is_same_tree(root, part):
    p=root / part
    return p.exists() or p.is_symlink()


def stage_info(stage):
    stage=Path(stage).resolve()
    meta=stage/'clone_metadata/source.json'
    if not meta.exists(): fatal('Not a staged Jagodic clone')
    return json.loads(meta.read_text())


def import_apply(stage):
    if os.geteuid()!=0: fatal('Apply requires sudo')
    if not shutil.which('rsync'): fatal('rsync missing')
    stage=Path(stage).resolve()
    metadata=stage_info(stage)
    if Path('/home/pi').is_dir() is False:
        fatal('Target must have /home/pi and user pi; use matching Raspberry Pi OS')
    if not (is_same_tree(stage,'home/pi/WA') or is_same_tree(stage,'home/wa_stopshop_mb/WA')):
        fatal('Staging lacks WA source tree')
    ip=shutil.which('ip')
    if ip:
        res=subprocess.run([ip,'route','show','default'],capture_output=True,text=True)
        if res.stdout.strip(): fatal('Target still has a default network route. Physically disconnect it before restoring.')
    print('SOURCE HOST:',metadata['hostname'])
    print('TARGET HOST:',os.uname().nodename)
    print('This installs Jagodic credentials and ledger data but leaves services DISABLED.')
    if input('Target physically isolated from original backend/ESP and no sales active? Type ISOLATED: ').strip()!='ISOLATED':
        fatal('Target isolation not confirmed')
    ts=time.strftime('%Y%m%d_%H%M%S')
    backup=Path('/var/lib/wa-jagodic-clone/backups')/ts
    backup.mkdir(parents=True, exist_ok=False)
    backup.chmod(0o700)
    applied=[]
    def copy_tree(rel):
        src=stage/rel
        if not (src.exists() or src.is_symlink()): return
        dst=Path('/')/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        backup_target=backup/rel
        backup_target.mkdir(parents=True,exist_ok=True)
        cmd=['rsync','-aH','--backup','--backup-dir='+str(backup_target),str(src)+'/' if src.is_dir() and not src.is_symlink() else str(src),str(dst)+'/' if src.is_dir() and not src.is_symlink() else str(dst)]
        subprocess.run(cmd,check=True)
        applied.append(rel)
    for home in USER_HOMES:
        base=str(home).lstrip('/')
        for part in ('WA','bin','.local/bin','.local/share/applications'):
            copy_tree(f'{base}/{part}')
        for item in (stage/base).iterdir() if (stage/base).is_dir() else []:
            if item.is_file() and item.suffix.lower() in ('.py','.sh','.service','.timer','.ini','.conf'):
                copy_tree(f'{base}/{item.name}')
        for part in RESTORED_HOME_CONFIG_NAMES:
            rel=f'{base}/.config/{part}'
            if part=='systemd/user':
                src=stage/rel
                if not src.exists(): continue
                dst=Path('/')/rel
                dst.mkdir(parents=True,exist_ok=True)
                targetbackup=backup/rel
                targetbackup.mkdir(parents=True, exist_ok=True)
                # Do not bring default.target.wants / timer enables on a different machine.
                cmd=['rsync','-aH','--backup','--backup-dir='+str(targetbackup),
                    '--exclude=*.wants/**','--exclude=*.requires/**','--exclude=*.wants','--exclude=*.requires',
                    str(src)+'/',str(dst)+'/']
                subprocess.run(cmd,check=True)
                applied.append(rel+' (no enablement links)')
            else:
                copy_tree(rel)
        cfg=stage/base/'.config'
        if cfg.exists():
            for p in cfg.iterdir():
                if p.is_file() and (p.name.endswith('.env') or p.name.endswith('.env.local') or p.name.startswith(('bouquetmat-','wa-','inverter-'))):
                    copy_tree(f'{base}/.config/{p.name}')
    copy_tree('usr/local/bin')
    # Root systemd unit files are copied without enablement links, so a later
    # technician can activate only the selected kiosk services after retargeting.
    root_units=stage/'etc/systemd/system'
    if root_units.is_dir():
        for item in root_units.iterdir():
            if item.name.lower().startswith(REL_SYSTEMD_PREFIXES) and (item.is_file() or item.is_dir()):
                rel=f'etc/systemd/system/{item.name}'
                if item.is_dir():
                    copy_tree(rel)
                elif item.is_file():
                    copy_tree(rel)

    # Root OS config/boot/network/udev/CUPS intentionally in staging for manual comparison.
    # No system services are started; systemd user unit enablement symlinks are omitted.
    summary=backup/'restore_summary.json'
    summary.write_text(json.dumps({'source':metadata['hostname'],'timestamp':ts,'copied':applied,'staging':str(stage),'manual_review': list(SNAPSHOT_ONLY)},indent=2))
    summary.chmod(0o600)
    print('APPLIED FILE TREES:',len(applied))
    print('PRE-EXISTING FILE BACKUPS:',backup)
    print('OS/NETWORK/BOOT/PRINTER CONFIG REMAINS UNDER STAGING FOR MANUAL REVIEW.')
    print('NO SERVICES STARTED OR ENABLED. DO NOT RECONNECT YET.')


def main():
    parser=argparse.ArgumentParser(description='Jagodic protected source-to-third-Pi clone (no secrets printed)')
    actions=parser.add_mutually_exclusive_group(required=True)
    actions.add_argument('--audit',action='store_true')
    actions.add_argument('--export',action='store_true')
    actions.add_argument('--verify',metavar='ENCRYPTED_ARCHIVE')
    actions.add_argument('--stage',metavar='ENCRYPTED_ARCHIVE')
    actions.add_argument('--apply',metavar='STAGED_DIRECTORY')
    parser.add_argument('--outdir',default='/home/pi/WA_Private_Clone',help='Where to create encrypted export')
    parser.add_argument('--stage-dir',help='New staging directory when decrypting')
    a=parser.parse_args()
    if a.audit:
        paths=source_file_candidates()
        print('Jagodic candidate source paths:')
        for item in paths: print(' ',item)
        print('Source paths discovered:',len(paths),'; application secrets included; Pi Connect/SSH identities excluded')
    elif a.export:
        encrypted_export(a.outdir)
    elif a.verify:
        print('PASS archive SHA256:',check_archive(a.verify))
    elif a.stage:
        if not a.stage_dir: fatal('--stage requires --stage-dir /var/lib/wa-jagodic-clone/stage-001')
        decrypt_to_stage(a.stage,a.stage_dir)
    elif a.apply:
        import_apply(a.apply)

if __name__=='__main__':main()
