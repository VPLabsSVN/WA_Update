#!/usr/bin/env python3
"""Print Jagodic clone migration evidence; never print secret values."""
import json
import os
from pathlib import Path
import re
import subprocess

ROOTS=(Path('/home/wa_stopshop_mb/WA/Main_program/Fis'),Path('/home/pi/WA/Main_program/Fis'))
APP=next((p for p in ROOTS if p.is_dir()),ROOTS[0])
KEYS=(
 'BACKEND_PANEL_ID_OVERRIDE','BACKEND_PANEL_NAME_OVERRIDE','INVERTER_PANEL_ID',
 'WA_PI_MANAGEMENT_IP','WA_SENSOR_POSITION_MAP','WA_R3_STATUS_PORT','WA_R3_RECOVERY_PORT',
 'HR_OIB','HR_BUSINESS_PREMISE','HR_ISU','HR_CERT_PATH','HR_CA_CERT_PATH',
 'POS_TERMINAL_ID','PAYMENT_ENABLED','SI_TAX_NUMBER','RECOVERY_TOKEN_R3'
)
SECRET_RE=re.compile(r'(TOKEN|SECRET|PASSWORD|PRIVATE|PASS|KEY|CERT|OIB|TAX)',re.I)


def print_secret_state(file):
    if not file.is_file():return
    try:
        if file.suffix=='.json':
            d=json.loads(file.read_text(encoding='utf-8'))
            r3=d.get('controllers',{}).get('r3',{})
            print('R3 config:', file, 'controller present:',bool(r3),'token configured:',bool(r3.get('token')))
        else:
            props={}
            for line in file.read_text(encoding='utf-8',errors='replace').splitlines():
                if line.strip().startswith('#') or '=' not in line:continue
                k,v=line.split('=',1)
                k=k.strip()
                if k in KEYS:
                    props[k]='configured' if SECRET_RE.search(k) and v.strip() else ('missing' if not v.strip() else v.strip()[:100])
            if props:
                print(file)
                for k,v in props.items():print(' ', k, '=',v)
    except (OSError,ValueError) as exc:print('Could not parse',file,type(exc).__name__)

print('=== JAGODIC THIRD MACHINE REVIEW (READ ONLY) ===')
print('Hostname:',os.uname().nodename)
print('WA tree:',APP,'exists:',APP.exists())
print('WARNING: all source IDs/keys are CLONED until manually changed.')
for file in [APP/'pi_recovery_endpoints.json', APP/'Panel_backend_merged.py',
             Path('/home/pi/.config/bouquetmat-health.env'),Path('/home/pi/.config/bouquetmat-inverter.env')]:
    print_secret_state(file)
if (APP/'Panel_backend_merged.py').is_file():
    text=(APP/'Panel_backend_merged.py').read_text(encoding='utf-8', errors='replace')
    for var in ('BACKEND_PANEL_ID_OVERRIDE','BACKEND_PANEL_NAME_OVERRIDE'):
        m=re.search(r'^\s*'+var+r'\s*=\s*(.+)$',text,re.M)
        if m:print(var,'=',m.group(1)[:100])
for name in ('bouquetmat.service','bouquetmat-ads.service','inverter-udp-bridge.service', 'wa-r3-watchdog.service'):
    p=Path('/home/pi/.config/systemd/user')/name
    print('User unit',name,'present:',p.exists())
for f in ('/etc/hostname','/boot/firmware/config.txt','/etc/NetworkManager/system-connections'):
    print('System path',f,'exists:',Path(f).exists())
res=subprocess.run(['ip','route','show','default'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True) if Path('/usr/sbin/ip').exists() or Path('/usr/bin/ip').exists() else None
print('NETWORK DEFAULT ROUTE:',bool(res and res.stdout.strip()))
print('CHECK MANUALLY: unique backend panel/device ID; ESP IP/token pairing; static IP; FURS/HR or SI fiscal IDs/cert; POS terminal; invoice ledger; printer; displays; advertisement paths; payment enable flag.')
print('DO NOT connect and start services until each duplicate device/merchant identity is resolved.')
