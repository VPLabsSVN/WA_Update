from pathlib import Path
import importlib.util
import tempfile
import tarfile
import json

modpath=Path(__file__).with_name('jagodic_clone_v1.py')
spec=importlib.util.spec_from_file_location('jagodic_clone_v1',modpath)
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp)
    app=root/'home/wa_stopshop_mb/WA/Main_program/Fis'
    app.mkdir(parents=True)
    (app/'pi_recovery_endpoints.json').write_text('{"controllers":{"r3":{"token":"SECRET_TEST_VALUE"}}}')
    cfg=root/'home/pi/.config'
    cfg.mkdir(parents=True)
    (cfg/'bouquetmat-inverter.env').write_text('INVERTER_SHARED_KEY=SECRET_TEST_VALUE')
    (cfg/'systemd/user').mkdir(parents=True)
    (cfg/'systemd/user/bouquetmat.service').write_text('ExecStart=/usr/bin/python3 /home/pi/WA/Main_program/Fis/Panel.py')
    (root/'home/pi/bb_reservation_v24_restart_guard_v2.py').write_text('# test')
    paths=mod.source_file_candidates(root)
    assert 'home/wa_stopshop_mb/WA' in paths
    assert 'home/pi/.config/bouquetmat-inverter.env' in paths
    assert 'home/pi/.config/systemd/user' in paths
    assert 'home/pi/bb_reservation_v24_restart_guard_v2.py' in paths
    assert 'clone_metadata' not in paths
    t=tarfile.TarInfo('home/pi/.ssh/id_rsa')
    assert mod.filtered(t) is None
    t=tarfile.TarInfo('home/pi/.config/rpi-connect/auth.json')
    assert mod.filtered(t) is None
    assert mod.filtered(tarfile.TarInfo('home/wa_stopshop_mb/WA/private.env')) is not None
    assert mod.safe_member_path(root/'stage','home/pi/WA/x.py')==root/'stage/home/pi/WA/x.py'
    try:
        mod.safe_member_path(root/'stage','../../etc/shadow')
    except SystemExit:pass
    else:raise AssertionError('path escape was allowed')
print('PASS: source includes Jagodic credentials and guard scripts; machine identities excluded; staged paths validated')
