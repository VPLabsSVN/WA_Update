# WA Jagodic → third Raspberry Pi — encrypted application and configuration clone

**Version:** 1.0 · 27 November 2026 · **Source:** Jagodic (`pi@Test1`) · **Destination:** a third Raspberry Pi running compatible Raspberry Pi OS Bookworm, user `pi`.

## What this toolkit does

The export reads the **current Jagodic machine**, not a stale October golden bundle. It includes all files under the existing Jagodic WA application tree (`/home/wa_stopshop_mb/WA` and/or `/home/pi/WA`, whichever exists), including local application JSON secrets and recovery endpoint tokens, application `.env` files, fiscal/payment certificate files located there, POS/fiscal state and receipts, runtime guards, advertisements and Python environments. It also captures the user's systemd service definitions, local helper scripts, ads/display/X11/WayVNC configuration, inversion/health environment files, printer/udev and OS/display boot configuration, plus a Debian package inventory.

The export is encrypted **during creation**, with GPG AES-256 and a passphrase you enter on the source Pi. No plaintext token-containing archive is written to disk, and nothing is uploaded by this toolkit. The output is `<timestamp>.tar.gz.gpg` plus `.sha256`. The recipient Pi must have its own compatible Debian/Raspberry Pi OS installation first; this is **not** a bootable full-disk image.

**Deliberately excluded:** Raspberry Pi Connect's account/device identity, SSH user keys and machine SSH host keys, machine-id, browser sessions, and caches. Their identities should be unique per Pi. Pi Connect can be paired to the third Pi separately.

**Important:** The archive *does* include Jagodic's original production credentials, business/accounting state and controller tokens because you requested a complete source copy. This makes it a **sensitive private backup**. NEVER upload it to public GitHub, paste secret contents into ChatGPT, email it unencrypted, or allow two physical machines with identical fiscal/backend/payment identities to operate at the same time.

## A. On the **Jagodic source Pi**

Copy this toolkit ZIP to the source (GitHub may hold the **toolkit only**, not the encrypted output) and unzip it:

```bash
mkdir -p /home/pi/WA_Jagodic_Clone_Toolkit
cd /home/pi/WA_Jagodic_Clone_Toolkit
unzip -o /home/pi/WA_Jagodic_Third_Machine_Clone_Toolkit_V1.zip
cd jagodic_clone_toolkit_v1

python3 test_jagodic_clone_v1.py
sudo python3 jagodic_clone_v1.py --audit
```

Install missing archive tools if necessary:

```bash
command -v gpg
command -v rsync
# only if missing: sudo apt update && sudo apt install -y gnupg rsync
```

Wait for the kiosk to be idle: **no purchase, payment or door movement and no unsettled invoice.** Stop the kiosk and its auto-restart guard (if present), and any background process that mutates transaction state; check running services first. On the Jagodic user session:

```bash
systemctl --user list-units --all --type=service | grep -Ei 'bouquetmat|ads|inverter|recovery|guard|wa-' || true
systemctl --user list-timers --all | grep -Ei 'bouquetmat|guard|wa-' || true

systemctl --user stop bouquetmat.service
# Stop a watchdog/restart-guard timer too, if the inventory above shows one.
# If the inverter/ads processes write data into the same WA snapshot,
# stop those relevant services temporarily while creating the snapshot.
```

Create the **encrypted, self-contained backup**, entering a long unique passphrase twice:

```bash
sudo python3 jagodic_clone_v1.py --export \
  --outdir /home/pi/WA_Private_Clone
```

The builder prompts you to type `SNAPSHOT` to confirm that no sales or unfinished door cycle are active. It creates files such as:

```
/home/pi/WA_Private_Clone/Jagodic_Full_Clone_YYYYMMDD_HHMMSS.tar.gz.gpg
/home/pi/WA_Private_Clone/Jagodic_Full_Clone_YYYYMMDD_HHMMSS.tar.gz.gpg.sha256
```

After success, restart the original Jagodic services that you stopped (including any auto-restart timers if they were active before):

```bash
systemctl --user start bouquetmat.service
systemctl --user is-active bouquetmat.service
```

Transfer **only** the encrypted `.tar.gz.gpg`, matching `.sha256`, and toolkit to a USB drive or privately with `scp`. Use `chmod 600` and a directory with `chmod 700`. Do not commit these backup files to `VPLabsSVN/WA_Update` or any repo.

## B. On the **new third Raspberry Pi**

Install matching **Raspberry Pi OS Bookworm 64-bit** and use the `pi` user. Set up SSH/USB temporarily to transfer the archive and its `.sha256` to `/home/pi/WA_Private_Clone/`; then **physically disconnect the target** from Ethernet/Wi-Fi. It must remain isolated until its unique backend/payment/fiscal/controller identity is configured.

```bash
# Before disconnection, on the clean OS:
sudo apt update
sudo apt install -y rsync gnupg python3

# With the toolkit and encrypted archive already transferred:
cd /home/pi/WA_Jagodic_Clone_Toolkit/jagodic_clone_toolkit_v1
python3 jagodic_clone_v1.py --verify \
  /home/pi/WA_Private_Clone/Jagodic_Full_Clone_YYYYMMDD_HHMMSS.tar.gz.gpg
```

Replace `YYYYMMDD_HHMMSS` with the archive's actual name. Nothing is installed yet.

After physically disconnecting the network, decrypt to a root-protected staging directory. A passphrase will be requested locally:

```bash
sudo python3 jagodic_clone_v1.py --stage \
  /home/pi/WA_Private_Clone/Jagodic_Full_Clone_YYYYMMDD_HHMMSS.tar.gz.gpg \
  --stage-dir /var/lib/wa-jagodic-clone/stage-001
```

Inspect the staged manifest, package inventory, services and config *without exposing the secret values*:

```bash
sudo cat /var/lib/wa-jagodic-clone/stage-001/clone_metadata/source.json
sudo less /var/lib/wa-jagodic-clone/stage-001/clone_metadata/os_packages.txt
```

Apply the saved WA application, its user service unit files, encrypted-env contents and helper scripts. The script checks for a default network route, requests that you type `ISOLATED`, backs up overwritten files under `/var/lib/wa-jagodic-clone/backups/`, and **does not start/enable any service**:

```bash
sudo python3 jagodic_clone_v1.py --apply \
  /var/lib/wa-jagodic-clone/stage-001
```

User service definitions are copied, but `*.wants` and `*.requires` enablement links are deliberately not installed. OS-specific configuration under `etc/` and `boot/` (network, udev, CUPS/printer, display, system services, hostname) remains under the staging directory for manual comparison. Only matching kiosk-named root service unit definitions are copied; their enablement is not activated. This prevents unexpected live operation with duplicate identities.

## C. Review everything that differs before reconnection

Run the redacted review:

```bash
python3 jagodic_target_review_v1.py
```

You must manually review and update at least:

1. **Panel identity and backend:** new panel ID/name, linked R3 panel ID, app backend registration and device/group identifiers. The source values still say `Jagodic` until changed.
2. **Networking:** target hostname, Pi IP, DHCP/static settings, controller IP addresses/positions (`.200`, `.201`, ports 48556/48557), Wi-Fi credentials and Pi discovery. Do not connect two machines with the same static IP.
3. **Recovery bridge and tokens:** source `pi_recovery_endpoints.json` and health/inverter env keys are preserved. If the third ESP32 is a separate controller, provision a matching **new** secret on both endpoints; do not assume Jagodic's existing token authenticates another ESP32.
4. **Business and fiscal identity:** Croatian FURS/HR certificate/key material, tax/OIB information, business premise, device/IOA identifiers, invoice numbering, outstanding payments, retry and invoice ledgers. Do not let a new independent machine transmit as the old machine. Coordinate numbering/registration with your fiscal integration requirements.
5. **Payments/POS:** terminal IDs, merchant credentials, device serials, payment enable flags and any webhook/source identities; do not reuse a live Jagodic terminal registration.
6. **Hardware/display:** DSI/HDMI mapping, touchscreen, Kivy resolution, motor/door mapping, cameras, USB printer, udev rules and ads output paths. Root OS files are available in the staging directory for comparison.
7. **Systemd services:** kiosk, ads, inverter bridge, recovery watchdog, maintenance scripts and anti-restart guard. Enable only the ones needed after adapting absolute paths and confirming dependencies.
8. **Remote access:** connect Raspberry Pi Connect as a *new* device; this bundle intentionally omits its linked identity and SSH keys.

**Data-state warning:** Copying the whole WA tree also copies fiscal/payment history and state, including outstanding invoice and retry ledgers. Do not merely delete or reset these when enabling a new production machine. Separate or reconcile them using the applicable accounting/merchant workflow.

Once these checks are complete, compare the staged `/etc` and `/boot` files with the new Pi's versions, install missing OS packages from the package inventory, re-create/verify virtualenvs if the CPU architecture or Python ABI differs, then perform an isolated functional test. Only then reconnect the target and enable the specific user services you intentionally choose:

```bash
systemctl --user daemon-reload
systemctl --user list-unit-files | grep -Ei 'bouquetmat|ads|inverter|wa-|guard'
# After changing identities and commissioning the machine, for example:
# systemctl --user enable --now bouquetmat.service
# systemctl --user enable --now bouquetmat-ads.service
```

## D. Important distinction: application clone vs. full disk image

This toolkit clones application code, configs, production application secrets, user services, and custom OS configs into a compatible fresh OS. It does **not** clone the installed Debian/Raspberry Pi OS packages, boot partitions, Linux kernel, entire filesystem, hardware identifiers, machine SSH host keys or Pi Connect account. If the third machine must be **bit-for-bit identical**, a powered-down offline SD/NVMe image of Jagodic is the correct starting point—but that image also duplicates host credentials and startup registrations and must be sanitized **before** first boot on the same network.

## E. Verification and rollback

`--audit` and `--verify` are read-only. `--stage` writes a new, protected staging folder only. `--apply` writes to the target system but does not enable services. The target creates its own backup directory under `/var/lib/wa-jagodic-clone/backups/`. This toolkit does not attempt automatic rollback of transactional data; compare the staged and saved files and restore selected files manually if needed.

Never paste the backup passphrase, production token, `.p12`, `.key` or complete `.env` contents into a chat. Diagnostics can be shared after redacting secrets and customer/payment information.
