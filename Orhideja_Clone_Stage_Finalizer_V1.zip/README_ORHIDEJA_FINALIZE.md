# Orhideja (Videm pri Ptuju) — Stage Finalizer V1

**Scope:** Third Raspberry Pi (`wa-third`, `192.168.1.107`), previously staged Jagodic clone in `/var/lib/wa-jagodic-clone/stage-001`. This package is *not* a working clone archive and contains **no fiscal certificates, POS credentials, recovery tokens, or production secrets**. Keep the encrypted Jagodic clone archive off public GitHub.

## What this package does

- Changes the existing four `TERMS_BODY_*` fields in the **staged** `Panel.py` to combined full General Terms and Privacy Policy text in Slovenian (`si`), English (`en`), German (`de`) and Croatian (`hr`). The Slovenian content was extracted from the two provided Word documents. Other languages are translations of that content. The full original content is not shortened or replaced by a generic policy.
- Applies a first purple-theme pass to specifically recognised button and background **UI accents** only, preserving operational red/green fault/availability colors. The script reports the number of replacements; if the installed `Panel.py` uses other theme constants they require source-specific follow-up.
- Downloads `IMG_901.png` through `IMG_914.png` from the public `VPLabsSVN/WA_Update` GitHub branch, validates their PNG headers and dimensions, and puts them into the staged `Main_program/Ads` folder **with only one preserved World Automatics logo**. All old ads are backed up outside the installed WA tree, under protected `clone_metadata`. It cannot decide which logo is the real logo if multiple plausible files exist: use `--logo "EXACT_FILENAME"` after `--inspect`.
- Downloads `ChatGPT Image Nov 28, 2026, 12_45_07 AM-1.png` to replace `back.png` (main) and `ChatGPT Image Nov 28, 2026, 12_45_08 AM-2.png` to replace `back2.png` (alternate), in the active known asset directories under `Main_program`.
- Stops without changing stage if `Orhideja`/`Videm pri Ptuju`, `PANEL_TYPE='A'`, `PAYMENT_ENABLED=False`, `bp_sent=0`, `allowed=0`, or `INVERTER_PANEL_ID=Orhideja` are not already present.

**What it does NOT do:** It does not install to `/home/wa_stopshop_mb/WA`, alter certificates, update the receipt logic, change ESP32 IP addresses, enable/disable any services, test live payment/fiscalization, or turn the machine on. It also does not prove that every non-POS payment/fiscal path is safely disabled. The commissioning guard `/etc/wa-third-production-ready` must remain absent.

## 1. On the third Pi — while Wi-Fi is connected

Copy this ZIP to `/home/pi`, extract it and run the inventory (read-only):

```bash
mkdir -p /home/pi/orhideja_finalize_v1
cd /home/pi/orhideja_finalize_v1
unzip -o /home/pi/Orhideja_Clone_Stage_Finalizer_V1.zip
sudo python3 orhideja_clone_finalize_v1.py --inspect
```

The inventory lists existing Ads filenames. If it says `Detected logo: <name>`, run:

```bash
sudo python3 orhideja_clone_finalize_v1.py --prepare
```

If it cannot identify the World Automatics logo unambiguously, use the **exact staged logo filename** printed by inspection:

```bash
sudo python3 orhideja_clone_finalize_v1.py --prepare --logo 'EXACT LOGO FILE NAME.png'
```

The script downloads 16 public PNGs. **It never downloads or uploads any private archive or key.** On success it reports the replacement count and paths to stage-only backups.

Review the included translation files before commercial launch. The source terms describe customer payment and reservation payment at the machine even though POS is currently disabled, so the operator should resolve that discrepancy and obtain legal review before enabling sales.

## 2. On the third Pi — before applying the clone

Confirm the guard is absent and the user and root service-guard drop-ins created earlier remain in place:

```bash
sudo test ! -e /etc/wa-third-production-ready && echo 'PASS: commissioning blocked'
for unit in bouquetmat.service bouquetmat-ads.service inverter-udp-bridge.service wa-r3-watchdog.service; do
  test -f "/home/pi/.config/systemd/user/${unit}.d/99-third-commissioning-guard.conf" || echo "MISSING USER GUARD: $unit"
done
for unit in bouquetmat-daily-reboot.timer bouquetmat-daily-reboot.service bouquetmat-clock-sync.service; do
  sudo test -f "/etc/systemd/system/${unit}.d/99-third-commissioning-guard.conf" || echo "MISSING ROOT GUARD: $unit"
done
```

Do **not** proceed if any guard is missing. Network disconnection for `--apply` is enforced by the original clone script; it is not overridden by this package.

## 3. Complete the clone installation — locally, not via Wi-Fi SSH

Attach monitor and keyboard to the third Raspberry Pi, then disconnect Ethernet and Wi-Fi. Check `ip route show default` is empty. Execute:

```bash
cd /home/pi/jagodic_clone_toolkit_v1
sudo python3 jagodic_clone_v1.py --apply /var/lib/wa-jagodic-clone/stage-001
```

Type `ISOLATED` only if physically disconnected and no payment or door operation is active. The tool copies the staged WA tree and relevant services but does **not** start or enable them.

Do not reboot/reconnect yet. Inspect cloned autostart, timers and guards; explicitly stop/mask any cloned service capable of running a kiosk, ads, backend, POS/fiscal traffic, watchdog or scheduled reboot. The user service controls are under the `pi` user manager; root controls are under the system manager. The existing user service guards are stored in `/home/pi/.config/systemd/user/*.service.d/99-third-commissioning-guard.conf`; the root guards are stored in `/etc/systemd/system/*.d/99-third-commissioning-guard.conf`.

```bash
sudo test ! -e /etc/wa-third-production-ready && echo 'PASS: commissioning still blocked'
sudo systemctl daemon-reload
systemctl --user daemon-reload
systemctl --user is-active bouquetmat.service || true
systemctl --user list-timers --all
sudo systemctl list-timers --all | grep -Ei 'bouquetmat|wa-|r3' || true
python3 /home/pi/jagodic_clone_toolkit_v1/jagodic_target_review_v1.py
```

**Do not start the kiosk**, POS, fiscal service, inverter bridge, recovery watchdog or ads at this stage.

## Remaining commissioning work

- New fiscal certificates, tax configuration, transaction sequence and receipt format/logic.
- Confirm every Slovenian and Croatian fiscalization endpoint/gate is blocked until specifically provisioned.
- Check all payment and reservation collection flows: `PAYMENT_ENABLED=False` must not allow unpaid dispensing.
- Update ESP32 addresses and independent recovery tokens/pairing; ensure the third machine cannot control original Jagodic controllers.
- Verify back image orientations and purple styling on the physical display while all transactional functions are disabled.
- Review all 4 translations and legal text against the actual payment process and vendor obligations.
- Re-enable services only after completing hardware, fiscal and identity commissioning; keep a recoverable backup of the third Pi.

## CLI

```text
python3 orhideja_clone_finalize_v1.py --inspect [--stage PATH] [--logo FILENAME]
sudo python3 orhideja_clone_finalize_v1.py --prepare [--stage PATH] [--logo FILENAME]
```

For local testing only, `--assets-dir /directory/with/all/16/pngs` bypasses GitHub downloads. Tested with a synthetic 7,016-independent stage layout and a representative older `Panel.py`; **the actual staged `Panel.py` has not been tested in this environment**. Script fails closed if its code structure or identity differs.
