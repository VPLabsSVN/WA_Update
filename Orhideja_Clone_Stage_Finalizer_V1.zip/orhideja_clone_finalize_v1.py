#!/usr/bin/env python3
"""Orhideja stage-only finalization: legal text, purple accents, ads, background photos.

NO service management, NO live file changes, NO fiscal/POS enablement.
This script updates ONLY an existing clone staging directory.
"""
from __future__ import annotations
import argparse
import ast
import datetime
import json
import os
from pathlib import Path
import re
import shutil
import struct
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request

STAGE_DEFAULT='/var/lib/wa-jagodic-clone/stage-001'
REPO='VPLabsSVN/WA_Update'
IMAGE_FILENAMES=[f'IMG_{n}.png' for n in range(901,915)]
BACKGROUND_FILENAMES=[
 'ChatGPT Image Nov 28, 2026, 12_45_07 AM-1.png',
 'ChatGPT Image Nov 28, 2026, 12_45_08 AM-2.png',
]
PNG_SIGNATURE=b'\x89PNG\r\n\x1a\n'

class Stop(RuntimeError): pass

def ensure(condition,message):
 if not condition: raise Stop(message)

def same_assign(source,key,expected):
 tree=ast.parse(source)
 vals=[]
 for x in tree.body:
  if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name) and x.targets[0].id==key:
   vals.append(x.value.value if isinstance(x.value,ast.Constant) else object())
 ensure(len(vals)==1 and vals[0]==expected,f'Expected {key} = {expected!r} in stage Panel.py (found {vals!r})')

def ensure_panel_backend(source):
 for k,val in [('BACKEND_PANEL_ID_OVERRIDE','Orhideja'),('BACKEND_PANEL_NAME_OVERRIDE','Videm pri Ptuju')]:
  same_assign(source,k,val)

def ensure_flags(stage,app):
 ensure((stage/'clone_metadata/source.json').is_file(), 'No clone_metadata/source.json; incorrect stage directory')
 panel=app/'Panel.py'
 backend=app/'Panel_backend_merged.py'
 ensure(panel.is_file() and backend.is_file(),'Expected Panel.py and Panel_backend_merged.py missing')
 ps=panel.read_text(encoding='utf-8')
 bs=backend.read_text(encoding='utf-8')
 same_assign(ps,'PANEL_TYPE','A')
 same_assign(ps,'PAYMENT_ENABLED',False)
 ensure_panel_backend(bs)
 flag=app/'bp_sent.txt'
 ensure(flag.is_file(),'Missing bp_sent.txt')
 d=dict(re.findall(r'(?m)^\s*([a-z_]+)\s*=\s*([0-9]+)\s*$',flag.read_text(encoding='utf-8')))
 ensure(d.get('bp_sent')=='0' and d.get('allowed')=='0','Expected bp_sent=0 and allowed=0')
 env=stage/'home/pi/.config/bouquetmat-inverter.env'
 ensure(env.is_file() and re.search(r'(?m)^INVERTER_PANEL_ID=Orhideja\s*$',env.read_text()), 'INVERTER_PANEL_ID not Orhideja')
 return panel,backend

def detect_ads_logo(ads_dir,explicit=None):
 ensure(ads_dir.is_dir(), f'Ads directory missing: {ads_dir}')
 files=[p for p in ads_dir.iterdir() if p.is_file() and not p.is_symlink()]
 if explicit:
  matches=[x for x in files if x.name==explicit]
  ensure(len(matches)==1, 'Requested logo not found in Ads: '+explicit)
  return matches[0]
 candidates=[p for p in files if
             (('world' in p.name.lower() and ('automat' in p.name.lower() or 'logo' in p.name.lower()))
              or re.search(r'(?i)(wa[_-]?logo|logo[_ -]?wa|logo[_ -]?world|world[_ -]?automatics)',p.name)
              or (p.name.lower().startswith('logo.') and p.suffix.lower() in ('.jpg','.jpeg','.png','.webp')))]
 if len(candidates)==1: return candidates[0]
 s=', '.join(x.name for x in candidates) if candidates else 'none'
 raise Stop(f'Logo detection ambiguous ({s}); run --inspect and then --apply --logo "EXACT_FILENAME"')

def visible_staged_paths(stage):
 mp=stage/'home/wa_stopshop_mb/WA/Main_program'
 app=mp/'Fis'
 ads=mp/'Ads'
 backgrounds=[x for x in (app/'back.png',app/'back2.png',mp/'Panel/back.png',mp/'Panel/back2.png') if x.is_file()]
 return app,ads,backgrounds

def inspect(stage,logo=None):
 app,ads,bgs=visible_staged_paths(stage)
 print('STAGED CONFIGURATION (no credentials printed)')
 try:
  panel, backend=ensure_flags(stage,app)
  print('  PASS: Orhideja / Videm pri Ptuju, panel A, POS disabled, FURS gate disabled, inverter ID')
  ps=panel.read_text(encoding='utf-8')
  tree=ast.parse(ps)
  legal={}
  for x in tree.body:
   if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name) and x.targets[0].id.startswith('TERMS_BODY_'):
    legal[x.targets[0].id]='static string' if isinstance(x.value,ast.Constant) and isinstance(x.value.value,str) else 'nonstatic'
  print('  legal variables:',','.join(sorted(legal)) or 'NONE')
 except Exception as e: print('  STOP configuration:',e)
 print('  Ads path:',ads,'exists:',ads.is_dir())
 if ads.is_dir():
  for p in sorted(ads.iterdir()):
   if p.is_file():print('    ',p.name)
  try: print('  Detected logo:',detect_ads_logo(ads,logo).name)
  except Stop as e: print('  LOGO SELECTION NEEDED:',e)
 print('  Background files:')
 for p in bgs:print('    ',p)
 if not bgs: print('    NONE (stage update would stop)')
 print('  Source image mapping: first file -> back.png, second file -> back2.png')

def offset(source, lineno, col):
 lines=source.splitlines(keepends=True)
 return sum(len(x.encode('utf-8')) for x in lines[:lineno-1])+col

def legal_patch(source, data):
 tree=ast.parse(source)
 assigns={}
 for node in tree.body:
  if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
   name=node.targets[0].id
   if name in ['TERMS_BODY_'+l.upper() for l in ['si','en','de','hr']]:
    ensure(isinstance(node.value,ast.Constant) and isinstance(node.value.value,str),f'{name} is not a static string')
    ensure(name not in assigns,f'duplicate {name} assignment')
    assigns[name]=node
 expected={f'TERMS_BODY_{lang.upper()}' for lang in ('si','en','de','hr')}
 ensure(set(assigns)==expected, f'Expected four static legal body constants, found {list(assigns)}')
 # Replace assignment VALUE spans only, preserving file layout including other code.
 raw=source.encode('utf-8')
 patches=[]
 for lang in ('si','en','de','hr'):
  node=assigns['TERMS_BODY_'+lang.upper()]
  ensure('terms_body' in source and source.count('TERMS_BODY_'+lang.upper())>=2, f'Missing UI terms mapping for {lang}')
  value=data[lang]
  ensure(len(value)>6000 and 'Zaranšek Simona s.p.' in value and '30' in value, f'Incomplete {lang} legal content')
  start=offset(source,node.value.lineno,node.value.col_offset)
  end=offset(source,node.value.end_lineno,node.value.end_col_offset)
  patches.append((start,end,repr(value).encode('utf-8')))
 for start,end,repl in sorted(patches,reverse=True):
  raw=raw[:start]+repl+raw[end:]
 output=raw.decode('utf-8')
 ast.parse(output)
 return output

def theme_patch(source):
 """Change only matched UI accents; deliberately do not modify red/green fault/status colors."""
 replacements=[
  (r'(?m)(\bbase_normal\s*=\s*ListProperty\()\[0\.20,\s*0\.33,\s*0\.23,\s*0\.84\]',r'\g<1>[0.40, 0.23, 0.58, 0.84]'),
  (r'(?m)(\bbase_hover\s*=\s*ListProperty\()\[0\.24,\s*0\.39,\s*0\.27,\s*0\.92\]',r'\g<1>[0.49, 0.29, 0.70, 0.92]'),
  (r'(?m)(\bbase_down\s*=\s*ListProperty\()\[0\.17,\s*0\.29,\s*0\.20,\s*0\.98\]',r'\g<1>[0.30, 0.15, 0.45, 0.98]'),
  (r'(?m)(\bbg_rgba\s*=\s*ListProperty\()\[0\.20,\s*0\.33,\s*0\.23,\s*0\.84\]',r'\g<1>[0.40, 0.23, 0.58, 0.84]'),
  (r'(?m)(\bfill_rgba\s*=\s*ListProperty\()\[0\.20,\s*0\.33,\s*0\.23,\s*0\.84\]',r'\g<1>[0.40, 0.23, 0.58, 0.84]'),
  (r'(?m)(\b(?:fill_rgba|bg_rgba):\s*)\[0\.20,\s*0\.33,\s*0\.23,\s*0\.84\]',r'\g<1>[0.40, 0.23, 0.58, 0.84]'),
  (r'(?m)(\brgba:\s*)0\.18,\s*0\.30,\s*0\.20,\s*root\.top_band_alpha',r'\g<1>0.35, 0.19, 0.50, root.top_band_alpha'),
  (r'(?m)(\brgba:\s*)0\.04,\s*0\.08,\s*0\.05,\s*root\.bg_alpha',r'\g<1>0.09, 0.04, 0.13, root.bg_alpha'),
 ]
 out=source; counts=[]
 for search,repl in replacements:
  out,n=re.subn(search,repl,out)
  counts.append(n)
 # Avoid changing the semantic colors for faults, availability and status LEDs.
 ast.parse(out)
 return out,counts

def png_metadata(blob:bytes,name:str):
 ensure(blob.startswith(PNG_SIGNATURE) and len(blob)>1024, f'Invalid or too-small PNG: {name} ({len(blob)} bytes)')
 ensure(blob[12:16]==b'IHDR',f'PNG missing IHDR: {name}')
 width,height=struct.unpack('>II',blob[16:24])
 ensure(64 <= width <= 10000 and 64 <= height <= 10000,f'PNG dimensions unexpected for {name}: {width}x{height}')
 return width,height

def fetch_image(name,asset_folder=None):
 if asset_folder:
  p=Path(asset_folder)/name
  ensure(p.is_file(), f'--assets-dir missing: {name}')
  data=p.read_bytes()
 else:
  url='https://raw.githubusercontent.com/'+REPO+'/main/'+urllib.parse.quote(name,safe='')
  req=urllib.request.Request(url,headers={'User-Agent':'WA-Orhideja-Clone-Finalizer/1.0'})
  print(f'  Downloading {name} ...',flush=True)
  try:
   with urllib.request.urlopen(req,timeout=450) as r:
    ensure(r.status==200,f'HTTP {r.status} downloading {name}')
    data=r.read(35*1024*1024+1)
  except (urllib.error.URLError,TimeoutError) as e:
   raise Stop(f'Download failed for {name}: {e}') from e
  ensure(len(data)<=35*1024*1024, f'Unexpectedly large image: {name}')
 wh=png_metadata(data,name)
 print(f'  Verified image {name}: {wh[0]}x{wh[1]} ({len(data)} bytes)')
 return data

def backup_original(path,backup):
 if path.is_dir():
  shutil.copytree(path,backup,symlinks=True)
 elif path.exists():
  backup.parent.mkdir(parents=True,exist_ok=True)
  shutil.copy2(path,backup)

def prepare(stage,legal,logo_name,asset_folder=None):
 ensure(os.geteuid()==0,'Use sudo for stage preparation')
 ensure(stage.resolve().as_posix().startswith('/var/lib/wa-jagodic-clone/stage-'), 'Expected stage under /var/lib/wa-jagodic-clone/stage-*')
 ensure(Path('/etc/wa-third-production-ready').exists() is False,'Commissioning authorization exists! Remove it before preparing')
 app,ads,backgrounds=visible_staged_paths(stage)
 panel,backend=ensure_flags(stage,app)
 # Fail closed if a symlink could make a stage write reach a different filesystem path.
 stage_resolved=stage.resolve()
 for candidate in (app,ads,panel,backend,app/'bp_sent.txt',stage/'home/pi/.config/bouquetmat-inverter.env'):
  ensure(candidate.resolve().is_relative_to(stage_resolved) and not candidate.is_symlink(),
         f'Unsafe symlink/outside-stage path: {candidate}')
 logo=detect_ads_logo(ads,logo_name)
 ensure(logo.resolve().is_relative_to(stage_resolved) and not logo.is_symlink(),
        'Logo must be a regular file contained within the stage')
 ensure(backgrounds,'No back.png or back2.png found in expected active asset locations')
 for p in backgrounds:
  ensure(p.resolve().is_relative_to(stage_resolved) and not p.is_symlink(),
         f'Unsafe symlink/outside-stage background: {p}')
 ensure({p.name for p in backgrounds}=={'back.png','back2.png'},'Expected both back.png and back2.png available in the active assets')
 data=json.loads(Path(legal).read_text(encoding='utf-8'))
 ensure(set(data)=={'si','en','de','hr'}, 'Expected legal translations for si, hr, en, de')
 # Strict code/asset preflight before downloads or mutations.
 source=panel.read_text(encoding='utf-8')
 newsource=legal_patch(source,data)
 newsource,theme_counts=theme_patch(newsource)
 if sum(theme_counts)==0:
  print('  WARNING: No matching known green/teal UI accent tokens; palette requires separate source inspection')
 else:
  print('  UI accent color replacements:',sum(theme_counts),'(groups:',theme_counts,')')
 # Download and validate the complete image set before altering staged files.
 payload={name:fetch_image(name,asset_folder) for name in IMAGE_FILENAMES+BACKGROUND_FILENAMES}
 # Confirm the logo is not among the requested removals
 ensure(logo.name not in IMAGE_FILENAMES,'Selected logo clashes with new photo filenames')
 stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
 backup=stage/'clone_metadata'/f'orhideja_assets_legal_prepatch_{stamp}'
 ensure(not backup.exists(),'Backup directory unexpectedly exists')
 backup.mkdir(parents=True,mode=0o700)
 app_rel=Path('home/wa_stopshop_mb/WA/Main_program/Fis')
 backup_original(panel,backup/app_rel/'Panel.py')
 backup_original(ads,backup/'home/wa_stopshop_mb/WA/Main_program/Ads')
 for p in backgrounds:
  backup_original(p,backup/p.relative_to(stage))
 # WRITE: stage-only edits. The backup is intentionally under clone_metadata (not installed).
 try:
  panel.write_text(newsource,encoding='utf-8')
  # Write Ads as exactly World Automatics logo + requested photographs.
  # Existing image collection has already been archived in the clone_metadata backup.
  tmpads=ads.parent/(ads.name+'_orhideja_prepared')
  ensure(not tmpads.exists(),'Temporary Ads folder exists; inspect before retrying')
  tmpads.mkdir()
  shutil.copy2(logo,tmpads/logo.name)
  for name in IMAGE_FILENAMES:
   (tmpads/name).write_bytes(payload[name])
  oldads=ads.parent/(ads.name+'_orhideja_old_do_not_use')
  ensure(not oldads.exists(),'Previous Ads backup directory exists; inspect before retrying')
  ads.rename(oldads)
  tmpads.rename(ads)
  # The full original Ads tree is preserved in clone_metadata and is not installed.
  # Remove the temporary same-tree swap so only the requested Ads directory is cloned.
  shutil.rmtree(oldads)
  for p in backgrounds:
   source_name=BACKGROUND_FILENAMES[0 if p.name=='back.png' else 1]
   p.write_bytes(payload[source_name])
  newpanel=panel.read_text(encoding='utf-8')
  ast.parse(newpanel)
  ensure(len([f for f in ads.iterdir() if f.is_file()])==15, 'Expected 14 ads + logo')
  for p in backgrounds: ensure(p.read_bytes().startswith(PNG_SIGNATURE),f'Background invalid: {p}')
 except BaseException:
  print('WRITE INTERRUPTED: originals are backed up at',backup, file=sys.stderr)
  raise
 print('\nPASS: ORHIDEJA STAGE UPDATED (NOT INSTALLED)')
 print('  Panel.py translated legal bodies: SI, EN, DE, HR')
 print('  Purple UI accent replacements:',sum(theme_counts))
 print('  Ads: 14 new PNG + preserved logo',logo.name)
 print('  Background images replaced in',len(backgrounds),'active asset paths')
 print('  Original Ads collection preserved only in protected clone_metadata backup')
 print('  Full original file backups:',backup)
 print('  NO services started. DO NOT enable POS, fiscalization, watchdog or backend.')
 return 0

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 g=ap.add_mutually_exclusive_group(required=True)
 g.add_argument('--inspect',action='store_true',help='Read-only stage inventory')
 g.add_argument('--prepare',action='store_true',help='Download and apply stage-only edits')
 ap.add_argument('--stage',default=STAGE_DEFAULT)
 ap.add_argument('--logo',help='Exact filename of World Automatics logo currently inside Ads folder')
 ap.add_argument('--assets-dir',help='Test/offline directory holding the original 16 GitHub PNGs')
 a=ap.parse_args()
 try:
  stage=Path(a.stage)
  if a.inspect:inspect(stage,a.logo)
  else:prepare(stage,Path(__file__).with_name('orhideja_legal_4languages.json'),a.logo,a.assets_dir)
 except Stop as e:
  print('STOP:',e,file=sys.stderr)
  return 2
 return 0
if __name__=='__main__':sys.exit(main())
