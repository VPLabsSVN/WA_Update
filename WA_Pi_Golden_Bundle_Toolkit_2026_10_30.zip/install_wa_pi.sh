#!/usr/bin/env bash
set -euo pipefail
TARGET_USER="${TARGET_USER:-pi}"
TARGET_GROUP="${TARGET_GROUP:-pi}"
TARGET_APP="${TARGET_APP:-/home/wa_stopshop_mb/WA/Main_program/Fis}"
INSTALL_APT="${INSTALL_APT:-0}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ -f "$ROOT/manifest.json" ]] || { echo "Run inside extracted bundle" >&2; exit 1; }

(cd "$ROOT" && sha256sum -c checksums/SHA256SUMS)

if [[ "$INSTALL_APT" == "1" ]]; then
  sudo apt-get update
  xargs -r sudo apt-get install -y < "$ROOT/config/apt-manual-packages.txt"
fi

sudo mkdir -p "$TARGET_APP"
sudo rsync -a --delete "$ROOT/app/Fis/" "$TARGET_APP/"
sudo chown -R "$TARGET_USER:$TARGET_GROUP" /home/wa_stopshop_mb/WA || true

sudo -u "$TARGET_USER" python3 -m venv "$TARGET_APP/venv"
sudo -u "$TARGET_USER" "$TARGET_APP/venv/bin/pip" install --upgrade pip wheel setuptools
sudo -u "$TARGET_USER" "$TARGET_APP/venv/bin/pip" install -r "$ROOT/config/requirements.txt"

USER_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6)"
USER_SYSTEMD="$USER_HOME/.config/systemd/user"
sudo -u "$TARGET_USER" mkdir -p "$USER_SYSTEMD"
sudo rsync -a "$ROOT/systemd/user/" "$USER_SYSTEMD/"
sudo chown -R "$TARGET_USER:$TARGET_GROUP" "$USER_HOME/.config"

HEALTH_ENV="$USER_HOME/.config/bouquetmat-health.env"
if [[ -f "$ROOT/config/bouquetmat-health.env.template" && ! -f "$HEALTH_ENV" ]]; then
  sudo -u "$TARGET_USER" cp "$ROOT/config/bouquetmat-health.env.template" "$HEALTH_ENV"
  TOKEN="$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(36))
PY
)"
  sudo -u "$TARGET_USER" sed -i \
    "s|RECOVERY_TOKEN_R3=__GENERATE_ON_INSTALL__|RECOVERY_TOKEN_R3=${TOKEN}|" "$HEALTH_ENV"
  chmod 600 "$HEALTH_ENV"
fi

if [[ -f "$ROOT/config/bouquetmat-inverter.env.template" && ! -f "$USER_HOME/.config/bouquetmat-inverter.env" ]]; then
  sudo -u "$TARGET_USER" cp "$ROOT/config/bouquetmat-inverter.env.template" "$USER_HOME/.config/bouquetmat-inverter.env"
  chmod 600 "$USER_HOME/.config/bouquetmat-inverter.env"
fi

for f in "$ROOT"/systemd/system/*; do [[ -e "$f" ]] && sudo cp -a "$f" /etc/systemd/system/; done
for f in "$ROOT"/scripts/*; do [[ -e "$f" ]] && sudo cp -a "$f" /usr/local/bin/; done

sudo systemctl daemon-reload
[[ -f /etc/systemd/system/bouquetmat-daily-reboot.timer ]] && sudo systemctl enable bouquetmat-daily-reboot.timer
[[ -f /etc/systemd/system/bouquetmat-clock-sync.timer ]] && sudo systemctl enable bouquetmat-clock-sync.timer

echo "INSTALL COMPLETE"
echo "Before starting services: provision fiscal certs/secrets/network and verify panel identity."
