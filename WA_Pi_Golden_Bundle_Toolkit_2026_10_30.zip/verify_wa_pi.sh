#!/usr/bin/env bash
set -euo pipefail
APP="${TARGET_APP:-/home/wa_stopshop_mb/WA/Main_program/Fis}"
echo "=== FILES ==="
for f in Panel.py Panel_backend_merged.py bouquetmat_launcher.py; do
  [[ -f "$APP/$f" ]] && echo "OK $f" || echo "MISSING $f"
done
if [[ -x "$APP/venv/bin/python" ]]; then
  "$APP/venv/bin/python" -m py_compile \
    "$APP/Panel.py" "$APP/Panel_backend_merged.py" "$APP/bouquetmat_launcher.py"
  echo "PYTHON COMPILE OK"
fi
echo "=== BACKEND ID ==="
grep -nE 'BACKEND_BASE_URL|BACKEND_PANEL_ID_OVERRIDE|BACKEND_PANEL_NAME_OVERRIDE|BACKEND_HEARTBEAT_SECONDS' \
  "$APP/Panel_backend_merged.py" 2>/dev/null || true
echo "=== USER SERVICES ==="
systemctl --user list-unit-files 2>/dev/null | grep -Ei 'bouquet|inverter|ads' || true
echo "=== TIMERS ==="
systemctl list-timers --all 2>/dev/null | grep -Ei 'bouquet|clock|reboot' || true
echo "=== HEALTH ENV ==="
if [[ -f "$HOME/.config/bouquetmat-health.env" ]]; then
  sed -E 's/^([A-Za-z0-9_]*(TOKEN|SECRET|PASSWORD|KEY)[A-Za-z0-9_]*)=.*/\1=<hidden>/I' \
    "$HOME/.config/bouquetmat-health.env"
fi
