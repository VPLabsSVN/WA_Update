#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${APP_DIR:-/home/wa_stopshop_mb/WA/Main_program/Fis}"
OUT_ROOT="${OUT_ROOT:-/home/pi/WA_Golden_Bundles}"
MACHINE_ID="${MACHINE_ID:-Majoska}"
MACHINE_NAME="${MACHINE_NAME:-Cakovec}"
VERSION="${VERSION:-WA-PI-1.0.0}"
STAMP="$(date +%Y%m%d_%H%M%S)"
BUNDLE_NAME="${MACHINE_ID}_${VERSION}_${STAMP}"
WORK="${OUT_ROOT}/${BUNDLE_NAME}"

[[ -d "$APP_DIR" ]] || { echo "ERROR: missing $APP_DIR" >&2; exit 1; }
mkdir -p "$WORK"/{app,systemd/user,systemd/system,scripts,config,checksums,meta,secrets}
chmod 700 "$WORK/secrets"

echo "[1/8] Copying app..."
rsync -a \
  --exclude 'venv/' --exclude '.git/' --exclude '__pycache__/' \
  --exclude '*.pyc' --exclude '*.pyo' --exclude '*.log' \
  --exclude '*.backup*' --exclude 'module-health-backup-*' \
  --exclude 'hr_fiscal_retry_queue.json' --exclude 'bp_sent.txt' \
  --exclude '*.p12' --exclude '*.pfx' --exclude '*.key' \
  --exclude '*.pem' --exclude '*.crt' --exclude '*.cer' \
  --exclude '*.env' --exclude 'monthly_invoice_reports/' \
  --exclude 'receipts/' --exclude 'runtime/' \
  "$APP_DIR/" "$WORK/app/Fis/"

echo "[2/8] Python/package metadata..."
if [[ -x "$APP_DIR/venv/bin/pip" ]]; then
  "$APP_DIR/venv/bin/pip" freeze > "$WORK/config/requirements.txt"
else
  python3 -m pip freeze > "$WORK/config/requirements.txt" || true
fi
python3 --version > "$WORK/meta/python-version.txt" 2>&1 || true
apt-mark showmanual | sort > "$WORK/config/apt-manual-packages.txt" || true
dpkg-query -W -f='${binary:Package}\t${Version}\n' | sort > "$WORK/meta/dpkg-versions.tsv" || true

echo "[3/8] Systemd..."
USER_SYSTEMD="$HOME/.config/systemd/user"
if [[ -d "$USER_SYSTEMD" ]]; then
  rsync -a --exclude '*.wants/' --exclude '*.requires/' \
    "$USER_SYSTEMD/" "$WORK/systemd/user/"
fi
for f in \
  /etc/systemd/system/bouquetmat-daily-reboot.service \
  /etc/systemd/system/bouquetmat-daily-reboot.timer \
  /etc/systemd/system/bouquetmat-clock-sync.service \
  /etc/systemd/system/bouquetmat-clock-sync.timer
do
  [[ -f "$f" ]] && cp -a "$f" "$WORK/systemd/system/"
done
[[ -f /usr/local/bin/bouquetmat-clock-sync.sh ]] && \
  cp -a /usr/local/bin/bouquetmat-clock-sync.sh "$WORK/scripts/"

echo "[4/8] Safe config templates..."
if [[ -f "$HOME/.config/bouquetmat-health.env" ]]; then
  grep -vE '(^|_)(TOKEN|SECRET|PASSWORD|KEY)=' \
    "$HOME/.config/bouquetmat-health.env" \
    > "$WORK/config/bouquetmat-health.env.template" || true
  echo 'RECOVERY_TOKEN_R3=__GENERATE_ON_INSTALL__' >> \
    "$WORK/config/bouquetmat-health.env.template"
fi
if [[ -f "$HOME/.config/bouquetmat-inverter.env" ]]; then
  sed -E \
    's/^([A-Za-z0-9_]*(TOKEN|SECRET|PASSWORD|KEY)[A-Za-z0-9_]*)=.*/\1=__SET_ON_INSTALL__/I' \
    "$HOME/.config/bouquetmat-inverter.env" \
    > "$WORK/config/bouquetmat-inverter.env.template"
fi
command -v nmcli >/dev/null 2>&1 && \
  nmcli -t -f NAME,TYPE connection show \
  > "$WORK/meta/network-connection-names.txt" 2>/dev/null || true
hostnamectl > "$WORK/meta/hostnamectl.txt" 2>&1 || true
uname -a > "$WORK/meta/uname.txt" 2>&1 || true
timedatectl > "$WORK/meta/timedatectl.txt" 2>&1 || true
ip -brief address > "$WORK/meta/ip-addresses.txt" 2>&1 || true
ip route > "$WORK/meta/ip-routes.txt" 2>&1 || true

echo "[5/8] Secret checklist..."
cat > "$WORK/secrets/README_SECRETS_NOT_INCLUDED.txt" <<'EOF'
NOT INCLUDED:
- RECOVERY_TOKEN_R3
- API/backend/inverter/payment secrets
- Wi-Fi credentials
- SSH private keys
- Croatian production P12/PFX/private keys/passwords
Provision these separately.
EOF

echo "[6/8] Manifest..."
APP_HASH="$(find "$WORK/app" -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum | awk '{print $1}')"
cat > "$WORK/manifest.json" <<EOF
{
  "schema": "wa-pi-golden-bundle-v1",
  "version": "$VERSION",
  "machine_id_source": "$MACHINE_ID",
  "machine_name_source": "$MACHINE_NAME",
  "created_at": "$(date --iso-8601=seconds)",
  "source_hostname": "$(hostname)",
  "default_target_path": "/home/wa_stopshop_mb/WA/Main_program/Fis",
  "app_tree_sha256": "$APP_HASH",
  "secrets_included": false
}
EOF

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "$SCRIPT_DIR/install_wa_pi.sh" "$WORK/install_wa_pi.sh"
cp "$SCRIPT_DIR/verify_wa_pi.sh" "$WORK/verify_wa_pi.sh"
chmod +x "$WORK/install_wa_pi.sh" "$WORK/verify_wa_pi.sh"

echo "[7/8] Checksums..."
(
  cd "$WORK"
  find . -type f ! -path './checksums/SHA256SUMS' -print0 \
    | sort -z | xargs -0 sha256sum > checksums/SHA256SUMS
)

echo "[8/8] Archive..."
mkdir -p "$OUT_ROOT"
if command -v zstd >/dev/null 2>&1; then
  ARCHIVE="${OUT_ROOT}/${BUNDLE_NAME}.tar.zst"
  tar -C "$OUT_ROOT" -cf - "$BUNDLE_NAME" | zstd -T0 -19 -o "$ARCHIVE"
else
  ARCHIVE="${OUT_ROOT}/${BUNDLE_NAME}.tar.gz"
  tar -C "$OUT_ROOT" -czf "$ARCHIVE" "$BUNDLE_NAME"
fi
sha256sum "$ARCHIVE" > "${ARCHIVE}.sha256"
echo "CREATED: $ARCHIVE"
echo "SHA256 : ${ARCHIVE}.sha256"
