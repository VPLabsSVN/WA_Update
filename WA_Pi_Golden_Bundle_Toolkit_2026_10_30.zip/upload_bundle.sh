#!/usr/bin/env bash
set -euo pipefail
FILE="${1:-}"
URL="${WA_DEPLOYMENT_UPLOAD_URL:-}"
[[ -f "$FILE" ]] || { echo "Usage: $0 bundle.tar.zst" >&2; exit 2; }
[[ -n "$URL" ]] || { echo "WA_DEPLOYMENT_UPLOAD_URL not configured." >&2; exit 3; }
curl --fail --show-error --progress-bar -X POST -F "file=@${FILE}" "$URL"
