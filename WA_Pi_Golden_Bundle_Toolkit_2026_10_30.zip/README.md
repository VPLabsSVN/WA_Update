# WA Pi Golden Bundle Toolkit

Build on the working Pi:

```bash
chmod +x *.sh
./build_wa_golden_bundle.sh
```

Output defaults to `/home/pi/WA_Golden_Bundles/`.

Restore on another Pi:

```bash
./install_wa_pi.sh
./verify_wa_pi.sh
```

On a fresh Pi, optionally install captured manual Debian packages too:

```bash
INSTALL_APT=1 ./install_wa_pi.sh
```

Secrets/private certificates are intentionally excluded. Provision them separately.

Do not boot a second machine with `Majoska` identity unless it is replacing the original machine.
