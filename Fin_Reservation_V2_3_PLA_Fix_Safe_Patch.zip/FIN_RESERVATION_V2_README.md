# Fin Reservation V2.3 — reserved_for PLA + existing Wolt prepaid collection

**Release note:** Supersedes V2, V2.1 and V2.2. Preserves V2.1's startup translation fix, and adds no-terminal-payment handling for trusted backend Wolt markers (especially the confirmed `reserved_for: "wolt"` convention). Do not install previous ZIPs.

**Target:** Fin machine `/home/wa_stopshop_mb/WA/Main_program/Fis`, deployed Fin Performance V1 only.

## Purpose

- `PLA` in trusted backend metadata (including `reserved_for: "PLA"` and case-insensitive `"pla"`) follows the existing **claim → door → confirm** flow without charging at the kiosk.
- Wolt reservations with the trusted backend marker **`reserved_for: "wolt"`** (or another exact Wolt-specific backend field) follow the **same no-terminal-payment collection path**. A Wolt reservation is assumed to have been settled externally, not paid via Fin's terminal. Valid recognized alternatives are exact `WOLT` in payment-marker fields or `payload`, `wolt`/`is_wolt`/`reserved_for_wolt` boolean `true`, or exact `wolt` text in `reservation_type`, `source`, `order_source`, `provider`, `platform`, `channel`, `type`.
- **Do not use customer-entered codes, product labels, blue LED status or item `status="wolt"` as payment proof**. Conflicts (e.g., Wolt marker + explicit unpaid flag, Wolt and PLA simultaneously) block both charging and door opening. No substring matching. 
- A reservation without a trusted PLA/Wolt marker (including a structured empty `payload`) enters the **existing payment-terminal flow** for its **one local reserved item**. Normal shopping/cart payment remains unchanged, and reserved products remain blocked from normal cart checkout.
- Declined/cancelled payment: no door opens; claim is released.
- A **committed** payment: confirm the server claim before scheduling the existing purchase, fiscalisation and local door command. This is intentionally different from the PLA path, to guard against an expired claim during long terminal checkout.
- Unknown/conflicting marker, missing/short server claim lease, remote-module reserved item, payment uncertainty, or confirmation failure: **fail closed**, no automatic new charge/door command; require review.
- Keep a mode-0600 local `.fin_reservation_v2_recovery.json` when a payment is in-flight. A restart with an unresolved record blocks new unpaid reservation payments until manually reconciled. Do **not** delete this record or roll back blindly if a payment may have been authorized.
- Kivy messages are translated into SI/EN/DE/HR. The V1 performance improvements stay in place.

## Critical integration assumptions to confirm before production use

**This is a staged release, not a proven end-to-end payment integration.** The actual server's claim response schema and paid marker representation have **not** been validated with a PLA reservation. `--check` proves only source compatibility and offline invariants; it does not contact the payment terminal or open a door.

1. **Before applying, verify the backend contract using a dedicated non-production/test reservation.** The claim response must contain `reservation.payload`, or another explicit payment marker field, and a verified `claim_expires_at`, `hold_expires_at`, or `claimed_until` at least **180 seconds in the future**. The patch first calls read-only `/verify` to select a hold: **60 seconds for PLA/Wolt** (original behavior), **600 seconds for unpaid**, and checks consistency again after claiming. If the backend does not report the hold expiry, **unpaid checkout will stop before charging**. That is intentional; extending/returning the lease may require a backend update.
2. Explicit `PLA` is recognized as `reserved_for="PLA"`/`"pla"`, `payload="PLA"`, or as exact `"PLA"` in fields named `marker`, `payment_marker`, `payment_code`, `payment_type`, `reservation_marker` in backend metadata. Other unknown payment-marker formats are blocked instead of guessing. Wolt markers in trusted backend metadata are recognized as documented above. The backend must be authoritative; this code cannot independently prove someone paid online.
3. **Unpaid remote-panel reservations are not enabled in this first release**; only local compartments are eligible. The existing PLA/Wolt remote collection path uses the original door dispatch logic and remains subject to the normal claim/confirm checks.
4. After paid confirmation, the normal Kivy purchase path launches the local door command. The recovery ledger clears on the **relay command's success callback**, not on confirmed physical door opening. For actual door-sensor verification and refunds, further controller/backend work is required.
5. Payment committed but backend confirmation fails, local door command fails, or Pi restarts mid-payment: no blind retry, no automatic refund. Reconcile terminal transaction/invoice, server reservation state and physical stock with the operator.
6. Use authorized test reservations and terminal test mode first. Never run a paid test unattended.

## Installation procedure

First run from the downloaded package directory:

```bash
bash fin_reservation_v2_apply.sh --check
```

The check validates exact Fin V1 file hashes, patch applicability, Python syntax and offline routing tests, without changing the app. **Do not apply until the server marker + claim-expiry contract is checked**.

Only during a supervised maintenance window with no customer payment in progress:

```bash
bash fin_reservation_v2_apply.sh --apply
# after noting the newly printed backup directory, when fully idle:
systemctl --user restart bouquetmat.service
systemctl --user status bouquetmat.service --no-pager -l
journalctl --user -u bouquetmat.service --since '10 minutes ago' -p warning..alert --no-pager
```

### Backups / rollback

Existing Fin Performance V1 backups are untouched. The V2 installer also saves `Panel.py`, `Panel_backend_merged.py`, `backend_client.py`, `Ads.py` in:

`~/fin_reservation_v2_backups/YYYYMMDD_HHMMSS/`

Use the **exact printed path** after checking no payment is in-flight:

```bash
bash fin_reservation_v2_apply.sh --rollback /home/pi/fin_reservation_v2_backups/YYYYMMDD_HHMMSS
# when fully idle, restart:
systemctl --user restart bouquetmat.service
```

**Rollback refuses if `.fin_reservation_v2_recovery.json` exists.** This prevents reverting to V1, which opens unpaid reservations, while a payment's status is unknown. Reconcile any outstanding payment with a responsible operator first. Neither installer nor rollback restarts the service automatically.

### Post-install supervised test checklist

1. Normal nonreserved item: checkout, authorized payment, opening, fiscalisation and receipt unchanged.
2. Valid PLA marker: existing door collection once, no terminal charge.
3. Verified Wolt booking (`reserved_for="wolt"`): existing door collection once, no terminal charge.
4. Wolt conflicting paid/unpaid metadata: no terminal charge and no door. Review server record.
3. Valid unpaid local reservation: checkout screen shows exact item/price; door remains closed until terminal outcome `committed` and backend confirm; one fiscal sale and one door command.
4. Declined/cancelled: no door; reservation remains eligible after release.
5. Claim-expiry absent/short: show payment-unavailable **without a charge or door operation**.
6. Remote unpaid or unknown marker: blocked pending integration.
7. Test failure and rollback, then restart only when idle.
8. Recheck Fin V1 performance and running process after the update.

**Security:** Do not upload actual `Panel.py`/`Panel_backend_merged.py` to public GitHub: the production backend snapshot contains embedded email credentials. The V2 source patch and helper do not include those credentials. Rotate compromised embedded credentials separately.

## Verification added in V2.1

`test_v2_translations_are_module_safe` evaluates the translation dictionary as a literal
and therefore catches module-level expressions like `self.t(...)` which compile
but fail at import. All offline tests still avoid hardware and payment calls.

**Do not assume --check verifies the server contract.** The V2.1 package still requests a 600-second
unpaid claim and requires an explicit trusted claim-expiry timestamp. A server which
omits the timestamp will safely block unpaid checkout before payment. Live test-mode
payment/door/fiscalisation is required before rollout to customers.

## Remaining backend contract checks (required before --apply)

- Confirm an actual Wolt reservation returns `reserved_for: "wolt"` (or a documented equivalent) in BOTH `/verify` and `/claim`; config vs claim must not disagree. A `status="wolt"` item alone is not evidence.
- The backend must ensure Wolt reservations represent externally authorized/paid orders, not merely an unverified merchant-provided text label. Current source logic trusts authenticated backend reservation metadata; it cannot independently validate the Wolt platform payment.
- Still verify unpaid claim-expiry fields on a test backend before enabling checkout. The previous live `--verify` probe did not test `/claim`, so no deployment should be inferred from these unit tests alone.
- Do NOT deploy if the claimed record lacks its Wolt marker or if the claim/verify/config classifications disagree; fail closed by design.
- Keep V1 running until end-to-end supervised tests can be performed. Store no plaintext production credentials in public GitHub.

## V2.3 Fin-specific PLA correction

- Accept exact `reserved_for: "PLA"` and `"pla"` (case-insensitive, surrounding whitespace stripped) in **authenticated backend reservation metadata** as a prepaid collection marker. This matches the live WA reservation convention.
- Keep `reserved_for: "wolt"` unchanged. Do **not** infer payment from numeric/customer-entered reservation codes, product status, item labels, arbitrary notes, or another unrelated `source: "PLA"` field.
- Conflicting Wolt/PLA markers or explicit unpaid flags always return `blocked`.
- Existing verify/claim/config route-consistency checks remain mandatory: an inconsistent record is rejected, not charged or opened.
- Additional offline regression tests cover reserved_for uppercase/lowercase, nested payloads, runtime claim routing, 60-second prepaid holds, and conflicting markers.
- Run the *bundled* `fin_reservation_v2_3_contract_test.py --expect pla` with an actual numeric test reservation whose authenticated backend `reserved_for` is PLA. The test prints the `reserved_for` category **without displaying the value**. Require both `Verified metadata classification: pla` and `Verified top-level reserved_for category: PLA` for this exact bugfix. The test prints the `reserved_for` category **without displaying the value**. Require both `Verified metadata classification: pla` and `Verified top-level reserved_for category: PLA` for this exact bugfix. Read-only test does not claim, charge or open a door.
- Separate **claim-and-release test** for a dedicated unpaid reservation remains necessary to verify >=180 seconds of server-confirmed claim lifetime before a payment test and production deployment. A test claim temporarily modifies reservation availability and can fail to release automatically.
- `--check` cannot verify a live paid/externally-settled booking or the payment terminal. Keep V1 running until real-server preflight and supervised checkout tests complete.
