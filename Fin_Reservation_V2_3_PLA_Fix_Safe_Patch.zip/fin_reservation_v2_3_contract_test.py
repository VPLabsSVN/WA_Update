#!/usr/bin/env python3
"""Fin V2.3 reservation backend contract test.

This is a CONTROLLED TEST, not a read-only probe: --claim-test temporarily
claims and releases the supplied *test* reservation. NO payment, door operation,
confirmation or redemption. A failed release may leave a temporary server hold.
No user-entered codes, claim tokens, credentials, or raw responses are printed.
"""
from __future__ import annotations
import argparse
import ast
import getpass
import json
import pathlib
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone

APPDIR = pathlib.Path('/home/wa_stopshop_mb/WA/Main_program/Fis')
PACKAGE_DIR = pathlib.Path.home() / 'fin_reservation_v2_3'
HELPER_SHA = '984a871b8e2a9b2460ded894adc2e920e32a4b690abafe0b6445ce4951bc13cc'


def get_config():
    src = APPDIR / 'Panel_backend_merged.py'
    tree = ast.parse(src.read_text(encoding='utf-8'), filename=str(src))
    values = {}
    allowed = {'BACKEND_BASE_URL', 'BACKEND_PANEL_KEY', 'BACKEND_PANEL_ID_OVERRIDE'}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in allowed:
                    try:
                        val = ast.literal_eval(node.value)
                    except (ValueError, SyntaxError, TypeError):
                        continue
                    if isinstance(val, str):
                        values[target.id] = val
    if not values.get('BACKEND_BASE_URL'):
        raise RuntimeError('BACKEND_BASE_URL could not be safely loaded')
    return values


def call(base: str, path: str, headers: dict, body=None):
    req = urllib.request.Request(
        base.rstrip('/') + path,
        headers=headers,
        data=None if body is None else json.dumps(body).encode('utf-8'),
        method='GET' if body is None else 'POST',
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as response:
            result = json.load(response)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f'{path} returned HTTP {exc.code} (body withheld)') from None
    except urllib.error.URLError as exc:
        raise RuntimeError(f'{path} connection error ({type(exc.reason).__name__})') from None
    if not isinstance(result, dict):
        raise RuntimeError(f'{path} response was not an object')
    return result


def reserved_for_classification(reservation):
    # Never expose a reservation field value; print only recognized marker types.
    if not isinstance(reservation, dict):
        return "NOT_PRESENT"
    if "reserved_for" not in reservation:
        return "NOT_PRESENT"
    value=reservation.get("reserved_for")
    if value is None or (isinstance(value,str) and not value.strip()):
        return "EMPTY"
    if isinstance(value,str) and value.strip().casefold()=="pla":
        return "PLA"
    if isinstance(value,str) and value.strip().casefold()=="wolt":
        return "WOLT"
    return "OTHER (withheld)"

def reserved_for_classification(reservation):
    # Never expose a reservation field value; print only recognized marker types.
    if not isinstance(reservation, dict):
        return "NOT_PRESENT"
    if "reserved_for" not in reservation:
        return "NOT_PRESENT"
    value=reservation.get("reserved_for")
    if value is None or (isinstance(value,str) and not value.strip()):
        return "EMPTY"
    if isinstance(value,str) and value.strip().casefold()=="pla":
        return "PLA"
    if isinstance(value,str) and value.strip().casefold()=="wolt":
        return "WOLT"
    return "OTHER (withheld)"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expect', choices=['unpaid', 'pla', 'wolt'], default='unpaid')
    parser.add_argument('--claim-test', action='store_true', help='Explicitly permit temporary test claim and release')
    args = parser.parse_args()

    import hashlib
    helper_file = PACKAGE_DIR / 'fin_reservation_v2_logic.py'
    if not helper_file.is_file() or hashlib.sha256(helper_file.read_bytes()).hexdigest() != HELPER_SHA:
        raise RuntimeError('Exact Fin V2.3 helper not found; do not test against unknown code')
    sys.path.insert(0, str(PACKAGE_DIR))
    from fin_reservation_v2_logic import reservation_route, claim_seconds_remaining

    cfg = get_config()
    base = cfg['BACKEND_BASE_URL']
    panel = cfg.get('BACKEND_PANEL_ID_OVERRIDE') or 'Fin'
    headers = {'Content-Type': 'application/json'}
    if cfg.get('BACKEND_PANEL_KEY'):
        headers['X-Panel-Key'] = cfg['BACKEND_PANEL_KEY']

    print('=== FIN V2.3 BACKEND CONTRACT TEST ===')
    print('Expected route:', args.expect)
    print('This requires a DEDICATED TEST reservation with no customer interaction.')
    print('No payment, door command, redemption or confirmation is performed.')
    code = getpass.getpass('Enter TEST reservation code (hidden): ').strip()
    if not code:
        raise RuntimeError('No test code supplied')

    verified = call(base, '/api/reservations/verify', headers, {'code': code, 'panel_id': panel})
    if verified.get('valid') is not True:
        print('FAIL: backend did not verify the test reservation')
        return 1
    record = verified.get('reservation')
    if not isinstance(record, dict):
        print('FAIL: verification returned no reservation record')
        return 1
    route = reservation_route(record)
    print('Verified metadata classification:', route)
    print('Verified top-level reserved_for category:', reserved_for_classification(record))
    print('Verified top-level reserved_for category:', reserved_for_classification(record))
    if route != args.expect:
        print('STOP: classification disagrees with expected route; nothing claimed')
        return 1

    config = call(base, f'/api/panels/{panel}/config', headers)
    matches = [row for row in config.get('reservation_codes', []) if isinstance(row, dict) and row.get('code') == code]
    if matches:
        config_routes = {reservation_route(row) for row in matches}
        print('Config metadata consistent:', config_routes == {route})
        print('Config top-level reserved_for categories:',
              ', '.join(sorted({reserved_for_classification(row) for row in matches})))
        print('Config top-level reserved_for categories:',
              ', '.join(sorted({reserved_for_classification(row) for row in matches})))
        if config_routes != {route}:
            print('STOP: config disagrees with verification; nothing claimed')
            return 1
    else:
        print('Config metadata: no matching record (not assessed)')

    if not args.claim_test:
        print('READ-ONLY PASS: no claim performed. Use --claim-test for server claim/expiry verification.')
        return 0

    answer = input('Type CLAIM-AND-RELEASE-TEST to test and immediately release the hold: ').strip()
    if answer != 'CLAIM-AND-RELEASE-TEST':
        print('Cancelled; nothing claimed')
        return 1

    hold = 600 if route == 'unpaid' else 60
    claim_token = None
    released = False
    try:
        claimed = call(base, '/api/reservations/claim', headers, {
            'code': code, 'panel_id': panel, 'claimed_by': 'panel', 'hold_seconds': hold,
        })
        claim_token = claimed.get('claim_token')
        if not isinstance(claim_token, str) or not claim_token:
            print('STOP: no claim token returned. Manual operator check of server claim state required.')
            return 1
        claimed_record = claimed.get('reservation')
        if not isinstance(claimed_record, dict):
            print('FAIL: claim returned no reservation record')
            return 1
        claimed_route = reservation_route(claimed_record)
        print('Claim metadata classification:', claimed_route)
        if claimed_route != route:
            print('FAIL: verify/claim metadata inconsistent; no payment should proceed')
            return 1
        seconds = claim_seconds_remaining(claimed)
        if seconds is None:
            print('Claim expiry: MISSING or INVALID (no reliable server lease)')
        else:
            print(f'Claim expires in approximately: {seconds:.0f} seconds')
        if route == 'unpaid' and (seconds is None or seconds < 180):
            print('FAIL: unpaid checkout lease would be rejected by V2.3')
            return 1
        print('Preliminary PASS: claim metadata and hold satisfy the V2.3 preflight requirements (release still required)')
        return 0
    finally:
        if claim_token:
            try:
                result = call(base, '/api/reservations/release', headers, {
                    'code': code, 'claim_token': claim_token, 'panel_id': panel,
                    'released_by': 'panel', 'release_reason': 'contract_test_completed',
                })
                if any(result.get(k) is False for k in ('ok', 'released', 'success') if k in result):
                    print('WARNING: release endpoint reported failure. Check reservation server manually.')
                elif any(result.get(k) is True for k in ('ok', 'released', 'success')):
                    released = True
                    print('Release endpoint explicitly acknowledged success.')
                else:
                    print('Release response had no recognized success flag; status not proven.')
                # This second verify does NOT claim, confirm or redeem the reservation.
                try:
                    after = call(base, '/api/reservations/verify', headers, {'code': code, 'panel_id': panel})
                    print('Post-release verify valid:', 'YES' if after.get('valid') is True else 'NO/UNKNOWN')
                    if after.get('valid') is not True:
                        released = False
                except Exception:
                    print('WARNING: post-release verification unavailable.')
                    released = False
            except Exception as exc:
                print('WARNING: auto-release failed:', type(exc).__name__)
                print('The TEST reservation may remain claimed until its server lease expires.')
        if not released:
            print('FAIL: Do not reuse the test reservation until its server state is reconciled.')
            raise SystemExit(2)
        print('CLAIM-AND-RELEASE PASS: test reservation released; inspect any remaining backend constraints before deployment.')


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print('Contract test stopped:', type(exc).__name__, str(exc) if isinstance(exc, RuntimeError) else '', file=sys.stderr)
        raise SystemExit(1)
