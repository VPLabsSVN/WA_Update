"""Pure reservation routing/lease checks for Fin V2.3.

No network, payment, hardware, or Kivy dependencies. A marker is NEVER
inferred from a customer-entered reservation code. Only backend data is used.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
from typing import Any

PLA_FIELDS = ("payment_marker", "payment_code", "payment_type", "marker", "reservation_marker")
PAID_FIELDS = ("is_paid", "paid", "payment_status")
# Wolt is prepaid outside the kiosk. These are existing reservation data fields,
# NEVER inferred from user-entered code, item status/LED, or free-text notes.
WOLT_TEXT_FIELDS = (
    "reserved_for", "reservation_type", "source", "order_source",
    "provider", "platform", "channel", "type",
)
WOLT_BOOLEAN_FIELDS = ("wolt", "is_wolt", "reserved_for_wolt")


def _scalar(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, str):
        return v.strip().upper()
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    return "?"


def _metadata_values(record: dict) -> tuple[list[str], list[str], bool, bool]:
    """Return trusted payment markers, paid signals, Wolt signal, and ambiguity."""
    markers: list[str] = []
    paid: list[str] = []
    wolt = False
    opaque = False
    def visit(obj, *, depth=0, is_payload=False):
        nonlocal opaque, wolt
        if depth > 5:
            opaque = True
            return
        if isinstance(obj, str) and is_payload:
            raw = obj.strip()
            if not raw:
                return
            if raw.upper() == "PLA":
                markers.append("PLA")
                return
            if raw.upper() == "WOLT":
                wolt = True
                return
            try:
                obj = json.loads(raw)
            except (ValueError, TypeError):
                opaque = True
                return
        if isinstance(obj, dict):
            for key, value in obj.items():
                if key in PLA_FIELDS:
                    if not isinstance(value, (str, type(None))):
                        opaque = True
                    else:
                        markers.append(_scalar(value))
                elif key in PAID_FIELDS:
                    paid.append(_scalar(value))
                elif key in WOLT_BOOLEAN_FIELDS:
                    if value is True:
                        wolt = True
                    elif value is not False and value is not None:
                        opaque = True  # reject ambiguous "true" strings / integers
                elif key in WOLT_TEXT_FIELDS:
                    if isinstance(value, str):
                        text = value.strip().casefold()
                        if key == "reserved_for" and text == "pla":
                            # Fin's backend uses reserved_for for prepaid PLA,
                            # just as it already uses reserved_for for Wolt.
                            # Read only trusted backend metadata, never the
                            # customer-entered numeric reservation code.
                            markers.append("PLA")
                        elif text == "wolt":
                            wolt = True
                        elif "wolt" in text or (key == "reserved_for" and "pla" in text):
                            # Do not interpret partial/ambiguous markers as
                            # either free collection or ordinary unpaid items.
                            opaque = True
                    elif value is not None:
                        opaque = True
                elif key == "status" and isinstance(value, str) and value.strip().casefold() == "wolt":
                    opaque = True  # item/LED status alone is not payment authorization
                elif key == "payload":
                    visit(value, depth=depth + 1, is_payload=True)
                elif isinstance(value, (dict, list)):
                    visit(value, depth=depth + 1)
        elif isinstance(obj, list):
            for value in obj[:20]:
                visit(value, depth=depth + 1)
            if len(obj) > 20:
                opaque = True
        elif obj is not None:
            opaque = True
    visit(record)
    return markers, paid, wolt, opaque


def reservation_route(record: dict) -> str:
    """Return 'pla', 'wolt', 'unpaid', or 'blocked' using backend metadata only.

    PLA and Wolt are external no-terminal-payment collection routes. Do not
    interpret the customer's submitted reservation code or item LED status.
    Conflicting evidence must never trigger a new charge or open a door.
    """
    if not isinstance(record, dict):
        return "blocked"
    markers, paid_states, wolt, opaque = _metadata_values(record)
    empty_markers = ("", "NONE", "UNPAID", "NOT_PAID", "NO", "FALSE")
    if any(m not in (*empty_markers, "PLA", "WOLT") for m in markers):
        return "blocked"
    pla = "PLA" in markers
    wolt = wolt or "WOLT" in markers
    if pla and wolt:
        return "blocked"  # conflicting external collection sources
    explicitly_paid = any(p in ("TRUE", "PAID", "YES", "COMMITTED", "SETTLED") for p in paid_states)
    explicitly_unpaid = any(p in ("FALSE", "UNPAID", "NOT_PAID") for p in paid_states)
    if any(p not in ("", "FALSE", "UNPAID", "NOT_PAID", "PENDING", "NONE",
                     "TRUE", "PAID", "YES", "COMMITTED", "SETTLED") for p in paid_states):
        return "blocked"
    if explicitly_paid and explicitly_unpaid:
        return "blocked"
    if opaque:
        return "blocked"
    if pla:
        return "blocked" if explicitly_unpaid else "pla"
    if wolt:
        return "blocked" if explicitly_unpaid else "wolt"
    # A generic paid flag without a verified external source must not be charged twice.
    if explicitly_paid:
        return "blocked"
    return "unpaid"


def claim_seconds_remaining(claim_result: dict, now: datetime | None = None) -> float | None:
    """Compute seconds left from an explicit server claim expiry; never from reservation expiry."""
    if not isinstance(claim_result, dict):
        return None
    obj = claim_result.get("reservation") or {}
    for container in (claim_result, obj if isinstance(obj, dict) else {}):
        for key in ("claim_expires_at", "hold_expires_at", "claimed_until"):
            raw = container.get(key)
            if not raw:
                continue
            try:
                stamp = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
                if stamp.tzinfo is None:
                    return None
                return (stamp - (now or datetime.now(timezone.utc))).total_seconds()
            except (ValueError, TypeError, OverflowError):
                return None
    return None
