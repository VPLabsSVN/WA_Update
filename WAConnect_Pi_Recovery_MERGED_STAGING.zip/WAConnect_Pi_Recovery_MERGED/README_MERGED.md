# WA Connect Pi recovery — merged remote + attended maintenance policy

This merge combines the working JSON endpoint/token bridge with the Full Maintenance staging safety split.

## Remote/mobile path

`command_type = module_recovery` remains the backend-to-Pi command family. The Pi may forward only commands that do **not** require a physical inspection:

- `remote_recovery_status`
- `remote_recovery_resync`
- `remote_recovery_led_refresh`
- `remote_motor_status`
- `remote_motor_stop`
- `remote_motor_quarantine` (motor 7 or 10)
- `remote_motor_recover_7` / `remote_motor_recover_10`
- generic `recover` / `remote_motor_recover` with motor 7 or 10, but only when fresh controller telemetry shows fault reason **1, 3 or 5**.

The backend/mobile path **always rejects `inspected_hardware=true`**. It also rejects `start`, `reinit`, `clear_fault`, and `clear_global` as local-maintenance-only commands.

Fault reasons 2, 4, 6 and 7 are never remotely recovered from the mobile/backend path.

## Local Pi attended maintenance

Use `wa_maintenance_cli.py`. It supports the full R3 maintenance allowlist and requires an interactive terminal before mutating operations. Inspection-required operations require both `--inspected-hardware` and an inspection note, followed by the explicit physical-inspection confirmation phrase.

Examples (dry run only):

```bash
python3 wa_maintenance_cli.py --action remote_motor_status
python3 wa_maintenance_cli.py --action remote_motor_recover --motor 7 --inspected-hardware --inspection-note 'Physically checked tray and TMC wiring'
```

Add `--execute` only while connected to the Pi and ready to send the command.

## Credential storage

The bridge uses `pi_recovery_endpoints.json`; ESP recovery tokens stay only on the Pi. Do not put them in backend commands, app payloads, logs, or URLs.

## Safety boundary

A backend user cannot turn an inspection-required fault into an inspected recovery by sending `inspected_hardware=true`; the Pi rejects it. Inspection-required actions are accepted only through the local attended maintenance CLI. The ESP32 then independently re-checks its door, ENN, TMC/UART/DRV/GSTAT, encoder and fault-state requirements.

## Installation

Do not blindly replace live `Panel_backend_merged.py` or `wa_module_health_bridge.py` if the live Pi has newer UI/backend changes. Merge only the recovery sections into the current live files, make timestamped backups, run `py_compile`, then restart `bouquetmat.service`.
