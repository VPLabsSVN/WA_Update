from __future__ import annotations
import inspect
import hashlib
import os
import re
import socket
import threading
import time
import csv
import calendar
import json
import smtplib
import glob
from email.message import EmailMessage

try:
    from receipt_printer import ReceiptPrinterConfig, print_receipt, extract_fiscal_marks
except Exception as _receipt_import_error:
    ReceiptPrinterConfig = None
    print_receipt = None
    extract_fiscal_marks = None
    print(f"[RECEIPT PRINTER] Import failed: {_receipt_import_error}")
from decimal import Decimal, ROUND_HALF_UP
from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Optional

import requests
from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout

import Panel as base

import sys
from datetime import datetime

LOG_FILE = "/home/wa_stopshop_mb/WA/Main_program/Fis/panel_runtime_log.txt"


# ---- RECEIPT PRINTER SETTINGS ----
# SK1-311SF4-Q-M-SP supports USB/RS232. Use usb_file on Raspberry when it appears as /dev/usb/lp0.
# For serial/COM usage, set RECEIPT_PRINTER_CONNECTION = "serial" and RECEIPT_PRINTER_DEVICE = "COM3" or "/dev/ttyUSB0".
RECEIPT_PRINTER_ENABLED = True
RECEIPT_PRINTER_CONNECTION = "usb_file"
RECEIPT_PRINTER_DEVICE = "/dev/usb/lp0"
RECEIPT_PRINTER_SERIAL_BAUDRATE = 115200
RECEIPT_PRINTER_WAIT_FOR_FISCAL_SECONDS = 8.0
RECEIPT_PRINTER_TAX_NUMBER = "68495875401"
RECEIPT_PRINTER_BUSINESS_NAME = "Cvetlicarna Majoska"
RECEIPT_PRINTER_OPERATOR_NAME = "TMP d.o.o."
RECEIPT_PRINTER_ADDRESS_LINE = "Dragoslavec Selo 12b, 40306 Macinec"
RECEIPT_PRINTER_QR_MODULE_SIZE = 4
RECEIPT_PRINTER_CUT_PAPER = True


# ---- MONTHLY INVOICE CSV / EMAIL REPORTING ----
# Every paid/fiscalized invoice is also written to a monthly CSV file.
# At the beginning of a new month, the app tries to send the completed previous month by email.
MONTHLY_INVOICE_REPORTS_ENABLED = True
MONTHLY_INVOICE_REPORT_DIR = os.path.join(os.path.dirname(LOG_FILE), "monthly_invoice_reports")
MONTHLY_INVOICE_SENT_MARKER_FILE = os.path.join(MONTHLY_INVOICE_REPORT_DIR, "monthly_invoice_email_sent.json")

# Test recipient requested by the user. Change this later for production.
MONTHLY_INVOICE_EMAIL_TO = "majoska.shop@gmail.com"

# Email sending stays disabled until SMTP credentials are entered.
# Titan Email SMTP defaults.
# Fill MONTHLY_INVOICE_SMTP_PASSWORD and set MONTHLY_INVOICE_EMAIL_ENABLED = True to send.
# Titan supports smtp.titan.email with either:
#   - port 465 + SSL/TLS  -> MONTHLY_INVOICE_SMTP_USE_TLS = False
#   - port 587 + STARTTLS -> MONTHLY_INVOICE_SMTP_USE_TLS = True
MONTHLY_INVOICE_EMAIL_ENABLED = False
MONTHLY_INVOICE_EMAIL_FROM = "vid.pejovnik@worldautomatics.com"
MONTHLY_INVOICE_SMTP_HOST = "smtp.titan.email"
MONTHLY_INVOICE_SMTP_PORT = 465
MONTHLY_INVOICE_SMTP_USERNAME = "vid.pejovnik@worldautomatics.com"
MONTHLY_INVOICE_SMTP_PASSWORD = "Tomaz123321!"
MONTHLY_INVOICE_SMTP_USE_TLS = False

# Test switch: when True, the app sends a combined CSV with all invoice rows on startup.
# Keep this False in production, otherwise it sends the all-invoices test report every startup.
MONTHLY_INVOICE_TEST_SEND_ALL_ON_STARTUP = False
MONTHLY_INVOICE_ALL_REPORT_FILENAME = "invoices_all_test_export.csv"

# Safety import: also scan older txt/json invoice logs and copy successful payments into monthly CSVs.
# This is safe to leave enabled because duplicate invoice/tax rows are skipped.
MONTHLY_INVOICE_IMPORT_OLD_TXT_ENABLED = False
MONTHLY_INVOICE_OLD_TXT_IMPORTED_MARKER_FILE = os.path.join(MONTHLY_INVOICE_REPORT_DIR, "old_txt_invoice_import_last.json")

MONTHLY_INVOICE_CSV_FIELDS = [
    "invoice_number",
    "issued_time",
    "amount",
    "tax_rate",
    "taxable_amount",
    "tax_amount",
]
_MONTHLY_INVOICE_REPORT_LOCK = threading.RLock()


# ---- CROATIAN FISCAL RETRY QUEUE ----
#
# Paid purchases must never be lost just because Croatian CIS
# is temporarily unavailable. Failed HR fiscalisation attempts
# are stored here using the ORIGINAL invoice number, timestamp
# and purchased items.
HR_FISCAL_RETRY_FILE = os.path.join(
    os.path.dirname(LOG_FILE),
    "hr_fiscal_retry_queue.json",
)
_HR_FISCAL_RETRY_LOCK = threading.RLock()


def _load_hr_fiscal_retry_queue() -> dict:
    with _HR_FISCAL_RETRY_LOCK:
        try:
            if not os.path.exists(HR_FISCAL_RETRY_FILE):
                return {}

            with open(
                HR_FISCAL_RETRY_FILE,
                "r",
                encoding="utf-8",
            ) as f:
                data = json.load(f)

            return data if isinstance(data, dict) else {}

        except Exception as exc:
            print(
                "[HR FISCAL RETRY] "
                f"Could not load queue: {exc}"
            )
            return {}


def _save_hr_fiscal_retry_queue(data: dict):
    with _HR_FISCAL_RETRY_LOCK:
        directory = os.path.dirname(
            HR_FISCAL_RETRY_FILE
        )
        os.makedirs(directory, exist_ok=True)

        tmp = HR_FISCAL_RETRY_FILE + ".tmp"

        with open(
            tmp,
            "w",
            encoding="utf-8",
        ) as f:
            json.dump(
                data,
                f,
                ensure_ascii=False,
                indent=2,
            )
            f.flush()
            os.fsync(f.fileno())

        os.replace(
            tmp,
            HR_FISCAL_RETRY_FILE,
        )


def _queue_hr_fiscal_retry(
    *,
    invoice_number,
    issue_datetime_iso,
    total,
    items,
    fiscal_status,
    error_text="",
):
    key = str(invoice_number)

    with _HR_FISCAL_RETRY_LOCK:
        data = _load_hr_fiscal_retry_queue()

        previous = data.get(key) or {}

        try:
            attempts = int(
                previous.get("attempts", 0)
            ) + 1
        except Exception:
            attempts = 1

        data[key] = {
            "invoice_number": key,
            "issue_datetime_iso": str(
                issue_datetime_iso
            ),
            "total": float(total or 0.0),
            "items": [
                deepcopy(it)
                for it in (items or [])
            ],
            "country_code": "HR",
            "payment_status": "paid",
            "fiscal_status": str(
                fiscal_status
            ),
            "last_error": str(
                error_text or ""
            )[:4000],
            "attempts": attempts,
            "updated_at": datetime.now().isoformat(),
        }

        _save_hr_fiscal_retry_queue(data)

    print(
        "[HR FISCAL RETRY] queued "
        f"invoice={key} attempts={attempts}"
    )


def _remove_hr_fiscal_retry(invoice_number):
    key = str(invoice_number)

    with _HR_FISCAL_RETRY_LOCK:
        data = _load_hr_fiscal_retry_queue()

        if key not in data:
            return

        data.pop(key, None)
        _save_hr_fiscal_retry_queue(data)

    print(
        "[HR FISCAL RETRY] cleared "
        f"invoice={key}"
    )



# Retry conservatively. The queue itself is durable, so there is
# no need to aggressively hammer the Croatian service.
HR_FISCAL_RETRY_INTERVAL_SECONDS = 300
_HR_FISCAL_RETRY_WORKER_LOCK = threading.Lock()


def _retry_queued_hr_fiscal_invoices(app=None):
    """
    Retry durable Croatian fiscalisation failures.

    IMPORTANT:
    - original invoice number is reused
    - original issue timestamp is reused
    - original items/tax values are reused
    - purchase fulfilment is never repeated here
    """

    if not _HR_FISCAL_RETRY_WORKER_LOCK.acquire(
        blocking=False
    ):
        return

    try:
        if app is None:
            try:
                app = App.get_running_app()
            except Exception:
                app = None

        # Never guess Croatia from the default SI value.
        if app is not None:
            confirmed = bool(
                getattr(
                    app,
                    "_backend_country_confirmed",
                    False,
                )
            )

            confirmed_country = str(
                getattr(
                    app,
                    "_backend_confirmed_country",
                    "",
                )
                or ""
            ).strip().upper()

            current_country = str(
                getattr(
                    app,
                    "machine_country_code",
                    "",
                )
                or ""
            ).strip().upper()

            if (
                not confirmed
                or confirmed_country != "HR"
                or current_country != "HR"
            ):
                return

        queue = _load_hr_fiscal_retry_queue()

        if not queue:
            return

        print(
            "[HR FISCAL RETRY] "
            f"processing {len(queue)} queued invoice(s)"
        )

        # Process oldest-looking records first.
        records = list(queue.values())

        records.sort(
            key=lambda x: str(
                x.get("issue_datetime_iso", "")
            )
        )

        for record in records:

            invoice_number = str(
                record.get("invoice_number") or ""
            ).strip()

            issue_datetime_iso = str(
                record.get("issue_datetime_iso") or ""
            ).strip()

            items = list(
                record.get("items") or []
            )

            if (
                not invoice_number
                or not issue_datetime_iso
                or not items
            ):
                print(
                    "[HR FISCAL RETRY] invalid queued "
                    f"record invoice={invoice_number!r}"
                )
                continue

            try:
                result = _country_process_transaction(
                    invoice_number=invoice_number,
                    issue_datetime_iso=issue_datetime_iso,
                    items=items,

                    # The original sale was already accepted
                    # and queued. Do not require the current
                    # bp_sent state to reconstruct the same
                    # fiscal attempt.
                    allowed_override=1,
                )

                ok = bool(
                    isinstance(result, dict)
                    and result.get("inv_ok")
                )

                if ok:
                    _remove_hr_fiscal_retry(
                        invoice_number
                    )

                    print(
                        "[HR FISCAL RETRY] SUCCESS "
                        f"invoice={invoice_number}"
                    )

                    try:
                        if app is not None:
                            app.backend_post_event_async(
                                "fiscalisation_retry_success",
                                payload={
                                    "invoice_number":
                                        invoice_number,
                                    "result":
                                        result,
                                },
                            )
                    except Exception:
                        pass

                else:
                    error_text = str(
                        result or ""
                    )

                    _queue_hr_fiscal_retry(
                        invoice_number=invoice_number,
                        issue_datetime_iso=(
                            issue_datetime_iso
                        ),
                        total=float(
                            record.get("total", 0.0)
                            or 0.0
                        ),
                        items=items,
                        fiscal_status="failed",
                        error_text=error_text,
                    )

                    print(
                        "[HR FISCAL RETRY] FAILED "
                        f"invoice={invoice_number}"
                    )

            except Exception as exc:

                _queue_hr_fiscal_retry(
                    invoice_number=invoice_number,
                    issue_datetime_iso=(
                        issue_datetime_iso
                    ),
                    total=float(
                        record.get("total", 0.0)
                        or 0.0
                    ),
                    items=items,
                    fiscal_status="error",
                    error_text=str(exc),
                )

                print(
                    "[HR FISCAL RETRY] ERROR "
                    f"invoice={invoice_number}: {exc}"
                )

    finally:
        _HR_FISCAL_RETRY_WORKER_LOCK.release()


def _hr_fiscal_retry_tick(app):
    """
    Clock callback. Actual network work runs outside the Kivy
    UI thread.
    """

    try:
        threading.Thread(
            target=_retry_queued_hr_fiscal_invoices,
            args=(app,),
            daemon=True,
        ).start()
    except Exception as exc:
        print(
            "[HR FISCAL RETRY] "
            f"could not start worker: {exc}"
        )


def _invoice_month_from_iso(issue_datetime_iso: str):
    try:
        dt = datetime.fromisoformat(str(issue_datetime_iso).replace("Z", "+00:00"))
    except Exception:
        dt = datetime.now()
    return dt.year, dt.month


def _monthly_invoice_csv_path(year: int, month: int) -> str:
    return os.path.join(MONTHLY_INVOICE_REPORT_DIR, f"invoices_{int(year):04d}_{int(month):02d}.csv")


def _all_invoices_csv_path() -> str:
    return os.path.join(MONTHLY_INVOICE_REPORT_DIR, MONTHLY_INVOICE_ALL_REPORT_FILENAME)



def _old_invoice_log_candidate_paths() -> list[str]:
    """Return possible old/current txt invoice log paths.

    The most useful old source is Panel.PAYMENT_LOG_FILE, which stores JSON lines
    written by append_payment_terminal_log().  LOG_FILE is also included because
    TeeLogger may contain pasted/printed JSON records in some deployments.
    """
    paths: list[str] = []

    def _add(path):
        if not path:
            return
        try:
            normalized = os.path.abspath(str(path))
        except Exception:
            normalized = str(path)
        if normalized not in paths:
            paths.append(normalized)

    _add(getattr(base, "PAYMENT_LOG_FILE", ""))
    _add(os.path.join(os.path.dirname(LOG_FILE), "payment_terminal_log.txt"))
    _add(LOG_FILE)
    return paths


def _json_from_log_line(line: str):
    text = str(line or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        pass

    # Runtime logs may prefix JSON with text. Try to parse the first {...} block.
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        candidate = text[start:end + 1]
        try:
            return json.loads(candidate)
        except Exception:
            return None
    return None


def _record_is_successful_invoice(record: dict) -> bool:
    if not isinstance(record, dict):
        return False
    if not record.get("invoice_number"):
        return False

    result = record.get("result") if isinstance(record.get("result"), dict) else {}
    outcome = str(result.get("outcome") or record.get("outcome") or "").lower()
    kind = str(record.get("kind") or "").lower()
    payment_status = str(record.get("payment_status") or "").lower()

    if outcome == "committed":
        return True
    if payment_status == "paid":
        return True
    if kind in {"payment_terminal_result", "payment_result"} and outcome == "committed":
        return True
    return False


def _record_to_invoice_args(record: dict):
    invoice_number = str(record.get("invoice_number") or "").strip()
    issue_datetime_iso = str(record.get("issue_datetime_iso") or record.get("issued_time") or record.get("logged_at") or "").strip()
    if not issue_datetime_iso:
        issue_datetime_iso = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    try:
        total = float(record.get("total") or record.get("amount") or 0.0)
    except Exception:
        total = 0.0
    items = record.get("items") if isinstance(record.get("items"), list) else []
    if not total and items:
        try:
            total = sum(float(it.get("price", 0.0)) for it in items if isinstance(it, dict))
        except Exception:
            total = 0.0
    return invoice_number, issue_datetime_iso, total, items


def import_old_txt_invoices_to_monthly_csv() -> int:
    """Import successful invoice rows from old txt/json logs into monthly CSVs.

    It can be run repeatedly. append_monthly_invoice_csv() skips duplicate
    invoice_number + tax_rate rows, so this acts as a safety net for older logs.
    """
    if not MONTHLY_INVOICE_REPORTS_ENABLED or not MONTHLY_INVOICE_IMPORT_OLD_TXT_ENABLED:
        return 0

    imported = 0
    scanned_records = 0
    for path in _old_invoice_log_candidate_paths():
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    record = _json_from_log_line(line)
                    if not isinstance(record, dict):
                        continue
                    scanned_records += 1
                    if not _record_is_successful_invoice(record):
                        continue
                    invoice_number, issue_datetime_iso, total, items = _record_to_invoice_args(record)
                    if not invoice_number:
                        continue
                    append_monthly_invoice_csv(invoice_number, issue_datetime_iso, total, items)
                    imported += 1
        except Exception as e:
            print(f"[OLD TXT INVOICE IMPORT] Could not scan {path}: {e}")

    if imported:
        print(f"[OLD TXT INVOICE IMPORT] Imported/checked {imported} successful old invoice record(s).")
    else:
        print(f"[OLD TXT INVOICE IMPORT] No old successful invoice records imported. Scanned JSON records: {scanned_records}.")
    return imported


def build_all_invoices_test_csv() -> str:
    """Build one combined CSV from all monthly invoice CSV files.

    This is mainly for email testing and accountant export checks. It combines rows
    from invoices_YYYY_MM.csv files and de-duplicates identical rows.
    """
    import_old_txt_invoices_to_monthly_csv()
    os.makedirs(MONTHLY_INVOICE_REPORT_DIR, exist_ok=True)
    out_path = _all_invoices_csv_path()
    monthly_paths = sorted(glob.glob(os.path.join(MONTHLY_INVOICE_REPORT_DIR, "invoices_????_??.csv")))

    rows: list[dict[str, str]] = []
    seen: set[tuple[str, str, str, str, str, str]] = set()

    for path in monthly_paths:
        # Avoid accidentally reading the combined test export if the filename is changed later.
        if os.path.abspath(path) == os.path.abspath(out_path):
            continue
        try:
            with open(path, "r", newline="", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    clean = {field: str(row.get(field, "")) for field in MONTHLY_INVOICE_CSV_FIELDS}
                    key = tuple(clean.get(field, "") for field in MONTHLY_INVOICE_CSV_FIELDS)
                    if key in seen:
                        continue
                    seen.add(key)
                    rows.append(clean)
        except Exception as e:
            print(f"[MONTHLY EMAIL TEST] Could not read {path}: {e}")

    def _sort_key(row: dict[str, str]):
        return (str(row.get("issued_time", "")), str(row.get("invoice_number", "")), str(row.get("tax_rate", "")))

    rows.sort(key=_sort_key)

    with _MONTHLY_INVOICE_REPORT_LOCK:
        with open(out_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=MONTHLY_INVOICE_CSV_FIELDS)
            writer.writeheader()
            writer.writerows(rows)

    print(f"[MONTHLY EMAIL TEST] Built all-invoices CSV: {out_path} ({len(rows)} row(s)).")
    return out_path


def _smtp_settings_ready() -> bool:
    if not MONTHLY_INVOICE_EMAIL_ENABLED:
        print("[MONTHLY EMAIL] Email sending disabled. Set MONTHLY_INVOICE_EMAIL_ENABLED = True to send.")
        return False
    if not MONTHLY_INVOICE_SMTP_HOST or not MONTHLY_INVOICE_SMTP_USERNAME or not MONTHLY_INVOICE_SMTP_PASSWORD:
        print("[MONTHLY EMAIL] Missing SMTP settings. Fill MONTHLY_INVOICE_SMTP_USERNAME/PASSWORD and enable email sending.")
        return False
    return True


def _send_invoice_csv_attachment(path: str, *, subject: str, body: str) -> bool:
    if not os.path.exists(path):
        print(f"[MONTHLY EMAIL] Attachment not found: {path}")
        return False

    if not _smtp_settings_ready():
        return False

    sender = MONTHLY_INVOICE_EMAIL_FROM or MONTHLY_INVOICE_SMTP_USERNAME
    recipient = MONTHLY_INVOICE_EMAIL_TO

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = recipient
    msg.set_content(body)

    with open(path, "rb") as f:
        msg.add_attachment(
            f.read(),
            maintype="text",
            subtype="csv",
            filename=os.path.basename(path),
        )

    try:
        if MONTHLY_INVOICE_SMTP_USE_TLS:
            with smtplib.SMTP(MONTHLY_INVOICE_SMTP_HOST, int(MONTHLY_INVOICE_SMTP_PORT), timeout=20) as smtp:
                smtp.ehlo()
                smtp.starttls()
                smtp.ehlo()
                smtp.login(MONTHLY_INVOICE_SMTP_USERNAME, MONTHLY_INVOICE_SMTP_PASSWORD)
                smtp.send_message(msg)
        else:
            with smtplib.SMTP_SSL(MONTHLY_INVOICE_SMTP_HOST, int(MONTHLY_INVOICE_SMTP_PORT), timeout=20) as smtp:
                smtp.login(MONTHLY_INVOICE_SMTP_USERNAME, MONTHLY_INVOICE_SMTP_PASSWORD)
                smtp.send_message(msg)
        print(f"[MONTHLY EMAIL] Sent {path} to {recipient}")
        return True
    except Exception as e:
        print(f"[MONTHLY EMAIL] Failed to send {path}: {e}")
        return False


def send_all_invoices_test_email() -> bool:
    path = build_all_invoices_test_csv()
    return _send_invoice_csv_attachment(
        path,
        subject="Bouquetmat ALL invoices test report",
        body=(
            "Attached is the Bouquetmat all-invoices CSV test report.\n\n"
            "This startup test report combines all invoices_YYYY_MM.csv files currently found "
            "in the monthly_invoice_reports folder.\n"
        ),
    )


def _money_decimal(value) -> Decimal:
    try:
        return Decimal(str(value or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    except Exception:
        return Decimal("0.00")


def _tax_rate_key(value) -> str:
    try:
        d = Decimal(str(value or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        return format(d, "f").rstrip("0").rstrip(".") or "0"
    except Exception:
        return "0"


def _build_monthly_invoice_rows(invoice_number: str, issue_datetime_iso: str, total: float, items: list) -> list[dict[str, str]]:
    by_tax: dict[str, Decimal] = {}

    for it in list(items or []):
        rate_key = _tax_rate_key(it.get("tax_pct", 0.0))
        by_tax.setdefault(rate_key, Decimal("0.00"))
        by_tax[rate_key] += _money_decimal(it.get("price", 0.0))

    if not by_tax:
        by_tax[_tax_rate_key(0.0)] = _money_decimal(total)

    rows: list[dict[str, str]] = []
    for rate_key, gross in sorted(by_tax.items(), key=lambda kv: Decimal(kv[0])):
        rate = Decimal(rate_key)
        if rate == 0:
            taxable = gross
            tax_amount = Decimal("0.00")
        else:
            taxable = (gross / (Decimal("1.00") + rate / Decimal("100.00"))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            tax_amount = (gross - taxable).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

        rows.append({
            "invoice_number": str(invoice_number),
            "issued_time": str(issue_datetime_iso),
            "amount": format(gross.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP), "f"),
            "tax_rate": rate_key,
            "taxable_amount": format(taxable, "f"),
            "tax_amount": format(tax_amount, "f"),
        })
    return rows


def append_monthly_invoice_csv(invoice_number: str, issue_datetime_iso: str, total: float, items: list) -> None:
    if not MONTHLY_INVOICE_REPORTS_ENABLED:
        return
    try:
        year, month = _invoice_month_from_iso(issue_datetime_iso)
        os.makedirs(MONTHLY_INVOICE_REPORT_DIR, exist_ok=True)
        path = _monthly_invoice_csv_path(year, month)
        rows = _build_monthly_invoice_rows(invoice_number, issue_datetime_iso, total, items)

        with _MONTHLY_INVOICE_REPORT_LOCK:
            existing_keys: set[tuple[str, str]] = set()
            if os.path.exists(path):
                try:
                    with open(path, "r", newline="", encoding="utf-8-sig") as f:
                        for row in csv.DictReader(f):
                            existing_keys.add((str(row.get("invoice_number", "")), str(row.get("tax_rate", ""))))
                except Exception as e:
                    print(f"[MONTHLY CSV] Could not read existing CSV for duplicate check: {e}")

            file_exists = os.path.exists(path) and os.path.getsize(path) > 0
            with open(path, "a", newline="", encoding="utf-8-sig") as f:
                writer = csv.DictWriter(f, fieldnames=MONTHLY_INVOICE_CSV_FIELDS)
                if not file_exists:
                    writer.writeheader()
                written = 0
                for row in rows:
                    key = (str(row.get("invoice_number", "")), str(row.get("tax_rate", "")))
                    if key in existing_keys:
                        continue
                    writer.writerow(row)
                    existing_keys.add(key)
                    written += 1
            print(f"[MONTHLY CSV] Invoice {invoice_number} written to {path} ({written} row(s)).")
    except Exception as e:
        print(f"[MONTHLY CSV] Failed to write invoice {invoice_number}: {e}")


def _load_monthly_email_sent_markers() -> dict:
    try:
        with open(MONTHLY_INVOICE_SENT_MARKER_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_monthly_email_sent_markers(markers: dict) -> None:
    os.makedirs(MONTHLY_INVOICE_REPORT_DIR, exist_ok=True)
    tmp = MONTHLY_INVOICE_SENT_MARKER_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(markers, f, ensure_ascii=False, indent=2)
    os.replace(tmp, MONTHLY_INVOICE_SENT_MARKER_FILE)


def send_monthly_invoice_csv_email(year: int, month: int) -> bool:
    path = _monthly_invoice_csv_path(year, month)
    key = f"{int(year):04d}-{int(month):02d}"

    if not os.path.exists(path):
        print(f"[MONTHLY EMAIL] No CSV exists for {key}: {path}")
        return False

    return _send_invoice_csv_attachment(
        path,
        subject=f"Bouquetmat monthly invoice report {key}",
        body=(
            f"Attached is the Bouquetmat monthly invoice CSV report for {key}.\n\n"
            f"File: {os.path.basename(path)}\n"
        ),
    )


def send_due_monthly_invoice_reports() -> None:
    """Send the completed previous month once. Runs safely on startup and every few hours."""
    if not MONTHLY_INVOICE_REPORTS_ENABLED:
        return
    import_old_txt_invoices_to_monthly_csv()
    now = datetime.now()
    prev_year = now.year
    prev_month = now.month - 1
    if prev_month <= 0:
        prev_year -= 1
        prev_month = 12

    key = f"{prev_year:04d}-{prev_month:02d}"
    markers = _load_monthly_email_sent_markers()
    if markers.get(key):
        return

    csv_path = _monthly_invoice_csv_path(prev_year, prev_month)
    if not os.path.exists(csv_path):
        return

    if send_monthly_invoice_csv_email(prev_year, prev_month):
        markers[key] = datetime.now().isoformat(timespec="seconds")
        _save_monthly_email_sent_markers(markers)

class TeeLogger:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
                s.flush()
            except Exception:
                pass

    def flush(self):
        for s in self.streams:
            try:
                s.flush()
            except Exception:
                pass

def setup_file_logging():
    try:
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        logfile = open(LOG_FILE, "a", encoding="utf-8", buffering=1)
        logfile.write("\n" + "=" * 80 + "\n")
        logfile.write(f"START {datetime.now().isoformat(timespec='seconds')}\n")
        logfile.write("=" * 80 + "\n")
        sys.stdout = TeeLogger(sys.__stdout__, logfile)
        sys.stderr = TeeLogger(sys.__stderr__, logfile)
        print(f"[LOG] Writing runtime log to: {LOG_FILE}")
    except Exception as e:
        print(f"[LOG] Failed to start file logging: {e}")

def _backend_force_white_keyboard_widgets(app):
    root = getattr(app, "root", None)
    if root is None:
        return

    def walk(widget, in_keyboard=False):
        try:
            if widget.__class__.__name__ in ("AdminKeyboard", "ReservationNumpad"):
                in_keyboard = True
        except Exception:
            pass

        if in_keyboard:
            try:
                if isinstance(widget, base.HoverButton):
                    widget.color = (1, 1, 1, 1)
                    widget.disabled_color = (1, 1, 1, 0.85)
                    try:
                        widget.canvas.ask_update()
                    except Exception:
                        pass
            except Exception:
                pass

        for child in getattr(widget, "children", []):
            walk(child, in_keyboard)

    for screen_name in ("admin_login", "reservation", "admin_edit_item", "admin_esp_status"):
        try:
            screen = root.get_screen(screen_name)
        except Exception:
            continue
        walk(screen)

base.I18N.setdefault("reserved", {"en": "Reserved", "si": "Rezervirano", "de": "Reserviert", "hr": "Rezervirano"})
base.I18N.setdefault("reserved_not_for_sale", {"en": "Reserved - not available", "si": "Rezervirano - ni na voljo", "de": "Reserviert - nicht verfügbar", "hr": "Rezervirano - nije dostupno"})

base.ICON_HR = getattr(base, "ICON_HR", os.path.join(getattr(base, "PANEL_DIR", "."), "flag_hr.png"))

_CROATIAN_BACKEND_OVERRIDES = {
    "reserved": "Rezervirano",
    "reserved_not_for_sale": "Rezervirano - nije dostupno",
    "module_slots": "Modul {panel_type} - {slots} mjesta",
    "reservation_enter_code": "Unesite kod rezervacije",
    "reservation_verify": "Provjeri",
    "reservation_collect": "Preuzmi",
    "reservation_clear": "Obriši",
    "reservation_code_invalid": "Kod rezervacije nije valjan.",
    "reservation_code_expired": "Kod rezervacije je istekao.",
    "reservation_code_redeemed": "Rezervacija je već iskorištena.",
    "reservation_code_claimed": "Rezervacija se trenutno obrađuje. Pokušajte ponovno uskoro.",
    "reservation_ready": "Rezervacija je valjana.",
    "reservation_collecting": "Preuzimanje rezervacije...",
    "reservation_success": "Rezervacija preuzeta.",
    "reservation_backend_error": "Greška poslužitelja rezervacija.",
}
for _k, _v in getattr(base, "I18N", {}).items():
    if isinstance(_v, dict) and "hr" not in _v:
        _v["hr"] = _CROATIAN_BACKEND_OVERRIDES.get(_k, _v.get("en", next(iter(_v.values()), _k)))

_BACKEND_HR_EXTRA = {
    "bouquet": "Buket",
    "instructions_body": getattr(base, "INSTRUCTIONS_BODY_HR", ""),
    "terms_body": getattr(base, "TERMS_BODY_HR", ""),
    "printing_receipt": "Račun",
    "reprint_receipt": "Račun",
    "not_available": "Nije dostupno (već kupljeno)",
    "add_to_cart": "Dodaj u košaricu",
    "cart_empty": "Košarica je prazna. Vratite se i odaberite proizvod.",
    "clear_cart": "Očisti",
    "keyboard_clear": "Obriši",
    "admin_accounts_missing": "Datoteka s admin računima nedostaje ili je prazna",
    "access_denied": "Pristup odbijen",
    "door_opening_now": "Otvaranje vrata...",
    "door_open_success": "Vrata otvorena",
    "door_open_failed": "Vrata se nisu otvorila. Dodirnite ponovno.",
    "door_open_partial": "Neka vrata su se otvorila, neka nisu.",
    "admin_tap_reopen": "Dodirnite za ponovno otvaranje vrata",
    "admin_role_manufacturer": "Proizvođač",
    "admin_role_owner": "Vlasnik",
    "admin_role_worker": "Radnik",
    "re_enable_all": "Otvori sve",
    "re_enable_this": "Otvori",
    "receipt": "Račun",
    "status_enabled": "Omogućeno",
    "status_disabled": "Onemogućeno",
    "payment_terminal_starting": "Povezivanje s platnim terminalom...",
    "please_pay_on_terminal": "Molimo dovršite plaćanje na terminalu.",
    "payment_approved": "Plaćanje potvrđeno.",
    "payment_failed": "Plaćanje nije uspjelo.",
    "payment_terminal_not_ready": "Platni terminal nije spreman.",
    "payment_cancelled_or_declined": "Plaćanje je otkazano ili odbijeno.",
    "relay_timeout": "Odabrana vrata ne odgovaraju.",
    "reopen_door": "Otvori",
    "buy_another": "Kupi",
    "printing_receipt": "Račun",
    "reprint_receipt": "Račun",
}
for _k, _v in getattr(base, "I18N", {}).items():
    if isinstance(_v, dict):
        if _k in _BACKEND_HR_EXTRA:
            _v["hr"] = _BACKEND_HR_EXTRA[_k]
        elif "hr" not in _v:
            _v["hr"] = _v.get("en", next(iter(_v.values()), _k))


# =========================================================
# CENTRAL BACKEND SETTINGS
# =========================================================
BACKEND_ENABLED = True
BACKEND_BASE_URL = "http://46.225.177.107"
BACKEND_PANEL_KEY = ""
BACKEND_SOFTWARE_VERSION = "0.1.0"
BACKEND_PANEL_ID_OVERRIDE = "Jagodic"   # panel ID
BACKEND_PANEL_NAME_OVERRIDE = "Smarje pri Jelsah" # panel name
BACKEND_HEARTBEAT_SECONDS = 15
BACKEND_COMMAND_POLL_SECONDS = 5
BACKEND_ADMIN_SYNC_SECONDS = 20
BACKEND_CONFIG_REFRESH_SECONDS = 5
BACKEND_STARTUP_RETRY_SECONDS = 3

# Manual reservation flow
RESERVATION_REQUEST_TIMEOUT_S = 5.0
RESERVATION_HOLD_SECONDS = 60
COMPONENT_PROBE_TIMEOUT_S = 1.0
REMOTE_PANEL_STALE_SECONDS = 45
REMOTE_PANEL_PRUNE_INTERVAL_S = 5


def _make_backend_panel_id(position: int) -> str:
    position = int(position)
    if position == 0:
        return "panel-0"
    if position < 0:
        return f"panel-neg{abs(position)}"
    return f"panel-{position}"


def _make_backend_panel_name(position: int) -> str:
    position = int(position)
    if position == 0:
        return "Main Panel"
    if position < 0:
        return f"Side Panel Left {abs(position)}"
    return f"Side Panel Right {position}"


BACKEND_PANEL_ID = (BACKEND_PANEL_ID_OVERRIDE.strip() or _make_backend_panel_id(int(getattr(base, "PANEL_POSITION", 0))))
BACKEND_PANEL_NAME = (BACKEND_PANEL_NAME_OVERRIDE.strip() or _make_backend_panel_name(int(getattr(base, "PANEL_POSITION", 0))))


# =========================================================
# Small backend clients
# =========================================================
class PanelBackendClient:
    def __init__(
        self,
        *,
        base_url: str,
        panel_id: str,
        panel_name: str,
        panel_type: str,
        position: int,
        software_version: str = "0.1.0",
        panel_key: str = "",
        timeout: float = 5.0,
    ):
        self.base_url = base_url.rstrip("/")
        self.panel_id = panel_id
        self.panel_name = panel_name
        self.panel_type = panel_type
        self.position = int(position)
        self.software_version = software_version
        self.panel_key = panel_key or ""
        self.timeout = float(timeout)
        self.last_command_version = 0
        self.session = requests.Session()

    @property
    def headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.panel_key:
            headers["X-Panel-Key"] = self.panel_key
        return headers

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _local_ip(self) -> str:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.connect(("8.8.8.8", 80))
            ip = sock.getsockname()[0]
            sock.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def register(self) -> dict[str, Any]:
        payload = {
            "panel_id": self.panel_id,
            "panel_name": self.panel_name,
            "panel_type": self.panel_type,
            "position": self.position,
            "local_ip": self._local_ip(),
            "software_version": self.software_version,
        }
        r = self.session.post(
            self._url("/api/panels/register"),
            json=payload,
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def heartbeat(
        self,
        *,
        status: str = "online",
        current_screen: str | None = None,
        cart_count: int = 0,
        payment_terminal_ready: bool = False,
        component_statuses: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload = {
            "status": status,
            "current_screen": current_screen,
            "cart_count": int(cart_count),
            "payment_terminal_ready": bool(payment_terminal_ready),
            "component_statuses": component_statuses or {},
        }
        r = self.session.post(
            self._url(f"/api/panels/{self.panel_id}/heartbeat"),
            json=payload,
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def get_config(self) -> dict[str, Any]:
        r = self.session.get(
            self._url(f"/api/panels/{self.panel_id}/config"),
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def sync_items(self, items: list[dict[str, Any]], *, replace_missing: bool = True) -> dict[str, Any]:
        payload = {
            "replace_missing": bool(replace_missing),
            "items": [
                {
                    "panel_position": int(it.get("panel_position", self.position)),
                    "item_id": int(it["id"]),
                    "label": str(it.get("label", it["id"])),
                    "price": float(it.get("price", 0.0)),
                    "tax_pct": float(it.get("tax_pct", 0.0)),
                    "enabled": bool(it.get("enabled", True)),
                }
                for it in items
                if it is not None and it.get("id") is not None
            ],
        }
        r = self.session.post(
            self._url(f"/api/panels/{self.panel_id}/items/sync"),
            json=payload,
            headers=self.headers,
            timeout=max(self.timeout, 10.0),
        )
        r.raise_for_status()
        return r.json()

    def sync_admin_users(self, users: list[dict[str, Any]], *, replace_missing: bool = True) -> dict[str, Any]:
        payload = {
            "replace_missing": bool(replace_missing),
            "users": [
                {
                    "username": str(u.get("username", "")).strip(),
                    "password": str(u.get("password", "")),
                    "role": str(u.get("role", "worker")),
                    "is_active": bool(u.get("is_active", True)),
                }
                for u in users
                if str(u.get("username", "")).strip()
            ],
        }
        r = self.session.post(
            self._url(f"/api/panels/{self.panel_id}/admin-users/sync"),
            json=payload,
            headers=self.headers,
            timeout=max(self.timeout, 10.0),
        )
        r.raise_for_status()
        return r.json()

    def post_event(self, event_type: str, *, severity: str = "info", payload: dict[str, Any] | None = None) -> dict[str, Any]:
        body = {
            "panel_id": self.panel_id,
            "event_type": event_type,
            "severity": severity,
            "payload": payload or {},
        }
        r = self.session.post(
            self._url("/api/events"),
            json=body,
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def post_sale(
        self,
        *,
        invoice_number: str,
        issue_datetime_iso: str,
        total_amount: float,
        payment_status: str,
        fiscal_status: str,
        items: list[dict[str, Any]],
        currency: str = "EUR",
    ) -> dict[str, Any]:
        body = {
            "panel_id": self.panel_id,
            "invoice_number": invoice_number,
            "issue_datetime_iso": issue_datetime_iso,
            "currency": currency,
            "total_amount": float(total_amount),
            "payment_status": payment_status,
            "fiscal_status": fiscal_status,
            "items": [
                {
                    "item_id": int(it["id"]),
                    "panel_position": int(it.get("panel_position", self.position)),
                    "label": str(it.get("label", it["id"])),
                    "quantity": int(it.get("quantity", 1)),
                    "unit_price": float(it.get("price", 0.0)),
                    "tax_pct": float(it.get("tax_pct", 0.0)),
                }
                for it in items
                if it is not None and it.get("id") is not None
            ],
        }
        r = self.session.post(
            self._url("/api/sales"),
            json=body,
            headers=self.headers,
            timeout=max(self.timeout, 10.0),
        )
        r.raise_for_status()
        return r.json()

    def post_door_event(
        self,
        *,
        item_id: int,
        panel_position: int,
        action: str,
        success: bool,
        error_text: str | None = None,
    ) -> dict[str, Any]:
        body = {
            "panel_id": self.panel_id,
            "item_id": int(item_id),
            "panel_position": int(panel_position),
            "action": action,
            "success": bool(success),
            "error_text": error_text,
        }
        r = self.session.post(
            self._url("/api/door-events"),
            json=body,
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def poll_commands(self) -> dict[str, Any]:
        r = self.session.get(
            self._url(f"/api/panels/{self.panel_id}/commands"),
            params={"since_version": int(self.last_command_version)},
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        data = r.json()
        self.last_command_version = int(data.get("latest_version", self.last_command_version) or self.last_command_version)
        return data

    def ack_commands(self, versions: list[int]) -> dict[str, Any]:
        body = {"command_versions": [int(v) for v in versions]}
        r = self.session.post(
            self._url(f"/api/panels/{self.panel_id}/commands/ack"),
            json=body,
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()


@dataclass
class ReservationClientConfig:
    base_url: str = BACKEND_BASE_URL
    panel_key: str = BACKEND_PANEL_KEY
    timeout: float = RESERVATION_REQUEST_TIMEOUT_S


class ReservationBackendClient:
    def __init__(self, config: ReservationClientConfig | None = None):
        self.config = config or ReservationClientConfig()
        self.session = requests.Session()

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.config.panel_key:
            headers["X-Panel-Key"] = self.config.panel_key
        return headers

    def _url(self, path: str) -> str:
        return self.config.base_url.rstrip("/") + path

    def verify(self, *, code: str, panel_id: Optional[str] = None) -> dict[str, Any]:
        payload = {"code": str(code).strip(), "panel_id": panel_id}
        resp = self.session.post(
            self._url("/api/reservations/verify"),
            json=payload,
            headers=self._headers(),
            timeout=self.config.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def redeem(self, *, code: str, panel_id: Optional[str] = None, redeemed_by: str = "panel") -> dict[str, Any]:
        payload = {
            "code": str(code).strip(),
            "panel_id": panel_id,
            "redeemed_by": redeemed_by,
        }
        resp = self.session.post(
            self._url("/api/reservations/redeem"),
            json=payload,
            headers=self._headers(),
            timeout=self.config.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def claim(self, *, code: str, panel_id: Optional[str] = None, claimed_by: str = "panel", hold_seconds: int = RESERVATION_HOLD_SECONDS) -> dict[str, Any]:
        payload = {
            "code": str(code).strip(),
            "panel_id": panel_id,
            "claimed_by": claimed_by,
            "hold_seconds": int(hold_seconds),
        }
        resp = self.session.post(
            self._url("/api/reservations/claim"),
            json=payload,
            headers=self._headers(),
            timeout=self.config.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def confirm(self, *, code: str, claim_token: str, panel_id: Optional[str] = None, redeemed_by: str = "panel") -> dict[str, Any]:
        payload = {
            "code": str(code).strip(),
            "claim_token": str(claim_token),
            "panel_id": panel_id,
            "redeemed_by": redeemed_by,
        }
        resp = self.session.post(
            self._url("/api/reservations/confirm"),
            json=payload,
            headers=self._headers(),
            timeout=self.config.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def release(self, *, code: str, claim_token: str, panel_id: Optional[str] = None, released_by: str = "panel", release_reason: str | None = None) -> dict[str, Any]:
        payload = {
            "code": str(code).strip(),
            "claim_token": str(claim_token),
            "panel_id": panel_id,
            "released_by": released_by,
            "release_reason": release_reason,
        }
        resp = self.session.post(
            self._url("/api/reservations/release"),
            json=payload,
            headers=self._headers(),
            timeout=self.config.timeout,
        )
        resp.raise_for_status()
        return resp.json()


# =========================================================
# Patch base I18N / KV / save hook
# =========================================================
base.I18N.update(
    {
        "reservation_enter_code": {
            "en": "Enter reservation code",
            "si": "Vnesite kodo rezervacije",
            "de": "Reservierungscode eingeben",
        },
        "reservation_verify": {
            "en": "Verify",
            "si": "Preveri",
            "de": "Prüfen",
        },
        "reservation_collect": {
            "en": "Collect",
            "si": "Prevzem",
            "de": "Abholen",
        },
        "reservation_clear": {
            "en": "Clear",
            "si": "Počisti",
            "de": "Leeren",
        },
        "reservation_code_invalid": {
            "en": "Reservation code is invalid.",
            "si": "Koda rezervacije ni veljavna.",
            "de": "Reservierungscode ist ungültig.",
        },
        "reservation_code_expired": {
            "en": "Reservation code has expired.",
            "si": "Koda rezervacije je potekla.",
            "de": "Reservierungscode ist abgelaufen.",
        },
        "reservation_code_redeemed": {
            "en": "Reservation was already used.",
            "si": "Rezervacija je že bila uporabljena.",
            "de": "Reservierung wurde bereits verwendet.",
        },
        "reservation_code_claimed": {
            "en": "Reservation is currently being processed. Please try again shortly.",
            "si": "Rezervacija se trenutno obdeluje. Poskusite znova čez trenutek.",
            "de": "Reservierung wird gerade verarbeitet. Bitte gleich erneut versuchen.",
        },
        "reservation_ready": {
            "en": "Reservation is valid.",
            "si": "Rezervacija je veljavna.",
            "de": "Reservierung ist gültig.",
        },
        "reservation_collecting": {
            "en": "Collecting reservation...",
            "si": "Prevzem rezervacije...",
            "de": "Reservierung wird abgeholt...",
        },
        "reservation_success": {
            "en": "Reservation collected.",
            "si": "Rezervacija prevzeta.",
            "de": "Reservierung abgeholt.",
        },
        "reservation_backend_error": {
            "en": "Reservation backend error.",
            "si": "Napaka strežnika rezervacij.",
            "de": "Fehler beim Reservierungsserver.",
        },
    }
)

# Croatian reservation translations added after base.I18N.update(), because update() replaces earlier keys.
_BACKEND_RESERVATION_HR = {
    "reservation_enter_code": "Unesite kod rezervacije",
    "reservation_verify": "Provjeri",
    "reservation_collect": "Preuzmi",
    "reservation_clear": "Obriši",
    "reservation_code_invalid": "Kod rezervacije nije valjan.",
    "reservation_code_expired": "Kod rezervacije je istekao.",
    "reservation_code_redeemed": "Rezervacija je već iskorištena.",
    "reservation_code_claimed": "Rezervacija se trenutno obrađuje. Pokušajte ponovno uskoro.",
    "reservation_ready": "Rezervacija je valjana.",
    "reservation_collecting": "Preuzimanje rezervacije...",
    "reservation_success": "Rezervacija preuzeta.",
    "reservation_backend_error": "Greška poslužitelja rezervacija.",
    "keyboard_clear": "Obriši",
}
for _k, _hr in _BACKEND_RESERVATION_HR.items():
    base.I18N.setdefault(_k, {})["hr"] = _hr

_RESERVATION_SCREEN_BLOCK = '''
<ReservationScreen>:
    name: "reservation"
    FullScreenFloat:
        FloatLayout:
            BoxLayout:
                orientation: "vertical"
                padding: [dp(30), TOP_PAD, dp(30), dp(30)]
                spacing: dp(20)
                size_hint: 1, 1

                Widget:
                    size_hint_y: None
                    height: dp(56)

                TitleLabel:
                    id: reservation_title
                    text: "Reservation"
                    size_hint_y: None
                    height: 0
                    opacity: 0

                BoxLayout:
                    size_hint_y: None
                    height: "80dp"
                    Widget:
                    RoundedTextInput:
                        id: reservation_code_input
                        hint_text: "Enter reservation code"
                        font_size: OTHER_TXT
                        fill_rgba: [0.2, 0.33, 0.23, 0.84]
                        border_rgba: [0.84, 0.71, 0.36, 0.95]
                        foreground_color: 1, 1, 1, 1
                        disabled_foreground_color: 1, 1, 1, 1
                        cursor_color: 1, 1, 1, 1
                        hint_text_color: 1, 1, 1, 0.78
                        hint_text_color_normal: 1, 1, 1, 0.78
                        hint_text_color_focus: 1, 1, 1, 0.78
                        selection_color: 1, 1, 1, 0.18
                        size_hint_x: None
                        width: min(dp(860), Window.width - dp(140))
                    Widget:

                Label:
                    id: reservation_status
                    text: ""
                    font_size: OTHER_TXT
                    bold: True
                    color: 1, 1, 1, 0.96
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    size_hint_y: None
                    height: "120dp"

                Widget:
                    size_hint_y: 0.08

                AdminKeyboard:

                BoxLayout:
                    size_hint_y: None
                    height: "110dp"
                    spacing: dp(16)

                    NavIconButton:
                        id: reservation_back_btn
                        icon: app.ICON_BACK
                        text: "Back"
                        on_release: app.goto_menu()

                    NavIconButton:
                        id: reservation_home_btn
                        icon: app.ICON_HOME
                        text: "Home"
                        on_release: app.goto_menu()

                    NavIconButton:
                        id: reservation_collect_btn
                        icon: app.ICON_RESERVATION
                        text: "Collect"
                        on_release: app.reservation_collect()

        HeaderBar:
'''.strip("\n")

if "<ReservationScreen>:" in base.KV:
    base.KV = re.sub(
        r"<ReservationScreen>:\n.*?(?=\n<PriceCheckScreen>:)",
        _RESERVATION_SCREEN_BLOCK + "\n",
        base.KV,
        flags=re.S,
    )

_original_save_items_state = base.save_items_state

def _save_items_state_patched(items):
    _original_save_items_state(items)
    try:
        app = App.get_running_app()
        if app and hasattr(app, "backend_sync_items_async"):
            if not getattr(app, "_backend_applying_config", False):
                app.backend_sync_items_async()
    except Exception as e:
        print(f"[BACKEND] patched save sync failed: {e}")

base.save_items_state = _save_items_state_patched


class PanelBackendReservationApp(base.PanelApp):
    def build(self):
        root = super().build()
        try:
            rs = root.get_screen("reservation")
            if "reservation_body" not in rs.ids and "reservation_status" in rs.ids:
                rs.ids["reservation_body"] = rs.ids["reservation_status"]
        except Exception:
            pass
        for delay in (0, 0.05, 0.2, 0.8):
            try:
                Clock.schedule_once(lambda _dt, app=self: _backend_force_white_keyboard_widgets(app), delay)
            except Exception:
                pass
        return root

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.backend_client = None
        self.backend_ready = False
        self.backend_last_error = ""
        self.backend_config_version = 0
        self.server_reservation_codes: list[dict[str, Any]] = []
        self._backend_last_config_signature = ""
        self._backend_stop = False
        self._backend_applying_config = False
        self._backend_pending_sales: dict[str, dict[str, Any]] = {}
        self._admin_sync_last_mtime: float | None = None
        self._admin_sync_last_hash: str = ""

        self._verified_reservation: dict[str, Any] | None = None
        self._reservation_claim_token: str | None = None
        self._last_fiscal_status = "unknown"
        self._last_fiscal_error = ""
        self._fiscal_results_by_invoice: dict[str, dict[str, Any]] = {}
        self._last_invoice_number: str | None = None
        self._last_issue_datetime_iso: str | None = None
        self._last_purchase_total: float = 0.0
        self._receipt_print_lock = threading.RLock()
        self.reservation_client = ReservationBackendClient(
            ReservationClientConfig(
                base_url=BACKEND_BASE_URL,
                panel_key=BACKEND_PANEL_KEY,
                timeout=RESERVATION_REQUEST_TIMEOUT_S,
            )
        )

        if BACKEND_ENABLED:
            self.backend_client = PanelBackendClient(
                base_url=BACKEND_BASE_URL,
                panel_id=BACKEND_PANEL_ID,
                panel_name=BACKEND_PANEL_NAME,
                panel_type=self.panel_type,
                position=int(getattr(base, "PANEL_POSITION", 0)),
                software_version=BACKEND_SOFTWARE_VERSION,
                panel_key=BACKEND_PANEL_KEY,
            )

    def on_start(self):
        super().on_start()
        for delay in (0, 0.1, 0.3, 1.0):
            try:
                Clock.schedule_once(lambda _dt, app=self: _backend_force_white_keyboard_widgets(app), delay)
            except Exception:
                pass
        if int(getattr(base, "PANEL_POSITION", 0)) == 0:
            try:
                Clock.schedule_interval(self._remote_panel_prune_tick, REMOTE_PANEL_PRUNE_INTERVAL_S)
            except Exception:
                pass
        self._start_backend_threads()
        self._start_monthly_invoice_reporter()

        # Croatian durable fiscal retry worker.
        # First check shortly after startup, then every 5 min.
        try:
            Clock.schedule_once(
                lambda _dt:
                    _hr_fiscal_retry_tick(self),
                20.0,
            )

            Clock.schedule_interval(
                lambda _dt:
                    _hr_fiscal_retry_tick(self),
                HR_FISCAL_RETRY_INTERVAL_SECONDS,
            )

            print(
                "[HR FISCAL RETRY] worker scheduled "
                f"every "
                f"{HR_FISCAL_RETRY_INTERVAL_SECONDS}s"
            )

        except Exception as exc:
            print(
                "[HR FISCAL RETRY] "
                f"schedule warning: {exc}"
            )

    def on_stop(self):
        self._backend_stop = True
        super().on_stop()

    def _start_monthly_invoice_reporter(self):
        if not MONTHLY_INVOICE_REPORTS_ENABLED:
            return
        try:
            Clock.schedule_once(lambda _dt: self._run_old_txt_invoice_import(), 5.0)
            Clock.schedule_once(lambda _dt: self._run_monthly_invoice_report_tick(), 10.0)
            Clock.schedule_interval(lambda _dt: self._run_monthly_invoice_report_tick(), 6 * 60 * 60)
            if MONTHLY_INVOICE_TEST_SEND_ALL_ON_STARTUP:
                Clock.schedule_once(lambda _dt: self._run_all_invoices_test_email(), 20.0)
                print("[MONTHLY EMAIL TEST] Startup all-invoices test email scheduled.")
            print("[MONTHLY EMAIL] Monthly invoice reporter scheduled.")
        except Exception as e:
            print(f"[MONTHLY EMAIL] Could not schedule monthly invoice reporter: {e}")

    def _run_old_txt_invoice_import(self):
        try:
            threading.Thread(target=import_old_txt_invoices_to_monthly_csv, daemon=True).start()
        except Exception as e:
            print(f"[OLD TXT INVOICE IMPORT] Could not start import thread: {e}")

    def _run_monthly_invoice_report_tick(self):
        try:
            threading.Thread(target=send_due_monthly_invoice_reports, daemon=True).start()
        except Exception as e:
            print(f"[MONTHLY EMAIL] Tick failed: {e}")

    def _run_all_invoices_test_email(self):
        try:
            threading.Thread(target=send_all_invoices_test_email, daemon=True).start()
        except Exception as e:
            print(f"[MONTHLY EMAIL TEST] Startup test failed: {e}")

    # ---------- remote panel stale handling ----------
    def _is_remote_panel_stale(self, panel: dict) -> bool:
        if not panel:
            return True
        try:
            updated_at = float(panel.get("updated_at", 0) or 0)
        except Exception:
            return True
        if updated_at <= 0:
            return True
        return (time.time() - updated_at) > float(REMOTE_PANEL_STALE_SECONDS)

    def _remote_panel_prune_tick(self, _dt):
        self._prune_stale_remote_panels()

    def _apply_remote_panel_message(self, msg: dict, addr):
        result = super()._apply_remote_panel_message(msg, addr)

        # IMPORTANT:
        # Remote side-panel items must NOT be synchronized through the main
        # panel backend item namespace. Remote panels have their own position
        # and may reuse item IDs such as 1..21.
        #
        # They are kept separately in self.remote_panels until backend
        # synchronization is sent with an explicit remote panel identity.
        return result

    def _prune_stale_remote_panels(self):
        if int(getattr(base, "PANEL_POSITION", 0)) != 0:
            return False

        removed_positions = []
        for pos, panel in list(getattr(self, "remote_panels", {}).items()):
            try:
                pos_i = int(pos)
            except Exception:
                continue
            if pos_i == int(getattr(base, "PANEL_POSITION", 0)):
                continue
            if self._is_remote_panel_stale(panel):
                removed_positions.append(pos_i)
                self.remote_panels.pop(pos_i, None)

        if not removed_positions:
            return False

        try:
            base.save_remote_panels_state(self.remote_panels)
        except Exception:
            pass

        if int(getattr(self, "current_panel_position", 0)) in removed_positions:
            self.current_panel_position = int(getattr(base, "PANEL_POSITION", 0))
            try:
                self._sync_current_panel_layout()
            except Exception:
                pass
            if getattr(self, "current_item_position", None) in removed_positions:
                self.current_item_position = int(getattr(base, "PANEL_POSITION", 0))
                self.current_item_id = None

        try:
            self._refresh_panel_nav_buttons()
            self.refresh_selection_grid()
            self.refresh_check_price_grid()
            self.refresh_admin_grid()
            self.refresh_cart_screen()
            self._update_item_detail_screen()
        except Exception:
            pass

        print(f"[REMOTE] Pruned stale side panels: {removed_positions}")
        try:
            if self.backend_client:
                self.backend_sync_items_async()
        except Exception:
            pass
        return True

    def available_panel_positions(self):
        local_position = int(getattr(base, "PANEL_POSITION", 0))

        if local_position != 0:
            return [local_position]

        self._prune_stale_remote_panels()

        alive = [local_position]

        for pos, panel in getattr(self, "remote_panels", {}).items():
            try:
                pos_i = int(pos)
            except Exception:
                continue

            if pos_i == local_position:
                continue

            if not self._is_remote_panel_stale(panel):
                alive.append(pos_i)

        # Temporary purely local UI test module.
        if bool(getattr(base, "UI_TEST_R3_ENABLED", False)):
            test_position = int(
                getattr(base, "UI_TEST_R3_POSITION", 99)
            )
            if test_position not in alive:
                alive.append(test_position)

        return sorted(alive)

    def panel_items_for_position(self, position: int):
        position = int(position)

        # Temporary local UI-only R3 module.
        if (
            bool(getattr(base, "UI_TEST_R3_ENABLED", False))
            and position == int(getattr(base, "UI_TEST_R3_POSITION", 99))
        ):
            return base.build_ui_test_r3_items()

        if position == int(getattr(base, "PANEL_POSITION", 0)):
            return self.items

        panel = getattr(self, "remote_panels", {}).get(position)
        if not panel or self._is_remote_panel_stale(panel):
            return []

        return panel.get("items", [])

    def switch_panel_view(self, direction: int):
        positions = self.available_panel_positions()
        current = int(getattr(self, "current_panel_position", 0))
        idx = positions.index(current) if current in positions else 0
        nxt = idx + (1 if direction > 0 else -1)

        if not (0 <= nxt < len(positions)):
            return

        self.current_panel_position = int(positions[nxt])
        self._sync_current_panel_layout()
        self._refresh_panel_nav_buttons()

        # Only rebuild the screen that is currently visible.
        current_screen = str(getattr(self.root, "current", "") or "")

        if current_screen == "selection":
            self.refresh_selection_grid()

        elif current_screen == "price_check":
            self.refresh_check_price_grid()

        elif current_screen == "admin_panel":
            self.refresh_admin_grid()

    def _probe_tcp_service(self, host: str, port: int, timeout: float = COMPONENT_PROBE_TIMEOUT_S):
        try:
            sock = socket.create_connection((str(host), int(port)), timeout=float(timeout))
            sock.close()
            return True, ""
        except socket.timeout:
            return False, self.t("relay_timeout")
        except TimeoutError:
            return False, self.t("relay_timeout")
        except OSError as e:
            msg = str(e).lower()
            if "timed out" in msg or "timeout" in msg:
                return False, self.t("relay_timeout")
            return False, self.t("relay_not_ready")
        except Exception:
            return False, self.t("relay_not_ready")

    def _collect_component_statuses(self) -> dict[str, Any]:
        statuses: dict[str, Any] = {}

        payment_error = str(getattr(self, "payment_start_error", "") or "")
        if bool(getattr(self, "payment_ready", False)):
            payment_status = "ok"
        elif payment_error:
            payment_status = "error"
        else:
            payment_status = "starting"
        statuses["payment_terminal"] = {
            "status": payment_status,
            "last_error": payment_error or None,
        }

        try:
            relay_cfgs_func = getattr(base, "relay_configs_for_item_ids", None)
            if callable(relay_cfgs_func):
                relay_cfgs = list(relay_cfgs_func(None) or [])
            else:
                relay_cfgs = [getattr(base, "RELAY_CFG", None)]
        except Exception:
            relay_cfgs = [getattr(base, "RELAY_CFG", None)]

        relay_entries = []
        relay_errors = []
        for relay_cfg in relay_cfgs:
            relay_host = getattr(relay_cfg, "host", None)
            relay_port = getattr(relay_cfg, "port", None)
            if not relay_host or not relay_port:
                continue
            relay_ok, relay_error = self._probe_tcp_service(relay_host, relay_port, timeout=COMPONENT_PROBE_TIMEOUT_S)
            try:
                relay_name = base.relay_label_for_cfg(relay_cfg)
            except Exception:
                relay_name = str(relay_host)
            relay_entries.append({
                "name": relay_name,
                "status": "ok" if relay_ok else "error",
                "host": str(relay_host),
                "port": int(relay_port),
                "last_error": relay_error or None,
            })
            if not relay_ok:
                relay_errors.append(f"{relay_name}: {relay_error or 'not ready'}")

        if relay_entries:
            statuses["relay"] = {
                "status": "ok" if not relay_errors else "error",
                "host": ",".join(str(x.get("host")) for x in relay_entries),
                "port": int(relay_entries[0].get("port") or 502),
                "relays": relay_entries,
                "last_error": "; ".join(relay_errors) if relay_errors else None,
            }
        else:
            statuses["relay"] = {
                "status": "unknown",
                "last_error": None,
            }

        statuses["fiscalisation"] = {
            "status": str(self._last_fiscal_status or "unknown"),
            "last_error": (self._last_fiscal_error or None),
        }

        statuses["remote_panels"] = {
            "status": "ok",
            "count": int(len(getattr(self, "remote_panels", {}) or {})),
            "positions": sorted([int(x) for x in (getattr(self, "remote_panels", {}) or {}).keys()]),
        }

        monitor = getattr(self, "_module_monitor", None)
        if monitor is not None:
            try:
                statuses["module_health"] = monitor.heartbeat_health()
            except Exception as exc:
                print("[MODULE_HEALTH] heartbeat build error:", exc)

        return statuses

    def _reservation_release_async(self, *, code: str, claim_token: str, reason: str = "relay_failed"):
        def worker():
            try:
                self.reservation_client.release(
                    code=code,
                    claim_token=claim_token,
                    panel_id=BACKEND_PANEL_ID,
                    released_by="panel",
                    release_reason=reason,
                )
                Clock.schedule_once(lambda _dt, c=code: self._set_local_reservation_status(c, "active"), 0)
            except Exception as e:
                print(f"[RESERVATION] release failed: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def _reservation_confirm_async(self, *, code: str, claim_token: str, on_ok=None, on_fail=None):
        def worker():
            try:
                result = self.reservation_client.confirm(
                    code=code,
                    claim_token=claim_token,
                    panel_id=BACKEND_PANEL_ID,
                    redeemed_by="panel",
                )
                if bool((result or {}).get("confirmed")):
                    if on_ok:
                        Clock.schedule_once(lambda _dt, r=result: on_ok(r), 0)
                else:
                    if on_fail:
                        Clock.schedule_once(lambda _dt, r=result: on_fail(r), 0)
            except Exception as e:
                if on_fail:
                    Clock.schedule_once(lambda _dt, msg=str(e): on_fail({"ok": False, "reason": msg}), 0)

        threading.Thread(target=worker, daemon=True).start()

    # ---------- backend sync ----------
    def _start_backend_threads(self):
        if not self.backend_client:
            return

        def fetch_and_apply_config(force_register: bool = False) -> bool:
            try:
                if force_register:
                    try:
                        self.backend_client.register()
                    except Exception:
                        pass
                cfg = self.backend_client.get_config()
                self.backend_ready = True
                self.backend_last_error = ""
                Clock.schedule_once(lambda _dt, c=cfg: self._backend_apply_config(c), 0)
                return True
            except Exception as e:
                self.backend_ready = False
                self.backend_last_error = str(e)
                return False

        def startup_worker():
            posted_startup_event = False
            while not self._backend_stop:
                try:
                    self.backend_client.register()
                    self.backend_client.sync_items(self._backend_visible_items_snapshot(), replace_missing=True)
                    self._maybe_sync_admin_users(force=True)
                    cfg = self.backend_client.get_config()
                    self.backend_ready = True
                    self.backend_last_error = ""
                    Clock.schedule_once(lambda _dt, c=cfg: self._backend_apply_config(c), 0)
                    if not posted_startup_event:
                        self.backend_post_event_async(
                            "panel_startup",
                            payload={
                                "panel_type": self.panel_type,
                                "position": int(getattr(base, "PANEL_POSITION", 0)),
                                "payment_ready": bool(self.payment_ready),
                            },
                        )
                        posted_startup_event = True
                    break
                except Exception as e:
                    self.backend_ready = False
                    self.backend_last_error = str(e)
                    print(f"[BACKEND] startup failed: {e}")
                    time.sleep(BACKEND_STARTUP_RETRY_SECONDS)

        def heartbeat_loop():
            while not self._backend_stop:
                try:
                    if self.backend_client:
                        current_screen = str(getattr(self.root, "current", "") or "") if self.root else ""
                        self.backend_client.heartbeat(
                            status="online",
                            current_screen=current_screen,
                            cart_count=len(self.cart_items()),
                            payment_terminal_ready=bool(self.payment_ready),
                            component_statuses=self._collect_component_statuses(),
                        )
                        self.backend_ready = True
                        self.backend_last_error = ""
                        self._maybe_sync_admin_users()
                except Exception as e:
                    self.backend_ready = False
                    self.backend_last_error = str(e)
                    print(f"[BACKEND] heartbeat failed: {e}")
                time.sleep(BACKEND_HEARTBEAT_SECONDS)

        def command_loop():
            while not self._backend_stop:
                try:
                    if self.backend_client:
                        data = self.backend_client.poll_commands()
                        commands = data.get("commands") or []
                        ack_versions: list[int] = []
                        for cmd in commands:
                            version = int(cmd.get("version", 0) or 0)
                            self._backend_apply_command(cmd)
                            if version > 0:
                                ack_versions.append(version)
                        if ack_versions:
                            self.backend_client.ack_commands(ack_versions)
                except Exception as e:
                    self.backend_ready = False
                    self.backend_last_error = str(e)
                    print(f"[BACKEND] command poll failed: {e}")
                time.sleep(BACKEND_COMMAND_POLL_SECONDS)

        def config_loop():
            while not self._backend_stop:
                try:
                    if self.backend_client:
                        ok = fetch_and_apply_config(force_register=(not bool(self.backend_ready)))
                        if not ok and not self.backend_ready:
                            try:
                                self.backend_client.register()
                                self.backend_client.sync_items(self._backend_visible_items_snapshot(), replace_missing=True)
                                self._maybe_sync_admin_users(force=True)
                            except Exception:
                                pass
                except Exception as e:
                    self.backend_ready = False
                    self.backend_last_error = str(e)
                    print(f"[BACKEND] config refresh failed: {e}")
                time.sleep(BACKEND_CONFIG_REFRESH_SECONDS)

        threading.Thread(target=startup_worker, daemon=True).start()
        threading.Thread(target=heartbeat_loop, daemon=True).start()
        threading.Thread(target=command_loop, daemon=True).start()
        threading.Thread(target=config_loop, daemon=True).start()

    def _backend_upsert_item_local(self, item_update: dict) -> bool:
        try:
            item_id = int(item_update.get("item_id", item_update.get("id")))
        except Exception:
            return False

        it = self._get_panel_item(int(getattr(base, "PANEL_POSITION", 0)), item_id)
        if it is None:
            return False

        if item_update.get("label") is not None:
            it["label"] = str(item_update.get("label"))
        if item_update.get("price") is not None:
            it["price"] = float(item_update.get("price"))
        if item_update.get("tax_pct") is not None:
            it["tax_pct"] = float(item_update.get("tax_pct"))
        if item_update.get("enabled") is not None:
            it["enabled"] = bool(item_update.get("enabled"))

        base.save_items_state(self.items)
        return True

    def _backend_upsert_item_remote(self, panel_position: int, item_update: dict) -> bool:
        payload = {
            "type": "remote_update_item",
            "item": {
                "id": int(item_update.get("item_id", item_update.get("id"))),
                "label": str(item_update.get("label")),
                "price": float(item_update.get("price")),
                "tax_pct": float(item_update.get("tax_pct")),
                "enabled": bool(item_update.get("enabled")),
            },
        }
        ack = self._send_remote_message_with_ack(int(panel_position), payload)
        if not ack.get("ok"):
            print(f"[BACKEND] remote side item upsert failed: {ack}")
            return False

        remote_item = self._get_panel_item(int(panel_position), int(item_update.get("item_id", item_update.get("id"))))
        if remote_item is not None:
            remote_item.update({
                "label": payload["item"]["label"],
                "price": payload["item"]["price"],
                "tax_pct": payload["item"]["tax_pct"],
                "enabled": payload["item"]["enabled"],
            })
        panel = getattr(self, "remote_panels", {}).get(int(panel_position))
        if panel is not None:
            panel["updated_at"] = time.time()
            try:
                if int(getattr(base, "PANEL_POSITION", 0)) == 0:
                    base.save_remote_panels_state(self.remote_panels)
            except Exception:
                pass
        return True

    def _backend_apply_side_item_upsert(self, payload: dict):
        try:
            panel_position = int(payload.get("panel_position", getattr(base, "PANEL_POSITION", 0)))
            item_update = {
                "item_id": int(payload.get("item_id", payload.get("id"))),
                "label": payload.get("label"),
                "price": payload.get("price"),
                "tax_pct": payload.get("tax_pct"),
                "enabled": payload.get("enabled"),
            }
        except Exception as e:
            print(f"[BACKEND] bad side_item_upsert payload: {payload} error={e}")
            return

        ok = False
        if panel_position == int(getattr(base, "PANEL_POSITION", 0)):
            ok = self._backend_upsert_item_local(item_update)
        else:
            ok = self._backend_upsert_item_remote(panel_position, item_update)

        if ok:
            try:
                self.refresh_selection_grid()
                self.refresh_check_price_grid()
                self.refresh_admin_grid()
                self.refresh_cart_screen()
                self._update_item_detail_screen()
            except Exception:
                pass
            try:
                if self.backend_client:
                    self.backend_sync_items_async()
            except Exception:
                pass
            self.backend_post_event_async(
                "side_item_upsert_applied",
                payload={"panel_position": panel_position, "item": item_update},
            )
        else:
            self.backend_post_event_async(
                "side_item_upsert_failed",
                severity="warning",
                payload={"panel_position": panel_position, "item": item_update},
            )

    def _backend_apply_command(self, cmd: dict):
        command_type = str(cmd.get("command_type", "") or "")
        payload = cmd.get("payload") or {}
        print(f"[BACKEND] command: {command_type} payload={payload}")

        if command_type in ("config_refresh", "reservation_refresh"):
            try:
                cfg = self.backend_client.get_config()
                Clock.schedule_once(lambda _dt, c=cfg: self._backend_apply_config(c), 0)
            except Exception as e:
                print(f"[BACKEND] config refresh failed: {e}")
        elif command_type == "reopen_door":
            item_ids = [int(x) for x in (payload.get("item_ids") or []) if x is not None]
            panel_position = int(payload.get("panel_position", base.PANEL_POSITION) or base.PANEL_POSITION)
            if panel_position == int(base.PANEL_POSITION):
                self.open_doors_sequential(item_ids, pulse_ms=base.DOOR_PULSE_MS, gap_ms=base.DOOR_GAP_MS)
            else:
                try:
                    ack = self._send_remote_message_with_ack(panel_position, {
                        "type": "remote_reopen",
                        "items": item_ids,
                    })
                    print(f"[BACKEND] reopen_door remote ack={ack}")
                except Exception as e:
                    print(f"[BACKEND] reopen_door remote failed: {e}")
        elif command_type in ("side_item_upsert", "remote_item_upsert"):
            Clock.schedule_once(lambda _dt, p=deepcopy(payload): self._backend_apply_side_item_upsert(p), 0)
        elif command_type == "module_recovery":
            # The backend command poll ACK means RECEIVED, not executed. This
            # worker publishes a separate controller result with correlation ID.
            def run_module_recovery():
                version = int(cmd.get("version", 0) or 0)
                request_id = str(payload.get("request_id") or "")
                action = str(payload.get("action") or "")
                position = payload.get("panel_position")
                event = {
                    "command_version": version,
                    "request_id": request_id,
                    "action": action,
                    "panel_position": position,
                }
                try:
                    if not request_id or version <= 0:
                        raise ValueError("Recovery request is missing a correlation ID or command version")
                    monitor = getattr(self, "_module_monitor", None)
                    if monitor is None:
                        raise RuntimeError("Module health bridge unavailable")
                    motor_raw = payload.get("motor")
                    motor = None if motor_raw is None else int(motor_raw)
                    inspected_hardware = payload.get("inspected_hardware", False)
                    if not isinstance(inspected_hardware, bool):
                        raise ValueError("inspected_hardware must be boolean")
                    result = monitor.send_backend_recovery(
                        int(position),
                        action,
                        request_id=request_id,
                        motor=motor,
                        inspected_hardware=inspected_hardware,
                    )
                    event.update({
                        "controller_state": result.get("controller_state", "controller_rejected"),
                        "wire_action": result.get("action"),
                        "motor": result.get("motor"),
                        "inspected_hardware": inspected_hardware,
                        "rotation_verified": bool(result.get("rotation_verified", False)),
                        "error_code": str(result.get("error_code") or result.get("error") or "")[:120],
                        "controller_reply_type": str(result.get("type") or "")[:80],
                    })
                    event_type = (
                        "module_recovery_controller_accepted" if result.get("ok")
                        else "module_recovery_failed"
                    )
                    self.backend_post_event_async(
                        event_type,
                        severity="info" if result.get("ok") else "warning",
                        payload=event,
                    )
                    print("[MODULE_HEALTH] recovery controller response", action,
                          "state=", event["controller_state"], "version=", version)
                except Exception as exc:
                    event.update({
                        "controller_state": "controller_rejected",
                        "error_code": str(exc)[:120],
                        "rotation_verified": False,
                    })
                    self.backend_post_event_async(
                        "module_recovery_failed", severity="warning", payload=event,
                    )
                    print("[MODULE_HEALTH] recovery request failed:", type(exc).__name__)
            threading.Thread(target=run_module_recovery, daemon=True, name="module-recovery").start()

        elif command_type == "side_panel_refresh":
            try:
                panel_position = int(payload.get("panel_position"))
                ack = self._send_remote_message_with_ack(panel_position, {"type": "remote_request_state"})
                print(f"[BACKEND] side_panel_refresh ack={ack}")
            except Exception as e:
                print(f"[BACKEND] side_panel_refresh failed: {e}")

    def _backend_apply_config(self, cfg: dict):
        if not cfg:
            return

        # Backend config is polled repeatedly. Do not rebuild Kivy widgets when
        # nothing relevant actually changed.
        relevant_config = {
            "config_version": cfg.get("config_version"),
            "items": cfg.get("items") or [],
            "reservation_codes": cfg.get("reservation_codes") or [],
        }

        try:
            encoded = json.dumps(
                relevant_config,
                sort_keys=True,
                separators=(",", ":"),
                default=str,
            ).encode("utf-8")
            signature = hashlib.sha256(encoded).hexdigest()
        except Exception:
            signature = repr(relevant_config)

        if signature == getattr(self, "_backend_last_config_signature", ""):
            return

        self._backend_last_config_signature = signature
        self.backend_config_version = int(cfg.get("config_version", self.backend_config_version) or self.backend_config_version)
        self.server_reservation_codes = list(cfg.get("reservation_codes") or [])

        server_items = cfg.get("items") or []
        if server_items:
            self._backend_applying_config = True
            try:
                merged_items = [deepcopy(it) for it in getattr(self, "items", [])]
                if not merged_items and hasattr(base, "_default_items"):
                    try:
                        merged_items = [deepcopy(it) for it in base._default_items()]
                    except Exception:
                        merged_items = []
                local_position = int(getattr(base, "PANEL_POSITION", 0))

                # Backend config may contain items from several physical
                # panels. Only this Pi's own panel may update self.items.
                normalized = []
                for it in server_items:
                    try:
                        panel_position = int(
                            it.get("panel_position", local_position)
                        )
                        if panel_position != local_position:
                            continue

                        normalized.append({
                            "id": int(it["item_id"]),
                            "label": str(
                                it.get("label", it["item_id"])
                            ),
                            "price": float(it.get("price", 0.0)),
                            "tax_pct": float(it.get("tax_pct", 0.0)),
                            "enabled": bool(it.get("enabled", True)),
                        })
                    except Exception as exc:
                        print(
                            f"[BACKEND] skipped invalid config item: {exc}"
                        )

                # Merge by item ID, never by list index.
                by_id = {}
                for item in merged_items:
                    try:
                        by_id[int(item.get("id"))] = item
                    except Exception:
                        continue

                for item in normalized:
                    item_id = int(item["id"])
                    if item_id in by_id:
                        by_id[item_id].update(item)
                    else:
                        merged_items.append(item)
                        by_id[item_id] = item

                self.items = merged_items
                base.save_items_state(self.items)
            finally:
                self._backend_applying_config = False

        # Only repaint what the user can actually see.
        current_screen = str(
            getattr(getattr(self, "root", None), "current", "") or ""
        )

        if current_screen == "selection":
            self.refresh_selection_grid()

        elif current_screen == "price_check":
            self.refresh_check_price_grid()

        elif current_screen == "admin_panel":
            self.refresh_admin_grid()

        elif current_screen == "cart":
            self.refresh_cart_screen()

        elif current_screen == "item_detail":
            if self.current_item_id is not None:
                self._update_item_detail_screen()

    def backend_sync_items_async(self):
        if not self.backend_client:
            return
        items_snapshot = self._backend_visible_items_snapshot()

        def worker():
            try:
                self.backend_client.sync_items(items_snapshot, replace_missing=True)
            except Exception as e:
                print(f"[BACKEND] item sync failed: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def backend_post_event_async(self, event_type: str, *, severity: str = "info", payload: dict | None = None):
        if not self.backend_client:
            return

        def worker():
            try:
                self.backend_client.post_event(event_type, severity=severity, payload=payload or {})
            except Exception as e:
                print(f"[BACKEND] event post failed: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def backend_post_sale_async(
        self,
        invoice_number: str,
        issue_datetime_iso: str,
        total: float,
        items: list,
        payment_status: str,
        fiscal_status: str,
    ):
        if not self.backend_client:
            return
        items_snapshot = [deepcopy(it) for it in (items or [])]

        def worker():
            try:
                self.backend_client.post_sale(
                    invoice_number=invoice_number,
                    issue_datetime_iso=issue_datetime_iso,
                    total_amount=total,
                    payment_status=payment_status,
                    fiscal_status=fiscal_status,
                    items=items_snapshot,
                )
            except Exception as e:
                print(f"[BACKEND] sale post failed: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def backend_post_door_event_async(
        self,
        item_id: int,
        panel_position: int,
        action: str,
        success: bool,
        error_text: str | None = None,
    ):
        if not self.backend_client:
            return

        def worker():
            try:
                self.backend_client.post_door_event(
                    item_id=item_id,
                    panel_position=panel_position,
                    action=action,
                    success=success,
                    error_text=error_text,
                )
            except Exception as e:
                print(f"[BACKEND] door event failed: {e}")

        threading.Thread(target=worker, daemon=True).start()

    # ---------- translations / reservation UI ----------
    def apply_translations(self):
        try:
            super().apply_translations()
        except Exception:
            pass
        try:
            _backend_force_white_keyboard_widgets(self)
        except Exception:
            pass
        try:
            rs = self.root.get_screen("reservation")
            rs.ids.reservation_title.text = self.t("reservation_title")
            rs.ids.reservation_code_input.hint_text = self.t("reservation_enter_code")
            rs.ids.reservation_collect_btn.text = self.t("reservation_collect")
            rs.ids.reservation_back_btn.text = self.t("back")
            rs.ids.reservation_home_btn.text = self.t("home")
            if self._verified_reservation:
                panel_position = int(self._verified_reservation.get("panel_position", 0))
                label = self._verified_reservation.get("label") or self._verified_reservation.get("code") or ""
                item_id = self._verified_reservation.get("item_id")
                rs.ids.reservation_status.text = f"{self.t('reservation_ready')}\n{label} | {item_id} | {panel_position}"
            elif rs.ids.reservation_status.text == self.t("reservation_body") or "to be implemented" in rs.ids.reservation_status.text.lower():
                rs.ids.reservation_status.text = ""
            rs.ids.reservation_collect_btn.disabled = False
            self._force_reservation_status_white()
        except Exception:
            pass

    def goto_reservation(self):
        self._cancel_timers()
        self._verified_reservation = None
        self.active_textinput = None
        self.keyboard_upper = False
        try:
            rs = self.root.get_screen("reservation")
            rs.ids.reservation_status.text = ""
            rs.ids.reservation_collect_btn.disabled = False
            rs.ids.reservation_code_input.text = ""
        except Exception:
            pass
        self.root.current = "reservation"
        try:
            self._force_light_input_text()
        except Exception:
            pass
        try:
            self._force_reservation_status_white()
        except Exception:
            pass
        try:
            Clock.schedule_once(lambda _dt: setattr(self.root.get_screen("reservation").ids.reservation_code_input, "focus", True), 0.1)
        except Exception:
            pass

    def reservation_clear(self):
        self._verified_reservation = None
        try:
            rs = self.root.get_screen("reservation")
            rs.ids.reservation_code_input.text = ""
            rs.ids.reservation_status.text = ""
            rs.ids.reservation_collect_btn.disabled = False
            self.active_textinput = rs.ids.reservation_code_input
            try:
                self._force_light_input_text()
            except Exception:
                pass
            Clock.schedule_once(lambda _dt: setattr(rs.ids.reservation_code_input, "focus", True), 0)
            Clock.schedule_once(lambda _dt: self._force_light_input_text(), 0.05)
        except Exception:
            pass

    def _reservation_reason_text(self, reason: str) -> str:
        reason = str(reason or "").lower()
        if reason == "expired":
            return self.t("reservation_code_expired")
        if reason in ("status_redeemed", "status_used"):
            return self.t("reservation_code_redeemed")
        if reason == "status_claimed":
            return self.t("reservation_code_claimed")
        if reason == "code_not_found":
            return self.t("reservation_code_invalid")
        if reason in ("claim_token_invalid", "claim_expired"):
            return self.t("reservation_backend_error")
        return self.t("reservation_backend_error")

    def _reservation_verify_then_collect_invalid(self, result: dict):
        rs = self.root.get_screen("reservation")
        rs.ids.reservation_status.text = self._reservation_reason_text((result or {}).get("reason"))
        rs.ids.reservation_collect_btn.disabled = False
        self._verified_reservation = None
        self.backend_post_event_async(
            "reservation_verify_failed",
            severity="warning",
            payload={"result": result or {}},
        )

    def reservation_collect(self):
        rs = self.root.get_screen("reservation")
        code = rs.ids.reservation_code_input.text.strip()
        if not code:
            rs.ids.reservation_status.text = self.t("reservation_code_invalid")
            rs.ids.reservation_collect_btn.disabled = False
            self._verified_reservation = None
            self._reservation_claim_token = None
            return

        rs.ids.reservation_status.text = self.t("reservation_collecting")
        rs.ids.reservation_collect_btn.disabled = True
        self._verified_reservation = None
        self._reservation_claim_token = None

        panel_id = BACKEND_PANEL_ID

        def worker():
            try:
                claim_result = self.reservation_client.claim(
                    code=code,
                    panel_id=panel_id,
                    claimed_by="panel",
                    hold_seconds=RESERVATION_HOLD_SECONDS,
                )
            except Exception as e:
                Clock.schedule_once(
                    lambda _dt, msg=str(e): self._reservation_collect_failed(msg),
                    0,
                )
                return

            if not bool((claim_result or {}).get("claimed")):
                Clock.schedule_once(lambda _dt, r=claim_result: self._reservation_verify_then_collect_invalid(r), 0)
                return

            reservation = (claim_result or {}).get("reservation") or {}
            claim_token = str((claim_result or {}).get("claim_token") or "")
            Clock.schedule_once(lambda _dt, r=reservation, c=code, t=claim_token: self._reservation_collect_claimed(c, t, r), 0)

        threading.Thread(target=worker, daemon=True).start()

    def _reservation_collect_failed(self, message: str):
        rs = self.root.get_screen("reservation")
        rs.ids.reservation_status.text = self.t('reservation_backend_error')
        rs.ids.reservation_collect_btn.disabled = False
        self._reservation_claim_token = None
        self.backend_post_event_async(
            "reservation_collect_failed",
            severity="warning",
            payload={"error": message},
        )

    def _reservation_collect_claimed(self, code: str, claim_token: str, reservation: dict):
        rs = self.root.get_screen("reservation")
        self._verified_reservation = reservation or {}
        self._reservation_claim_token = claim_token or None

        panel_position = int((reservation or {}).get("panel_position", 0))
        item_id = (reservation or {}).get("item_id")
        label = (reservation or {}).get("label") or (reservation or {}).get("code") or code

        if item_id is None or not claim_token:
            rs.ids.reservation_status.text = self.t("reservation_backend_error")
            rs.ids.reservation_collect_btn.disabled = False
            if claim_token:
                self._reservation_release_async(code=code, claim_token=claim_token, reason="missing_item")
            return

        self.backend_post_event_async(
            "reservation_claimed",
            payload={"reservation": reservation, "claim_token": claim_token},
        )

        if int(panel_position) == int(getattr(base, "PANEL_POSITION", 0)):
            self.open_doors_sequential(
                [int(item_id)],
                pulse_ms=base.DOOR_PULSE_MS,
                gap_ms=base.DOOR_GAP_MS,
                on_complete=lambda results, iid=int(item_id), lbl=str(label), p=int(panel_position), c=code, t=claim_token: self._reservation_local_open_done(iid, lbl, p, c, t, results),
            )
        else:
            ack = self._send_remote_message_with_ack(
                int(panel_position),
                {
                    "type": "remote_purchase",
                    "items": [int(item_id)],
                    "reservation_code": code,
                },
            )
            results = ack.get("results") or [{"id": int(item_id), "ok": bool(ack.get("ok")), "error": ack.get("error")}]
            self._reservation_remote_open_done(int(item_id), str(label), int(panel_position), code, claim_token, results)

    def _reservation_collect_confirm_failed(self, code: str, claim_token: str, result: dict):
        rs = self.root.get_screen("reservation")
        rs.ids.reservation_status.text = self.t("reservation_backend_error")
        rs.ids.reservation_collect_btn.disabled = False
        self.backend_post_event_async(
            "reservation_confirm_failed",
            severity="warning",
            payload={"code": code, "result": result or {}},
        )

    def _reservation_local_open_done(self, item_id: int, label: str, panel_position: int, code: str, claim_token: str, results: list[dict]):
        rs = self.root.get_screen("reservation")
        ok = any(bool(r.get("ok")) and int(r.get("id")) == int(item_id) for r in (results or []))
        if not ok:
            error_text = next((str(r.get("error")) for r in (results or []) if int(r.get("id", -1)) == int(item_id) and r.get("error")), "")
            self._reservation_release_async(code=code, claim_token=claim_token, reason="relay_failed")
            rs.ids.reservation_status.text = self.t('door_open_failed')
            rs.ids.reservation_collect_btn.disabled = False
            return

        def on_confirm_ok(_result):
            it = self._get_panel_item(panel_position, item_id)
            if it is not None:
                it["enabled"] = False
                base.save_items_state(self.items)
            self.refresh_selection_grid()
            self.refresh_check_price_grid()
            self.refresh_admin_grid()
            self.refresh_cart_screen()
            if self.current_item_id is not None:
                self._update_item_detail_screen()

            self._last_purchased_items = [{"id": int(item_id), "label": str(label), "price": None, "panel_position": int(panel_position)}]
            try:
                if self.backend_client:
                    self.backend_sync_items_async()
            except Exception:
                pass
            self.receipt_available = False
            self.apply_translations()
            rs.ids.reservation_status.text = self.t("reservation_success")
            self._set_local_reservation_status(code, "redeemed")
            self._verified_reservation = None
            self._reservation_claim_token = None
            Clock.schedule_once(lambda _dt: self._show_reservation_success_screen(), 0.2)

        self._reservation_confirm_async(
            code=code,
            claim_token=claim_token,
            on_ok=on_confirm_ok,
            on_fail=lambda result, c=code, t=claim_token: self._reservation_collect_confirm_failed(c, t, result),
        )

    def _reservation_remote_open_done(self, item_id: int, label: str, panel_position: int, code: str, claim_token: str, results: list[dict]):
        rs = self.root.get_screen("reservation")
        ok = any(bool(r.get("ok")) and int(r.get("id")) == int(item_id) for r in (results or []))
        if not ok:
            error_text = next((str(r.get("error")) for r in (results or []) if int(r.get("id", -1)) == int(item_id) and r.get("error")), "")
            self._reservation_release_async(code=code, claim_token=claim_token, reason="remote_open_failed")
            rs.ids.reservation_status.text = self.t('door_open_failed')
            rs.ids.reservation_collect_btn.disabled = False
            return

        def on_confirm_ok(_result):
            panel = self.remote_panels.get(int(panel_position))
            if panel is not None:
                for remote_item in (panel.get("items") or []):
                    if int(remote_item.get("id")) == int(item_id):
                        remote_item["enabled"] = False
                        break
            self.refresh_selection_grid()
            self.refresh_check_price_grid()
            self.refresh_admin_grid()
            self.refresh_cart_screen()
            if self.current_item_id is not None:
                self._update_item_detail_screen()

            self._last_purchased_items = [{"id": int(item_id), "label": str(label), "price": None, "panel_position": int(panel_position)}]
            try:
                if self.backend_client:
                    self.backend_sync_items_async()
            except Exception:
                pass
            self.receipt_available = False
            self.apply_translations()
            rs.ids.reservation_status.text = self.t("reservation_success")
            self._set_local_reservation_status(code, "redeemed")
            self._verified_reservation = None
            self._reservation_claim_token = None
            Clock.schedule_once(lambda _dt: self._show_reservation_success_screen(), 0.2)

        self._reservation_confirm_async(
            code=code,
            claim_token=claim_token,
            on_ok=on_confirm_ok,
            on_fail=lambda result, c=code, t=claim_token: self._reservation_collect_confirm_failed(c, t, result),
        )

    def _show_reservation_success_screen(self):
        self._update_thanks_opening_label()
        try:
            thx = self.root.get_screen("thanks")
            thx.ids.thanks_sub.color = (1, 1, 1, 0.98)
        except Exception:
            pass
        self.root.current = "thanks"
        self._cancel_timers()
        self._thanks_event = Clock.schedule_once(lambda _dt: self.goto_menu(), base.THANKYOU_SECONDS)

    # ---------- overrides for event reporting ----------
    def admin_login(self):
        before_user = self.current_admin_username
        before_role = self.current_admin_role
        super().admin_login()
        if self.current_admin_username and (self.current_admin_username != before_user or self.current_admin_role != before_role):
            self.backend_post_event_async(
                "admin_login",
                payload={
                    "username": self.current_admin_username,
                    "role": self.current_admin_role,
                    "screen": getattr(self.root, "current", ""),
                },
            )

    def goto_menu(self):
        logout_user = None
        logout_role = None
        try:
            if self.root and self.root.current in ("admin_login", "admin_panel", "admin_edit_item") and self.current_admin_username:
                logout_user = self.current_admin_username
                logout_role = self.current_admin_role
        except Exception:
            pass
        super().goto_menu()
        if logout_user:
            self.backend_post_event_async(
                "admin_logout",
                payload={"username": logout_user, "role": logout_role},
            )

    def open_doors_sequential(self, hidden_ids, action: str = base.DOOR_ACTION, pulse_ms: int = base.DOOR_PULSE_MS, gap_ms: int = base.DOOR_GAP_MS, on_complete=None):
        def wrapped(results):
            try:
                for result in (results or []):
                    item_id = int(result.get("id"))
                    self.backend_post_door_event_async(
                        item_id=item_id,
                        panel_position=int(getattr(base, "PANEL_POSITION", 0)),
                        action=str(action),
                        success=bool(result.get("ok")),
                        error_text=result.get("error"),
                    )
            except Exception as e:
                print(f"[BACKEND] local door result logging failed: {e}")
            if on_complete:
                on_complete(results)

        return super().open_doors_sequential(hidden_ids, action=action, pulse_ms=pulse_ms, gap_ms=gap_ms, on_complete=wrapped)

    def _handle_payment_failure(self, items, error_text: str):
        self.backend_post_event_async(
            "payment_failed",
            severity="warning",
            payload={
                "error": str(error_text or ""),
                "items": items or [],
            },
        )
        super()._handle_payment_failure(items, error_text)

    def _handle_payment_result(self, items, invoice_number: str, issue_datetime_iso: str, total: float, result: dict):
        self.backend_post_event_async(
            "payment_result",
            payload={
                "invoice_number": invoice_number,
                "issue_datetime_iso": issue_datetime_iso,
                "total": float(total),
                "result": result or {},
            },
        )
        super()._handle_payment_result(items, invoice_number, issue_datetime_iso, total, result)

    def _complete_successful_purchase(self, items, invoice_number: str, issue_datetime_iso: str, total: float):
        self._last_invoice_number = str(invoice_number)
        self._last_issue_datetime_iso = str(issue_datetime_iso)

        # Keep an immutable invoice-specific snapshot for receipt printing.
        # Do not rely only on _last_purchased_items because that state may be
        # unavailable/cleared by the time the receipt is actually printed.
        receipt_items = [deepcopy(it) for it in (items or [])]

        if not hasattr(self, "_receipt_context_by_invoice"):
            self._receipt_context_by_invoice = {}

        self._receipt_context_by_invoice[str(invoice_number)] = {
            "items": receipt_items,
            "total": float(total),
            "issue_datetime_iso": str(issue_datetime_iso),
        }

        # Keep only the newest 20 receipt contexts.
        while len(self._receipt_context_by_invoice) > 20:
            oldest = next(iter(self._receipt_context_by_invoice))
            self._receipt_context_by_invoice.pop(oldest, None)

        print(
            f"[RECEIPT SNAPSHOT] invoice={invoice_number} "
            f"items={[(i.get('id'), i.get('price'), i.get('tax_pct')) for i in receipt_items]}"
        )
        try:
            self._last_purchase_total = float(total)
        except Exception:
            self._last_purchase_total = 0.0
        self._backend_pending_sales[invoice_number] = {
            "items": [deepcopy(it) for it in (items or [])],
            "total": float(total),
        }
        self.backend_post_event_async(
            "purchase_completed",
            payload={
                "invoice_number": invoice_number,
                "issue_datetime_iso": issue_datetime_iso,
                "total": float(total),
                "items": items or [],
            },
        )
        super()._complete_successful_purchase(items, invoice_number, issue_datetime_iso, total)

    def _worker_send(self, invoice_number: str, issue_datetime_iso: str, *args, **kwargs):
        ctx = self._backend_pending_sales.get(invoice_number) or {}
        items = ctx.get("items") or kwargs.get("items") or []
        total = float(ctx.get("total", 0.0))
        if not total and items:
            total = sum(float(it.get("price", 0.0)) for it in items)

        fiscal_status = "error"
        result = None
        self._last_fiscal_error = ""

        try:
            sig = inspect.signature(base.process_transaction)
            if "items" in sig.parameters:
                result = base.process_transaction(
                    invoice_number=invoice_number,
                    issue_datetime_iso=issue_datetime_iso,
                    items=items,
                )
            elif "amount" in sig.parameters:
                amount = kwargs.get("amount")
                if amount is None and args:
                    amount = args[0]
                if amount is None:
                    amount = total
                result = base.process_transaction(
                    invoice_number=invoice_number,
                    issue_datetime_iso=issue_datetime_iso,
                    amount=float(amount),
                )
            else:
                result = base.process_transaction(invoice_number=invoice_number, issue_datetime_iso=issue_datetime_iso)

            if isinstance(result, dict):
                if result.get("inv_ok"):
                    fiscal_status = "ok"
                elif result.get("queued_failed"):
                    fiscal_status = "queued_failed"
                elif result.get("skipped"):
                    fiscal_status = "skipped"
                else:
                    fiscal_status = "failed"
                    self._last_fiscal_error = str(result)
            else:
                fiscal_status = "ok"
        except Exception as e:
            fiscal_status = "error"
            result = {"exception": str(e)}
            self._last_fiscal_error = str(e)
        finally:
            self._last_fiscal_status = fiscal_status
            self._fiscal_results_by_invoice[str(invoice_number)] = {
                "status": fiscal_status,
                "result": result or {},
                "updated_at": time.time(),
            }
            if not total and items:
                total = sum(float(it.get("price", 0.0)) for it in items)
            append_monthly_invoice_csv(
                invoice_number=invoice_number,
                issue_datetime_iso=issue_datetime_iso,
                total=total,
                items=items,
            )
            self.backend_post_sale_async(
                invoice_number=invoice_number,
                issue_datetime_iso=issue_datetime_iso,
                total=total,
                items=items,
                payment_status="paid",
                fiscal_status=fiscal_status,
            )
            self.backend_post_event_async(
                "fiscalisation_result",
                payload={
                    "invoice_number": invoice_number,
                    "issue_datetime_iso": issue_datetime_iso,
                    "total": total,
                    "fiscal_status": fiscal_status,
                    "result": result or {},
                },
            )
            # ------------------------------------------------
            # Durable Croatian fiscal retry bookkeeping.
            #
            # The customer purchase has already completed at
            # this point. Fiscal failure must therefore NOT
            # interfere with fulfilment. Instead retain the
            # ORIGINAL sale identity for later retry.
            # ------------------------------------------------
            try:
                result_country = ""

                if isinstance(result, dict):
                    result_country = str(
                        result.get("country_code")
                        or ""
                    ).strip().upper()

                current_country = str(
                    getattr(
                        self,
                        "machine_country_code",
                        "",
                    )
                    or ""
                ).strip().upper()

                fiscal_country = (
                    result_country
                    or current_country
                )

                if (
                    fiscal_country == "HR"
                    and fiscal_status == "ok"
                ):
                    _remove_hr_fiscal_retry(
                        invoice_number
                    )

                elif (
                    fiscal_country == "HR"
                    and fiscal_status
                    in (
                        "failed",
                        "error",
                        "queued_failed",
                    )
                ):
                    error_text = (
                        self._last_fiscal_error
                        or str(result or "")
                    )

                    _queue_hr_fiscal_retry(
                        invoice_number=invoice_number,
                        issue_datetime_iso=(
                            issue_datetime_iso
                        ),
                        total=total,
                        items=items,
                        fiscal_status=(
                            fiscal_status
                        ),
                        error_text=error_text,
                    )

            except Exception as retry_exc:
                print(
                    "[HR FISCAL RETRY] "
                    "queue bookkeeping failed: "
                    f"{retry_exc}"
                )

            self._backend_pending_sales.pop(
                invoice_number,
                None,
            )


    def _receipt_printer_config(self):
        if ReceiptPrinterConfig is None:
            return None
        return ReceiptPrinterConfig(
            enabled=bool(RECEIPT_PRINTER_ENABLED),
            connection=str(RECEIPT_PRINTER_CONNECTION),
            device=str(RECEIPT_PRINTER_DEVICE),
            serial_baudrate=int(RECEIPT_PRINTER_SERIAL_BAUDRATE),
            tax_number=str(RECEIPT_PRINTER_TAX_NUMBER),
            business_name=str(RECEIPT_PRINTER_BUSINESS_NAME),
            operator_name=str(RECEIPT_PRINTER_OPERATOR_NAME),
            address_line=str(RECEIPT_PRINTER_ADDRESS_LINE),
            qr_module_size=int(RECEIPT_PRINTER_QR_MODULE_SIZE),
            cut_paper=bool(RECEIPT_PRINTER_CUT_PAPER),
        )

    def _set_receipt_print_status(self, message: str):
        raw_message = str(message)

        lang = str(
            getattr(self, "lang", "en") or "en"
        ).lower()

        translations = {
            "Preparing receipt": {
                "en": "Preparing receipt",
                "si": "Priprava računa",
                "hr": "Priprema računa",
                "de": "Beleg wird vorbereitet",
            },
            "Printing receipt": {
                "en": "Printing receipt",
                "si": "Tiskanje računa",
                "hr": "Ispis računa",
                "de": "Beleg wird gedruckt",
            },
            "Receipt printed": {
                "en": "Receipt printed",
                "si": "Račun natisnjen",
                "hr": "Račun ispisan",
                "de": "Beleg gedruckt",
            },
            "Receipt printer disabled": {
                "en": "Receipt printer disabled",
                "si": "Tiskalnik računov je onemogočen",
                "hr": "Pisač računa je onemogućen",
                "de": "Belegdrucker deaktiviert",
            },
            "No invoice available": {
                "en": "No invoice available",
                "si": "Račun ni na voljo",
                "hr": "Račun nije dostupan",
                "de": "Kein Beleg verfügbar",
            },
        }

        if raw_message.startswith("Receipt print failed:"):
            detail = raw_message.split(":", 1)[1].strip()

            prefix = {
                "en": "Receipt print failed",
                "si": "Tiskanje računa ni uspelo",
                "hr": "Ispis računa nije uspio",
                "de": "Belegdruck fehlgeschlagen",
            }.get(lang, "Receipt print failed")

            message = f"{prefix}: {detail}"

        else:
            message = translations.get(
                raw_message,
                {},
            ).get(
                lang,
                raw_message,
            )

        def _update(_dt):
            try:
                rp = self.root.get_screen("receipt_printing")
                base_text = str(rp.ids.receipt_print_for.text or "").split("\n\n[", 1)[0]
                rp.ids.receipt_print_for.text = base_text + "\n\n[" + str(message) + "]"
            except Exception:
                pass
        try:
            Clock.schedule_once(_update, 0)
        except Exception:
            print(f"[RECEIPT PRINTER] {message}")

    def _wait_for_fiscal_result(self, invoice_number: str) -> dict[str, Any]:
        deadline = time.time() + max(0.0, float(RECEIPT_PRINTER_WAIT_FOR_FISCAL_SECONDS))
        while time.time() < deadline:
            info = self._fiscal_results_by_invoice.get(str(invoice_number))
            if info is not None:
                return info
            time.sleep(0.15)
        return self._fiscal_results_by_invoice.get(str(invoice_number), {"status": "pending", "result": {}})

    def _build_last_receipt_data(self, invoice_number: str, fiscal_info: dict[str, Any]) -> dict[str, Any]:
        invoice_key = str(invoice_number)

        receipt_contexts = getattr(self, "_receipt_context_by_invoice", {}) or {}
        ctx = receipt_contexts.get(invoice_key) or {}

        # Primary source: immutable per-invoice snapshot.
        items = [deepcopy(it) for it in (ctx.get("items") or [])]

        # Backward-compatible fallback.
        if not items:
            items = [
                deepcopy(it)
                for it in (getattr(self, "_last_purchased_items", []) or [])
            ]

        try:
            total = float(ctx.get("total", 0.0) or 0.0)
        except Exception:
            total = 0.0

        if not total:
            total = float(getattr(self, "_last_purchase_total", 0.0) or 0.0)

        print(
            f"[RECEIPT DATA] invoice={invoice_number} "
            f"items={[(i.get('id'), i.get('price'), i.get('tax_pct')) for i in items]} "
            f"total={total}"
        )
        if not total and items:
            try:
                total = sum(float(it.get("price", 0.0) or 0.0) for it in items)
            except Exception:
                total = 0.0
        result = fiscal_info.get("result") if isinstance(fiscal_info, dict) else {}
        marks = extract_fiscal_marks(result) if extract_fiscal_marks is not None else {
            "zki": "",
            "jir": "",
            "zoi": "",
            "eor": "",
        }
        return {
            "invoice_number": str(invoice_number),
            "issue_datetime_iso": str(getattr(self, "_last_issue_datetime_iso", "") or ""),
            "items": items,
            "total": total,
            "fiscal_status": str((fiscal_info or {}).get("status") or getattr(self, "_last_fiscal_status", "unknown")),
            "zki": str(marks.get("zki", "")),
            "jir": str(marks.get("jir", "")),
            # Legacy values retained internally only.
            "zoi": str(marks.get("zoi", "")),
            "eor": str(marks.get("eor", "")),
        }

    def _worker_print_last_receipt(self, invoice_number: str):
        with self._receipt_print_lock:
            try:
                if print_receipt is None or ReceiptPrinterConfig is None:
                    raise RuntimeError("receipt_printer.py is not available")
                self._set_receipt_print_status("Preparing receipt")
                fiscal_info = self._wait_for_fiscal_result(invoice_number)
                receipt_data = self._build_last_receipt_data(invoice_number, fiscal_info)
                cfg = self._receipt_printer_config()
                if cfg is None:
                    raise RuntimeError("receipt printer config is not available")
                self._set_receipt_print_status("Printing receipt")
                ok = print_receipt(receipt_data, cfg)
                self._set_receipt_print_status("Receipt printed" if ok else "Receipt printer disabled")
            except Exception as e:
                self._set_receipt_print_status(f"Receipt print failed: {e}")
                print(f"[RECEIPT PRINTER] Failed: {e}")

    def on_receipt(self):
        invoice_number = str(getattr(self, "_last_invoice_number", "") or "").strip()
        if not invoice_number:
            self._set_receipt_print_status("No invoice available")
            print("[RECEIPT PRINTER] No invoice available to print")
            return
        threading.Thread(target=self._worker_print_last_receipt, args=(invoice_number,), daemon=True).start()

    def on_reprint_receipt(self):
        print("Reprint receipt requested")
        self.on_receipt()


    def _backend_visible_items_snapshot(self):
        snapshot = []

        def _append_items(items, panel_position: int, visible_count: int):
            for it in list(items or [])[:max(0, int(visible_count or 0))]:
                try:
                    row = deepcopy(it)
                except Exception:
                    try:
                        row = dict(it)
                    except Exception:
                        continue
                try:
                    row["panel_position"] = int(panel_position)
                    snapshot.append(row)
                except Exception:
                    continue

        local_position = int(getattr(base, "PANEL_POSITION", 0))
        local_visible_count = int(
            getattr(
                self,
                "panel_visible_count",
                getattr(base, "PANEL_VISIBLE_ITEMS", len(getattr(self, "items", []))) or len(getattr(self, "items", [])),
            )
        )
        _append_items(list(getattr(self, "items", []) or []), local_position, local_visible_count)

        if local_position == 0:
            for pos, panel in list(getattr(self, "remote_panels", {}).items()):
                try:
                    pos_i = int(pos)
                except Exception:
                    continue
                if pos_i == local_position or self._is_remote_panel_stale(panel):
                    continue
                panel_type = str((panel or {}).get("panel_type", getattr(base, "PANEL_TYPE", "A")) or "A").upper()
                layout = getattr(base, "PANEL_TYPE_CONFIGS", {}).get(panel_type, getattr(base, "PANEL_LAYOUT", {"visible_items": len((panel or {}).get("items") or [])}))
                visible_count = int((layout or {}).get("visible_items", len((panel or {}).get("items") or [])))
                _append_items((panel or {}).get("items") or [], pos_i, visible_count)

        return snapshot

    def _admin_accounts_file_path(self) -> str:
        return str(getattr(base, "ADMIN_ACCOUNTS_FILE", os.path.join(getattr(base, "PANEL_DIR", "."), "admin_accounts.txt")))

    def _load_local_admin_users_for_backend(self):
        users = []
        try:
            if hasattr(base, "load_admin_accounts"):
                loaded = base.load_admin_accounts() or {}
                for username, info in loaded.items():
                    if not username:
                        continue
                    users.append({
                        "username": str(username),
                        "password": str((info or {}).get("password", "")),
                        "role": str((info or {}).get("role", "worker")),
                        "is_active": True,
                    })
                    
                if users:
                    return users
        except Exception as e:
            print(f"[BACKEND] admin account helper load failed: {e}")

        path = self._admin_accounts_file_path()
        try:
            with open(path, "r", encoding="utf-8") as f:
                for raw_line in f:
                    line = raw_line.strip()
                    if not line or line.startswith("#"):
                        continue
                    parts = [p.strip() for p in line.split("|")]
                    if len(parts) != 3:
                        continue
                    role, username, password = parts
                    if not username:
                        continue
                    users.append({
                        "username": username,
                        "password": password,
                        "role": role or "worker",
                        "is_active": True,
                    })
        except Exception as e:
            print(f"[BACKEND] admin account file read failed: {e}")
        return users

    def _should_sync_admin_users(self) -> bool:
        return bool(self.backend_client) and int(getattr(base, "PANEL_POSITION", 0)) == 0

    def _admin_users_fingerprint(self, users) -> str:
        parts = [f"{u.get('username','')}|{u.get('role','')}|{u.get('password','')}|{1 if u.get('is_active', True) else 0}" for u in sorted(users, key=lambda x: str(x.get('username','')))]
        return hashlib.sha256("\n".join(parts).encode("utf-8")).hexdigest()

    def _maybe_sync_admin_users(self, force: bool = False):
        if not self._should_sync_admin_users() or not self.backend_client:
            return
        path = self._admin_accounts_file_path()
        try:
            mtime = os.path.getmtime(path)
        except Exception:
            mtime = None
        if (not force) and mtime is not None and self._admin_sync_last_mtime is not None and mtime == self._admin_sync_last_mtime:
            return

        users = self._load_local_admin_users_for_backend()
        fingerprint = self._admin_users_fingerprint(users)
        if (not force) and fingerprint == self._admin_sync_last_hash:
            self._admin_sync_last_mtime = mtime
            return

        try:
            self.backend_client.sync_admin_users(users, replace_missing=True)
            self._admin_sync_last_hash = fingerprint
            self._admin_sync_last_mtime = mtime
            print(f"[BACKEND] synced {len(users)} admin users for {BACKEND_PANEL_ID}")
        except Exception as e:
            print(f"[BACKEND] admin user sync failed: {e}")

    def _reservation_blocks_item(self, row: dict) -> bool:
        try:
            status = str((row or {}).get("status", "") or "").lower()
        except Exception:
            status = ""
        if status not in ("active", "claimed"):
            return False
        try:
            expires_at = (row or {}).get("expires_at")
            if expires_at:
                from datetime import datetime, timezone
                raw = str(expires_at).replace("Z", "+00:00")
                dt = datetime.fromisoformat(raw)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                if dt < datetime.now(timezone.utc):
                    return False
        except Exception:
            pass
        return True

    def _is_item_reserved(self, panel_position: int, item_id: int) -> bool:
        try:
            panel_position = int(panel_position)
            item_id = int(item_id)
        except Exception:
            return False
        for row in list(getattr(self, "server_reservation_codes", []) or []):
            try:
                if not self._reservation_blocks_item(row):
                    continue
                if int(row.get("panel_position", 0)) == panel_position and int(row.get("item_id")) == item_id:
                    return True
            except Exception:
                continue
        return False

    def _set_local_reservation_status(self, code: str, status: str):
        code = str(code or "").strip()
        if not code:
            return
        updated = []
        changed = False
        for row in list(getattr(self, "server_reservation_codes", []) or []):
            row_copy = dict(row or {})
            if str(row_copy.get("code", "")).strip() == code:
                row_copy["status"] = str(status)
                if str(status).lower() != "active":
                    row_copy.pop("claim_token", None)
                    row_copy.pop("claim_expires_at", None)
                changed = True
            updated.append(row_copy)
        if changed:
            self.server_reservation_codes = updated

    def _remove_local_reservation_code(self, code: str):
        code = str(code or "").strip()
        if not code:
            return
        before = list(getattr(self, "server_reservation_codes", []) or [])
        self.server_reservation_codes = [
            dict(row or {})
            for row in before
            if str((row or {}).get("code", "")).strip() != code
        ]

    def _append_reserved_suffix(self, text: str):
        reserved_txt = self.t("reserved")
        lines = [ln for ln in str(text or "").split("\n") if ln.strip()]
        if reserved_txt not in lines:
            lines.append(reserved_txt)
        return lines

    def _iter_widget_descendants(self, widget):
        for child in getattr(widget, "children", []) or []:
            yield child
            yield from self._iter_widget_descendants(child)

    def _finalize_reserved_button_visual(self, btn, *, item_id: int | None = None, allow_click: bool = False):
        try:
            descendants = list(self._iter_widget_descendants(btn))
            label_widgets = [w for w in descendants if isinstance(w, Label)]
            label_widgets = sorted(
                label_widgets,
                key=lambda w: (float(getattr(w, "center_y", 0.0)), float(getattr(w, "y", 0.0))),
                reverse=True,
            )

            reserved_text = self.t("reserved")
            number_text = f"#{int(item_id)}" if item_id is not None else ""

            if label_widgets:
                try:
                    label_widgets[0].text = number_text
                except Exception:
                    pass
            if len(label_widgets) >= 2:
                try:
                    label_widgets[1].text = reserved_text
                    label_widgets[1].halign = "center"
                    label_widgets[1].valign = "middle"
                except Exception:
                    pass
            for lb in label_widgets[2:]:
                try:
                    lb.text = ""
                except Exception:
                    pass

            # Hide the small price badge row if it exists.
            for box in descendants:
                if not isinstance(box, BoxLayout):
                    continue
                if box is btn:
                    continue
                try:
                    h = float(getattr(box, "height", 0) or 0)
                    w = float(getattr(box, "width", 0) or 0)
                    btn_w = float(getattr(btn, "width", 0) or 0)
                except Exception:
                    continue

                try:
                    contains_label = any(isinstance(x, Label) for x in self._iter_widget_descendants(box))
                except Exception:
                    contains_label = False

                if contains_label and 20 <= h <= 90 and (btn_w <= 0 or w < btn_w):
                    try:
                        box.opacity = 0
                    except Exception:
                        pass
                    try:
                        box.size_hint_y = None
                    except Exception:
                        pass
                    try:
                        box.height = 0
                    except Exception:
                        pass

            try:
                btn.disabled = (not allow_click)
            except Exception:
                pass
            try:
                btn.canvas.ask_update()
            except Exception:
                pass
        except Exception:
            pass

    def _decorate_reserved_button(self, btn, *, item_id: int | None = None, allow_click: bool = False):
        try:
            btn.disabled_rgba = [0.62, 0.62, 0.62, 0.62]
            btn.base_normal = [0.62, 0.62, 0.62, 0.62]
            btn.base_hover = [0.62, 0.62, 0.62, 0.62]
            btn.base_down = [0.62, 0.62, 0.62, 0.62]
            try:
                btn.border_rgba = [0.82, 0.82, 0.82, 0.72]
            except Exception:
                pass
            try:
                btn.badge_bg_rgba = [0, 0, 0, 0]
            except Exception:
                pass
            if hasattr(btn, "title_text"):
                btn.title_text = f"#{int(item_id)}" if item_id is not None else str(getattr(btn, "title_text", "") or "")
            if hasattr(btn, "price_text"):
                btn.price_text = ""
            if hasattr(btn, "status_text"):
                btn.status_text = self.t("reserved")
            if hasattr(btn, "title_font_size"):
                btn.title_font_size = "27sp"
            if hasattr(btn, "status_font_size"):
                btn.status_font_size = "18sp"

            try:
                btn.disabled = (not allow_click)
            except Exception:
                pass

            try:
                btn.refresh_bg()
            except Exception:
                pass

            Clock.schedule_once(
                lambda _dt, b=btn, iid=item_id, ac=allow_click: self._finalize_reserved_button_visual(b, item_id=iid, allow_click=ac),
                0,
            )
            Clock.schedule_once(
                lambda _dt, b=btn, iid=item_id, ac=allow_click: self._finalize_reserved_button_visual(b, item_id=iid, allow_click=ac),
                0.05,
            )
        except Exception:
            pass

    def _force_reservation_status_white(self):
        try:
            rs = self.root.get_screen("reservation")
        except Exception:
            return
        for wid in ("reservation_status", "reservation_body"):
            try:
                lbl = rs.ids[wid]
            except Exception:
                continue
            try:
                lbl.color = (1, 1, 1, 0.98)
            except Exception:
                pass
            try:
                lbl.disabled_color = (1, 1, 1, 0.98)
            except Exception:
                pass
            try:
                lbl.canvas.ask_update()
            except Exception:
                pass

    def add_current_to_cart(self):

        try:
            if self._is_item_reserved(getattr(self, "current_item_position", 0), getattr(self, "current_item_id", -1)):
                if self.root:
                    try:
                        scr = self.root.get_screen("item_detail")
                        scr.ids.item_note.text = self.t("reserved_not_for_sale")
                    except Exception:
                        pass
                return
        except Exception:
            pass
        return super().add_current_to_cart()

    def checkout_from_detail(self):
        try:
            if self._is_item_reserved(getattr(self, "current_item_position", 0), getattr(self, "current_item_id", -1)):
                if self.root:
                    try:
                        scr = self.root.get_screen("item_detail")
                        scr.ids.item_note.text = self.t("reserved_not_for_sale")
                    except Exception:
                        pass
                return
        except Exception:
            pass
        return super().checkout_from_detail()

    def start_cart_checkout(self):
        try:
            bad = []
            for entry in list(getattr(self, "cart_entries", []) or []):
                pos = int(entry.get("panel_position", getattr(base, "PANEL_POSITION", 0)))
                iid = int(entry.get("id"))
                if self._is_item_reserved(pos, iid):
                    bad.append((pos, iid))
            if bad:
                self.cart_entries = [
                    x for x in list(getattr(self, "cart_entries", []) or [])
                    if (int(x.get("panel_position", getattr(base, "PANEL_POSITION", 0))), int(x.get("id"))) not in bad
                ]
                self.update_cart_badge()
                self.refresh_cart_screen()
                self.goto_cart()
                return
        except Exception:
            pass
        return super().start_cart_checkout()

    def refresh_selection_grid(self):
        super().refresh_selection_grid()
        try:
            sel = self.root.get_screen("selection")
            left = sel.ids.items_grid_left
            right = sel.ids.items_grid_right
            visible = list(self.active_panel_items())
            left_buttons = [w for w in reversed(left.children)]
            right_buttons = [w for w in reversed(right.children)]
            current_pos = int(getattr(self, "current_panel_position", getattr(base, "PANEL_POSITION", 0)))
            for idx, it in enumerate(visible):
                btn = left_buttons[idx] if idx < int(self.panel_left_count) else right_buttons[idx - int(self.panel_left_count)]
                if self._is_item_reserved(current_pos, int(it["id"])):
                    self._decorate_reserved_button(btn, item_id=int(it["id"]))
        except Exception as e:
            print(f"[RESERVED] selection decorate failed: {e}")

    def refresh_check_price_grid(self):
        super().refresh_check_price_grid()
        try:
            scr = self.root.get_screen("price_check")
            left = scr.ids.check_grid_left
            right = scr.ids.check_grid_right
            visible = list(self.active_panel_items())
            left_buttons = [w for w in reversed(left.children)]
            right_buttons = [w for w in reversed(right.children)]
            current_pos = int(getattr(self, "current_panel_position", getattr(base, "PANEL_POSITION", 0)))
            for idx, it in enumerate(visible):
                btn = left_buttons[idx] if idx < int(self.panel_left_count) else right_buttons[idx - int(self.panel_left_count)]
                if self._is_item_reserved(current_pos, int(it["id"])):
                    self._decorate_reserved_button(btn, item_id=int(it["id"]))
        except Exception as e:
            print(f"[RESERVED] price decorate failed: {e}")

    def refresh_admin_grid(self):
        super().refresh_admin_grid()
        try:
            scr = self.root.get_screen("admin_panel")
            left = scr.ids.admin_grid_left
            right = scr.ids.admin_grid_right
            visible = list(self.active_panel_items())
            left_buttons = [w for w in reversed(left.children)]
            right_buttons = [w for w in reversed(right.children)]
            current_pos = int(getattr(self, "current_panel_position", getattr(base, "PANEL_POSITION", 0)))
            for idx, it in enumerate(visible):
                btn = left_buttons[idx] if idx < int(self.panel_left_count) else right_buttons[idx - int(self.panel_left_count)]
                if self._is_item_reserved(current_pos, int(it["id"])):
                    self._decorate_reserved_button(btn, item_id=int(it["id"]), allow_click=True)
        except Exception as e:
            print(f"[RESERVED] admin decorate failed: {e}")

    def _update_item_detail_screen(self):
        super()._update_item_detail_screen()
        try:
            scr = self.root.get_screen("item_detail")
            panel_position = int(getattr(self, "current_item_position", getattr(base, "PANEL_POSITION", 0)))
            item_id = getattr(self, "current_item_id", None)
            if item_id is None:
                return
            if self._is_item_reserved(panel_position, int(item_id)):
                scr.ids.item_note.text = self.t("reserved_not_for_sale")
                scr.ids.item_add_btn.disabled = True
                try:
                    scr.ids.item_checkout_btn.disabled = (len(getattr(self, "cart_entries", [])) == 0)
                except Exception:
                    scr.ids.item_checkout_btn.disabled = True
        except Exception as e:
            print(f"[RESERVED] detail decorate failed: {e}")


# =========================
# Additional UI tweaks patch
# =========================
base.I18N.setdefault("module_slots", {
    "en": "Module {panel_type} - {slots} slots",
    "si": "Modul {panel_type} - {slots} mest",
    "de": "Modul {panel_type} - {slots} Plätze",
    "hr": "Modul {panel_type} - {slots} mjesta",
})

def _backend_patch_module_info_kv():
    try:
        kv = base.KV
    except Exception:
        return

    replacements = {
        """
                Widget:

                HoverButton:
                    id: selection_right_btn
""": """
                Label:
                    id: selection_module_info
                    text: ""
                    color: 1, 1, 1, 0.96
                    font_size: "24sp"
                    bold: True
                    halign: "center"
                    valign: "middle"
                    text_size: self.size

                HoverButton:
                    id: selection_right_btn
""",
        """
                Widget:

                HoverButton:
                    id: check_price_right_btn
""": """
                Label:
                    id: check_price_module_info
                    text: ""
                    color: 1, 1, 1, 0.96
                    font_size: "24sp"
                    bold: True
                    halign: "center"
                    valign: "middle"
                    text_size: self.size

                HoverButton:
                    id: check_price_right_btn
""",
        """
                Widget:

                HoverButton:
                    id: admin_right_btn
""": """
                Label:
                    id: admin_module_info
                    text: ""
                    color: 1, 1, 1, 0.96
                    font_size: "24sp"
                    bold: True
                    halign: "center"
                    valign: "middle"
                    text_size: self.size

                HoverButton:
                    id: admin_right_btn
""",
    }

    changed = False
    for old, new in replacements.items():
        if old in kv and new not in kv:
            kv = kv.replace(old, new)
            changed = True
    if changed:
        base.KV = kv

_backend_patch_module_info_kv()


def _button_labels_top_to_bottom(widget):
    labels = []
    try:
        descendants = widget.walk(restrict=True)
    except Exception:
        descendants = []
    for child in descendants:
        if isinstance(child, Label):
            labels.append(child)
    labels = sorted(
        labels,
        key=lambda w: (float(getattr(w, "center_y", 0.0)), float(getattr(w, "y", 0.0))),
        reverse=True,
    )
    return labels


def _force_admin_login_status_white(self):
    try:
        scr = self.root.get_screen("admin_login")
        lbl = scr.ids.login_status
        lbl.color = (1, 1, 1, 0.98)
        try:
            lbl.disabled_color = (1, 1, 1, 0.98)
        except Exception:
            pass
        try:
            lbl.canvas.ask_update()
        except Exception:
            pass
    except Exception:
        pass


def _refresh_module_info_labels(self):
    if not getattr(self, "root", None):
        return
    try:
        panel_type = str(self.current_panel_type() or getattr(self, "panel_type", "A"))
    except Exception:
        panel_type = str(getattr(self, "panel_type", "A"))
    try:
        slots = int(getattr(self, "panel_visible_count", 0) or 0)
    except Exception:
        slots = 0

    text = self.t("module_slots").format(panel_type=panel_type, slots=slots)
    targets = (
        ("selection", "selection_module_info"),
        ("price_check", "check_price_module_info"),
        ("admin_panel", "admin_module_info"),
    )
    for screen_name, wid in targets:
        try:
            scr = self.root.get_screen(screen_name)
            if wid in scr.ids:
                scr.ids[wid].text = text
        except Exception:
            pass


def _move_admin_reopen_button_right(self):
    try:
        scr = self.root.get_screen("admin_edit_item")
        btn = scr.ids.edit_reenable_btn
        parent = btn.parent
        if not parent:
            return
        parent.remove_widget(btn)
        parent.add_widget(btn, index=0)
    except Exception:
        pass


def _style_available_button_number(self, btn, *, enabled=True, reserved=False):
    try:
        labels = _button_labels_top_to_bottom(btn)
        if not labels:
            return
        top = labels[0]
        if reserved:
            top.color = (0.92, 0.92, 0.92, 0.90)
        elif enabled:
            top.color = (0.78, 0.94, 0.78, 0.98)
        else:
            top.color = (0.92, 0.92, 0.92, 0.88)
        try:
            top.canvas.ask_update()
        except Exception:
            pass
    except Exception:
        pass


def _hide_price_badge_only(self, btn):
    try:
        descendants = list(self._iter_widget_descendants(btn))
    except Exception:
        descendants = []
    for box in descendants:
        if not isinstance(box, BoxLayout):
            continue
        if box is btn:
            continue
        try:
            h = float(getattr(box, "height", 0) or 0)
            w = float(getattr(box, "width", 0) or 0)
            btn_w = float(getattr(btn, "width", 0) or 0)
        except Exception:
            continue
        try:
            contains_label = any(isinstance(x, Label) for x in self._iter_widget_descendants(box))
        except Exception:
            contains_label = False
        if contains_label and 20 <= h <= 100 and (btn_w <= 0 or w < btn_w):
            try:
                box.opacity = 0
                box.size_hint_y = None
                box.height = 0
            except Exception:
                pass


def _finalize_reserved_button_visual_patched(self, btn, *, item_id: int | None = None, allow_click: bool = False):
    try:
        self._hide_price_badge_only(btn)
        try:
            btn.disabled = (not allow_click)
        except Exception:
            pass
        self._style_available_button_number(btn, enabled=False, reserved=True)
        try:
            btn.canvas.ask_update()
        except Exception:
            pass
    except Exception:
        pass


def _decorate_reserved_button_patched(self, btn, *, item_id: int | None = None, allow_click: bool = False):
    try:
        btn.disabled_rgba = [0.62, 0.62, 0.62, 0.62]
        btn.base_normal = [0.62, 0.62, 0.62, 0.62]
        btn.base_hover = [0.70, 0.70, 0.70, 0.76]
        btn.base_down = [0.56, 0.56, 0.56, 0.82]
        try:
            btn.border_rgba = [0.82, 0.82, 0.82, 0.72]
        except Exception:
            pass
        try:
            btn.badge_bg_rgba = [0, 0, 0, 0]
        except Exception:
            pass

        if hasattr(btn, "title_text"):
            btn.title_text = f"#{int(item_id)}" if item_id is not None else str(getattr(btn, "title_text", "") or "")
        if hasattr(btn, "price_text"):
            btn.price_text = ""
        if hasattr(btn, "status_text"):
            btn.status_text = self.t("reserved")
        if hasattr(btn, "title_font_size"):
            btn.title_font_size = "27sp"
        if hasattr(btn, "status_font_size"):
            btn.status_font_size = "18sp"

        try:
            btn.disabled = (not allow_click)
        except Exception:
            pass
        try:
            btn.refresh_bg()
        except Exception:
            pass

        Clock.schedule_once(lambda _dt, b=btn, iid=item_id, ac=allow_click: self._finalize_reserved_button_visual(b, item_id=iid, allow_click=ac), 0)
        Clock.schedule_once(lambda _dt, b=btn, iid=item_id, ac=allow_click: self._finalize_reserved_button_visual(b, item_id=iid, allow_click=ac), 0.05)
        Clock.schedule_once(lambda _dt, b=btn, iid=item_id, ac=allow_click: self._finalize_reserved_button_visual(b, item_id=iid, allow_click=ac), 0.15)
    except Exception:
        pass


# monkey-patch reserved visuals and utility helpers
PanelBackendReservationApp._finalize_reserved_button_visual = _finalize_reserved_button_visual_patched
PanelBackendReservationApp._decorate_reserved_button = _decorate_reserved_button_patched
PanelBackendReservationApp._force_admin_login_status_white = _force_admin_login_status_white
PanelBackendReservationApp._refresh_module_info_labels = _refresh_module_info_labels
PanelBackendReservationApp._move_admin_reopen_button_right = _move_admin_reopen_button_right
PanelBackendReservationApp._style_available_button_number = _style_available_button_number
PanelBackendReservationApp._hide_price_badge_only = _hide_price_badge_only

# wrap existing methods with lightweight UI refreshes
_OLD_BUILD = PanelBackendReservationApp.build
def _build_patched(self):
    root = _OLD_BUILD(self)
    for delay in (0, 0.05, 0.2):
        try:
            Clock.schedule_once(lambda _dt, app=self: app._move_admin_reopen_button_right(), delay)
            Clock.schedule_once(lambda _dt, app=self: app._refresh_module_info_labels(), delay)
            Clock.schedule_once(lambda _dt, app=self: app._force_admin_login_status_white(), delay)
        except Exception:
            pass
    return root
PanelBackendReservationApp.build = _build_patched

_OLD_ON_START = PanelBackendReservationApp.on_start
def _on_start_patched(self):
    _OLD_ON_START(self)
    for delay in (0, 0.1, 0.3, 1.0):
        try:
            Clock.schedule_once(lambda _dt, app=self: app._move_admin_reopen_button_right(), delay)
            Clock.schedule_once(lambda _dt, app=self: app._refresh_module_info_labels(), delay)
            Clock.schedule_once(lambda _dt, app=self: app._force_admin_login_status_white(), delay)
        except Exception:
            pass
PanelBackendReservationApp.on_start = _on_start_patched

_OLD_APPLY_TRANSLATIONS = PanelBackendReservationApp.apply_translations
def _apply_translations_patched(self):
    _OLD_APPLY_TRANSLATIONS(self)
    try:
        self._refresh_module_info_labels()
    except Exception:
        pass
    try:
        self._force_admin_login_status_white()
    except Exception:
        pass
PanelBackendReservationApp.apply_translations = _apply_translations_patched

_OLD_SWITCH_PANEL_VIEW = PanelBackendReservationApp.switch_panel_view
def _switch_panel_view_patched(self, direction: int):
    _OLD_SWITCH_PANEL_VIEW(self, direction)
    try:
        self._refresh_module_info_labels()
    except Exception:
        pass
PanelBackendReservationApp.switch_panel_view = _switch_panel_view_patched

_OLD_GOTO_SELECTION = PanelBackendReservationApp.goto_selection
def _goto_selection_patched(self):
    _OLD_GOTO_SELECTION(self)
    try:
        self._refresh_module_info_labels()
    except Exception:
        pass
PanelBackendReservationApp.goto_selection = _goto_selection_patched

if hasattr(PanelBackendReservationApp, "goto_check_price"):
    _OLD_GOTO_CHECK_PRICE = PanelBackendReservationApp.goto_check_price
    def _goto_check_price_patched(self):
        _OLD_GOTO_CHECK_PRICE(self)
        try:
            self._refresh_module_info_labels()
        except Exception:
            pass
    PanelBackendReservationApp.goto_check_price = _goto_check_price_patched

_OLD_GOTO_ADMIN_PANEL = PanelBackendReservationApp.goto_admin_panel
def _goto_admin_panel_patched(self):
    _OLD_GOTO_ADMIN_PANEL(self)
    try:
        self._refresh_module_info_labels()
    except Exception:
        pass
    try:
        self._move_admin_reopen_button_right()
    except Exception:
        pass
PanelBackendReservationApp.goto_admin_panel = _goto_admin_panel_patched

_OLD_ADMIN_LOGIN = PanelBackendReservationApp.admin_login
def _admin_login_patched(self):
    _OLD_ADMIN_LOGIN(self)
    try:
        self._force_admin_login_status_white()
    except Exception:
        pass
PanelBackendReservationApp.admin_login = _admin_login_patched

_OLD_RES_INVALID = PanelBackendReservationApp._reservation_verify_then_collect_invalid
def _reservation_verify_then_collect_invalid_patched(self, result: dict):
    _OLD_RES_INVALID(self, result)
    try:
        self._force_reservation_status_white()
    except Exception:
        pass
PanelBackendReservationApp._reservation_verify_then_collect_invalid = _reservation_verify_then_collect_invalid_patched

_OLD_RES_FAILED = PanelBackendReservationApp._reservation_collect_failed
def _reservation_collect_failed_patched(self, message: str):
    _OLD_RES_FAILED(self, message)
    try:
        self._force_reservation_status_white()
    except Exception:
        pass
PanelBackendReservationApp._reservation_collect_failed = _reservation_collect_failed_patched

_OLD_RES_LOCAL = PanelBackendReservationApp._reservation_local_open_done
def _reservation_local_open_done_patched(self, item_id, label, panel_position, code, claim_token, results):
    _OLD_RES_LOCAL(self, item_id, label, panel_position, code, claim_token, results)
    try:
        self._force_reservation_status_white()
    except Exception:
        pass
PanelBackendReservationApp._reservation_local_open_done = _reservation_local_open_done_patched

_OLD_RES_REMOTE = PanelBackendReservationApp._reservation_remote_open_done
def _reservation_remote_open_done_patched(self, item_id, label, panel_position, code, claim_token, results):
    _OLD_RES_REMOTE(self, item_id, label, panel_position, code, claim_token, results)
    try:
        self._force_reservation_status_white()
    except Exception:
        pass
PanelBackendReservationApp._reservation_remote_open_done = _reservation_remote_open_done_patched

_OLD_REFRESH_SELECTION = PanelBackendReservationApp.refresh_selection_grid
def _refresh_selection_grid_patched(self):
    _OLD_REFRESH_SELECTION(self)
    try:
        sel = self.root.get_screen("selection")
        left = sel.ids.items_grid_left
        right = sel.ids.items_grid_right
        visible = list(self.active_panel_items())
        left_buttons = [w for w in reversed(left.children)]
        right_buttons = [w for w in reversed(right.children)]
        current_pos = int(getattr(self, "current_panel_position", getattr(base, "PANEL_POSITION", 0)))
        for idx, it in enumerate(visible):
            btn = left_buttons[idx] if idx < int(self.panel_left_count) else right_buttons[idx - int(self.panel_left_count)]
            reserved = self._is_item_reserved(current_pos, int(it["id"]))
            self._style_available_button_number(btn, enabled=bool(it.get("enabled", True)) and not reserved, reserved=reserved)
    except Exception:
        pass
    try:
        self._refresh_module_info_labels()
    except Exception:
        pass
PanelBackendReservationApp.refresh_selection_grid = _refresh_selection_grid_patched

_OLD_REFRESH_CHECK = PanelBackendReservationApp.refresh_check_price_grid
def _refresh_check_price_grid_patched(self):
    _OLD_REFRESH_CHECK(self)
    try:
        scr = self.root.get_screen("price_check")
        left = scr.ids.check_grid_left
        right = scr.ids.check_grid_right
        visible = list(self.active_panel_items())
        left_buttons = [w for w in reversed(left.children)]
        right_buttons = [w for w in reversed(right.children)]
        current_pos = int(getattr(self, "current_panel_position", getattr(base, "PANEL_POSITION", 0)))
        for idx, it in enumerate(visible):
            btn = left_buttons[idx] if idx < int(self.panel_left_count) else right_buttons[idx - int(self.panel_left_count)]
            reserved = self._is_item_reserved(current_pos, int(it["id"]))
            self._style_available_button_number(btn, enabled=bool(it.get("enabled", True)) and not reserved, reserved=reserved)
    except Exception:
        pass
    try:
        self._refresh_module_info_labels()
    except Exception:
        pass
PanelBackendReservationApp.refresh_check_price_grid = _refresh_check_price_grid_patched

_OLD_REFRESH_ADMIN = PanelBackendReservationApp.refresh_admin_grid
def _refresh_admin_grid_patched(self):
    _OLD_REFRESH_ADMIN(self)
    try:
        scr = self.root.get_screen("admin_panel")
        left = scr.ids.admin_grid_left
        right = scr.ids.admin_grid_right
        visible = list(self.active_panel_items())
        left_buttons = [w for w in reversed(left.children)]
        right_buttons = [w for w in reversed(right.children)]
        current_pos = int(getattr(self, "current_panel_position", getattr(base, "PANEL_POSITION", 0)))
        for idx, it in enumerate(visible):
            btn = left_buttons[idx] if idx < int(self.panel_left_count) else right_buttons[idx - int(self.panel_left_count)]
            reserved = self._is_item_reserved(current_pos, int(it["id"]))
            self._style_available_button_number(btn, enabled=bool(it.get("enabled", True)) and not reserved, reserved=reserved)
    except Exception:
        pass
    try:
        self._refresh_module_info_labels()
    except Exception:
        pass
PanelBackendReservationApp.refresh_admin_grid = _refresh_admin_grid_patched


# ---- Final HR flag + reserved visual patch ----
_OLD_BACKEND_INIT_HR = PanelBackendReservationApp.__init__
def _backend_init_hr(self, **kwargs):
    _OLD_BACKEND_INIT_HR(self, **kwargs)
    try:
        self.ICON_HR = getattr(base, "ICON_HR", os.path.join(getattr(base, "PANEL_DIR", "."), "flag_hr.png"))
    except Exception:
        pass
PanelBackendReservationApp.__init__ = _backend_init_hr

def _reserved_button_labels_fix(self, btn, *, item_id: int | None = None, allow_click: bool = False):
    try:
        if hasattr(btn, "number_text"):
            btn.number_text = ""
        if hasattr(btn, "title_text"):
            btn.title_text = self.t("reserved")
        if hasattr(btn, "price_text"):
            btn.price_text = ""
        if hasattr(btn, "status_text"):
            btn.status_text = ""
        if hasattr(btn, "title_color_rgba"):
            btn.title_color_rgba = [0.95, 0.95, 0.95, 0.96]
        if hasattr(btn, "number_color_rgba"):
            btn.number_color_rgba = [0.92, 0.92, 0.92, 0.90]
        if hasattr(btn, "title_font_size"):
            btn.title_font_size = "26sp"
        if hasattr(btn, "status_font_size"):
            btn.status_font_size = "18sp"
        try:
            btn.disabled = (not allow_click)
        except Exception:
            pass
        try:
            btn.refresh_bg()
        except Exception:
            pass
        try:
            self._hide_price_badge_only(btn)
        except Exception:
            pass
        try:
            btn.canvas.ask_update()
        except Exception:
            pass
    except Exception:
        pass

def _decorate_reserved_button_final(self, btn, *, item_id: int | None = None, allow_click: bool = False):
    try:
        btn.disabled_rgba = [0.62, 0.62, 0.62, 0.62]
        btn.base_normal = [0.62, 0.62, 0.62, 0.62]
        btn.base_hover = [0.70, 0.70, 0.70, 0.76]
        btn.base_down = [0.56, 0.56, 0.56, 0.82]
        try:
            btn.border_rgba = [0.82, 0.82, 0.82, 0.72]
        except Exception:
            pass
        try:
            btn.badge_bg_rgba = [0, 0, 0, 0]
        except Exception:
            pass
        self._reserved_button_labels_fix(btn, item_id=item_id, allow_click=allow_click)
        Clock.schedule_once(lambda _dt, b=btn, iid=item_id, ac=allow_click: self._reserved_button_labels_fix(b, item_id=iid, allow_click=ac), 0)
        Clock.schedule_once(lambda _dt, b=btn, iid=item_id, ac=allow_click: self._reserved_button_labels_fix(b, item_id=iid, allow_click=ac), 0.05)
        Clock.schedule_once(lambda _dt, b=btn, iid=item_id, ac=allow_click: self._reserved_button_labels_fix(b, item_id=iid, allow_click=ac), 0.15)
    except Exception:
        pass

PanelBackendReservationApp._reserved_button_labels_fix = _reserved_button_labels_fix
PanelBackendReservationApp._decorate_reserved_button = _decorate_reserved_button_final
PanelBackendReservationApp._finalize_reserved_button_visual = _reserved_button_labels_fix


# ---- Final patch: Croatian completeness + reservation numpad + reserved-as-empty visuals ----
_RESERVATION_NUMPAD_PATCH = r'''
<ReservationKey@HoverButton>:
    font_size: "28sp"
    halign: "center"
    valign: "middle"
    text_size: self.size
    color: 1, 1, 1, 0.98
    base_normal: [0.84, 0.84, 0.84, 0.30]
    base_hover: [0.90, 0.90, 0.90, 0.36]
    base_down: [0.96, 0.96, 0.96, 0.42]
    disabled_rgba: [0.75, 0.75, 0.75, 0.12]
    border_rgba: [1, 1, 1, 0.65]

<ReservationIconKey@FloatLayout>:
    icon: ""
    key_value: ""
    disabled: False

    HoverButton:
        text: ""
        disabled: root.disabled
        size_hint: 1, 1
        pos_hint: {"x": 0, "y": 0}
        base_normal: [0.84, 0.84, 0.84, 0.30]
        base_hover: [0.90, 0.90, 0.90, 0.36]
        base_down: [0.96, 0.96, 0.96, 0.42]
        disabled_rgba: [0.75, 0.75, 0.75, 0.12]
        border_rgba: [1, 1, 1, 0.65]
        on_release: app.admin_keyboard_key(root.key_value) if not root.disabled else None

    AnchorLayout:
        anchor_x: "center"
        anchor_y: "center"
        size_hint: 1, 1
        pos_hint: {"x": 0, "y": 0}

        CrispImage:
            source: root.icon
            size_hint: None, None
            size: dp(52), dp(52)
            fit_mode: "contain"
            opacity: 1 if not root.disabled else 0.45

<ReservationNumpad@BoxLayout>:
    orientation: "vertical"
    size_hint_y: None
    height: dp(330)
    spacing: dp(10)
    padding: [dp(16), dp(16), dp(16), dp(16)]

    canvas.before:
        Color:
            rgba: 0, 0, 0, 0.14
        RoundedRectangle:
            pos: self.x, self.y + dp(-3)
            size: self.size
            radius: [dp(28), dp(28), dp(28), dp(28)]
        Color:
            rgba: 0.84, 0.84, 0.84, 0.18
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(28), dp(28), dp(28), dp(28)]
        Color:
            rgba: 1, 1, 1, 0.65
        Line:
            rounded_rectangle: (self.x, self.y, self.width, self.height, dp(28))
            width: dp(1.5)

    GridLayout:
        cols: 3
        rows: 4
        spacing: dp(10)

        ReservationKey:
            text: "1"
            on_release: app.admin_keyboard_key(self.text)
        ReservationKey:
            text: "2"
            on_release: app.admin_keyboard_key(self.text)
        ReservationKey:
            text: "3"
            on_release: app.admin_keyboard_key(self.text)
        ReservationKey:
            text: "4"
            on_release: app.admin_keyboard_key(self.text)
        ReservationKey:
            text: "5"
            on_release: app.admin_keyboard_key(self.text)
        ReservationKey:
            text: "6"
            on_release: app.admin_keyboard_key(self.text)
        ReservationKey:
            text: "7"
            on_release: app.admin_keyboard_key(self.text)
        ReservationKey:
            text: "8"
            on_release: app.admin_keyboard_key(self.text)
        ReservationKey:
            text: "9"
            on_release: app.admin_keyboard_key(self.text)
        ReservationKey:
            text: app.keyboard_clear_label
            on_release: app.admin_keyboard_key("Clear")
        ReservationKey:
            text: "0"
            on_release: app.admin_keyboard_key(self.text)
        ReservationIconKey:
            icon: app.ICON_KEY_BACKSPACE
            key_value: "Backspace"
'''

_RESERVATION_SCREEN_BLOCK_NUMPAD = '''
<ReservationScreen>:
    name: "reservation"
    FullScreenFloat:
        FloatLayout:
            BoxLayout:
                orientation: "vertical"
                padding: [dp(30), TOP_PAD, dp(30), dp(30)]
                spacing: dp(20)
                size_hint: 1, 1

                Widget:
                    size_hint_y: None
                    height: dp(56)

                TitleLabel:
                    id: reservation_title
                    text: "Reservation"
                    size_hint_y: None
                    height: 0
                    opacity: 0

                BoxLayout:
                    size_hint_y: None
                    height: "80dp"
                    Widget:
                    RoundedTextInput:
                        id: reservation_code_input
                        hint_text: "Enter reservation code"
                        font_size: OTHER_TXT
                        fill_rgba: [0.2, 0.33, 0.23, 0.84]
                        border_rgba: [0.84, 0.71, 0.36, 0.95]
                        foreground_color: 1, 1, 1, 1
                        disabled_foreground_color: 1, 1, 1, 1
                        cursor_color: 1, 1, 1, 1
                        hint_text_color: 1, 1, 1, 0.78
                        hint_text_color_normal: 1, 1, 1, 0.78
                        hint_text_color_focus: 1, 1, 1, 0.78
                        selection_color: 1, 1, 1, 0.18
                        input_filter: "int"
                        size_hint_x: None
                        width: min(dp(860), Window.width - dp(140))
                    Widget:

                Label:
                    id: reservation_status
                    text: ""
                    font_size: OTHER_TXT
                    bold: True
                    color: 1, 1, 1, 0.96
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    size_hint_y: None
                    height: "120dp"

                Widget:
                    size_hint_y: 0.08

                ReservationNumpad:

                BoxLayout:
                    size_hint_y: None
                    height: "110dp"
                    spacing: dp(16)

                    NavIconButton:
                        id: reservation_back_btn
                        icon: app.ICON_BACK
                        text: "Back"
                        on_release: app.goto_menu()

                    NavIconButton:
                        id: reservation_home_btn
                        icon: app.ICON_HOME
                        text: "Home"
                        on_release: app.goto_menu()

                    NavIconButton:
                        id: reservation_collect_btn
                        icon: app.ICON_RESERVATION
                        text: "Collect"
                        on_release: app.reservation_collect()

        HeaderBar:
'''.strip("\n")

if '<ReservationNumpad@BoxLayout>:' not in base.KV:
    base.KV = _RESERVATION_NUMPAD_PATCH + "\n" + base.KV
base.KV = re.sub(r"<ReservationScreen>:\n.*?(?=\n<PriceCheckScreen>:)", _RESERVATION_SCREEN_BLOCK_NUMPAD + "\n", base.KV, flags=re.S)

def _apply_reserved_button_visual(self, btn, *, item_id: int | None = None, allow_click: bool = False):
    try:
        btn.disabled = False
        btn.base_normal = [0.45, 0.45, 0.45, 0.58]
        btn.base_hover = [0.48, 0.48, 0.48, 0.66]
        btn.base_down = [0.40, 0.40, 0.40, 0.78]
        btn.disabled_rgba = [0.45, 0.45, 0.45, 0.58]
        btn.border_rgba = [0.70, 0.70, 0.70, 0.65]
        btn.number_color_rgba = [0.82, 0.82, 0.82, 0.95]
        btn.title_color_rgba = [0.88, 0.88, 0.88, 0.95]
        btn.price_color_rgba = [0.50, 0.45, 0.39, 1.0]
        btn.number_text = ""
        btn.title_text = self.t("reserved")
        btn.price_text = ""
        btn.status_text = ""
        try:
            btn.badge_bg_rgba = [0, 0, 0, 0]
        except Exception:
            pass
        try:
            self._hide_price_badge_only(btn)
        except Exception:
            pass
        try:
            self._style_available_button_number(btn, enabled=False, reserved=True)
        except Exception:
            pass
        btn.refresh_bg()
    except Exception:
        pass

def _refresh_selection_grid_reserved_final(self):
    sel = self.root.get_screen("selection")
    sel.ids.selection_title.text = self._panel_title(self.t("select_bouquet"))
    left = sel.ids.items_grid_left
    right = sel.ids.items_grid_right
    left.clear_widgets()
    right.clear_widgets()
    self._refresh_panel_nav_buttons()
    visible = list(self.active_panel_items())
    current_pos = int(getattr(self, "current_panel_position", getattr(base, "PANEL_POSITION", 0)))
    for idx, it in enumerate(visible):
        item_id = int(it["id"])
        reserved = self._is_item_reserved(current_pos, item_id)
        in_cart = (not reserved) and any(int(x.get("panel_position")) == int(self.current_panel_position) and int(x.get("id")) == item_id for x in self.cart_entries)
        if reserved:
            number_text, name_text, price_text = "", self.t("reserved"), ""
        else:
            number_text, name_text, price_text = self._bouquet_card_parts(it, empty_label=self.t("empty"))
            if in_cart and it["enabled"]:
                name_text = self.t("in_cart")
                price_text = ""
        btn = base.BouquetButton(number_text=number_text, title_text=name_text, price_text=price_text, number_font_size="26sp", title_font_size=("25sp" if (reserved or not bool(it.get("enabled", True))) else "35sp"), title_max_lines=(1 if (reserved or not bool(it.get("enabled", True))) else 2), price_font_size="26sp", status_text="", status_font_size="15sp")
        btn.disabled = False
        if reserved:
            self._apply_reserved_button_visual(btn, item_id=item_id, allow_click=False)
        else:
            self._apply_bouquet_button_palette(btn, is_empty=(not it["enabled"]), is_in_cart=in_cart)
            self._style_available_button_number(btn, enabled=bool(it.get("enabled", True)), reserved=False)
            btn.refresh_bg()
            if it["enabled"]:
                btn.bind(on_release=lambda _btn, iid=item_id: self.goto_item_detail(iid))
        self._add_bouquet_button_to_grid(btn, idx, left, right)
    try:
        self._refresh_module_info_labels()
    except Exception:
        pass

def _refresh_check_price_grid_reserved_final(self):
    ps = self.root.get_screen("price_check")
    ps.ids.check_price_title.text = self._panel_title(self.t("check_price_title"))
    left = ps.ids.check_grid_left
    right = ps.ids.check_grid_right
    left.clear_widgets()
    right.clear_widgets()
    self._refresh_panel_nav_buttons()
    visible = list(self.active_panel_items())
    current_pos = int(getattr(self, "current_panel_position", getattr(base, "PANEL_POSITION", 0)))
    for idx, it in enumerate(visible):
        item_id = int(it["id"])
        reserved = self._is_item_reserved(current_pos, item_id)
        in_cart = (not reserved) and any(int(x.get("panel_position")) == int(self.current_panel_position) and int(x.get("id")) == item_id for x in self.cart_entries)
        if reserved:
            number_text, name_text, price_text = "", self.t("reserved"), ""
        else:
            number_text, name_text, price_text = self._bouquet_card_parts(it, empty_label=self.t("empty"))
            if in_cart and it["enabled"]:
                name_text = self.t("in_cart")
                price_text = ""
        btn = base.BouquetButton(number_text=number_text, title_text=name_text, price_text=price_text, number_font_size="26sp", title_font_size=("25sp" if (reserved or not bool(it.get("enabled", True))) else "35sp"), title_max_lines=(1 if (reserved or not bool(it.get("enabled", True))) else 2), price_font_size="26sp", status_text="", status_font_size="15sp")
        btn.disabled = False
        if reserved:
            self._apply_reserved_button_visual(btn, item_id=item_id, allow_click=False)
        else:
            self._apply_bouquet_button_palette(btn, is_empty=(not it["enabled"]), is_in_cart=in_cart)
            self._style_available_button_number(btn, enabled=bool(it.get("enabled", True)), reserved=False)
            btn.refresh_bg()
        self._add_bouquet_button_to_grid(btn, idx, left, right)
    try:
        self._refresh_module_info_labels()
    except Exception:
        pass

def _refresh_admin_grid_reserved_final(self):
    ap = self.root.get_screen("admin_panel")
    left = ap.ids.admin_grid_left
    right = ap.ids.admin_grid_right
    left.clear_widgets()
    right.clear_widgets()
    worker_mode = (self.current_admin_role == base.ADMIN_ROLE_WORKER)
    visible = list(self.active_panel_items())
    current_pos = int(getattr(self, "current_panel_position", getattr(base, "PANEL_POSITION", 0)))
    for idx, it in enumerate(visible):
        item_id = int(it["id"])
        reserved = self._is_item_reserved(current_pos, item_id)
        is_empty = (not bool(it["enabled"])) or reserved
        if reserved:
            number_text, name_text, price_text = "", self.t("reserved"), ""
        else:
            number_text, name_text, price_text = self._bouquet_card_parts(it, empty_label=self.t("empty"))
        btn = base.BouquetButton(number_text=number_text, title_text=name_text, price_text=price_text, number_font_size="26sp", title_font_size=("25sp" if (reserved or not bool(it.get("enabled", True))) else "35sp"), title_max_lines=(1 if (reserved or not bool(it.get("enabled", True))) else 2), price_font_size="26sp", status_text="", status_font_size="15sp")
        is_pending = (item_id in self._admin_door_pending_ids)
        was_success = (item_id in self._admin_door_success_ids)
        if reserved and not is_pending and not was_success:
            self._apply_reserved_button_visual(btn, item_id=item_id, allow_click=True)
        else:
            self._apply_bouquet_button_palette(btn, is_empty=is_empty, is_pending=is_pending, was_success=was_success)
            self._style_available_button_number(btn, enabled=(bool(it.get("enabled", True)) and not reserved), reserved=reserved)
            btn.refresh_bg()
        if worker_mode:
            btn.bind(on_release=lambda _btn, iid=item_id: self.admin_worker_reopen_door(iid))
        else:
            btn.bind(on_release=lambda _btn, iid=item_id: self.goto_admin_edit(iid))
        self._add_bouquet_button_to_grid(btn, idx, left, right)
    try:
        self._refresh_module_info_labels()
    except Exception:
        pass

PanelBackendReservationApp._apply_reserved_button_visual = _apply_reserved_button_visual
PanelBackendReservationApp._decorate_reserved_button = _apply_reserved_button_visual
PanelBackendReservationApp._finalize_reserved_button_visual = _apply_reserved_button_visual
PanelBackendReservationApp.refresh_selection_grid = _refresh_selection_grid_reserved_final
PanelBackendReservationApp.refresh_check_price_grid = _refresh_check_price_grid_reserved_final
PanelBackendReservationApp.refresh_admin_grid = _refresh_admin_grid_reserved_final


# ============================================================
# FINAL R1/R2/R3 UI + FAST PANEL SWITCH PATCH
# ============================================================

_standard_selection_refresh = PanelBackendReservationApp.refresh_selection_grid


def _refresh_selection_grid_r_aware(self):
    """
    R1/R2/R3 use the dedicated layout implemented by Panel.py:
      - four upper positions
      - revolver selector buttons

    Standard A/B/C/D continue through the reservation-aware backend renderer.
    """
    try:
        panel_type = str(self.current_panel_type()).upper()
    except Exception:
        panel_type = ""

    if panel_type in ("R1", "R2", "R3"):
        return base.PanelApp.refresh_selection_grid(self)

    return _standard_selection_refresh(self)


def _switch_panel_view_r3_safe_fast(self, direction: int):
    positions = self.available_panel_positions()

    current = int(
        getattr(
            self,
            "current_panel_position",
            getattr(base, "PANEL_POSITION", 0),
        )
    )

    try:
        idx = positions.index(current)
    except ValueError:
        idx = 0

    nxt = idx + (1 if direction > 0 else -1)

    if not (0 <= nxt < len(positions)):
        return

    current_screen = str(
        getattr(getattr(self, "root", None), "current", "") or ""
    )

    # IMPORTANT:
    # Remove old widgets BEFORE changing rows/cols.
    #
    # Otherwise changing e.g. a D grid to R3's 2-row grid while the
    # D buttons still exist causes:
    # GridLayoutException: Too many children in GridLayout.
    try:
        if current_screen == "selection":
            scr = self.root.get_screen("selection")
            scr.ids.items_grid_left.clear_widgets()
            scr.ids.items_grid_right.clear_widgets()

        elif current_screen == "price_check":
            scr = self.root.get_screen("price_check")
            scr.ids.check_grid_left.clear_widgets()
            scr.ids.check_grid_right.clear_widgets()

        elif current_screen == "admin_panel":
            scr = self.root.get_screen("admin_panel")
            scr.ids.admin_grid_left.clear_widgets()
            scr.ids.admin_grid_right.clear_widgets()
    except Exception as exc:
        print(f"[PANEL SWITCH] pre-clear warning: {exc}")

    # Now it is safe to change the grid dimensions.
    self.current_panel_position = int(positions[nxt])
    self._sync_current_panel_layout()
    self._refresh_panel_nav_buttons()

    # Rebuild only the screen the user is actually looking at.
    if current_screen == "selection":
        self.refresh_selection_grid()

    elif current_screen == "price_check":
        self.refresh_check_price_grid()

    elif current_screen == "admin_panel":
        self.refresh_admin_grid()


PanelBackendReservationApp.refresh_selection_grid = _refresh_selection_grid_r_aware
PanelBackendReservationApp.switch_panel_view = _switch_panel_view_r3_safe_fast



# ============================================================
# FINAL R-MODULE ISOLATION / UI TEST SAFETY PATCH
# ============================================================

# Keep the R overview geometry completely out of normal modules.
_PRE_R_ISOLATED_SELECTION_REFRESH = (
    PanelBackendReservationApp.refresh_selection_grid
)


def _refresh_selection_grid_r_isolated(self):
    try:
        panel_type = str(self.current_panel_type()).upper()
    except Exception:
        panel_type = ""

    # When leaving R1/R2/R3, remove the selector circles and restore
    # the normal selection-screen height BEFORE the standard renderer.
    if panel_type not in ("R1", "R2", "R3"):
        try:
            self._refresh_revolver_buttons()
        except Exception as exc:
            print(f"[R UI] normal-layout restore warning: {exc}")

    result = _PRE_R_ISOLATED_SELECTION_REFRESH(self)

    # Run it again afterwards because several backend decorators modify
    # selection widgets after the base renderer.
    if panel_type not in ("R1", "R2", "R3"):
        try:
            self._refresh_revolver_buttons()
        except Exception:
            pass

    return result


PanelBackendReservationApp.refresh_selection_grid = (
    _refresh_selection_grid_r_isolated
)


# ------------------------------------------------------------
# ADMIN:
# Position 99 is only a synthetic R3 UI test.
# Never try to render 21 synthetic R items in the ordinary
# admin two-column grid.
# ------------------------------------------------------------

_PRE_R_SAFE_GOTO_ADMIN_PANEL = (
    PanelBackendReservationApp.goto_admin_panel
)


def _goto_admin_panel_r_safe(self):
    try:
        current = int(
            getattr(
                self,
                "current_panel_position",
                getattr(base, "PANEL_POSITION", 0),
            )
        )

        ui_test_enabled = bool(
            getattr(base, "UI_TEST_R3_ENABLED", False)
        )
        ui_test_position = int(
            getattr(base, "UI_TEST_R3_POSITION", 99)
        )

        if ui_test_enabled and current == ui_test_position:

            # Clear existing widgets while the OLD dimensions are
            # still valid, before switching grid dimensions.
            try:
                adm = self.root.get_screen("admin_panel")
                adm.ids.admin_grid_left.clear_widgets()
                adm.ids.admin_grid_right.clear_widgets()
            except Exception:
                pass

            # Admin goes back to the real/local module.
            self.current_panel_position = int(
                getattr(base, "PANEL_POSITION", 0)
            )

            try:
                self._sync_current_panel_layout()
            except Exception:
                pass

            # Temporary wheel state must not carry into admin.
            try:
                self.current_revolver = None
                self.current_revolver_panel_position = None
            except Exception:
                pass

    except Exception as exc:
        print(f"[ADMIN] R3 test reset warning: {exc}")

    return _PRE_R_SAFE_GOTO_ADMIN_PANEL(self)


PanelBackendReservationApp.goto_admin_panel = (
    _goto_admin_panel_r_safe
)


# ------------------------------------------------------------
# UI-ONLY R3 SAFETY
#
# Position 99 is not hardware.
# Never send its IDs 1..21 to payment / relay code.
# ------------------------------------------------------------

def _is_ui_test_r3_position(position):
    try:
        return (
            bool(getattr(base, "UI_TEST_R3_ENABLED", False))
            and int(position)
                == int(getattr(base, "UI_TEST_R3_POSITION", 99))
        )
    except Exception:
        return False


_PRE_UI_TEST_CHECKOUT_DETAIL = (
    PanelBackendReservationApp.checkout_from_detail
)


def _checkout_from_detail_ui_test_guard(self):
    position = getattr(
        self,
        "current_item_position",
        getattr(self, "current_panel_position", 0),
    )

    if _is_ui_test_r3_position(position):
        print(
            "[UI TEST R3] Checkout blocked: synthetic module has "
            "no physical payment/relay mapping."
        )

        try:
            scr = self.root.get_screen("item_detail")
            scr.ids.item_note.text = (
                "UI test module - payment and relay disabled"
            )
        except Exception:
            pass

        return

    return _PRE_UI_TEST_CHECKOUT_DETAIL(self)


PanelBackendReservationApp.checkout_from_detail = (
    _checkout_from_detail_ui_test_guard
)


_PRE_UI_TEST_CART_CHECKOUT = (
    PanelBackendReservationApp.start_cart_checkout
)


def _start_cart_checkout_ui_test_guard(self):
    try:
        has_test_item = any(
            _is_ui_test_r3_position(
                entry.get(
                    "panel_position",
                    getattr(base, "PANEL_POSITION", 0),
                )
            )
            for entry in (
                list(getattr(self, "cart_entries", []) or [])
            )
        )

        if has_test_item:
            print(
                "[UI TEST R3] Cart checkout blocked: synthetic "
                "module has no physical payment/relay mapping."
            )

            try:
                self.refresh_cart_screen()
                cart = self.root.get_screen("cart")
                cart.ids.cart_checkout_btn.disabled = True
                cart.ids.cart_total.text = (
                    "UI TEST - payment / relay disabled"
                )
                self.root.current = "cart"
            except Exception:
                pass

            return

    except Exception as exc:
        print(f"[UI TEST R3] Checkout guard warning: {exc}")
        return

    return _PRE_UI_TEST_CART_CHECKOUT(self)


PanelBackendReservationApp.start_cart_checkout = (
    _start_cart_checkout_ui_test_guard
)



# ============================================================
# FINAL ADMIN R1/R2/R3 TOP-4 SAFETY PATCH
#
# Standard admin GridLayout has four cells for R modules.
# The customer R3 contains 21 positions, but Admin must not try
# to push all 21 into this 2x2 grid.
#
# For R1/R2/R3 the existing admin renderer is reused unchanged,
# but panel_visible_count is temporarily limited to 4.
# This preserves:
#   - existing admin styling
#   - reservations
#   - admin roles
#   - edit/reopen behaviour
#   - normal A/B/C/D behaviour
# ============================================================

_PRE_ADMIN_R_TOP4_REFRESH = (
    PanelBackendReservationApp.refresh_admin_grid
)


def _refresh_admin_grid_r_top4_safe(self):
    try:
        panel_type = str(self.current_panel_type()).upper()
    except Exception:
        panel_type = ""

    if panel_type not in ("R1", "R2", "R3"):
        return _PRE_ADMIN_R_TOP4_REFRESH(self)

    old_visible_count = int(
        getattr(self, "panel_visible_count", 4)
    )

    try:
        # R admin overview currently contains only the four
        # ordinary upper compartments.
        self.panel_visible_count = 4

        return _PRE_ADMIN_R_TOP4_REFRESH(self)

    finally:
        # Restore the true R1/R2/R3 visible count immediately.
        self.panel_visible_count = old_visible_count


PanelBackendReservationApp.refresh_admin_grid = (
    _refresh_admin_grid_r_top4_safe
)





# ============================================================
# FINAL ADMIN PRICE / STATUS KEYBOARD / COUNTRY TAX PATCH
# ============================================================


# ------------------------------------------------------------
# ADMIN PRICES:
# Keep price TEXT, remove only its rounded white badge.
# ------------------------------------------------------------

_PRE_ADMIN_PRICE_STYLE_REFRESH = (
    PanelBackendReservationApp.refresh_admin_grid
)


def _refresh_admin_grid_price_text_only(self):
    result = _PRE_ADMIN_PRICE_STYLE_REFRESH(self)

    try:
        scr = self.root.get_screen("admin_panel")

        for grid in (
            scr.ids.admin_grid_left,
            scr.ids.admin_grid_right,
        ):
            for btn in list(grid.children):
                if isinstance(btn, base.BouquetButton):
                    # Price remains exactly as rendered by Admin.
                    btn.show_price_badge = False

                    # Make bare price clearly visible.
                    btn.price_color_rgba = [
                        0.76, 0.96, 0.78, 1.0
                    ]

                    try:
                        btn.refresh_bg()
                    except Exception:
                        pass

    except Exception as exc:
        print(
            f"[ADMIN] price text-only styling warning: {exc}"
        )

    return result


PanelBackendReservationApp.refresh_admin_grid = (
    _refresh_admin_grid_price_text_only
)


# ------------------------------------------------------------
# STATUS SCREEN:
# force actual virtual-keyboard BUTTON text to white too.
# ------------------------------------------------------------

_PRE_STATUS_WHITE_KEYBOARD = (
    PanelBackendReservationApp.goto_admin_esp_status
)


def _goto_admin_esp_status_white_keyboard(self):
    result = _PRE_STATUS_WHITE_KEYBOARD(self)

    for delay in (0, 0.05, 0.15, 0.30):
        try:
            Clock.schedule_once(
                lambda _dt, app=self:
                    _backend_force_white_keyboard_widgets(app),
                delay,
            )
        except Exception:
            pass

    return result


PanelBackendReservationApp.goto_admin_esp_status = (
    _goto_admin_esp_status_white_keyboard
)


# ------------------------------------------------------------
# COUNTRY -> TAX OPTIONS
#
# Backend already stores SI / HR country_code.
#
# SI: 0 / 9.5 / 22
# HR: 0 / 5 / 25
# ------------------------------------------------------------

def _apply_country_tax_options(self, country_code):
    code = str(country_code or "SI").strip().upper()

    if code not in ("SI", "HR"):
        code = "SI"

    self.machine_country_code = code

    if code == "HR":
        self.admin_tax_option_1 = 0.0
        self.admin_tax_option_2 = 5.0
        self.admin_tax_option_3 = 25.0
    else:
        self.admin_tax_option_1 = 0.0
        self.admin_tax_option_2 = 9.5
        self.admin_tax_option_3 = 22.0

    print(
        "[COUNTRY/TAX] "
        f"country={self.machine_country_code}, "
        f"rates={self.admin_tax_option_1:g}/"
        f"{self.admin_tax_option_2:g}/"
        f"{self.admin_tax_option_3:g}"
    )

    try:
        self._refresh_admin_tax_buttons()
    except Exception:
        pass


PanelBackendReservationApp._apply_country_tax_options = (
    _apply_country_tax_options
)


# Read country_code from every backend config refresh.
_PRE_COUNTRY_BACKEND_APPLY_CONFIG = (
    PanelBackendReservationApp._backend_apply_config
)


def _backend_apply_config_country_tax(self, cfg):
    try:
        cfg = cfg or {}

        explicit_code = (
            cfg.get("country_code")
            or (cfg.get("panel") or {}).get("country_code")
        )

        code = (
            explicit_code
            or getattr(self, "machine_country_code", "SI")
        )

        self._apply_country_tax_options(code)

        if explicit_code:
            normalized = str(explicit_code).strip().upper()

            if normalized in ("SI", "HR"):
                self._backend_country_confirmed = True
                self._backend_confirmed_country = normalized

                print(
                    "[COUNTRY/TAX] backend confirmed country="
                    f"{normalized}"
                )

    except Exception as exc:
        print(f"[COUNTRY/TAX] config warning: {exc}")

    return _PRE_COUNTRY_BACKEND_APPLY_CONFIG(self, cfg)


PanelBackendReservationApp._backend_apply_config = (
    _backend_apply_config_country_tax
)


# ============================================================
# CHECKOUT COUNTRY SAFETY GATE
#
# Do not allow a payment to begin until the backend has
# explicitly confirmed whether this installation is SI or HR.
# This prevents the built-in SI default from being used before
# the real backend configuration arrives.
# ============================================================

_PRE_COUNTRY_SAFE_START_CART_CHECKOUT = (
    PanelBackendReservationApp.start_cart_checkout
)


def _start_cart_checkout_country_safe(self):

    confirmed = bool(
        getattr(
            self,
            "_backend_country_confirmed",
            False,
        )
    )

    confirmed_country = str(
        getattr(
            self,
            "_backend_confirmed_country",
            "",
        )
        or ""
    ).strip().upper()

    current_country = str(
        getattr(
            self,
            "machine_country_code",
            "",
        )
        or ""
    ).strip().upper()

    if (
        not confirmed
        or confirmed_country not in ("SI", "HR")
        or current_country != confirmed_country
    ):
        print(
            "[CHECKOUT] BLOCKED: backend country has not "
            "been safely confirmed. "
            f"confirmed={confirmed} "
            f"backend_country={confirmed_country!r} "
            f"current_country={current_country!r}"
        )

        try:
            self.backend_post_event_async(
                "checkout_blocked_country_unconfirmed",
                severity="warning",
                payload={
                    "confirmed": confirmed,
                    "backend_country": confirmed_country,
                    "current_country": current_country,
                },
            )
        except Exception:
            pass

        # Stay on cart. No invoice/payment is created.
        try:
            self.goto_cart()
        except Exception:
            pass

        return

    return _PRE_COUNTRY_SAFE_START_CART_CHECKOUT(self)


PanelBackendReservationApp.start_cart_checkout = (
    _start_cart_checkout_country_safe
)



# ============================================================
# FINAL ADMIN PRICE BADGE RESTORE + STRAY CARD CLEANUP
# ============================================================

_PRE_ADMIN_PRICE_BADGE_RESTORE = (
    PanelBackendReservationApp.refresh_admin_grid
)


def _refresh_admin_grid_price_badges_restored(self):
    result = _PRE_ADMIN_PRICE_BADGE_RESTORE(self)

    try:
        scr = self.root.get_screen("admin_panel")
        left = scr.ids.admin_grid_left
        right = scr.ids.admin_grid_right

        # Legitimate Admin cards:
        # keep the normal rounded white price badge.
        for grid in (left, right):
            for btn in list(grid.children):
                if not isinstance(btn, base.BouquetButton):
                    continue

                try:
                    btn.show_price_badge = True
                except Exception:
                    pass

                # Restore the normal price colour as well.
                try:
                    btn.price_color_rgba = [
                        0.50, 0.45, 0.39, 1.0
                    ]
                except Exception:
                    pass

                try:
                    btn.refresh_bg()
                    btn.canvas.ask_update()
                except Exception:
                    pass

        # Safety cleanup:
        # Any BouquetButton visible on Admin that is NOT actually
        # a child of one of the two Admin grids is an orphan and
        # must not render at (0,0) / bottom-left.
        def walk(widget):
            yield widget
            for child in list(
                getattr(widget, "children", []) or []
            ):
                yield from walk(child)

        for widget in walk(scr):
            if not isinstance(widget, base.BouquetButton):
                continue

            if widget.parent not in (left, right):
                try:
                    widget.opacity = 0
                    widget.disabled = True
                except Exception:
                    pass

    except Exception as exc:
        print(
            f"[ADMIN] price badge cleanup warning: {exc}"
        )

    return result


PanelBackendReservationApp.refresh_admin_grid = (
    _refresh_admin_grid_price_badges_restored
)



# ============================================================
# FINAL COUNTRY TAX + FISCAL ROUTER + CLEAN ADMIN R-PANEL PATCH
# ============================================================


# ============================================================
# COUNTRY-SPECIFIC TAX VALUES
#
# IMPORTANT:
# The button text itself is NOT fiscal data.
#
# Button
#   -> admin_tax_selected
#   -> saved item["tax_pct"]
#   -> fiscalisation uses item["tax_pct"]
# ============================================================

def _country_tax_options_final(self):
    code = str(
        getattr(self, "machine_country_code", "SI") or "SI"
    ).strip().upper()

    if code == "HR":
        return [0.0, 5.0, 25.0]

    return [0.0, 9.5, 22.0]


def _normalize_admin_tax_value_country(self, value):
    options = self._country_tax_options_final()

    try:
        value = float(value)
    except Exception:
        value = options[0]

    return min(
        options,
        key=lambda x: abs(float(x) - value)
    )


def _refresh_admin_tax_buttons_country(self):
    if not self.root:
        return

    try:
        scr = self.root.get_screen("admin_edit_item")
    except Exception:
        return

    options = self._country_tax_options_final()

    selected = float(
        self._normalize_admin_tax_value(
            getattr(
                self,
                "admin_tax_selected",
                options[0],
            )
        )
    )

    try:
        scr.ids.edit_tax.text = str(selected)
    except Exception:
        pass

    button_ids = (
        "edit_tax_0_btn",
        "edit_tax_9_5_btn",
        "edit_tax_22_btn",
    )

    for value, wid in zip(options, button_ids):

        try:
            btn = scr.ids[wid]
        except Exception:
            continue

        # Button DISPLAY follows country.
        btn.text = f"{value:g}%"

        btn.color = (1, 1, 1, 0.97)
        btn.disabled_rgba = [
            0.40, 0.40, 0.40, 0.35
        ]

        if abs(selected - value) < 0.01:
            btn.border_rgba = [
                0.63, 0.82, 0.66, 0.95
            ]
            btn.base_normal = [
                0.20, 0.33, 0.23, 0.84
            ]
            btn.base_hover = [
                0.24, 0.39, 0.27, 0.92
            ]
            btn.base_down = [
                0.17, 0.29, 0.20, 0.98
            ]
        else:
            btn.border_rgba = [
                0.70, 0.70, 0.70, 0.65
            ]
            btn.base_normal = [
                0.45, 0.45, 0.45, 0.58
            ]
            btn.base_hover = [
                0.48, 0.48, 0.48, 0.66
            ]
            btn.base_down = [
                0.40, 0.40, 0.40, 0.78
            ]

        try:
            btn.refresh_bg()
        except Exception:
            pass


PanelBackendReservationApp._country_tax_options_final = (
    _country_tax_options_final
)

PanelBackendReservationApp._normalize_admin_tax_value = (
    _normalize_admin_tax_value_country
)

PanelBackendReservationApp._refresh_admin_tax_buttons = (
    _refresh_admin_tax_buttons_country
)


# ============================================================
# FISCALISATION ROUTER
#
# Existing bp_sent.txt allowed=0 remains the MASTER switch.
#
# SI -> existing Fiscalisation.py
# HR -> hr/Fiscalisation_HR.py
# ============================================================

import importlib.util as _fiscal_importlib
from pathlib import Path as _FiscalPath
from datetime import datetime as _FiscalDatetime
import Fiscalisation as _fiscal_si


_SI_PROCESS_TRANSACTION = (
    _fiscal_si.process_transaction
)

_HR_FISCAL_MODULE = None

_HR_FISCAL_PATH = _FiscalPath(
    "/home/wa_stopshop_mb/WA/Main_program/Fis/hr/"
    "Fiscalisation_HR.py"
)

_HR_FISCAL_ENV = _FiscalPath(
    "/home/wa_stopshop_mb/WA/Main_program/Fis/hr/"
    "fiscalisation_hr.env"
)


def _load_hr_fiscal_env():
    """
    Load HR fiscalisation environment variables into this kiosk
    process without printing secrets.
    """
    if not _HR_FISCAL_ENV.exists():
        return

    for raw in _HR_FISCAL_ENV.read_text(
        encoding="utf-8"
    ).splitlines():

        line = raw.strip()

        if (
            not line
            or line.startswith("#")
            or "=" not in line
        ):
            continue

        key, value = line.split("=", 1)

        key = key.strip()
        value = value.strip().strip('"').strip("'")

        if key:
            # fiscalisation_hr.env is authoritative.
            # Values must be refreshed when the file changes;
            # setdefault() kept stale TEST/PRODUCTION settings
            # inside the long-running kiosk process.
            os.environ[key] = value


def _get_hr_fiscal_module():
    global _HR_FISCAL_MODULE

    # Reload the HR environment on EVERY fiscal call.
    # The Python module may stay cached, but its _load_config()
    # reads os.environ, so this keeps the current env file
    # authoritative without restarting between config changes.
    _load_hr_fiscal_env()

    if _HR_FISCAL_MODULE is not None:
        return _HR_FISCAL_MODULE

    if not _HR_FISCAL_PATH.exists():
        raise RuntimeError(
            "Croatian fiscalisation module not found: "
            + str(_HR_FISCAL_PATH)
        )

    _load_hr_fiscal_env()

    spec = _fiscal_importlib.spec_from_file_location(
        "wa_fiscalisation_hr",
        str(_HR_FISCAL_PATH),
    )

    if spec is None or spec.loader is None:
        raise RuntimeError(
            "Could not load Croatian fiscalisation module"
        )

    module = _fiscal_importlib.module_from_spec(spec)
    spec.loader.exec_module(module)

    if not callable(
        getattr(module, "fiscalize_invoice", None)
    ):
        raise RuntimeError(
            "Fiscalisation_HR.py has no "
            "fiscalize_invoice() function"
        )

    _HR_FISCAL_MODULE = module
    return module


def _validate_country_tax_items(country, items):
    country = str(country).upper()

    allowed_rates = (
        {0.0, 5.0, 25.0}
        if country == "HR"
        else {0.0, 9.5, 22.0}
    )

    normalized_rates = []

    for index, item in enumerate(items or [], 1):

        try:
            rate = float(
                item.get("tax_pct", 0.0)
            )
        except Exception:
            raise ValueError(
                f"Item {index} has invalid tax_pct"
            )

        match = next(
            (
                x for x in allowed_rates
                if abs(rate - x) < 0.01
            ),
            None,
        )

        if match is None:
            raise ValueError(
                f"{country} item {index} has "
                f"invalid VAT rate {rate:g}%"
            )

        normalized_rates.append(float(match))

    return normalized_rates


def _country_process_transaction(
    invoice_number,
    issue_datetime_iso,
    amount=None,
    *,
    tax_entries=None,
    items=None,
    allowed_override=None,
):
    """
    Country-aware fiscal entry point.

    IMPORTANT:
    bp_sent.txt allowed=0 disables BOTH fiscal systems.
    """

    # --------------------------------------------------------
    # Existing global safety switch
    # --------------------------------------------------------
    _bp_sent, allowed = _fiscal_si.read_state()

    if allowed_override is not None:
        allowed = (
            1 if int(allowed_override) != 0 else 0
        )

    if allowed == 0:
        return {
            "skipped": True,
            "reason": "allowed=0",
            "country_code": str(
                getattr(
                    App.get_running_app(),
                    "machine_country_code",
                    "SI",
                )
            ).upper(),
        }

    app = App.get_running_app()

    country = str(
        getattr(
            app,
            "machine_country_code",
            "SI",
        )
        or "SI"
    ).strip().upper()

    if country not in ("SI", "HR"):
        raise ValueError(
            f"Unsupported fiscal country: {country}"
        )

    item_list = list(items or [])

    # ========================================================
    # SLOVENIA
    # ========================================================
    if country == "SI":

        _validate_country_tax_items(
            "SI",
            item_list,
        )

        result = _SI_PROCESS_TRANSACTION(
            invoice_number=invoice_number,
            issue_datetime_iso=issue_datetime_iso,
            amount=amount,
            tax_entries=tax_entries,
            items=item_list or None,
        )

        if isinstance(result, dict):
            result["country_code"] = "SI"

        return result

    # ========================================================
    # CROATIA
    # ========================================================

    if not item_list:
        raise ValueError(
            "HR fiscalisation requires purchased items "
            "with price and tax_pct."
        )

    rates = _validate_country_tax_items(
        "HR",
        item_list,
    )

    distinct_rates = sorted(set(rates))

    total = round(
        sum(
            float(it.get("price", 0.0))
            for it in item_list
        ),
        2,
    )

    if total <= 0:
        raise ValueError(
            "HR fiscalisation total must be > 0"
        )

    hr = _get_hr_fiscal_module()

    try:
        issue_dt = _FiscalDatetime.fromisoformat(
            str(issue_datetime_iso)
        )
    except Exception:
        issue_dt = None

    hr_result = hr.fiscalize_invoice(
        items=item_list,
        payment_method="K",
        invoice_number=str(invoice_number),
        issue_dt=issue_dt,
    )

    return {
        "inv_ok": bool(
            isinstance(hr_result, dict)
            and hr_result.get("ok")
        ),
        "country_code": "HR",
        "hr": hr_result,
    }


# The existing backend _worker_send already calls
# base.process_transaction(items=...). Replace that one entry
# point instead of rewriting the working payment/backend flow.
base.process_transaction = (
    _country_process_transaction
)


# ============================================================
# CLEAN ADMIN RENDERER
#
# This REPLACES the chain of old Admin price wrappers.
# One renderer -> one button -> one price badge.
# ============================================================

def _clean_admin_revolver_controls(self):

    try:
        scr = self.root.get_screen("admin_panel")
        row = scr.ids.admin_revolver_row
        controls = scr.ids.admin_revolver_controls
    except Exception:
        return

    controls.clear_widgets()

    try:
        panel_type = str(
            self.current_panel_type()
        ).upper()
    except Exception:
        panel_type = ""

    if panel_type not in ("R1", "R2", "R3"):
        row.height = 0
        row.opacity = 0
        return

    defs = list(
        self.revolver_definitions()
    )

    if not defs:
        row.height = 0
        row.opacity = 0
        return

    row.height = dp(195)
    row.opacity = 1

    from kivy.uix.widget import Widget
    from kivy.uix.anchorlayout import AnchorLayout

    controls.add_widget(
        Widget(size_hint_x=1)
    )

    for definition in defs:

        holder = AnchorLayout(
            anchor_x="center",
            anchor_y="center",
            size_hint_x=None,
            width=dp(220),
        )

        title_key = definition.get(
            "title_key"
        )

        if title_key:
            title = self.t(title_key)
        else:
            title = str(
                definition.get(
                    "title",
                    definition.get("key", "Revolver"),
                )
            )

        btn = base.RevolverSelectorButton(
            text=title,
            size_hint=(None, None),
            size=(dp(185), dp(185)),
        )

        btn.bind(
            on_release=lambda _btn, d=dict(definition):
                self.open_admin_revolver(d)
        )

        holder.add_widget(btn)
        controls.add_widget(holder)

    controls.add_widget(
        Widget(size_hint_x=1)
    )


PanelBackendReservationApp._clean_admin_revolver_controls = (
    _clean_admin_revolver_controls
)


def _refresh_admin_grid_clean_final(self):

    ap = self.root.get_screen("admin_panel")

    left = ap.ids.admin_grid_left
    right = ap.ids.admin_grid_right

    # Completely discard the previous Admin cards first.
    left.clear_widgets()
    right.clear_widgets()

    try:
        panel_type = str(
            self.current_panel_type()
        ).upper()
    except Exception:
        panel_type = ""

    # --------------------------------------------------------
    # R1/R2/R3:
    # ordinary Admin grid contains upper compartments 1..4.
    # Revolvers are rendered in their own row underneath.
    # --------------------------------------------------------
    if panel_type in ("R1", "R2", "R3"):
        visible = list(
            self.r_panel_top_items()
        )
    else:
        visible = list(
            self.active_panel_items()
        )

    worker_mode = (
        self.current_admin_role
        == base.ADMIN_ROLE_WORKER
    )

    current_pos = int(
        getattr(
            self,
            "current_panel_position",
            getattr(base, "PANEL_POSITION", 0),
        )
    )

    for idx, it in enumerate(visible):

        item_id = int(it["id"])

        try:
            reserved = self._is_item_reserved(
                current_pos,
                item_id,
            )
        except Exception:
            reserved = False

        enabled = bool(
            it.get("enabled", True)
        )

        is_empty = (
            (not enabled)
            or reserved
        )

        if reserved:
            # Customer/admin-visible numbering for R3 side module.
            # Keep internal item_id unchanged at 1..21.
            try:
                _admin_visible_id = (
                    item_id + 7
                    if (
                        int(self.current_panel_position) == 1
                        and str(self.current_panel_type()).upper() == "R3"
                        and 1 <= item_id <= 21
                    )
                    else item_id
                )
            except Exception:
                _admin_visible_id = item_id

            number_text = f"#{_admin_visible_id}"
            name_text = self.t("reserved")
            price_text = ""
        else:
            (
                number_text,
                name_text,
                price_text,
            ) = self._bouquet_card_parts(
                it,
                empty_label=self.t("empty"),
            )

        btn = base.BouquetButton(
            number_text=number_text,
            title_text=name_text,
            price_text=price_text,
            number_font_size="26sp",
            title_font_size=(
                "25sp"
                if is_empty
                else "35sp"
            ),
            title_max_lines=(
                1 if is_empty else 2
            ),
            price_font_size="26sp",
            status_text="",
            status_font_size="15sp",
        )

        # Restore the NORMAL white rounded price badge.
        try:
            btn.show_price_badge = True
        except Exception:
            pass

        is_pending = (
            item_id
            in self._admin_door_pending_ids
        )

        was_success = (
            item_id
            in self._admin_door_success_ids
        )

        self._apply_bouquet_button_palette(
            btn,
            is_empty=is_empty,
            is_pending=is_pending,
            was_success=was_success,
        )

        if reserved:
            try:
                self._decorate_reserved_button(
                    btn,
                    item_id=item_id,
                    allow_click=True,
                )
            except Exception:
                pass

        try:
            btn.refresh_bg()
        except Exception:
            pass

        if worker_mode:
            btn.bind(
                on_release=lambda _btn, iid=item_id:
                    self.admin_worker_reopen_door(iid)
            )
        else:
            btn.bind(
                on_release=lambda _btn, iid=item_id:
                    self.goto_admin_edit(iid)
            )

        self._add_bouquet_button_to_grid(
            btn,
            idx,
            left,
            right,
        )

    # R selectors are separate from the item GridLayouts.
    self._clean_admin_revolver_controls()

    try:
        self._refresh_module_info_labels()
    except Exception:
        pass


# This final assignment bypasses all the older stacked
# refresh_admin_grid price wrappers.
PanelBackendReservationApp.refresh_admin_grid = (
    _refresh_admin_grid_clean_final
)


# ============================================================
# ADMIN REVOLVER SCREEN
# ============================================================

_PRE_CUSTOMER_OPEN_REVOLVER = (
    PanelBackendReservationApp.open_revolver
)

_PRE_CUSTOMER_REVOLVER_BACK = (
    PanelBackendReservationApp.goto_selection_from_revolver
)


def _open_revolver_customer_final(
    self,
    definition,
):
    self._admin_revolver_mode = False

    try:
        rev = self.root.get_screen("revolver")
        rev.ids.revolver_cart_btn.opacity = 1
        rev.ids.revolver_cart_btn.disabled = False
    except Exception:
        pass

    return _PRE_CUSTOMER_OPEN_REVOLVER(
        self,
        definition,
    )


PanelBackendReservationApp.open_revolver = (
    _open_revolver_customer_final
)


def _refresh_admin_revolver_screen(self):

    if not self.current_revolver:
        return

    if (
        getattr(
            self,
            "current_revolver_panel_position",
            None,
        )
        is not None
    ):
        self.current_panel_position = int(
            self.current_revolver_panel_position
        )

    scr = self.root.get_screen("revolver")
    wheel = scr.ids.revolver_grid
    wheel.clear_widgets()

    definition = self.current_revolver
    items = self._revolver_items(
        definition
    )

    title_key = definition.get("title_key")

    if title_key:
        scr.ids.revolver_title.text = self.t(
            title_key
        )
    else:
        scr.ids.revolver_title.text = str(
            definition.get(
                "title",
                definition.get("key", "Revolver"),
            )
        )

    # Cart has no meaning in Admin revolver mode.
    try:
        scr.ids.revolver_cart_btn.opacity = 0
        scr.ids.revolver_cart_btn.disabled = True
    except Exception:
        pass

    count = len(items)

    if count == 0:
        return

    import math

    if count <= 7:
        button_size = dp(138)
        radius_x = 0.30
        radius_y = 0.30
        font_size = "22sp"
    else:
        button_size = dp(120)
        radius_x = 0.34
        radius_y = 0.29
        font_size = "19sp"

    start_id = int(
        definition["start_id"]
    )

    start_angle = math.pi / 2.0

    for index, it in enumerate(items):

        item_id = int(it["id"])
        # R3 customer/admin-visible numbering.
        # Keep internal item IDs unchanged.
        try:
            if (
                int(self.current_panel_position) == 1
                and str(self.current_panel_type()).upper() == "R3"
                and 1 <= item_id <= 21
            ):
                slot_no = item_id + 7
            else:
                slot_no = item_id - start_id + 1
        except Exception:
            slot_no = item_id - start_id + 1

        enabled = bool(
            it.get("enabled", True)
        )

        if enabled:
            price = float(
                it.get("price", 0.0)
            )
            text = (
                f"{slot_no}\n"
                f"{price:.2f}€"
            )
        else:
            text = (
                f"{slot_no}\n"
                f"{self.t('empty')}"
            )

        angle = (
            start_angle
            - (
                2.0
                * math.pi
                * index
                / count
            )
        )

        cx = (
            0.5
            + radius_x
            * math.cos(angle)
        )

        cy = (
            0.5
            + radius_y
            * math.sin(angle)
        )

        btn = base.RevolverSlotButton(
            text=text,
            font_size=font_size,
            size_hint=(None, None),
            size=(
                button_size,
                button_size,
            ),
            pos_hint={
                "center_x": cx,
                "center_y": cy,
            },
        )

        # In Admin even empty slots must be editable/re-openable.
        btn.disabled = False

        btn.bind(
            on_release=lambda _btn, iid=item_id:
                self.goto_admin_edit(iid)
        )

        wheel.add_widget(btn)


PanelBackendReservationApp._refresh_admin_revolver_screen = (
    _refresh_admin_revolver_screen
)


def _open_admin_revolver(
    self,
    definition,
):
    self._cancel_timers()

    self._admin_revolver_mode = True

    self.current_revolver = dict(
        definition
    )

    self.current_revolver_panel_position = int(
        self.current_panel_position
    )

    self._refresh_admin_revolver_screen()

    self.root.current = "revolver"


PanelBackendReservationApp.open_admin_revolver = (
    _open_admin_revolver
)


def _goto_from_revolver_final(self):

    if bool(
        getattr(
            self,
            "_admin_revolver_mode",
            False,
        )
    ):

        if (
            getattr(
                self,
                "current_revolver_panel_position",
                None,
            )
            is not None
        ):
            self.current_panel_position = int(
                self.current_revolver_panel_position
            )

        self.current_revolver = None
        self.current_revolver_panel_position = None
        self._admin_revolver_mode = False

        try:
            rev = self.root.get_screen("revolver")
            rev.ids.revolver_cart_btn.opacity = 1
            rev.ids.revolver_cart_btn.disabled = False
        except Exception:
            pass

        self.refresh_admin_grid()
        self.root.current = "admin_panel"
        return

    return _PRE_CUSTOMER_REVOLVER_BACK(self)


PanelBackendReservationApp.goto_selection_from_revolver = (
    _goto_from_revolver_final
)



# ============================================================
# FINAL REVOLVER LIVE LANGUAGE + HEADER PATCH
#
# - language flags already exist in HeaderBar
# - refresh wheel immediately when language changes
# - customer and Admin revolvers both supported
# - populate normal top-right header
# ============================================================


def _refresh_revolver_context_ui(self):
    """
    Refresh everything that depends on language while the
    dedicated revolver screen is visible.
    """

    if not getattr(self, "root", None):
        return

    try:
        if self.root.current != "revolver":
            return
    except Exception:
        return

    try:
        scr = self.root.get_screen("revolver")
    except Exception:
        return

    admin_mode = bool(
        getattr(
            self,
            "_admin_revolver_mode",
            False,
        )
    )

    # --------------------------------------------------------
    # Rebuild the correct wheel using the newly selected
    # language.
    # --------------------------------------------------------
    try:
        if admin_mode:
            self._refresh_admin_revolver_screen()
        else:
            self.refresh_revolver_screen()
    except Exception as exc:
        print(
            "[REVOLVER] language refresh warning:",
            exc,
        )

    # --------------------------------------------------------
    # Bottom navigation text
    # --------------------------------------------------------
    try:
        scr.ids.revolver_back_btn.text = self.t("back")
    except Exception:
        pass

    try:
        scr.ids.revolver_home_btn.text = self.t("home")
    except Exception:
        pass

    try:
        scr.ids.revolver_cart_btn.text = self.t("cart")
    except Exception:
        pass

    # --------------------------------------------------------
    # Customer screen title:
    # always the translated equivalent of "Select a bouquet".
    #
    # Admin keeps its Revolver 7 / Revolver 10 title.
    # --------------------------------------------------------
    if not admin_mode:
        try:
            scr.ids.revolver_title.text = self.t(
                "select_bouquet"
            )
        except Exception:
            pass

    # --------------------------------------------------------
    # Top-right header:
    # use the visible page title + Cvetličarna Tulipan.
    # --------------------------------------------------------
    try:
        title = str(
            scr.ids.revolver_title.text or ""
        ).strip()

        self.header_right_title = title
        self.header_right_brand = (
            "Cvetličarna Jana"
            if title
            else ""
        )
    except Exception:
        pass

    try:
        scr.canvas.ask_update()
    except Exception:
        pass


PanelBackendReservationApp._refresh_revolver_context_ui = (
    _refresh_revolver_context_ui
)


# ============================================================
# LANGUAGE CHANGES
# ============================================================

_PRE_REVOLVER_APPLY_TRANSLATIONS = (
    PanelBackendReservationApp.apply_translations
)


def _apply_translations_revolver_live(self):
    _PRE_REVOLVER_APPLY_TRANSLATIONS(self)

    # apply_translations() handles all normal screens.
    # The dedicated wheel must be rebuilt because its slots are
    # generated dynamically rather than defined only in KV.
    try:
        self._refresh_revolver_context_ui()
    except Exception:
        pass


PanelBackendReservationApp.apply_translations = (
    _apply_translations_revolver_live
)


# ============================================================
# CUSTOMER REVOLVER OPEN
# ============================================================

_PRE_REVOLVER_OPEN_HEADER = (
    PanelBackendReservationApp.open_revolver
)


def _open_revolver_with_live_header(
    self,
    definition,
):
    result = _PRE_REVOLVER_OPEN_HEADER(
        self,
        definition,
    )

    # open_revolver() changes root.current near the end, so run
    # the header update after the ScreenManager has switched.
    for delay in (0, 0.05):
        try:
            Clock.schedule_once(
                lambda _dt, app=self:
                    app._refresh_revolver_context_ui(),
                delay,
            )
        except Exception:
            pass

    return result


PanelBackendReservationApp.open_revolver = (
    _open_revolver_with_live_header
)


# ============================================================
# ADMIN REVOLVER OPEN
# ============================================================

if hasattr(
    PanelBackendReservationApp,
    "open_admin_revolver",
):
    _PRE_ADMIN_REVOLVER_OPEN_HEADER = (
        PanelBackendReservationApp.open_admin_revolver
    )

    def _open_admin_revolver_with_live_header(
        self,
        definition,
    ):
        result = _PRE_ADMIN_REVOLVER_OPEN_HEADER(
            self,
            definition,
        )

        for delay in (0, 0.05):
            try:
                Clock.schedule_once(
                    lambda _dt, app=self:
                        app._refresh_revolver_context_ui(),
                    delay,
                )
            except Exception:
                pass

        return result

    PanelBackendReservationApp.open_admin_revolver = (
        _open_admin_revolver_with_live_header
    )



# ============================================================
# FINAL REVOLVER HEADER PERSISTENCE + WHITE TITLE
# + ADMIN ORPHAN PRICE CLEANUP
# ============================================================


# ------------------------------------------------------------
# 1. Make revolver a first-class header screen.
#
# This prevents _refresh_header_right_info() from clearing the
# top-right text when another refresh occurs after we return
# to the revolver screen.
# ------------------------------------------------------------

_PRE_SCREEN_HEADER_TITLE_REV_FINAL = (
    PanelBackendReservationApp._screen_header_title
)


def _screen_header_title_revolver_final(
    self,
    screen_name=None,
):
    current = str(
        screen_name
        or getattr(
            getattr(self, "root", None),
            "current",
            "",
        )
        or ""
    )

    if current == "revolver":
        try:
            scr = self.root.get_screen("revolver")
            title = str(
                scr.ids.revolver_title.text or ""
            ).strip()

            if title:
                return title
        except Exception:
            pass

        if bool(
            getattr(
                self,
                "_admin_revolver_mode",
                False,
            )
        ):
            return "Revolver"

        return self.t("select_bouquet")

    return _PRE_SCREEN_HEADER_TITLE_REV_FINAL(
        self,
        screen_name,
    )


PanelBackendReservationApp._screen_header_title = (
    _screen_header_title_revolver_final
)


# ------------------------------------------------------------
# 2. Final visual refresh for customer AND Admin revolvers.
# ------------------------------------------------------------

_PRE_REVOLVER_CONTEXT_UI_FINAL = (
    PanelBackendReservationApp._refresh_revolver_context_ui
)


def _refresh_revolver_context_ui_final(self):

    _PRE_REVOLVER_CONTEXT_UI_FINAL(self)

    if not getattr(self, "root", None):
        return

    if str(self.root.current) != "revolver":
        return

    try:
        scr = self.root.get_screen("revolver")
    except Exception:
        return

    # Main text above wheel must always be white.
    try:
        scr.ids.revolver_title.color = (
            1, 1, 1, 0.98
        )
    except Exception:
        pass

    # Re-establish top-right title/brand after any screen,
    # language, item-edit or backend refresh.
    try:
        title = str(
            scr.ids.revolver_title.text or ""
        ).strip()

        self.header_right_title = title
        self.header_right_brand = (
            "Cvetličarna Jana"
            if title
            else ""
        )
    except Exception:
        pass

    try:
        scr.canvas.ask_update()
    except Exception:
        pass


PanelBackendReservationApp._refresh_revolver_context_ui = (
    _refresh_revolver_context_ui_final
)


# ------------------------------------------------------------
# 3. Whenever ScreenManager enters "revolver", restore its
#    dynamic language/header state.
#
# This fixes:
# item -> Back -> revolver
# Admin item -> Back -> revolver
# and other return paths.
# ------------------------------------------------------------

_PRE_BUILD_REVOLVER_ENTRY_FINAL = (
    PanelBackendReservationApp.build
)


def _build_revolver_entry_final(self):

    root = _PRE_BUILD_REVOLVER_ENTRY_FINAL(self)

    if not getattr(
        self,
        "_revolver_entry_binding_done",
        False,
    ):

        def _screen_changed(_sm, screen_name):

            if str(screen_name) != "revolver":
                return

            for delay in (0, 0.03, 0.10):
                try:
                    Clock.schedule_once(
                        lambda _dt, app=self:
                            app._refresh_revolver_context_ui(),
                        delay,
                    )
                except Exception:
                    pass

        try:
            root.bind(current=_screen_changed)

            self._revolver_entry_binding_done = True
        except Exception:
            pass

    return root


PanelBackendReservationApp.build = (
    _build_revolver_entry_final
)


# ------------------------------------------------------------
# 4. ADMIN FLOATING PRICE CLEANUP
#
# Legitimate price labels must belong to a BouquetButton that
# itself belongs to admin_grid_left or admin_grid_right.
#
# Any € label outside such a card is the stray overlay.
# ------------------------------------------------------------

_PRE_ADMIN_FLOATING_PRICE_FINAL = (
    PanelBackendReservationApp.refresh_admin_grid
)


def _refresh_admin_grid_no_orphan_prices(self):

    result = _PRE_ADMIN_FLOATING_PRICE_FINAL(self)

    try:
        scr = self.root.get_screen("admin_panel")

        left = scr.ids.admin_grid_left
        right = scr.ids.admin_grid_right

        def walk(widget):
            yield widget

            for child in list(
                getattr(
                    widget,
                    "children",
                    [],
                )
                or []
            ):
                yield from walk(child)

        for widget in walk(scr):

            if not isinstance(widget, Label):
                continue

            text = str(
                getattr(
                    widget,
                    "text",
                    "",
                )
                or ""
            )

            if "€" not in text:
                continue

            # Find the BouquetButton owning this price.
            owner = None
            node = widget.parent

            while (
                node is not None
                and node is not scr
            ):

                if isinstance(
                    node,
                    base.BouquetButton,
                ):
                    owner = node
                    break

                node = getattr(
                    node,
                    "parent",
                    None,
                )

            legitimate = (
                owner is not None
                and owner.parent
                in (left, right)
            )

            if legitimate:
                continue

            print(
                "[ADMIN] removing orphan "
                f"price label: {text!r}"
            )

            # Remove the stray text.
            try:
                widget.text = ""
                widget.opacity = 0
            except Exception:
                pass

            # Also hide its small badge container so there is
            # no leftover rounded white background.
            try:
                parent = widget.parent

                if parent is not None:
                    h = float(
                        getattr(
                            parent,
                            "height",
                            0,
                        )
                        or 0
                    )

                    w = float(
                        getattr(
                            parent,
                            "width",
                            0,
                        )
                        or 0
                    )

                    if (
                        0 <= h <= 110
                        and 0 <= w <= 400
                    ):
                        parent.opacity = 0
            except Exception:
                pass

    except Exception as exc:
        print(
            "[ADMIN] orphan price cleanup warning:",
            exc,
        )

    return result


PanelBackendReservationApp.refresh_admin_grid = (
    _refresh_admin_grid_no_orphan_prices
)



# ============================================================
# FINAL CUSTOMER R OVERVIEW = ADMIN R OVERVIEW
# ============================================================

_PRE_CUSTOMER_R_ADMIN_STYLE_REFRESH = (
    PanelBackendReservationApp.refresh_selection_grid
)


def _refresh_selection_grid_customer_like_admin(self):

    result = _PRE_CUSTOMER_R_ADMIN_STYLE_REFRESH(self)

    try:
        panel_type = str(
            self.current_panel_type()
        ).upper()
    except Exception:
        panel_type = ""

    try:
        scr = self.root.get_screen("selection")

        row = scr.ids.revolver_button_row
        old_controls = scr.ids.selection_revolver_controls

    except Exception:
        return result

    # Remove the older selector buttons placed next to the arrows.
    try:
        old_controls.clear_widgets()
    except Exception:
        pass

    if panel_type not in ("R1", "R2", "R3"):

        # Normal modules keep no R selector row.
        try:
            row.clear_widgets()
            row.height = 0
            row.opacity = 0
        except Exception:
            pass

        return result

    # --------------------------------------------------------
    # Rebuild customer selector row exactly like Admin.
    # --------------------------------------------------------
    row.clear_widgets()
    row.height = dp(195)
    row.opacity = 1
    row.spacing = dp(18)

    from kivy.uix.widget import Widget
    from kivy.uix.anchorlayout import AnchorLayout

    defs = list(
        self.revolver_definitions()
    )

    row.add_widget(
        Widget(size_hint_x=1)
    )

    for definition in defs:

        holder = AnchorLayout(
            anchor_x="center",
            anchor_y="center",
            size_hint_x=None,
            width=dp(220),
        )

        title_key = definition.get(
            "title_key"
        )

        if title_key:
            title = self.t(title_key)
        else:
            title = str(
                definition.get(
                    "title",
                    definition.get(
                        "key",
                        "Revolver",
                    ),
                )
            )

        btn = base.RevolverSelectorButton(
            text=title,
            size_hint=(None, None),
            size=(dp(185), dp(185)),
        )

        btn.bind(
            on_release=lambda _btn, d=dict(definition):
                self.open_revolver(d)
        )

        holder.add_widget(btn)
        row.add_widget(holder)

    row.add_widget(
        Widget(size_hint_x=1)
    )

    return result


PanelBackendReservationApp.refresh_selection_grid = (
    _refresh_selection_grid_customer_like_admin
)



# ============================================================
# TEMP ADMIN FLOATING PRICE RUNTIME DIAGNOSTIC
# ============================================================

_PRE_ADMIN_PRICE_TREE_DIAG = (
    PanelBackendReservationApp.refresh_admin_grid
)


def _refresh_admin_grid_price_tree_diag(self):

    result = _PRE_ADMIN_PRICE_TREE_DIAG(self)

    def dump(_dt):

        try:
            scr = self.root.get_screen("admin_panel")
        except Exception:
            return

        print("")
        print("========== ADMIN EURO WIDGET DUMP ==========")

        def walk(widget, depth=0):

            try:
                text = str(
                    getattr(widget, "text", "")
                    or ""
                )
            except Exception:
                text = ""

            if "€" in text:

                chain = []
                node = widget

                for _ in range(8):
                    if node is None:
                        break

                    chain.append(
                        node.__class__.__name__
                    )

                    node = getattr(
                        node,
                        "parent",
                        None,
                    )

                try:
                    pos = tuple(widget.pos)
                except Exception:
                    pos = None

                try:
                    size = tuple(widget.size)
                except Exception:
                    size = None

                print(
                    "[EURO_WIDGET]",
                    "class=",
                    widget.__class__.__name__,
                    "text=",
                    repr(text),
                    "pos=",
                    pos,
                    "size=",
                    size,
                    "opacity=",
                    getattr(widget, "opacity", None),
                    "parents=",
                    " -> ".join(chain),
                )

            for child in list(
                getattr(widget, "children", [])
                or []
            ):
                walk(child, depth + 1)

        walk(scr)

        print("========== END EURO WIDGET DUMP ==========")
        print("")

    Clock.schedule_once(dump, 0.20)

    return result


PanelBackendReservationApp.refresh_admin_grid = (
    _refresh_admin_grid_price_tree_diag
)



# ============================================================
# TEMP ADMIN PRICE OWNER / GEOMETRY DIAGNOSTIC
# ============================================================

_PRE_ADMIN_PRICE_OWNER_DIAG = (
    PanelBackendReservationApp.refresh_admin_grid
)


def _refresh_admin_grid_price_owner_diag(self):

    result = _PRE_ADMIN_PRICE_OWNER_DIAG(self)

    def dump(_dt):

        try:
            scr = self.root.get_screen("admin_panel")
            left = scr.ids.admin_grid_left
            right = scr.ids.admin_grid_right
        except Exception:
            return

        print("")
        print("========== ADMIN PRICE OWNER DUMP ==========")

        for grid_name, grid in (
            ("LEFT", left),
            ("RIGHT", right),
        ):
            print(
                "[GRID]",
                grid_name,
                "pos=", tuple(grid.pos),
                "size=", tuple(grid.size),
                "rows=", getattr(grid, "rows", None),
                "cols=", getattr(grid, "cols", None),
            )

            # reversed() gives display/addition order more naturally.
            for index, btn in enumerate(
                reversed(list(grid.children)),
                1,
            ):

                if not isinstance(
                    btn,
                    base.BouquetButton,
                ):
                    continue

                prices = []

                def walk(widget):
                    for child in list(
                        getattr(widget, "children", [])
                        or []
                    ):
                        yield child
                        yield from walk(child)

                for w in walk(btn):
                    if isinstance(w, Label):
                        text = str(
                            getattr(w, "text", "")
                            or ""
                        )

                        if "€" in text:
                            prices.append({
                                "text": text,
                                "pos": tuple(w.pos),
                                "size": tuple(w.size),
                            })

                print(
                    "[CARD]",
                    grid_name,
                    f"index={index}",
                    "number=", repr(
                        getattr(
                            btn,
                            "number_text",
                            "",
                        )
                    ),
                    "title=", repr(
                        getattr(
                            btn,
                            "title_text",
                            "",
                        )
                    ),
                    "price=", repr(
                        getattr(
                            btn,
                            "price_text",
                            "",
                        )
                    ),
                    "btn_pos=", tuple(btn.pos),
                    "btn_size=", tuple(btn.size),
                    "prices=", prices,
                )

        print("========== END PRICE OWNER DUMP ==========")
        print("")

    Clock.schedule_once(dump, 0.25)

    return result


PanelBackendReservationApp.refresh_admin_grid = (
    _refresh_admin_grid_price_owner_diag
)



# ============================================================
# FINAL COUNTRY-AWARE DEFAULT HOME LANGUAGE
#
# SI -> Slovenian
# HR -> Croatian
# ============================================================


def _country_default_language(self):
    country = str(
        getattr(
            self,
            "machine_country_code",
            "SI",
        )
        or "SI"
    ).strip().upper()

    if country == "HR":
        return "hr"

    return "si"


PanelBackendReservationApp._country_default_language = (
    _country_default_language
)


def _go_to_country_home(self):
    """
    Reset kiosk to its country's default language and Home.
    """

    lang = self._country_default_language()

    self.lang = lang

    try:
        self.apply_translations()
    except Exception:
        pass

    try:
        self.clear_cart()
    except Exception:
        pass

    try:
        self.goto_menu()
    except Exception:
        if self.root:
            self.root.current = "menu"

    try:
        self._refresh_header_right_info()
    except Exception:
        pass

    print(
        f"[HOME] default country="
        f"{getattr(self, 'machine_country_code', 'SI')} "
        f"language={lang}"
    )


PanelBackendReservationApp._go_to_country_home = (
    _go_to_country_home
)


# ------------------------------------------------------------
# Inactivity timeout
# ------------------------------------------------------------

def _handle_inactivity_timeout_country(self, _dt):
    self._go_to_country_home()


PanelBackendReservationApp._handle_inactivity_timeout = (
    _handle_inactivity_timeout_country
)


# ------------------------------------------------------------
# Startup
#
# Backend country may arrive shortly after startup, therefore
# check it again after the initial backend config has had time
# to load.
# ------------------------------------------------------------

_PRE_COUNTRY_HOME_ON_START = (
    PanelBackendReservationApp.on_start
)


def _on_start_country_home(self):

    _PRE_COUNTRY_HOME_ON_START(self)

    def apply_country_home(_dt):
        try:
            self._go_to_country_home()
        except Exception as exc:
            print(
                "[HOME] country startup warning:",
                exc,
            )

    # Give backend config time to populate machine_country_code.
    Clock.schedule_once(
        apply_country_home,
        2.0,
    )


PanelBackendReservationApp.on_start = (
    _on_start_country_home
)



# ============================================================
# FINAL SAFE COUNTRY DEFAULT HOME V2
#
# - SI -> Slovenian
# - HR -> Croatian
# - no full goto_menu()/hidden-screen refresh during timeout
# - country is applied when backend config is actually known
# ============================================================


def _country_default_language_v2(self):

    country = str(
        getattr(
            self,
            "machine_country_code",
            "SI",
        )
        or "SI"
    ).strip().upper()

    return "hr" if country == "HR" else "si"


PanelBackendReservationApp._country_default_language = (
    _country_default_language_v2
)


def _safe_country_home_v2(self):
    """
    Minimal home reset that avoids rebuilding hidden R3 screens.
    """

    lang = self._country_default_language()

    # --------------------------------------------------------
    # Language
    # --------------------------------------------------------
    if getattr(self, "lang", None) != lang:
        self.lang = lang

        try:
            self.apply_translations()
        except Exception as exc:
            print(
                "[HOME] translation warning:",
                exc,
            )

    # --------------------------------------------------------
    # Cancel local purchase timers only.
    # --------------------------------------------------------
    try:
        self._cancel_timers()
    except Exception:
        pass

    # --------------------------------------------------------
    # Clear cart directly, without calling the full clear_cart()
    # renderer chain.
    # --------------------------------------------------------
    try:
        self.cart_entries = []
    except Exception:
        pass

    try:
        self.current_item_id = None
    except Exception:
        pass

    try:
        self.current_revolver = None
        self.current_revolver_panel_position = None
        self._admin_revolver_mode = False
    except Exception:
        pass

    try:
        self.update_cart_badge()
    except Exception:
        pass

    # --------------------------------------------------------
    # Clear Admin state if needed.
    # --------------------------------------------------------
    try:
        current = str(self.root.current or "")
    except Exception:
        current = ""

    if current in (
        "admin_login",
        "admin_panel",
        "admin_esp_status",
        "admin_edit_item",
    ):
        try:
            self._clear_admin_session()
        except Exception:
            pass

    # --------------------------------------------------------
    # Go directly to menu.
    # --------------------------------------------------------
    try:
        self.root.current = "menu"
    except Exception as exc:
        print(
            "[HOME] screen switch failed:",
            exc,
        )
        return

    # --------------------------------------------------------
    # Refresh only menu/header-related visuals.
    # --------------------------------------------------------
    try:
        self._refresh_header_right_info()
    except Exception:
        pass

    try:
        self._force_light_input_text()
    except Exception:
        pass

    try:
        Clock.schedule_once(
            self._refresh_all_hover_buttons,
            0,
        )
    except Exception:
        pass

    # Restart 120 s inactivity timer.
    try:
        self._reset_inactivity_timer()
    except Exception:
        pass

    print(
        "[HOME] safe default "
        f"country={getattr(self, 'machine_country_code', 'SI')} "
        f"language={lang}"
    )


PanelBackendReservationApp._go_to_country_home = (
    _safe_country_home_v2
)


# ============================================================
# INACTIVITY
# ============================================================

def _handle_inactivity_timeout_country_v2(
    self,
    _dt,
):
    self._go_to_country_home()


PanelBackendReservationApp._handle_inactivity_timeout = (
    _handle_inactivity_timeout_country_v2
)


# ============================================================
# BACKEND COUNTRY ARRIVAL
#
# Poll briefly after startup until backend country is available.
# Apply it once, rather than guessing at a fixed 2-second delay.
# ============================================================

def _apply_startup_country_when_ready(self, _dt):

    country = str(
        getattr(
            self,
            "machine_country_code",
            "",
        )
        or ""
    ).strip().upper()

    if country not in ("SI", "HR"):
        return True

    if getattr(
        self,
        "_startup_country_applied",
        False,
    ):
        return False

    self._startup_country_applied = True

    lang = (
        "hr"
        if country == "HR"
        else "si"
    )

    self.lang = lang

    try:
        self.apply_translations()
    except Exception as exc:
        print(
            "[HOME] startup translation warning:",
            exc,
        )

    # Keep whichever screen is currently active.
    # On normal startup this is menu.
    if (
        getattr(self, "root", None)
        and self.root.current == "menu"
    ):
        try:
            self._refresh_header_right_info()
        except Exception:
            pass

    print(
        f"[HOME] startup country={country} "
        f"language={lang}"
    )

    return False


_PRE_COUNTRY_SAFE_ON_START = (
    PanelBackendReservationApp.on_start
)


def _on_start_country_safe_v2(self):

    self._startup_country_applied = False

    _PRE_COUNTRY_SAFE_ON_START(self)

    # Check every 0.5 s until backend country has arrived.
    Clock.schedule_interval(
        self._apply_startup_country_when_ready,
        0.5,
    )


PanelBackendReservationApp._apply_startup_country_when_ready = (
    _apply_startup_country_when_ready
)

PanelBackendReservationApp.on_start = (
    _on_start_country_safe_v2
)



# ============================================================
# FINAL COUNTRY HOME V3
#
# Fixes:
# - Kivy inactivity callback crash
# - startup choosing default SI before backend country arrives
# ============================================================


def _country_default_language_v3(self):

    country = str(
        getattr(
            self,
            "machine_country_code",
            "SI",
        )
        or "SI"
    ).strip().upper()

    if country == "HR":
        return "hr"

    return "si"


PanelBackendReservationApp._country_default_language = (
    _country_default_language_v3
)


def _go_to_country_home_v3(self):

    lang = self._country_default_language()

    try:
        self.lang = lang
    except Exception:
        pass

    try:
        self.apply_translations()
    except Exception as exc:
        print(
            "[HOME] translation warning:",
            exc,
        )

    try:
        self._cancel_timers()
    except Exception:
        pass

    # Clear purchase state without broad hidden-screen rebuilds.
    try:
        self.cart_entries = []
    except Exception:
        pass

    try:
        self.current_item_id = None
    except Exception:
        pass

    try:
        self.current_revolver = None
        self.current_revolver_panel_position = None
        self._admin_revolver_mode = False
    except Exception:
        pass

    try:
        current = str(
            getattr(
                self.root,
                "current",
                "",
            )
            or ""
        )
    except Exception:
        current = ""

    if current in (
        "admin_login",
        "admin_panel",
        "admin_esp_status",
        "admin_edit_item",
    ):
        try:
            self._clear_admin_session()
        except Exception:
            pass

    try:
        self.root.current = "menu"
    except Exception as exc:
        print(
            "[HOME] menu switch warning:",
            exc,
        )
        return

    try:
        self.update_cart_badge()
    except Exception:
        pass

    try:
        self._refresh_header_right_info()
    except Exception:
        pass

    try:
        Clock.schedule_once(
            self._refresh_all_hover_buttons,
            0,
        )
    except Exception:
        pass

    print(
        "[HOME] country-home "
        f"country={getattr(self, 'machine_country_code', '?')} "
        f"language={lang}"
    )


PanelBackendReservationApp._go_to_country_home = (
    _go_to_country_home_v3
)


# ============================================================
# IMPORTANT:
# Name this function EXACTLY "_handle_inactivity_timeout".
#
# Kivy WeakMethod resolves callbacks by their function name.
# ============================================================

def _handle_inactivity_timeout(self, _dt):

    try:
        self._go_to_country_home()
    finally:
        # Re-arm timer only after successful timeout handling.
        try:
            self._reset_inactivity_timer()
        except Exception:
            pass


PanelBackendReservationApp._handle_inactivity_timeout = (
    _handle_inactivity_timeout
)


# ============================================================
# STARTUP COUNTRY
#
# machine_country_code initially defaults to SI.
# Therefore SI alone cannot be treated as proof that backend
# config has arrived.
#
# We wait until we observe HR, or until the backend has had a
# few seconds to respond before accepting SI.
# ============================================================

def _startup_country_watch_v3(self, _dt):

    elapsed = float(
        getattr(
            self,
            "_country_watch_elapsed",
            0.0,
        )
    ) + 0.5

    self._country_watch_elapsed = elapsed

    country = str(
        getattr(
            self,
            "machine_country_code",
            "",
        )
        or ""
    ).strip().upper()

    # HR can only have come from backend/config, so accept
    # immediately.
    if country == "HR":

        self.lang = "hr"

        try:
            self.apply_translations()
        except Exception as exc:
            print(
                "[HOME] HR startup translation warning:",
                exc,
            )

        try:
            if self.root.current == "menu":
                self._refresh_header_right_info()
        except Exception:
            pass

        print(
            "[HOME] backend country confirmed HR; "
            "language=hr"
        )

        self._startup_country_applied = True
        return False

    # SI is the built-in initial default. Give backend time to
    # replace it before accepting it as the real country.
    if elapsed >= 8.0 and country == "SI":

        self.lang = "si"

        try:
            self.apply_translations()
        except Exception:
            pass

        print(
            "[HOME] backend remained SI; language=si"
        )

        self._startup_country_applied = True
        return False

    return True


PanelBackendReservationApp._startup_country_watch_v3 = (
    _startup_country_watch_v3
)


_PRE_COUNTRY_V3_ON_START = (
    PanelBackendReservationApp.on_start
)


def _on_start_country_v3(self):

    self._country_watch_elapsed = 0.0
    self._startup_country_applied = False

    _PRE_COUNTRY_V3_ON_START(self)

    # The base on_start still initially paints SI.
    # This watcher changes it as soon as the actual HR backend
    # config arrives.
    Clock.schedule_interval(
        self._startup_country_watch_v3,
        0.5,
    )


PanelBackendReservationApp.on_start = (
    _on_start_country_v3
)



# ============================================================
# FINAL COUNTRY LANGUAGE V4
#
# HR -> Croatian on startup and inactivity return.
# SI -> Slovenian.
# ============================================================


def _country_language_v4(self):

    code = str(
        getattr(
            self,
            "machine_country_code",
            "SI",
        )
        or "SI"
    ).strip().upper()

    return "hr" if code == "HR" else "si"


PanelBackendReservationApp._country_language_v4 = (
    _country_language_v4
)


def _country_home_v4(self):

    lang = self._country_language_v4()

    self.lang = lang

    try:
        self.apply_translations()
    except Exception as exc:
        print(
            "[COUNTRY-LANG] translation warning:",
            exc,
        )

    try:
        self._cancel_timers()
    except Exception:
        pass

    try:
        self.cart_entries = []
        self.current_item_id = None
    except Exception:
        pass

    try:
        self._admin_revolver_mode = False
        self.current_revolver = None
        self.current_revolver_panel_position = None
    except Exception:
        pass

    try:
        self.root.current = "menu"
    except Exception as exc:
        print(
            "[COUNTRY-LANG] menu warning:",
            exc,
        )
        return

    try:
        self.update_cart_badge()
    except Exception:
        pass

    try:
        self._refresh_header_right_info()
    except Exception:
        pass

    try:
        Clock.schedule_once(
            self._refresh_all_hover_buttons,
            0,
        )
    except Exception:
        pass

    print(
        "[COUNTRY-LANG] home "
        f"country={getattr(self, 'machine_country_code', '?')} "
        f"language={lang}"
    )


PanelBackendReservationApp._country_home_v4 = (
    _country_home_v4
)


# Exact name required by Kivy WeakMethod.
def _handle_inactivity_timeout(self, _dt):

    try:
        self._country_home_v4()
    finally:
        try:
            self._reset_inactivity_timer()
        except Exception:
            pass


PanelBackendReservationApp._handle_inactivity_timeout = (
    _handle_inactivity_timeout
)


# ------------------------------------------------------------
# Startup country watcher.
#
# The base class initially assumes SI, so don't immediately
# accept SI. HR is accepted as soon as backend configuration
# changes machine_country_code to HR.
# ------------------------------------------------------------

def _country_startup_watch_v4(self, _dt):

    self._country_watch_v4_elapsed = (
        float(
            getattr(
                self,
                "_country_watch_v4_elapsed",
                0.0,
            )
        )
        + 0.5
    )

    country = str(
        getattr(
            self,
            "machine_country_code",
            "",
        )
        or ""
    ).strip().upper()

    if country == "HR":

        if self.lang != "hr":
            self.lang = "hr"

            try:
                self.apply_translations()
            except Exception as exc:
                print(
                    "[COUNTRY-LANG] HR startup warning:",
                    exc,
                )

        print(
            "[COUNTRY-LANG] backend confirmed HR; "
            "startup language=hr"
        )

        return False

    # SI is the base/default value. Wait long enough for backend
    # configuration before accepting it.
    if (
        country == "SI"
        and self._country_watch_v4_elapsed >= 10.0
    ):

        if self.lang != "si":
            self.lang = "si"

            try:
                self.apply_translations()
            except Exception:
                pass

        print(
            "[COUNTRY-LANG] backend/default SI; "
            "startup language=si"
        )

        return False

    return True


PanelBackendReservationApp._country_startup_watch_v4 = (
    _country_startup_watch_v4
)


_PRE_COUNTRY_V4_ON_START = (
    PanelBackendReservationApp.on_start
)


def _on_start_country_v4(self):

    self._country_watch_v4_elapsed = 0.0

    _PRE_COUNTRY_V4_ON_START(self)

    Clock.schedule_interval(
        self._country_startup_watch_v4,
        0.5,
    )


PanelBackendReservationApp.on_start = (
    _on_start_country_v4
)




# ============================================================
# FINAL SAFE ADMIN GRID CLEAR FOR PANEL GEOMETRY CHANGES
# ============================================================

_PRE_ADMIN_GRID_CAPACITY_SAFE = (
    PanelBackendReservationApp.refresh_admin_grid
)


def _refresh_admin_grid_capacity_safe(self):
    """
    Safely clear stale Admin widgets before the normal renderer runs.

    When switching between differently sized panels (for example a normal
    panel and R3), the GridLayout rows/cols may already reflect the new panel
    while children from the previous panel are still present.

    Kivy can otherwise raise:
        GridLayoutException: Too many children in GridLayout
    even while clear_widgets() is trying to remove those old children.
    """

    try:
        screen = self.root.get_screen("admin_panel")

        grids = (
            screen.ids.admin_grid_left,
            screen.ids.admin_grid_right,
        )

        for grid in grids:
            old_rows = getattr(grid, "rows", None)
            old_cols = getattr(grid, "cols", None)

            child_count = len(list(getattr(grid, "children", []) or []))

            if child_count:
                cols = int(old_cols or 1)
                rows = int(old_rows or 1)

                needed_rows = max(
                    1,
                    (child_count + cols - 1) // cols,
                )

                # Temporarily enlarge only when necessary.
                if rows * cols < child_count:
                    grid.rows = max(rows, needed_rows)

                grid.clear_widgets()

                # Restore the intended geometry after the stale widgets
                # are gone. Existing KV bindings remain intact.
                if old_rows is not None:
                    grid.rows = old_rows
                if old_cols is not None:
                    grid.cols = old_cols

    except Exception as exc:
        print(f"[ADMIN GRID SAFE CLEAR] warning: {exc}")

    return _PRE_ADMIN_GRID_CAPACITY_SAFE(self)


PanelBackendReservationApp.refresh_admin_grid = (
    _refresh_admin_grid_capacity_safe
)



# === WA LED STATUS + PAYMENT HEALTH V1 ===
import json as _wa_json
import socket as _wa_socket
import subprocess as _wa_subprocess
import threading as _wa_threading
import time as _wa_time

# Main controller = panel position 0
# R3 side panel   = panel position 1
_WA_LED_ENDPOINTS = {
    0: ("192.168.1.200", 48556),
    1: ("192.168.1.201", 48556),
}

_WA_LED_VALID_STATUS = {
    "available",
    "unavailable",
    "reserved",
    "wolt",
}

# Check item state twice per second.
# Only changed statuses are transmitted after the startup snapshot.
_WA_LED_POLL_SECONDS = 0.50

# Payment-terminal health check interval.
_WA_PAYMENT_HEALTH_SECONDS = 10.0


def _wa_normalize_status(value):
    s = str(value or "").strip().lower()

    aliases = {
        "empty": "unavailable",
        "disabled": "unavailable",
        "red": "unavailable",

        "full": "available",
        "enabled": "available",
        "normal": "available",
        "white": "available",
        "green": "available",

        "orange": "reserved",
        "blue": "wolt",
    }

    s = aliases.get(s, s)

    if s in _WA_LED_VALID_STATUS:
        return s

    return ""


def _wa_item_status(self, panel_position, item):
    item = dict(item or {})

    try:
        item_id = int(item.get("id", 0) or 0)
    except Exception:
        item_id = 0

    # If backend/app explicitly supplies a status, use it.
    for key in (
        "status",
        "availability",
        "availability_status",
        "state",
    ):
        status = _wa_normalize_status(item.get(key))

        if status:
            return status

    # Possible explicit Wolt flags.
    if (
        bool(item.get("wolt", False))
        or bool(item.get("is_wolt", False))
    ):
        return "wolt"

    # Reservation state is separate from the normal enabled flag.
    try:
        if (
            item_id > 0
            and bool(
                self._is_item_reserved(
                    int(panel_position),
                    item_id,
                )
            )
        ):
            return "reserved"
    except Exception:
        pass

    # Normal item state.
    return (
        "available"
        if bool(item.get("enabled", True))
        else "unavailable"
    )


def _wa_items_for_led_panel(self, panel_position):
    pos = int(panel_position)

    # Main local panel.
    if pos == int(getattr(base, "PANEL_POSITION", 0)):
        return list(getattr(self, "items", []) or [])

    # Remote R3 panel.
    panel = (
        (getattr(self, "remote_panels", {}) or {})
        .get(pos)
        or {}
    )

    return list(panel.get("items") or [])


def _wa_send_led_packet(ip, port, items):
    payload = {
        "type": "update",
        "items": items,
    }

    raw = _wa_json.dumps(
        payload,
        separators=(",", ":"),
    ).encode("utf-8")

    sock = _wa_socket.socket(
        _wa_socket.AF_INET,
        _wa_socket.SOCK_DGRAM,
    )

    try:
        sock.sendto(
            raw,
            (str(ip), int(port)),
        )
    finally:
        sock.close()


def _wa_sync_led_statuses(self, _dt=0, force=False):
    cache = getattr(
        self,
        "_wa_led_status_cache",
        None,
    )

    if cache is None:
        cache = {}
        self._wa_led_status_cache = cache

    for pos, endpoint in _WA_LED_ENDPOINTS.items():

        items = _wa_items_for_led_panel(
            self,
            pos,
        )

        if not items:
            continue

        current = {}
        full_snapshot = []

        for item in items:
            try:
                item_id = int(item.get("id"))
            except Exception:
                continue

            if item_id <= 0:
                continue

            status = self._wa_item_status(
                pos,
                item,
            )

            current[item_id] = status

            # IMPORTANT:
            # Always clear an old custom RGB override so the ESP
            # displays the canonical status colour.
            full_snapshot.append({
                "id": item_id,
                "status": status,
                "color": None,
            })

        if not full_snapshot:
            continue

        changed = bool(force)

        if not changed:
            for item_id, status in current.items():
                if cache.get(
                    (int(pos), int(item_id))
                ) != status:
                    changed = True
                    break

        # Also detect items removed from this panel.
        if not changed:
            cached_ids = {
                int(key[1])
                for key in cache.keys()
                if int(key[0]) == int(pos)
            }

            if cached_ids != set(current.keys()):
                changed = True

        if not changed:
            continue

        ip, port = endpoint

        try:
            _wa_send_led_packet(
                ip,
                port,
                full_snapshot,
            )

            # Only update cache after successful UDP send.
            for key in list(cache.keys()):
                if int(key[0]) == int(pos):
                    del cache[key]

            for item_id, status in current.items():
                cache[
                    (int(pos), int(item_id))
                ] = status

            print(
                f"[LED STATUS] FULL SYNC "
                f"panel={pos} "
                f"-> {ip}:{port} "
                f"items={len(full_snapshot)}"
            )

        except Exception as exc:
            print(
                f"[LED STATUS] FULL SYNC failed "
                f"panel={pos} "
                f"{ip}:{port}: {exc}"
            )


def _wa_ping_terminal():
    try:
        result = _wa_subprocess.run(
            [
                "ping",
                "-c", "1",
                "-W", "1",
                str(base.PAYMENT_TERMINAL_IP),
            ],
            stdout=_wa_subprocess.DEVNULL,
            stderr=_wa_subprocess.DEVNULL,
            timeout=3.0,
            check=False,
        )

        return result.returncode == 0

    except Exception:
        return False


def _wa_try_tim_status(service):
    """
    If the installed Python TIM wrapper exposes a safe
    terminal-status getter, use it.

    We deliberately do NOT open another TCP connection to
    port 7784 while TIM API owns the payment connection.
    """

    if service is None:
        return False, "service missing"

    api = getattr(
        service,
        "api",
        None,
    )

    if api is None:
        return False, "api missing"

    for name in (
        "get_terminal_status",
        "terminal_status",
        "get_status",
    ):

        fn = getattr(
            api,
            name,
            None,
        )

        if not callable(fn):
            continue

        try:
            lock = getattr(
                service,
                "_lock",
                None,
            )

            if lock is None:
                value = fn()
            else:
                with lock:
                    value = fn()

            return (
                True,
                f"{name}={value!r}",
            )

        except Exception as exc:
            return (
                False,
                f"{name} failed: {exc}",
            )

    return (
        None,
        "TIM status getter not exposed by wrapper",
    )


def _wa_payment_health_worker(self):
    last_state = None

    # Prevent reconnect loops.
    next_reconnect = 0.0

    while not bool(
        getattr(
            self,
            "_wa_payment_health_stop",
            False,
        )
    ):

        try:
            network_ok = _wa_ping_terminal()

            service = getattr(
                self,
                "payment_service",
                None,
            )

            started = bool(
                service is not None
                and getattr(
                    service,
                    "_started",
                    False,
                )
            )

            if started:
                api_ok, api_detail = (
                    _wa_try_tim_status(service)
                )
            else:
                api_ok = None
                api_detail = "session not started"

            state = (
                network_ok,
                started,
                api_ok,
                api_detail
                if api_ok is False
                else "",
            )

            if state != last_state:

                print(
                    "[PAYMENT HEALTH] "
                    f"network="
                    f"{'online' if network_ok else 'offline'} "
                    f"session="
                    f"{'started' if started else 'not-started'} "
                    f"tim_status={api_detail}"
                )

                last_state = state

            # Important:
            # We don't kill a working TIM session merely because
            # an ICMP ping was missed.
            #
            # But if the normal payment service already knows its
            # TIM session is down, reconnect while the machine is idle
            # rather than waiting for the customer to press Pay.

            now = _wa_time.monotonic()

            if (
                bool(
                    getattr(
                        base,
                        "PAYMENT_ENABLED",
                        True,
                    )
                )
                and network_ok
                and not started
                and now >= next_reconnect
            ):

                next_reconnect = now + 30.0

                print(
                    "[PAYMENT HEALTH] "
                    "terminal reachable; "
                    "starting background TIM reconnect"
                )

                try:
                    self._start_payment_terminal_async()

                except Exception as exc:
                    print(
                        "[PAYMENT HEALTH] "
                        f"reconnect start failed: {exc}"
                    )

        except Exception as exc:

            print(
                "[PAYMENT HEALTH] "
                f"monitor error: {exc}"
            )

        # Sleep in short increments so shutdown is fast.
        for _ in range(
            int(
                _WA_PAYMENT_HEALTH_SECONDS
                * 2
            )
        ):

            if bool(
                getattr(
                    self,
                    "_wa_payment_health_stop",
                    False,
                )
            ):
                return

            _wa_time.sleep(0.5)


PanelBackendReservationApp._wa_item_status = (
    _wa_item_status
)

PanelBackendReservationApp._wa_sync_led_statuses = (
    _wa_sync_led_statuses
)


_WA_OLD_ON_START_LED_HEALTH = (
    PanelBackendReservationApp.on_start
)

_WA_OLD_ON_STOP_LED_HEALTH = (
    PanelBackendReservationApp.on_stop
)


def _wa_on_start_led_health(self):

    result = _WA_OLD_ON_START_LED_HEALTH(
        self
    )

    self._wa_led_status_cache = {}
    self._wa_payment_health_stop = False

    # Send FULL current state after startup.
    Clock.schedule_once(
        lambda _dt:
            _wa_sync_led_statuses(
                self,
                force=True,
            ),
        2.0,
    )

    # Afterwards only send actual changes.
    Clock.schedule_interval(
        lambda _dt:
            _wa_sync_led_statuses(
                self,
                force=False,
            ),
        _WA_LED_POLL_SECONDS,
    )

    # Continuous payment-terminal health monitor.
    _wa_threading.Thread(
        target=_wa_payment_health_worker,
        args=(self,),
        daemon=True,
        name="payment-health",
    ).start()

    return result


def _wa_on_stop_led_health(self):

    self._wa_payment_health_stop = True

    return _WA_OLD_ON_STOP_LED_HEALTH(
        self
    )


PanelBackendReservationApp.on_start = (
    _wa_on_start_led_health
)

PanelBackendReservationApp.on_stop = (
    _wa_on_stop_led_health
)

# === END WA LED STATUS + PAYMENT HEALTH V1 ===



# === WA ADMIN OPEN + WOLT RESERVATION FINAL ===

import uuid as _wa_uuid
import socket as _wa_socket2
import json as _wa_json2
import threading as _wa_threading2


def _wa_matching_active_reservation(self, panel_position, item_id):
    try:
        panel_position = int(panel_position)
        item_id = int(item_id)
    except Exception:
        return None

    for row in list(
        getattr(self, "server_reservation_codes", [])
        or []
    ):
        try:
            if not self._reservation_blocks_item(row):
                continue

            if (
                int(row.get("panel_position", 0))
                == panel_position
                and int(row.get("item_id"))
                == item_id
            ):
                return row

        except Exception:
            continue

    return None


def _wa_reservation_is_wolt(row):
    row = dict(row or {})

    # Explicit boolean forms.
    for key in (
        "wolt",
        "is_wolt",
        "reserved_for_wolt",
    ):
        value = row.get(key)

        if value is True:
            return True

        if str(value or "").strip().lower() in (
            "1",
            "true",
            "yes",
            "on",
        ):
            return True

    # Text forms. This intentionally includes reserved_for,
    # because that is the important distinction requested here.
    for key in (
        "reserved_for",
        "reservation_type",
        "source",
        "order_source",
        "provider",
        "platform",
        "channel",
        "type",
    ):
        value = str(
            row.get(key, "")
            or ""
        ).strip().lower()

        if value == "wolt":
            return True

        if "wolt" in value:
            return True

    return False


def _wa_item_status_final(self, panel_position, item):
    item = dict(item or {})

    try:
        item_id = int(item.get("id", 0) or 0)
    except Exception:
        item_id = 0

    # Explicit Wolt item status has highest priority.
    for key in (
        "status",
        "availability",
        "availability_status",
        "state",
    ):
        value = str(
            item.get(key, "")
            or ""
        ).strip().lower()

        if value == "wolt":
            return "wolt"

    if (
        bool(item.get("wolt", False))
        or bool(item.get("is_wolt", False))
    ):
        return "wolt"

    # Reservations override normal available/unavailable LED display.
    reservation = _wa_matching_active_reservation(
        self,
        panel_position,
        item_id,
    )

    if reservation is not None:

        # Wolt reservation MUST be blue.
        if _wa_reservation_is_wolt(reservation):
            return "wolt"

        # Ordinary reservation is orange.
        return "reserved"

    # Other explicitly supplied statuses.
    aliases = {
        "available": "available",
        "full": "available",
        "enabled": "available",

        "unavailable": "unavailable",
        "empty": "unavailable",
        "disabled": "unavailable",

        "reserved": "reserved",
    }

    for key in (
        "status",
        "availability",
        "availability_status",
        "state",
    ):
        value = str(
            item.get(key, "")
            or ""
        ).strip().lower()

        if value in aliases:
            return aliases[value]

    return (
        "available"
        if bool(item.get("enabled", True))
        else "unavailable"
    )


PanelBackendReservationApp._wa_item_status = (
    _wa_item_status_final
)


def _wa_admin_open_physical_only(
    self,
    panel_position,
    item_ids,
):
    panel_position = int(panel_position)

    ids = []

    for raw in item_ids or []:
        try:
            iid = int(raw)
        except Exception:
            continue

        if iid > 0 and iid not in ids:
            ids.append(iid)

    if not ids:
        return []

    request_id = (
        "admin-"
        + _wa_uuid.uuid4().hex
    )

    # ========================================================
    # MAIN 7-ITEM CONTROLLER .200
    # ========================================================
    if panel_position == int(
        getattr(base, "PANEL_POSITION", 0)
    ):
        payload = {
            "type": "admin_open",
            "items": ids,
            "request_id": request_id,
        }

        sock = _wa_socket2.socket(
            _wa_socket2.AF_INET,
            _wa_socket2.SOCK_DGRAM,
        )

        try:
            sock.settimeout(5.0)

            sock.sendto(
                _wa_json2.dumps(
                    payload,
                    separators=(",", ":"),
                ).encode("utf-8"),
                ("192.168.1.200", 48556),
            )

            data, addr = sock.recvfrom(16384)

            ack = _wa_json2.loads(
                data.decode("utf-8")
            )

            print(
                "[ADMIN OPEN] .200 ACK:",
                ack,
            )

            return (
                ack.get("results")
                or [
                    {
                        "id": iid,
                        "ok": bool(ack.get("ok")),
                        "error": ack.get("error"),
                    }
                    for iid in ids
                ]
            )

        except Exception as exc:
            print(
                "[ADMIN OPEN] .200 failed:",
                exc,
            )

            return [
                {
                    "id": iid,
                    "ok": False,
                    "error": str(exc),
                }
                for iid in ids
            ]

        finally:
            try:
                sock.close()
            except Exception:
                pass

    # ========================================================
    # R3 CONTROLLER .201
    # ========================================================
    try:
        ack = self._send_remote_message_with_ack(
            panel_position,
            {
                "type": "remote_admin_open",
                "items": ids,
                "request_id": request_id,
            },
            timeout_s=30.0,
        )

        print(
            "[ADMIN OPEN] R3 ACK:",
            ack,
        )

        return (
            ack.get("results")
            or [
                {
                    "id": iid,
                    "ok": bool(ack.get("ok")),
                    "error": ack.get("error"),
                }
                for iid in ids
            ]
        )

    except Exception as exc:
        print(
            "[ADMIN OPEN] R3 failed:",
            exc,
        )

        return [
            {
                "id": iid,
                "ok": False,
                "error": str(exc),
            }
            for iid in ids
        ]


def _wa_admin_single_open_final(self):
    if not self.admin_has_full_privileges():
        try:
            scr = self.root.get_screen(
                "admin_edit_item"
            )
            scr.ids.edit_status.text = (
                self.t("access_denied")
            )
        except Exception:
            pass

        return

    item_id = int(
        self._admin_edit_item_id
    )

    panel_position = int(
        self._admin_edit_panel_position
    )

    try:
        scr = self.root.get_screen(
            "admin_edit_item"
        )

        scr.ids.edit_status.text = (
            self.t("door_opening_now")
        )
    except Exception:
        pass

    self._admin_set_pending_ids(
        [item_id]
    )

    def worker():
        results = (
            _wa_admin_open_physical_only(
                self,
                panel_position,
                [item_id],
            )
        )

        Clock.schedule_once(
            lambda _dt:
                _wa_admin_single_done_final(
                    self,
                    item_id,
                    panel_position,
                    results,
                ),
            0,
        )

    _wa_threading2.Thread(
        target=worker,
        daemon=True,
    ).start()


def _wa_admin_single_done_final(
    self,
    item_id,
    panel_position,
    results,
):
    success_ids, failed_ids = (
        self._admin_apply_door_feedback(
            results,
            panel_position=panel_position,
        )
    )

    # CRITICAL:
    # DO NOT MODIFY item["enabled"].
    # DO NOT MODIFY status.
    # DO NOT trigger LED synchronization manually.

    if int(item_id) in success_ids:
        print(
            f"[ADMIN OPEN] item={item_id} "
            "opened; inventory/status unchanged"
        )

        try:
            self.goto_admin_panel()
        except Exception:
            pass

        return

    try:
        scr = self.root.get_screen(
            "admin_edit_item"
        )

        scr.ids.edit_status.text = (
            self.t("door_open_failed")
        )
    except Exception:
        pass


def _wa_admin_open_all_final(self):
    if not self.admin_can_reopen_doors():
        self._refresh_admin_panel_title(
            self.t("access_denied")
        )
        return

    panel_position = int(
        self.current_panel_position
    )

    # Physical open only.
    # Opening all must NOT alter inventory.
    #
    # R3 has four fixed upper doors and two shared revolver doors.
    # For Admin -> Open all:
    #   1..4 = fixed upper doors
    #   5    = R7 home position / shared door
    #   12   = R10 home position / shared door
    #
    # Existing remote_admin_open handling will position the revolvers
    # before opening them, without changing inventory/status.
    try:
        panel_type = str(self.current_panel_type()).upper()
    except Exception:
        panel_type = ""

    if panel_type == "R3":
        target_ids = [1, 2, 3, 4, 5, 12]
        print(
            "[ADMIN OPEN] R3 open-all -> "
            "upper 1,2,3,4 + R7 home item 5 + R10 home item 12"
        )
    else:
        target_ids = [
            int(x["id"])
            for x in self.active_panel_items()
        ]

    if not target_ids:
        return

    self._admin_set_pending_ids(
        target_ids
    )

    self._refresh_admin_panel_title(
        self.t("door_opening_now")
    )

    def worker():
        results = (
            _wa_admin_open_physical_only(
                self,
                panel_position,
                target_ids,
            )
        )

        Clock.schedule_once(
            lambda _dt:
                _wa_admin_all_done_final(
                    self,
                    panel_position,
                    results,
                ),
            0,
        )

    _wa_threading2.Thread(
        target=worker,
        daemon=True,
    ).start()


def _wa_admin_all_done_final(
    self,
    panel_position,
    results,
):
    self._admin_apply_door_feedback(
        results,
        panel_position=panel_position,
    )

    # Again: physical door action only.
    # No inventory/status mutation.
    print(
        "[ADMIN OPEN] open-all completed; "
        "inventory/status unchanged"
    )

    try:
        self.refresh_admin_grid()
    except Exception:
        pass


# Override the inherited old Admin functions.
PanelBackendReservationApp.admin_reenable_current_from_edit = (
    _wa_admin_single_open_final
)

PanelBackendReservationApp._admin_reenable_current_done = (
    _wa_admin_single_done_final
)

PanelBackendReservationApp.admin_enable_all = (
    _wa_admin_open_all_final
)

PanelBackendReservationApp._admin_enable_all_done = (
    _wa_admin_all_done_final
)

PanelBackendReservationApp._admin_worker_reopen_done = (
    _wa_admin_all_done_final
)

# === END WA ADMIN OPEN + WOLT RESERVATION FINAL ===



# ============================================================
# FINAL R3 UI FIX
# - R10 LEFT / FIRST
# - R7 RIGHT / SECOND
# - customer upper 1..4 reservation visuals after final rebuild
# ============================================================

_PRE_FINAL_R3_SELECTION_REFRESH = (
    PanelBackendReservationApp.refresh_selection_grid
)


def _final_r3_revolver_definitions(self):
    """
    Physical mapping remains:
      R7  = items 5..11
      R10 = items 12..21

    Only visual order changes for R3:
      LEFT/FIRST  = R10
      RIGHT/SECOND = R7
    """

    try:
        panel_type = str(
            self.current_panel_type()
        ).upper()
    except Exception:
        panel_type = ""

    if panel_type == "R3":
        return [
            {
                "key": "R10",
                "title_key": "revolver_10",
                "start_id": 12,
                "end_id": 21,
            },
            {
                "key": "R7",
                "title_key": "revolver_7",
                "start_id": 5,
                "end_id": 11,
            },
        ]

    # Preserve normal R1 / R2 behavior from Panel.py.
    return base.PanelApp.revolver_definitions(self)


PanelBackendReservationApp.revolver_definitions = (
    _final_r3_revolver_definitions
)


def _final_r3_customer_reserved_pass(self, _dt=0):
    try:
        if str(self.current_panel_type()).upper() != "R3":
            return

        position = int(self.current_panel_position)

        # Exactly the four fixed upper compartments.
        items = list(self.r_panel_top_items() or [])
        items = sorted(
            items,
            key=lambda x: int(x.get("id", 0)),
        )[:4]

        scr = self.root.get_screen("selection")

        left = scr.ids.items_grid_left
        right = scr.ids.items_grid_right

        # Only actual bouquet cards, never fillers/layout widgets.
        left_buttons = [
            w for w in reversed(left.children)
            if isinstance(w, base.BouquetButton)
        ]

        right_buttons = [
            w for w in reversed(right.children)
            if isinstance(w, base.BouquetButton)
        ]

        buttons = left_buttons + right_buttons

        print(
            "[R3 CUSTOMER] "
            f"position={position} "
            f"items={[int(x.get('id')) for x in items]} "
            f"buttons={len(buttons)}"
        )

        for idx, item in enumerate(items):

            if idx >= len(buttons):
                print(
                    "[R3 CUSTOMER] "
                    f"missing button for index={idx}"
                )
                continue

            item_id = int(item["id"])
            btn = buttons[idx]

            reserved = False

            try:
                reserved = bool(
                    self._is_item_reserved(
                        position,
                        item_id,
                    )
                )
            except Exception as exc:
                print(
                    f"[R3 CUSTOMER] reservation check "
                    f"item={item_id} error={exc}"
                )

            if reserved:
                self._apply_reserved_button_visual(
                    btn,
                    item_id=item_id,
                    allow_click=False,
                )

                print(
                    "[R3 CUSTOMER RESERVED] "
                    f"panel={position} item={item_id}"
                )

        # Also force the revolver row to rebuild using R10,R7.
        try:
            self._refresh_revolver_buttons()
        except Exception as exc:
            print(
                "[R3 ORDER] refresh failed:",
                exc,
            )

        try:
            print(
                "[R3 ORDER FINAL]",
                [
                    x.get("key")
                    for x in self.revolver_definitions()
                ],
            )
        except Exception:
            pass

    except Exception as exc:
        print(
            "[R3 CUSTOMER] final pass failed:",
            exc,
        )


def _final_r3_selection_refresh(self):

    result = _PRE_FINAL_R3_SELECTION_REFRESH(self)

    try:
        if str(self.current_panel_type()).upper() == "R3":

            # Run after all existing customer/admin-style layout
            # rebuilding and delayed styling has finished.
            Clock.schedule_once(
                lambda dt: _final_r3_customer_reserved_pass(
                    self,
                    dt,
                ),
                0,
            )

            Clock.schedule_once(
                lambda dt: _final_r3_customer_reserved_pass(
                    self,
                    dt,
                ),
                0.15,
            )

            Clock.schedule_once(
                lambda dt: _final_r3_customer_reserved_pass(
                    self,
                    dt,
                ),
                0.40,
            )

    except Exception as exc:
        print(
            "[R3 CUSTOMER] scheduling failed:",
            exc,
        )

    return result


PanelBackendReservationApp.refresh_selection_grid = (
    _final_r3_selection_refresh
)



# ============================================================
# REMOTE SIDE PANEL BACKEND REGISTRATION
# ============================================================

_REMOTE_BACKEND_CLIENTS = {}


def _remote_backend_panel_id(position: int, panel_type: str) -> str:
    """
    Main panel Testing:
        Testing

    R3 at position 1:
        Testing-R3

    Other future modules:
        Testing-R1
        Testing-R2
        Testing-B-2
        etc.
    """
    position = int(position)
    panel_type = str(panel_type or "A").upper()

    if panel_type in ("R1", "R2", "R3"):
        suffix = panel_type
    else:
        suffix = f"{panel_type}-{position}"

    return f"{BACKEND_PANEL_ID}-{suffix}"


def _remote_backend_panel_name(position: int, panel_type: str) -> str:
    panel_type = str(panel_type or "A").upper()

    if panel_type == "R3":
        return "R3 Side Module"

    if panel_type == "R2":
        return "R2 Side Module"

    if panel_type == "R1":
        return "R1 Side Module"

    return f"Side Module {position}"


def _get_remote_backend_client(self, position: int):
    position = int(position)

    panel = getattr(self, "remote_panels", {}).get(position)

    if not panel:
        return None

    panel_type = str(
        panel.get("panel_type", "A")
    ).upper()

    key = (position, panel_type)

    client = _REMOTE_BACKEND_CLIENTS.get(key)

    if client is not None:
        return client

    panel_id = _remote_backend_panel_id(
        position,
        panel_type,
    )

    panel_name = _remote_backend_panel_name(
        position,
        panel_type,
    )

    client = PanelBackendClient(
        base_url=BACKEND_BASE_URL,
        panel_id=panel_id,
        panel_name=panel_name,
        panel_type=panel_type,
        position=position,
        software_version=BACKEND_SOFTWARE_VERSION,
        panel_key=BACKEND_PANEL_KEY,
    )

    _REMOTE_BACKEND_CLIENTS[key] = client

    return client


def _register_remote_panel_backend(self, position: int):
    position = int(position)

    panel = getattr(self, "remote_panels", {}).get(position)

    if not panel:
        print(
            f"[REMOTE BACKEND] position={position} missing"
        )
        return False

    panel_type = str(
        panel.get("panel_type", "A")
    ).upper()

    client = _get_remote_backend_client(
        self,
        position,
    )

    if client is None:
        return False

    payload = {
        "panel_id": client.panel_id,
        "panel_name": client.panel_name,
        "panel_type": panel_type,
        "position": position,
        "local_ip": client._local_ip(),
        "software_version": BACKEND_SOFTWARE_VERSION,
        "module_group": BACKEND_PANEL_ID,
    }

    try:
        r = client.session.post(
            client._url("/api/panels/register"),
            json=payload,
            headers=client.headers,
            timeout=client.timeout,
        )

        r.raise_for_status()

        print(
            "[REMOTE BACKEND] registered "
            f"panel_id={client.panel_id} "
            f"type={panel_type} "
            f"position={position} "
            f"group={BACKEND_PANEL_ID}"
        )

        return True

    except Exception as exc:
        print(
            "[REMOTE BACKEND] registration failed "
            f"position={position}: {exc}"
        )

        return False


def _sync_remote_panel_items_backend(self, position: int):
    position = int(position)

    panel = getattr(self, "remote_panels", {}).get(position)

    if not panel:
        return False

    client = _get_remote_backend_client(
        self,
        position,
    )

    if client is None:
        return False

    items = []

    for raw in panel.get("items", []) or []:
        try:
            item = dict(raw)

            item["id"] = int(item["id"])

            # Explicitly tag this item's side-panel position.
            item["panel_position"] = position

            items.append(item)

        except Exception:
            continue

    try:
        result = client.sync_items(
            items,
            replace_missing=True,
        )

        print(
            "[REMOTE BACKEND] synced "
            f"{len(items)} item(s) "
            f"to {client.panel_id}: {result}"
        )

        return True

    except Exception as exc:
        print(
            "[REMOTE BACKEND] item sync failed "
            f"position={position}: {exc}"
        )

        return False


def _remote_panel_backend_update_async(
    self,
    position: int,
):
    position = int(position)

    def worker():
        if not _register_remote_panel_backend(
            self,
            position,
        ):
            return

        _sync_remote_panel_items_backend(
            self,
            position,
        )

    threading.Thread(
        target=worker,
        daemon=True,
    ).start()


PanelBackendReservationApp._get_remote_backend_client = (
    _get_remote_backend_client
)

PanelBackendReservationApp._register_remote_panel_backend = (
    _register_remote_panel_backend
)

PanelBackendReservationApp._sync_remote_panel_items_backend = (
    _sync_remote_panel_items_backend
)

PanelBackendReservationApp._remote_panel_backend_update_async = (
    _remote_panel_backend_update_async
)


# ------------------------------------------------------------
# Hook discovery/announcement handling.
# ------------------------------------------------------------

_PRE_REMOTE_BACKEND_APPLY_MESSAGE = (
    PanelBackendReservationApp._apply_remote_panel_message
)


def _apply_remote_panel_message_backend_registered(
    self,
    msg,
    addr,
):
    result = _PRE_REMOTE_BACKEND_APPLY_MESSAGE(
        self,
        msg,
        addr,
    )

    try:
        position = int(
            msg.get("position")
        )
    except Exception:
        return result

    try:
        panel = getattr(
            self,
            "remote_panels",
            {},
        ).get(position)

        if not panel:
            return result

        panel_type = str(
            panel.get("panel_type", "")
        ).upper()

        if panel_type not in (
            "A",
            "B",
            "C",
            "D",
            "R1",
            "R2",
            "R3",
        ):
            return result

        self._remote_panel_backend_update_async(
            position
        )

    except Exception as exc:
        print(
            "[REMOTE BACKEND] discovery hook failed:",
            exc,
        )

    return result


PanelBackendReservationApp._apply_remote_panel_message = (
    _apply_remote_panel_message_backend_registered
)


if __name__ == "__main__":
    setup_file_logging()
    PanelBackendReservationApp().run()
    

# ---- Tulipan brand patch ----
def _refresh_header_right_info_tulipan(self, *_args):
    title = str(self._screen_header_title() or "").strip()
    self.header_right_title = title
    self.header_right_brand = "Cvetličarna Jana" if title else ""

base.PanelApp._refresh_header_right_info = _refresh_header_right_info_tulipan
PanelBackendReservationApp._refresh_header_right_info = _refresh_header_right_info_tulipan


# ============================================================
# FINAL R3 CUSTOMER OVERVIEW: EXACTLY TOP ITEMS 1..4
# ============================================================

_PRE_R3_TOP4_REFRESH = PanelBackendReservationApp.refresh_selection_grid


def _refresh_selection_grid_r3_exact_top4(self):
    try:
        panel_type = str(self.current_panel_type()).upper()
    except Exception:
        panel_type = ""

    # Non-R modules retain existing behavior.
    if panel_type not in ("R1", "R2", "R3"):
        return _PRE_R3_TOP4_REFRESH(self)

    sel = self.root.get_screen("selection")

    left = sel.ids.items_grid_left
    right = sel.ids.items_grid_right

    # Never allow stale A/B/C/D cards to remain.
    left.clear_widgets()
    right.clear_widgets()

    all_items = list(
        self.panel_items_for_position(
            int(self.current_panel_position)
        ) or []
    )

    # R modules show ONLY the four fixed upper compartments here.
    top_items = [
        it for it in all_items
        if 1 <= int(it.get("id", 0)) <= 4
    ]

    top_items.sort(
        key=lambda it: int(it.get("id", 0))
    )

    # Defensive guard: never render more than four.
    top_items = top_items[:4]

    # Temporarily make the base PanelApp see exactly the upper four.
    original_method = self.panel_items_for_position

    def top4_items(position):
        if int(position) == int(self.current_panel_position):
            return top_items
        return original_method(position)

    self.panel_items_for_position = top4_items

    try:
        # Use the established R-module renderer in Panel.py.
        result = base.PanelApp.refresh_selection_grid(self)
    finally:
        self.panel_items_for_position = original_method

    # Ensure revolver selector row matches R1/R2/R3.
    try:
        self._refresh_revolver_buttons()
    except Exception as exc:
        print(f"[R3 TOP4] revolver refresh warning: {exc}")

    print(
        "[R3 TOP4] panel_position="
        f"{self.current_panel_position} "
        f"type={panel_type} "
        f"top_ids={[int(x.get('id')) for x in top_items]}"
    )

    return result


PanelBackendReservationApp.refresh_selection_grid = (
    _refresh_selection_grid_r3_exact_top4
)



# ============================================================
# FINAL R3 NORMAL RESERVATION + REVOLVER DISPLAY ORDER
# ============================================================

_PRE_R3_DISPLAY_FIX_REFRESH = (
    PanelBackendReservationApp.refresh_selection_grid
)

_PRE_R3_DISPLAY_FIX_DEFS = (
    PanelBackendReservationApp.revolver_definitions
)


def _wa_r3_revolver_definitions_10_first(self):
    """
    Keep physical/logical item ranges unchanged.
    Only change the displayed selector order for R3:
        Revolver 10 first
        Revolver 7 second
    """
    defs = list(_PRE_R3_DISPLAY_FIX_DEFS(self) or [])

    try:
        panel_type = str(self.current_panel_type()).upper()
    except Exception:
        panel_type = ""

    if panel_type != "R3":
        return defs

    return sorted(
        defs,
        key=lambda d: (
            0 if str(d.get("key", "")).upper() == "R10" else
            1 if str(d.get("key", "")).upper() == "R7" else
            2
        )
    )


PanelBackendReservationApp.revolver_definitions = (
    _wa_r3_revolver_definitions_10_first
)


def _wa_r3_decorate_top_reservations(self):
    """
    Apply backend reservation visuals to R1/R2/R3 fixed upper
    compartments after Panel.py has rendered them.
    """
    try:
        panel_type = str(self.current_panel_type()).upper()
    except Exception:
        panel_type = ""

    if panel_type not in ("R1", "R2", "R3"):
        return

    try:
        sel = self.root.get_screen("selection")

        left = sel.ids.items_grid_left
        right = sel.ids.items_grid_right

        top_items = list(self.r_panel_top_items() or [])
        top_items.sort(
            key=lambda x: int(x.get("id", 0))
        )

        # Kivy children are stored in reverse insertion order.
        left_buttons = list(reversed(left.children))
        right_buttons = list(reversed(right.children))

        buttons = left_buttons + right_buttons

        current_pos = int(
            getattr(
                self,
                "current_panel_position",
                getattr(base, "PANEL_POSITION", 0),
            )
        )

        for idx, item in enumerate(top_items):
            if idx >= len(buttons):
                break

            try:
                item_id = int(item.get("id"))
            except Exception:
                continue

            if self._is_item_reserved(
                current_pos,
                item_id,
            ):
                btn = buttons[idx]

                self._apply_reserved_button_visual(
                    btn,
                    item_id=item_id,
                    allow_click=True,
                )

                print(
                    f"[R3 RESERVED] "
                    f"panel={current_pos} "
                    f"item={item_id}"
                )

    except Exception as exc:
        print(
            f"[R3 RESERVED] decoration failed: {exc}"
        )


def _wa_r3_selection_refresh_final(self):
    result = _PRE_R3_DISPLAY_FIX_REFRESH(self)

    try:
        panel_type = str(self.current_panel_type()).upper()
    except Exception:
        panel_type = ""

    if panel_type in ("R1", "R2", "R3"):

        # Apply reservation state to upper 1..4.
        _wa_r3_decorate_top_reservations(self)

        # Rebuild selector buttons using the new R10 -> R7 order.
        try:
            self._refresh_revolver_buttons()
        except Exception as exc:
            print(
                f"[R3 ORDER] selector refresh failed: {exc}"
            )

        try:
            print(
                "[R3 ORDER] "
                + ", ".join(
                    str(x.get("key"))
                    for x in self.revolver_definitions()
                )
            )
        except Exception:
            pass

    return result


PanelBackendReservationApp.refresh_selection_grid = (
    _wa_r3_selection_refresh_final
)



# ============================================================
# FINAL R3 NORMAL RESERVATION + REVOLVER DISPLAY ORDER
# ============================================================

_PRE_R3_DISPLAY_FIX_REFRESH = (
    PanelBackendReservationApp.refresh_selection_grid
)

_PRE_R3_DISPLAY_FIX_DEFS = (
    PanelBackendReservationApp.revolver_definitions
)


def _wa_r3_revolver_definitions_10_first(self):
    """
    Keep physical/logical item ranges unchanged.
    Only change the displayed selector order for R3:
        Revolver 10 first
        Revolver 7 second
    """
    defs = list(_PRE_R3_DISPLAY_FIX_DEFS(self) or [])

    try:
        panel_type = str(self.current_panel_type()).upper()
    except Exception:
        panel_type = ""

    if panel_type != "R3":
        return defs

    return sorted(
        defs,
        key=lambda d: (
            0 if str(d.get("key", "")).upper() == "R10" else
            1 if str(d.get("key", "")).upper() == "R7" else
            2
        )
    )


PanelBackendReservationApp.revolver_definitions = (
    _wa_r3_revolver_definitions_10_first
)


def _wa_r3_decorate_top_reservations(self):
    """
    Apply backend reservation visuals to R1/R2/R3 fixed upper
    compartments after Panel.py has rendered them.
    """
    try:
        panel_type = str(self.current_panel_type()).upper()
    except Exception:
        panel_type = ""

    if panel_type not in ("R1", "R2", "R3"):
        return

    try:
        sel = self.root.get_screen("selection")

        left = sel.ids.items_grid_left
        right = sel.ids.items_grid_right

        top_items = list(self.r_panel_top_items() or [])
        top_items.sort(
            key=lambda x: int(x.get("id", 0))
        )

        # Kivy children are stored in reverse insertion order.
        left_buttons = list(reversed(left.children))
        right_buttons = list(reversed(right.children))

        buttons = left_buttons + right_buttons

        current_pos = int(
            getattr(
                self,
                "current_panel_position",
                getattr(base, "PANEL_POSITION", 0),
            )
        )

        for idx, item in enumerate(top_items):
            if idx >= len(buttons):
                break

            try:
                item_id = int(item.get("id"))
            except Exception:
                continue

            if self._is_item_reserved(
                current_pos,
                item_id,
            ):
                btn = buttons[idx]

                self._apply_reserved_button_visual(
                    btn,
                    item_id=item_id,
                    allow_click=True,
                )

                print(
                    f"[R3 RESERVED] "
                    f"panel={current_pos} "
                    f"item={item_id}"
                )

    except Exception as exc:
        print(
            f"[R3 RESERVED] decoration failed: {exc}"
        )


def _wa_r3_selection_refresh_final(self):
    result = _PRE_R3_DISPLAY_FIX_REFRESH(self)

    try:
        panel_type = str(self.current_panel_type()).upper()
    except Exception:
        panel_type = ""

    if panel_type in ("R1", "R2", "R3"):

        # Apply reservation state to upper 1..4.
        _wa_r3_decorate_top_reservations(self)

        # Rebuild selector buttons using the new R10 -> R7 order.
        try:
            self._refresh_revolver_buttons()
        except Exception as exc:
            print(
                f"[R3 ORDER] selector refresh failed: {exc}"
            )

        try:
            print(
                "[R3 ORDER] "
                + ", ".join(
                    str(x.get("key"))
                    for x in self.revolver_definitions()
                )
            )
        except Exception:
            pass

    return result


PanelBackendReservationApp.refresh_selection_grid = (
    _wa_r3_selection_refresh_final
)


# ============================================================
# FINAL SELECTION GRID CRASH SAFETY
#
# Prevent:
#   GridLayoutException:
#   Too many children in GridLayout. Increase rows/cols!
#
# Causes handled:
#   1. panel geometry changes while old widgets still exist
#   2. refresh requests arriving from non-Kivy threads
#   3. overlapping/repeated selection refresh requests
# ============================================================

import threading as _grid_threading
from kivy.clock import Clock as _GridClock


_SELECTION_REFRESH_BEFORE_CRASH_SAFETY = (
    PanelBackendReservationApp.refresh_selection_grid
)


def _selection_grid_make_clear_safe(self):
    """
    Temporarily increase GridLayout capacity before removing old
    children. Increasing capacity is safe even if the panel layout
    was already changed from A/B/C/D to R1/R2/R3.
    """
    try:
        scr = self.root.get_screen("selection")
    except Exception:
        return

    for grid_id in (
        "items_grid_left",
        "items_grid_right",
    ):
        try:
            grid = scr.ids[grid_id]
        except Exception:
            continue

        try:
            child_count = len(grid.children)

            current_rows = int(
                getattr(grid, "rows", 0) or 0
            )

            current_cols = int(
                getattr(grid, "cols", 0) or 0
            )

            # We only INCREASE capacity here.
            #
            # Most of these grids use one column, but calculate
            # conservatively in case that changes later.
            cols = max(1, current_cols)

            required_rows = max(
                1,
                (child_count + cols - 1) // cols,
            )

            if current_rows < required_rows:
                grid.rows = required_rows

        except Exception as exc:
            print(
                f"[GRID SAFETY] capacity warning "
                f"{grid_id}: {exc}"
            )


def _selection_grid_clear_safe(self):
    try:
        scr = self.root.get_screen("selection")
    except Exception:
        return

    for grid_id in (
        "items_grid_left",
        "items_grid_right",
    ):
        try:
            grid = scr.ids[grid_id]

            _selection_grid_make_clear_safe(self)

            grid.clear_widgets()

        except Exception as exc:
            print(
                f"[GRID SAFETY] clear warning "
                f"{grid_id}: {exc}"
            )


def _run_selection_refresh_safe(self):
    # Multiple queued backend/R3 refresh requests can collapse
    # into one actual render.
    if getattr(
        self,
        "_selection_refresh_running",
        False,
    ):
        return

    self._selection_refresh_running = True

    try:
        # IMPORTANT:
        # First make the OLD layout capable of holding its
        # existing children.
        _selection_grid_make_clear_safe(self)

        # Then remove the old widgets BEFORE any layout geometry
        # is recalculated.
        _selection_grid_clear_safe(self)

        # With empty grids it is now safe to apply the current
        # panel's intended row/column geometry.
        try:
            self._sync_current_panel_layout()
        except Exception as exc:
            print(
                f"[GRID SAFETY] layout sync warning: {exc}"
            )

        # Run the complete existing renderer.
        _SELECTION_REFRESH_BEFORE_CRASH_SAFETY(self)

    except Exception as exc:
        print(
            "[GRID SAFETY] selection refresh failed:",
            repr(exc),
        )

        # Do NOT kill the complete vending application because
        # one UI refresh failed.
        try:
            _selection_grid_make_clear_safe(self)
        except Exception:
            pass

    finally:
        self._selection_refresh_running = False
        self._selection_refresh_pending = False


def _refresh_selection_grid_crash_safe(self):
    # Kivy widgets must be modified from the main UI thread.
    if (
        _grid_threading.current_thread()
        is not _grid_threading.main_thread()
    ):
        if not getattr(
            self,
            "_selection_refresh_pending",
            False,
        ):
            self._selection_refresh_pending = True

            _GridClock.schedule_once(
                lambda _dt:
                    _run_selection_refresh_safe(self),
                0,
            )

        return

    return _run_selection_refresh_safe(self)


PanelBackendReservationApp.refresh_selection_grid = (
    _refresh_selection_grid_crash_safe
)



# ============================================================
# R3 REVOLVER SELECTOR ORANGE OPENING BLINK
# ============================================================
#
# UI ONLY.
#
# Pending IDs:
#   R7  = items 5..11
#   R10 = items 12..21
#
# While an Admin Open is pending, the corresponding large
# revolver selector circle flashes orange. Inventory, ESP state,
# LEDs and item availability are NOT modified.
# ============================================================

from kivy.graphics import Color as _R3BlinkColor
from kivy.graphics import Ellipse as _R3BlinkEllipse


def _wa_r3_attach_orange_overlay(btn):
    """Add a reusable orange circular overlay behind the button text."""
    if getattr(btn, "_wa_r3_orange_overlay_installed", False):
        return

    try:
        with btn.canvas.before:
            color = _R3BlinkColor(1.0, 0.46, 0.05, 0.0)
            ellipse = _R3BlinkEllipse(
                pos=btn.pos,
                size=btn.size,
            )

        def update_geometry(*_args):
            try:
                ellipse.pos = btn.pos
                ellipse.size = btn.size
            except Exception:
                pass

        btn.bind(
            pos=update_geometry,
            size=update_geometry,
        )

        btn._wa_r3_orange_color = color
        btn._wa_r3_orange_ellipse = ellipse
        btn._wa_r3_orange_overlay_installed = True

    except Exception as exc:
        print(
            "[R3 OPEN BLINK] could not attach overlay:",
            exc,
        )


def _wa_r3_revolver_blink_tick(self, _dt=0):
    try:
        pending = {
            int(x)
            for x in getattr(
                self,
                "_admin_door_pending_ids",
                set(),
            )
        }
    except Exception:
        pending = set()

    r7_pending = any(
        5 <= item_id <= 11
        for item_id in pending
    )

    r10_pending = any(
        12 <= item_id <= 21
        for item_id in pending
    )

    anything_pending = (
        r7_pending or r10_pending
    )

    if anything_pending:
        self._wa_r3_revolver_blink_phase = not bool(
            getattr(
                self,
                "_wa_r3_revolver_blink_phase",
                False,
            )
        )
    else:
        self._wa_r3_revolver_blink_phase = False

    phase = bool(
        getattr(
            self,
            "_wa_r3_revolver_blink_phase",
            False,
        )
    )

    # Find every R7/R10 selector currently present.
    # This covers both Selection and Admin revolver rows.
    try:
        widgets = list(self.root.walk())
    except Exception:
        widgets = []

    for widget in widgets:
        if not isinstance(
            widget,
            base.RevolverSelectorButton,
        ):
            continue

        _wa_r3_attach_orange_overlay(widget)

        txt = str(
            getattr(widget, "text", "")
            or ""
        ).strip().lower()

        is_r10 = (
            "revolver 10" in txt
            or txt.endswith(" 10")
        )

        is_r7 = (
            "revolver 7" in txt
            or txt.endswith(" 7")
        )

        active = (
            (is_r7 and r7_pending)
            or
            (is_r10 and r10_pending)
        )

        try:
            widget._wa_r3_orange_color.rgba = (
                1.0,
                0.46,
                0.05,
                0.92 if (active and phase) else 0.0,
            )
        except Exception:
            pass

    # Stop timer automatically when nothing is opening.
    if not anything_pending:
        event = getattr(
            self,
            "_wa_r3_revolver_blink_event",
            None,
        )

        if event is not None:
            try:
                event.cancel()
            except Exception:
                pass

        self._wa_r3_revolver_blink_event = None

        return False

    return True


def _wa_r3_start_revolver_blink(self):
    # Update immediately so the user sees feedback without
    # waiting for the first timer interval.
    try:
        _wa_r3_revolver_blink_tick(
            self,
            0,
        )
    except Exception:
        pass

    if getattr(
        self,
        "_wa_r3_revolver_blink_event",
        None,
    ) is not None:
        return

    self._wa_r3_revolver_blink_event = (
        Clock.schedule_interval(
            lambda dt:
                _wa_r3_revolver_blink_tick(
                    self,
                    dt,
                ),
            0.45,
        )
    )


# Wrap the existing pending-ID method rather than changing any
# door/open logic.
_WA_PRE_R3_SET_PENDING_IDS = (
    PanelBackendReservationApp._admin_set_pending_ids
)


def _wa_r3_set_pending_ids_with_circle_blink(
    self,
    ids,
):
    result = _WA_PRE_R3_SET_PENDING_IDS(
        self,
        ids,
    )

    try:
        panel_type = str(
            self.current_panel_type()
        ).upper()
    except Exception:
        panel_type = ""

    if panel_type == "R3":
        try:
            ids_int = {
                int(x)
                for x in (ids or [])
            }
        except Exception:
            ids_int = set()

        if any(
            5 <= x <= 21
            for x in ids_int
        ):
            _wa_r3_start_revolver_blink(
                self
            )

    return result


PanelBackendReservationApp._admin_set_pending_ids = (
    _wa_r3_set_pending_ids_with_circle_blink
)

print(
    "[R3 UI] revolver orange opening blink installed"
)

# === END R3 REVOLVER SELECTOR ORANGE OPENING BLINK ===


# ============================================================
# FINAL R3 CUSTOMER DISPLAY NUMBERS 8..28
#
# Real/backend IDs stay 1..21.
# Only visible customer labels are shifted by +7.
# Applies only to real R3 side module at panel position 1.
# ============================================================

_PRE_R3_DISPLAY_8_28_REFRESH = (
    PanelBackendReservationApp.refresh_selection_grid
)


def _refresh_selection_grid_r3_display_8_28(self):
    try:
        panel_type = str(
            self.current_panel_type()
        ).strip().upper()

        panel_position = int(
            self.current_panel_position
        )
    except Exception:
        panel_type = ""
        panel_position = -1

    # Everything except the real R3 side module stays unchanged.
    if (
        panel_type != "R3"
        or panel_position != 1
    ):
        return _PRE_R3_DISPLAY_8_28_REFRESH(self)

    original_items_method = (
        self.panel_items_for_position
    )

    def r3_display_items(position):
        real_items = list(
            original_items_method(position)
            or []
        )

        if int(position) != 1:
            return real_items

        display_items = []

        for raw in real_items:
            # Always copy; never mutate stored/backend item data.
            item = dict(raw)

            try:
                item_id = int(
                    item.get("id")
                )
            except Exception:
                display_items.append(item)
                continue

            # Keep ID unchanged.
            # Only customer-visible label changes.
            if 1 <= item_id <= 21:
                item["label"] = str(
                    item_id + 7
                )

            display_items.append(item)

        return display_items

    self.panel_items_for_position = (
        r3_display_items
    )

    try:
        return _PRE_R3_DISPLAY_8_28_REFRESH(
            self
        )
    finally:
        self.panel_items_for_position = (
            original_items_method
        )


PanelBackendReservationApp.refresh_selection_grid = (
    _refresh_selection_grid_r3_display_8_28
)



# ============================================================
# REOPEN: FORCE RESEND CURRENT ITEM/LED STATUSES TO ESP32
# ============================================================

_PRE_REOPEN_WITHOUT_STATUS_RESEND = (
    PanelBackendReservationApp.on_reopen_door
)


def _on_reopen_door_with_status_resend(self):
    # Keep the existing reopen behaviour completely unchanged.
    _PRE_REOPEN_WITHOUT_STATUS_RESEND(self)

    def resend_statuses(_dt=0):
        try:
            self._wa_sync_led_statuses(
                force=True
            )

            print(
                "[REOPEN STATUS] Forced complete status "
                "snapshot resend to ESP32."
            )

        except Exception as exc:
            print(
                "[REOPEN STATUS] Status resend failed:",
                exc,
            )

    # Send immediately after Reopen.
    Clock.schedule_once(
        resend_statuses,
        0.10,
    )

    # Send once more shortly afterwards in case the ESP is
    # busy with the physical reopen operation during the first packet.
    Clock.schedule_once(
        resend_statuses,
        1.00,
    )


PanelBackendReservationApp.on_reopen_door = (
    _on_reopen_door_with_status_resend
)


# ============================================================
# REOPEN: SHOW ALL REOPENED BOUQUETS ON CUSTOMER SCREEN
# ============================================================

_PRE_REOPEN_WITHOUT_SCREEN_MESSAGE = (
    PanelBackendReservationApp.on_reopen_door
)


def _on_reopen_door_with_screen_message(self):
    items = list(
        getattr(
            self,
            "_last_purchased_items",
            [],
        )
        or []
    )

    # Build customer-visible bouquet list BEFORE running reopen.
    lines = []

    for it in items:
        try:
            real_id = int(it.get("id"))
            panel_position = int(
                it.get(
                    "panel_position",
                    getattr(
                        self,
                        "current_panel_position",
                        0,
                    ),
                )
            )

            if (
                panel_position == 1
                and 1 <= real_id <= 21
            ):
                visible_id = real_id + 7
            else:
                visible_id = it.get(
                    "label",
                    real_id,
                )

            lines.append(
                f"{self.t('bouquet')} {visible_id}"
            )

        except Exception:
            pass

    # Single-item fallback.
    if (
        not lines
        and getattr(
            self,
            "_last_purchased_hidden_id",
            None,
        )
        is not None
    ):
        try:
            real_id = int(
                self._last_purchased_hidden_id
            )

            panel_position = int(
                getattr(
                    self,
                    "current_item_position",
                    getattr(
                        self,
                        "current_panel_position",
                        0,
                    ),
                )
            )

            if (
                panel_position == 1
                and 1 <= real_id <= 21
            ):
                visible_id = real_id + 7
            else:
                visible_id = getattr(
                    self,
                    "_last_purchased_label",
                    real_id,
                )

            lines.append(
                f"{self.t('bouquet')} {visible_id}"
            )

        except Exception:
            pass

    lang = str(
        getattr(
            self,
            "lang",
            "si",
        )
        or "si"
    ).lower()

    headers = {
        "si": "Ponovno odpiranje vrat:",
        "hr": "Ponovno otvaranje vrata:",
        "en": "Reopening doors:",
        "de": "Türen werden erneut geöffnet:",
    }

    header = headers.get(
        lang,
        headers["en"],
    )

    message = header

    if lines:
        message += "\n" + "\n".join(lines)

    # Update whichever purchase screen is currently visible.
    try:
        current = str(
            getattr(
                self.root,
                "current",
                "",
            )
            or ""
        )

        if current == "thanks":
            self.root.get_screen(
                "thanks"
            ).ids.thanks_sub.text = message

        elif current == "receipt_printing":
            self.root.get_screen(
                "receipt_printing"
            ).ids.receipt_print_for.text = message

    except Exception as exc:
        print(
            "[REOPEN SCREEN] display warning:",
            exc,
        )

    print(
        "[REOPEN SCREEN]",
        lines,
    )

    # Run the existing reopen handler.
    # This also preserves the status-resend wrapper installed earlier.
    result = _PRE_REOPEN_WITHOUT_SCREEN_MESSAGE(
        self
    )

    def restore_normal_text(_dt):
        try:
            current = str(
                getattr(
                    self.root,
                    "current",
                    "",
                )
                or ""
            )

            if current == "thanks":
                self._update_thanks_opening_label()

            elif current == "receipt_printing":
                self._update_receipt_printing_for_label()

        except Exception as exc:
            print(
                "[REOPEN SCREEN] restore warning:",
                exc,
            )

    # Keep reopen message visible for 6 seconds.
    Clock.schedule_once(
        restore_normal_text,
        6.0,
    )

    return result


PanelBackendReservationApp.on_reopen_door = (
    _on_reopen_door_with_screen_message
)


# ============================================================
# THANK-YOU SCREEN: ALWAYS USE FULL INVOICE ITEM SNAPSHOT
# ============================================================

def _update_thanks_opening_label_full_purchase(self):
    if not getattr(self, "root", None):
        return

    thx = self.root.get_screen("thanks")

    items = []

    # --------------------------------------------------------
    # 1. Prefer immutable invoice-specific purchase snapshot.
    # --------------------------------------------------------
    try:
        invoice_number = str(
            getattr(
                self,
                "_last_invoice_number",
                "",
            )
            or ""
        )

        receipt_contexts = getattr(
            self,
            "_receipt_context_by_invoice",
            {},
        ) or {}

        context = receipt_contexts.get(
            invoice_number,
            {},
        ) or {}

        items = list(
            context.get("items") or []
        )

    except Exception as exc:
        print(
            "[THANKS FULL ITEMS] snapshot warning:",
            exc,
        )
        items = []

    # --------------------------------------------------------
    # 2. Fallback to normal last-purchased list.
    # --------------------------------------------------------
    if not items:
        items = list(
            getattr(
                self,
                "_last_purchased_items",
                [],
            )
            or []
        )

    # --------------------------------------------------------
    # Build customer-visible bouquet list.
    # --------------------------------------------------------
    if items:
        lines = []

        for it in items:
            try:
                real_id = int(
                    it.get("id")
                )

                panel_position = int(
                    it.get(
                        "panel_position",
                        0,
                    )
                )

                # R3:
                # real 1..21 -> visible 8..28
                if (
                    panel_position == 1
                    and 1 <= real_id <= 21
                ):
                    visible_id = real_id + 7
                else:
                    visible_id = it.get(
                        "label",
                        real_id,
                    )

                lines.append(
                    f"{self.t('bouquet')} {visible_id}"
                )

            except Exception as exc:
                print(
                    "[THANKS FULL ITEMS] item warning:",
                    exc,
                )

        if lines:
            thx.ids.thanks_sub.text = (
                f"{self.t('door_opening_hdr')}\n"
                + "\n".join(lines)
            )

            print(
                "[THANKS FULL ITEMS]",
                lines,
            )

            return

    # --------------------------------------------------------
    # 3. Legacy single-item fallback.
    # --------------------------------------------------------
    hid = getattr(
        self,
        "_last_purchased_hidden_id",
        None,
    )

    lbl = getattr(
        self,
        "_last_purchased_label",
        None,
    )

    if hid is None:
        thx.ids.thanks_sub.text = ""
        return

    try:
        real_id = int(hid)

        panel_position = int(
            getattr(
                self,
                "current_item_position",
                getattr(
                    self,
                    "current_panel_position",
                    0,
                ),
            )
        )

        if (
            panel_position == 1
            and 1 <= real_id <= 21
        ):
            visible_id = real_id + 7
        else:
            visible_id = (
                lbl
                if lbl is not None
                else real_id
            )

    except Exception:
        visible_id = lbl

    thx.ids.thanks_sub.text = (
        f"{self.t('door_opening_hdr')}\n"
        f"{self.t('bouquet')} {visible_id}"
    )


PanelBackendReservationApp._update_thanks_opening_label = (
    _update_thanks_opening_label_full_purchase
)


# ============================================================
# REOPEN: RESET INACTIVITY TIMER
# ============================================================

_PRE_REOPEN_WITHOUT_TIMER_RESET = (
    PanelBackendReservationApp.on_reopen_door
)


def _on_reopen_door_with_timer_reset(self):
    try:
        self._reset_inactivity_timer()

        print(
            "[REOPEN TIMER] Inactivity timer reset."
        )

    except Exception as exc:
        print(
            "[REOPEN TIMER] Reset failed:",
            exc,
        )

    return _PRE_REOPEN_WITHOUT_TIMER_RESET(
        self
    )


PanelBackendReservationApp.on_reopen_door = (
    _on_reopen_door_with_timer_reset
)


# ============================================================
# FINAL PURCHASE / THANK-YOU / REOPEN UI FIX
#
# - preserve full purchased item list
# - always go to Thank You after successful payment
# - show ALL bouquets
# - R3 visible numbering 8..28
# - reset inactivity timer on successful purchase
# - Reopen shows explicit "Reopening doors" heading
# ============================================================


def _final_purchase_items(self):
    """
    Return the complete immutable item list for the latest invoice.
    Fall back to _last_purchased_items only if necessary.
    """
    try:
        invoice = str(
            getattr(self, "_last_invoice_number", "") or ""
        )

        contexts = getattr(
            self,
            "_receipt_context_by_invoice",
            {},
        ) or {}

        ctx = contexts.get(invoice, {}) or {}

        items = list(ctx.get("items") or [])

        if items:
            return [dict(x) for x in items]

    except Exception as exc:
        print(
            "[FINAL PURCHASE ITEMS] snapshot error:",
            exc,
        )

    return [
        dict(x)
        for x in (
            getattr(self, "_last_purchased_items", [])
            or []
        )
    ]


PanelBackendReservationApp._final_purchase_items = (
    _final_purchase_items
)


def _final_visible_bouquet_lines(self, items=None):
    if items is None:
        items = self._final_purchase_items()

    lines = []

    for it in items or []:
        try:
            real_id = int(it.get("id"))

            panel_position = int(
                it.get("panel_position", 0)
            )

            # R3 side module:
            # internal 1..21 -> customer 8..28
            if (
                panel_position == 1
                and 1 <= real_id <= 21
            ):
                visible_id = real_id + 7
            else:
                visible_id = it.get(
                    "label",
                    real_id,
                )

            lines.append(
                f"{self.t('bouquet')} {visible_id}"
            )

        except Exception as exc:
            print(
                "[FINAL PURCHASE ITEMS] line error:",
                exc,
            )

    return lines


PanelBackendReservationApp._final_visible_bouquet_lines = (
    _final_visible_bouquet_lines
)


# ------------------------------------------------------------
# SUCCESSFUL PURCHASE
# ------------------------------------------------------------

_PRE_FINAL_COMPLETE_PURCHASE = (
    PanelBackendReservationApp._complete_successful_purchase
)


def _complete_successful_purchase_final_ui(
    self,
    items,
    invoice_number,
    issue_datetime_iso,
    total,
):
    # Run ALL existing payment / door / backend behaviour first.
    result = _PRE_FINAL_COMPLETE_PURCHASE(
        self,
        items,
        invoice_number,
        issue_datetime_iso,
        total,
    )

    # Retrieve the immutable complete purchase snapshot.
    full_items = self._final_purchase_items()

    if full_items:
        # Critical:
        # make the normal reopen logic see ALL purchased items.
        self._last_purchased_items = [
            dict(x)
            for x in full_items
        ]

    lines = self._final_visible_bouquet_lines(
        full_items
    )

    try:
        thx = self.root.get_screen("thanks")

        # Normal Thank You title.
        thx.ids.thanks_title.text = (
            self.t("thank_you")
        )

        if lines:
            thx.ids.thanks_sub.text = (
                f"{self.t('door_opening_hdr')}\n"
                + "\n".join(lines)
            )
        else:
            thx.ids.thanks_sub.text = (
                self.t("door_opening_hdr")
            )

        # Explicitly enter Thank You screen.
        self.root.current = "thanks"

        print(
            "[THANKS FINAL] showing full purchase:",
            lines,
        )

    except Exception as exc:
        print(
            "[THANKS FINAL] UI error:",
            exc,
        )

    # Start a fresh full inactivity period from the moment
    # the Thank You screen appears.
    try:
        self._reset_inactivity_timer()

        print(
            "[THANKS FINAL] inactivity timer reset"
        )

    except Exception as exc:
        print(
            "[THANKS FINAL] timer reset error:",
            exc,
        )

    return result


PanelBackendReservationApp._complete_successful_purchase = (
    _complete_successful_purchase_final_ui
)


# ------------------------------------------------------------
# REOPEN SCREEN MESSAGE
# ------------------------------------------------------------

_PRE_FINAL_REOPEN = (
    PanelBackendReservationApp.on_reopen_door
)


def _on_reopen_door_final_ui(self):
    # Make absolutely sure existing reopen code receives
    # the complete purchase list.
    full_items = self._final_purchase_items()

    if full_items:
        self._last_purchased_items = [
            dict(x)
            for x in full_items
        ]

    lines = self._final_visible_bouquet_lines(
        full_items
    )

    lang = str(
        getattr(self, "lang", "hr") or "hr"
    ).lower()

    reopen_headers = {
        "hr": "Ponovno otvaranje vrata",
        "si": "Ponovno odpiranje vrat",
        "en": "Reopening doors",
        "de": "Türen werden erneut geöffnet",
    }

    reopen_header = reopen_headers.get(
        lang,
        reopen_headers["en"],
    )

    try:
        current = str(
            getattr(self.root, "current", "") or ""
        )

        # THANK-YOU SCREEN
        if current == "thanks":
            thx = self.root.get_screen("thanks")

            # Put the heading in the actual upper title field.
            thx.ids.thanks_title.text = reopen_header

            thx.ids.thanks_sub.text = (
                "\n".join(lines)
                if lines
                else ""
            )

        # RECEIPT SCREEN
        elif current == "receipt_printing":
            rp = self.root.get_screen(
                "receipt_printing"
            )

            # Put heading in actual upper title field.
            rp.ids.receipt_print_title.text = (
                reopen_header
            )

            rp.ids.receipt_print_for.text = (
                "\n".join(lines)
                if lines
                else ""
            )

        print(
            "[REOPEN FINAL UI]",
            reopen_header,
            lines,
        )

    except Exception as exc:
        print(
            "[REOPEN FINAL UI] display error:",
            exc,
        )

    # Explicit timer reset.
    try:
        self._reset_inactivity_timer()
        print(
            "[REOPEN FINAL UI] inactivity timer reset"
        )
    except Exception as exc:
        print(
            "[REOPEN FINAL UI] timer error:",
            exc,
        )

    # Run all existing reopen behaviour:
    # doors + status resend etc.
    result = _PRE_FINAL_REOPEN(self)

    def restore_reopen_screen(_dt):
        try:
            current = str(
                getattr(
                    self.root,
                    "current",
                    "",
                )
                or ""
            )

            if current == "thanks":
                thx = self.root.get_screen(
                    "thanks"
                )

                thx.ids.thanks_title.text = (
                    self.t("thank_you")
                )

                thx.ids.thanks_sub.text = (
                    f"{self.t('door_opening_hdr')}\n"
                    + "\n".join(lines)
                )

            elif current == "receipt_printing":
                rp = self.root.get_screen(
                    "receipt_printing"
                )

                rp.ids.receipt_print_title.text = (
                    self.t("printing_receipt")
                )

                self._update_receipt_printing_for_label()

        except Exception as exc:
            print(
                "[REOPEN FINAL UI] restore error:",
                exc,
            )

    # Show explicit reopen heading for 6 seconds.
    Clock.schedule_once(
        restore_reopen_screen,
        6.0,
    )

    return result


PanelBackendReservationApp.on_reopen_door = (
    _on_reopen_door_final_ui
)


# ============================================================
# AUTOMATIC RECEIPT AFTER FISCALISATION
#
# - prints once automatically after fiscal worker completes
# - keeps normal receipt button unchanged
# - prevents duplicate automatic print for same invoice
# ============================================================

_PRE_AUTO_RECEIPT_WORKER_SEND = (
    PanelBackendReservationApp._worker_send
)


def _worker_send_with_auto_receipt(
    self,
    invoice_number,
    issue_datetime_iso,
    *args,
    **kwargs,
):
    # Run the complete existing fiscalisation/backend flow first.
    result = _PRE_AUTO_RECEIPT_WORKER_SEND(
        self,
        invoice_number,
        issue_datetime_iso,
        *args,
        **kwargs,
    )

    invoice_key = str(invoice_number)

    try:
        already_printed = getattr(
            self,
            "_auto_receipt_printed_invoices",
            set(),
        )

        if not isinstance(already_printed, set):
            already_printed = set()

        self._auto_receipt_printed_invoices = (
            already_printed
        )

        if invoice_key in already_printed:
            print(
                "[AUTO RECEIPT] already printed invoice",
                invoice_key,
            )
            return result

        already_printed.add(invoice_key)

        def auto_print(_dt):
            try:
                print(
                    "[AUTO RECEIPT] printing invoice",
                    invoice_key,
                )

                # Use the EXACT same receipt-print function
                # as the customer's existing Print Receipt button.
                self.on_receipt()

            except Exception as exc:
                print(
                    "[AUTO RECEIPT] print failed:",
                    exc,
                )

        # Run actual UI/receipt action on Kivy thread.
        Clock.schedule_once(
            auto_print,
            0,
        )

    except Exception as exc:
        print(
            "[AUTO RECEIPT] scheduling failed:",
            exc,
        )

    return result


PanelBackendReservationApp._worker_send = (
    _worker_send_with_auto_receipt
)

# ============================================================
# FINAL LOCALIZED RECEIPT PRINTER STATUS
# ============================================================

_PRE_LOCALIZED_RECEIPT_STATUS = (
    PanelBackendReservationApp._set_receipt_print_status
)


def _set_receipt_print_status_localized(self, message):
    lang = str(
        getattr(self, "lang", "en") or "en"
    ).lower()

    translations = {
        "Preparing receipt": {
            "en": "Preparing receipt",
            "si": "Priprava računa",
            "hr": "Priprema računa",
            "de": "Beleg wird vorbereitet",
        },
        "Printing receipt": {
            "en": "Printing receipt",
            "si": "Tiskanje računa",
            "hr": "Ispis računa",
            "de": "Beleg wird gedruckt",
        },
        "Receipt printed": {
            "en": "Receipt printed",
            "si": "Račun natisnjen",
            "hr": "Račun ispisan",
            "de": "Beleg gedruckt",
        },
        "Receipt printer disabled": {
            "en": "Receipt printer disabled",
            "si": "Tiskalnik računov je onemogočen",
            "hr": "Pisač računa je onemogućen",
            "de": "Belegdrucker deaktiviert",
        },
        "No invoice available": {
            "en": "No invoice available",
            "si": "Račun ni na voljo",
            "hr": "Račun nije dostupan",
            "de": "Kein Beleg verfügbar",
        },
    }

    translated = translations.get(
        str(message),
        {},
    ).get(
        lang,
        str(message),
    )

    return _PRE_LOCALIZED_RECEIPT_STATUS(
        self,
        translated,
    )


PanelBackendReservationApp._set_receipt_print_status = (
    _set_receipt_print_status_localized
)

