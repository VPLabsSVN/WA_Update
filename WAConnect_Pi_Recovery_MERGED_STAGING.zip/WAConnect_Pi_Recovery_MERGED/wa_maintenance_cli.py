#!/usr/bin/env python3
"""Operator-side R3 attended maintenance interface; NO WAC mobile/API access.

By default validates arguments only; --execute sends exactly one command.
For inspected hardware this requires a local interactive TTY declaration.
This CLI is not evidence of physical presence. Protect Pi SSH access.
"""
import argparse
import json
import os
import sys
from wa_module_health_bridge import ModuleHealthBridge

ALL_ACTIONS = (
    "remote_recovery_status", "remote_recovery_resync", "remote_recovery_led_refresh",
    "remote_motor_status", "remote_motor_stop", "remote_motor_recover",
    "remote_motor_start", "remote_motor_reinit", "remote_motor_quarantine",
    "remote_motor_clear_fault", "remote_motor_clear_global",
)
READ_ONLY = {"remote_recovery_status", "remote_motor_status"}


def main(argv=None):
    p = argparse.ArgumentParser(description="R3 attended LAN maintenance; inspection-required actions stay local to the Pi")
    p.add_argument("--action", choices=ALL_ACTIONS, required=True)
    p.add_argument("--motor", type=int, choices=(7,10))
    p.add_argument("--inspected-hardware", action="store_true")
    p.add_argument("--inspection-note", default="", help="Brief physical inspection summary; not a secret")
    p.add_argument("--execute", action="store_true", help="Actually transmit to local R3")
    args = p.parse_args(argv)
    bridge = ModuleHealthBridge()
    if args.action in {"remote_motor_recover", "remote_motor_start", "remote_motor_reinit",
                       "remote_motor_quarantine", "remote_motor_clear_fault"}:
        if args.motor not in (7, 10): p.error("--motor 7 or 10 required")
    elif args.motor is not None:
        p.error("--motor not accepted for this action")
    if args.inspected_hardware:
        if args.action not in {"remote_motor_recover", "remote_motor_reinit",
                               "remote_motor_clear_fault", "remote_motor_clear_global"}:
            p.error("Inspection attestation is not valid for this command")
        if len(args.inspection_note.strip()) < 12:
            p.error("--inspection-note must describe a real physical inspection")
    elif args.inspection_note:
        p.error("--inspection-note requires --inspected-hardware")
    elif args.action == "remote_motor_clear_global":
        p.error("Global fault clearing requires --inspected-hardware")
    # Avoid logging the token or sending a command in dry-run mode.
    if not args.execute:
        print(json.dumps({"mode":"DRY RUN: no network or hardware action", "action":args.action,
                          "motor":args.motor, "inspected_hardware":args.inspected_hardware,
                          "inspection_note_supplied":bool(args.inspection_note)},indent=2))
        return 0
    if args.action not in READ_ONLY:
        if not sys.stdin.isatty():
            p.error("Mutating operations require an interactive operator terminal")
        label = f"{args.action} {args.motor if args.motor is not None else 'R3'}"
        print("WARNING: This command may affect live motors or machine availability.")
        print("Inspect the machine and ensure no customer access or active purchase.")
        expected = f"CONFIRM {label}"
        if input(f"Type '{expected}' to continue: ").strip() != expected:
            print("Cancelled; no UDP sent.")
            return 2
    if args.inspected_hardware:
        if not sys.stdin.isatty():
            p.error("Hardware-inspection attestation requires an interactive operator")
        statement = "I PHYSICALLY INSPECTED THE MACHINE"
        if input(f"Type '{statement}' only after physical inspection: ").strip() != statement:
            print("Cancelled; no UDP sent.")
            return 2
    try:
        result = bridge.send_maintenance_command(
            args.action, motor=args.motor, inspected_hardware=args.inspected_hardware,
            inspection_note=args.inspection_note,
        )
    except (OSError, ValueError, TimeoutError) as exc:
        print("RECOVERY REFUSED:",type(exc).__name__,str(exc)[:150],file=sys.stderr)
        return 1
    print(json.dumps(result,indent=2,sort_keys=True))
    if result.get("ok"):
        print("Controller acknowledged the action. This does not prove sustained rotation.")
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
