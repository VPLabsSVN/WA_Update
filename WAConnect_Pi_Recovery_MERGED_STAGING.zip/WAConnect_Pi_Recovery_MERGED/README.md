# WA Connect Pi Recovery — STAGING ONLY

Files are derived from the Raspberry Pi archive provided on 2026-11-09. The active Pi process is **not** changed by the included staging script.

On Raspberry Pi: copy this whole directory to `/home/pi/WAConnect_Pi_Recovery_Staging/`, then run:
```
python3 /home/pi/WAConnect_Pi_Recovery_Staging/stage_pi_recovery.py --check
python3 /home/pi/WAConnect_Pi_Recovery_Staging/stage_pi_recovery.py --stage
```

The helper verifies SHA-256 hashes of the three live Pi source files and staged copies. If the Pi files have changed since the archive was created, it stops without overwriting anything. It never calls ESP32 commands, restarts the POS/Kivy process or modifies the backend.

What the patch adds: bounded `remote_motor_recover_7` and `_10` for fresh R3 firmware reason codes 1/3/5; source-address, response-type and request-ID checks; separate correlated controller-result events. Inspected mechanical/electrical fault overrides and direct ESP32 restarts are NOT available from the Android app.

**Important**: The Pi must have the existing `RECOVERY_TOKEN_201` (or legacy `RECOVERY_TOKEN_R3`) in its secure environment. Do not paste it into chats. Firmware currently contains a hard-coded motor-maintenance credential; rotate it in a coordinated maintenance window and keep the UDP port restricted to LAN. Do not run the staged files or restart the live Kivy process until the transition/backup procedure is agreed.


## Updated backend -> Pi recovery contract

The existing backend command type remains `module_recovery`. The Pi command ACK still means received; final ESP/controller outcome is posted separately as a correlated backend event.

Current payload examples:

```json
{"request_id":"r-123","action":"status","panel_position":1}
```

```json
{"request_id":"r-124","action":"recover","panel_position":1,"motor":7,"inspected_hardware":false}
```

```json
{"request_id":"r-125","action":"reinit","panel_position":1,"motor":10,"inspected_hardware":true}
```

Supported R3 aliases: `status`, `stop`, `recover`, `start`, `reinit`, `quarantine`, `clear_fault`, `clear_global`, `recovery_status`, `resync`, `led_refresh`. Full `remote_motor_*` / `remote_recovery_*` names are also accepted. Legacy `remote_motor_recover_7` and `_10` remain compatible.

Credentials are loaded from `pi_recovery_endpoints.json`; ESP recovery tokens are never supplied by the backend command. Inspected recovery is disabled by default and requires `WA_ALLOW_BACKEND_INSPECTED_RECOVERY=1` on the Pi.
