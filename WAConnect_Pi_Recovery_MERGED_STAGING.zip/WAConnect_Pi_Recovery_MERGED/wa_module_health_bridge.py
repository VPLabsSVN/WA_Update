"""WA Connect Pi module-health bridge.

- Keeps sensor data separate by ESP source IP.
- Accepts current SHT3x packets immediately.
- Accepts R3 motor telemetry on UDP 48557 when firmware is upgraded.
- Produces backend-compatible component_statuses.module_health.
- Backend-triggered recovery uses the same per-controller JSON endpoint configuration as the local recovery CLI.
- R3 supports correlated safe and operator recovery commands; inspected overrides remain explicitly gated.
"""
from __future__ import annotations

import json
import os
import socket
import threading
import time
import uuid
from datetime import datetime, timezone

R3_STATUS_PORT = int(os.environ.get("WA_R3_STATUS_PORT", "48557"))
RECOVERY_CONFIG_FILE = os.environ.get(
    "WA_RECOVERY_CONFIG_FILE",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "pi_recovery_endpoints.json"),
)
SENSOR_STALE_SECONDS = float(os.environ.get("WA_SENSOR_STALE_SECONDS", "90"))
MOTOR_STALE_SECONDS = float(os.environ.get("WA_MOTOR_STALE_SECONDS", "90"))

SAFE_BACKEND_ACTIONS = frozenset({
    "remote_recovery_status",
    "remote_recovery_resync",
    "remote_recovery_led_refresh",
    "remote_motor_status",
    "remote_motor_stop",
    "remote_motor_quarantine",
    "remote_motor_recover_7",
    "remote_motor_recover_10",
})

R3_REMOTE_SAFE_REASONS = frozenset({1, 3, 5})

R3_GROUP_ACTIONS = frozenset({
    "remote_motor_recover",
    "remote_motor_start",
    "remote_motor_reinit",
    "remote_motor_quarantine",
    "remote_motor_clear_fault",
})

R3_INSPECTION_ALLOWED_ACTIONS = frozenset({
    "remote_motor_recover",
    "remote_motor_reinit",
    "remote_motor_clear_fault",
    "remote_motor_clear_global",
})

# Commands the mobile/backend path may issue without any physical-inspection
# attestation. Anything outside this set is local-maintenance only.
R3_BACKEND_REMOTE_ACTIONS = frozenset({
    "remote_recovery_status",
    "remote_recovery_resync",
    "remote_recovery_led_refresh",
    "remote_motor_status",
    "remote_motor_stop",
    "remote_motor_recover",
    "remote_motor_quarantine",
})

BACKEND_ACTION_ALIASES = {
    "status": "remote_motor_status",
    "motor_status": "remote_motor_status",
    "stop": "remote_motor_stop",
    "recover": "remote_motor_recover",
    "start": "remote_motor_start",
    "reinit": "remote_motor_reinit",
    "quarantine": "remote_motor_quarantine",
    "clear_fault": "remote_motor_clear_fault",
    "clear-fault": "remote_motor_clear_fault",
    "clear_global": "remote_motor_clear_global",
    "clear-global": "remote_motor_clear_global",
    "recovery_status": "remote_recovery_status",
    "resync": "remote_recovery_resync",
    "led_refresh": "remote_recovery_led_refresh",
    "led-refresh": "remote_recovery_led_refresh",
}

OPTIONAL_NUMERIC_FIELDS = {
    "fan_rpm": (0, 20000),
    "fan_pwm_pct": (0, 100),
    "uptime_s": (0, 10**9),
    "recovery_count": (0, 10**9),
}
OPTIONAL_BOOL_FIELDS = {
    "ethernet_ok", "i2c_ok", "mcp20_ok", "mcp21_ok", "mcp22_ok",
    "fan_ok", "heater_on", "cooler_on", "uv_on", "as5600_ok",
    "tmc_uart_ok", "maintenance_busy", "network_job_active",
}


class ModuleHealthBridge:
    def __init__(self):
        mapping = os.environ.get(
            "WA_SENSOR_POSITION_MAP",
            "192.168.1.200:0,192.168.1.201:1",
        ).strip()
        self.position_for_ip = {}
        for entry in mapping.split(","):
            entry = entry.strip()
            if not entry:
                continue
            ip, sep, pos = entry.rpartition(":")
            if not sep or not ip:
                raise ValueError("WA_SENSOR_POSITION_MAP must be IP:position,IP:position")
            pos = int(pos)
            if pos < -20 or pos > 20:
                raise ValueError("Invalid module position")
            self.position_for_ip[ip] = pos

        self.lock = threading.RLock()
        self.sensor = {}
        self.controller = {}
        self.motors = {}
        self.motor_listener_running = False

    @staticmethod
    def _number(packet, key, lo, hi):
        try:
            n = float(packet[key])
            return n if n == n and lo <= n <= hi else None
        except (TypeError, KeyError, ValueError):
            return None

    def record_sensor(self, ip: str, packet: dict):
        if ip not in self.position_for_ip or not isinstance(packet, dict):
            return
        online = self._number(packet, "online", 0, 20)
        value = {
            "temperature_c": self._number(packet, "temp_c", -50, 90) if online and online > 0 else None,
            "humidity_rh": self._number(packet, "hum_rh", 0, 100) if online and online > 0 else None,
            "sensors_online": int(online) if online is not None else None,
            "s44_online": bool(packet.get("s44_online")),
            "s45_online": bool(packet.get("s45_online")),
        }
        for key, (lo, hi) in OPTIONAL_NUMERIC_FIELDS.items():
            if key in packet:
                value[key] = self._number(packet, key, lo, hi)
        for key in OPTIONAL_BOOL_FIELDS:
            if key in packet:
                value[key] = bool(packet.get(key))
        for key in ("reset_reason", "last_error", "controller_state"):
            if key in packet:
                value[key] = str(packet.get(key) or "")[:160]
        with self.lock:
            self.sensor[ip] = (time.time(), value)

    def _status_listener(self):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("0.0.0.0", R3_STATUS_PORT))
                sock.settimeout(2.0)
                self.motor_listener_running = True
                while True:
                    try:
                        data, sender = sock.recvfrom(16384)
                    except socket.timeout:
                        continue
                    ip = sender[0]
                    if ip not in self.position_for_ip:
                        continue
                    try:
                        packet = json.loads(data.decode("utf-8"))
                    except (ValueError, UnicodeDecodeError):
                        continue
                    if not isinstance(packet, dict):
                        continue
                    expected_pos = self.position_for_ip[ip]
                    try:
                        packet_pos = int(packet.get("position", expected_pos))
                    except (TypeError, ValueError):
                        continue
                    if packet_pos != expected_pos:
                        continue
                    ptype = str(packet.get("type") or "")
                    if ptype == "r3_motor_status":
                        motors = packet.get("motors") or []
                        if not isinstance(motors, list):
                            continue
                        clean = [dict(m) for m in motors if isinstance(m, dict) and m.get("motor") in (7, 10)][:2]
                        controller = {
                            "uptime_s": packet.get("uptime_s"),
                            "idle_enabled": packet.get("idle_enabled"),
                            "global_fault": packet.get("global_fault"),
                            "has_fault": packet.get("has_fault"),
                            "maintenance_busy": packet.get("maintenance_busy"),
                            "network_job_active": packet.get("network_job_active"),
                            "event": packet.get("event"),
                        }
                        with self.lock:
                            now = time.time()
                            self.motors[ip] = (now, clean)
                            self.controller[ip] = (now, controller)
                    elif ptype in ("module_status", "controller_status"):
                        with self.lock:
                            self.controller[ip] = (time.time(), dict(packet))
        except OSError as exc:
            print("[MODULE_HEALTH] status listener not started:", exc)
        finally:
            self.motor_listener_running = False

    def start(self):
        if self.position_for_ip and not self.motor_listener_running:
            threading.Thread(target=self._status_listener, daemon=True, name="wa-module-health-status").start()

    @staticmethod
    def _issue(code, title, description, severity="warning", requires_inspection=False, recovery_action=None):
        row = {
            "code": str(code)[:60],
            "title": str(title)[:100],
            "description": str(description)[:500],
            "severity": "error" if severity == "error" else "warning",
            "requires_inspection": bool(requires_inspection),
        }
        if recovery_action:
            row["recovery_action"] = recovery_action
        return row

    def heartbeat_health(self) -> dict:
        now = time.time()
        result = {}
        with self.lock:
            sensors = dict(self.sensor)
            motors = dict(self.motors)
            controllers = dict(self.controller)

        for ip, pos in self.position_for_ip.items():
            sensor_time, sensor = sensors.get(ip, (0, {}))
            motor_time, motor_rows = motors.get(ip, (0, []))
            ctrl_time, _ctrl = controllers.get(ip, (0, {}))
            last = max(sensor_time, motor_time, ctrl_time)
            issues = []

            if not sensor_time:
                issues.append(self._issue("TELEMETRY_MISSING", "No sensor telemetry", "No sensor packet has been received from this module."))
            elif now - sensor_time > SENSOR_STALE_SECONDS:
                issues.append(self._issue("SENSOR_STALE", "No recent SHT3x measurements", "The last sensor packet is stale. Check controller, LAN and sensor wiring.", "warning", True))
            elif sensor.get("sensors_online") == 0:
                issues.append(self._issue("SENSOR_OFFLINE", "SHT3x sensors offline", "No SHT3x sensors are reporting.", "error", True))
            elif sensor.get("sensors_online") == 1:
                issues.append(self._issue("SENSOR_DEGRADED", "One SHT3x sensor offline", "Climate values are based on one sensor; inspect the second sensor.", "warning", True))

            checks = (
                ("ethernet_ok", "ETHERNET_FAULT", "Controller Ethernet/link problem"),
                ("i2c_ok", "I2C_FAULT", "Controller I2C bus problem"),
                ("mcp20_ok", "MCP20_FAULT", "MCP23017 0x20 unavailable"),
                ("mcp21_ok", "MCP21_FAULT", "MCP23017 0x21 unavailable"),
                ("mcp22_ok", "MCP22_FAULT", "MCP23017 0x22 unavailable"),
                ("fan_ok", "FAN_FAULT", "Fan/tachometer indicates a fan problem"),
                ("as5600_ok", "AS5600_FAULT", "AS5600 encoder problem"),
                ("tmc_uart_ok", "TMC_UART_FAULT", "TMC2209 UART communication problem"),
            )
            for field, code, title in checks:
                if sensor_time and field in sensor and sensor.get(field) is False:
                    issues.append(self._issue(code, title, title + ".", "error", True))

            if pos == 1:
                if motor_time and now - motor_time > MOTOR_STALE_SECONDS:
                    issues.append(self._issue("R3_STATUS_OUT_OF_SYNC", "R3 status updates stopped", "Motor telemetry is stale. A safe status resync can be requested.", "warning", False, "remote_recovery_resync"))
                elif sensor_time and not motor_time and now - sensor_time > MOTOR_STALE_SECONDS:
                    issues.append(self._issue("R3_STATUS_MISSING", "R3 motor telemetry missing", "R3 climate telemetry is live but motor-status telemetry has not been received.", "warning", False, "remote_recovery_resync"))
                elif motor_time:
                    for row in motor_rows:
                        if row.get("fault_latched"):
                            motor = row.get("motor")
                            fault = str(row.get("fault_name") or row.get("fault_reason") or "unknown")
                            try:
                                fault_reason = int(row.get("fault_reason") or 0)
                            except (ValueError, TypeError):
                                fault_reason = 0
                            # Do not offer a reset while the controller is busy or in a
                            # shared/global fault state. Source telemetry must be fresh.
                            safe = (
                                motor in (7, 10)
                                and fault_reason in R3_REMOTE_SAFE_REASONS
                                and not controllers.get(ip, (0, {}))[1].get("global_fault", False)
                                and not controllers.get(ip, (0, {}))[1].get("maintenance_busy", False)
                                and not controllers.get(ip, (0, {}))[1].get("network_job_active", False)
                            )
                            issues.append(self._issue(
                                f"R3_MOTOR_{motor}_FAULT", f"R3 motor {motor} fault",
                                f"Controller reports {fault}. " + ("A guarded recovery may be requested." if safe else "Physical inspection may be required before recovery."),
                                "error", not safe,
                                f"remote_motor_recover_{motor}" if safe else None,
                            ))

            result[str(pos)] = {
                "position": pos,
                "temperature_c": sensor.get("temperature_c") if sensor_time and now - sensor_time <= SENSOR_STALE_SECONDS else None,
                "humidity_rh": sensor.get("humidity_rh") if sensor_time and now - sensor_time <= SENSOR_STALE_SECONDS else None,
                "sensors_online": sensor.get("sensors_online") if sensor_time else None,
                "reported_at": datetime.fromtimestamp(last, timezone.utc).isoformat() if last else None,
                "issues": issues,
            }
        return result

    @staticmethod
    def _validate_request_id(request_id: str | None) -> str:
        if request_id is None:
            request_id = "pi-" + uuid.uuid4().hex
        if not isinstance(request_id, str) or not (1 <= len(request_id) <= 64):
            raise ValueError("Invalid recovery request ID")
        if not all(c.isascii() and (c.isalnum() or c in "_-") for c in request_id):
            raise ValueError("Invalid recovery request ID")
        return request_id

    @staticmethod
    def _load_recovery_config() -> dict:
        try:
            with open(RECOVERY_CONFIG_FILE, "r", encoding="utf-8") as fh:
                cfg = json.load(fh)
        except Exception as exc:
            raise ValueError(f"Unable to load recovery endpoint configuration: {exc}") from exc
        controllers = cfg.get("controllers") or {}
        if not isinstance(controllers, dict):
            raise ValueError("Recovery endpoint configuration has no controllers object")
        return cfg

    @staticmethod
    def _endpoint_for_controller(controller: str) -> dict:
        cfg = ModuleHealthBridge._load_recovery_config()
        endpoint = (cfg.get("controllers") or {}).get(str(controller or "").strip().lower())
        if not isinstance(endpoint, dict):
            raise ValueError(f"Recovery controller '{controller}' is not configured")
        ip = str(endpoint.get("ip") or "").strip()
        token = str(endpoint.get("token") or "").strip()
        try:
            port = int(endpoint["port"])
        except Exception as exc:
            raise ValueError(f"Invalid recovery UDP port for {controller}") from exc
        if not ip or len(token) < 24 or not (1 <= port <= 65535):
            raise ValueError(f"Incomplete recovery endpoint configuration for {controller}")
        return {"ip": ip, "port": port, "token": token}

    def _r3_local_safe_recovery_allowed(self, motor: int) -> None:
        target_ip = self._endpoint_for_controller("r3")["ip"]
        with self.lock:
            motor_time, motor_rows = self.motors.get(target_ip, (0, []))
            ctrl_time, ctrl = self.controller.get(target_ip, (0, {}))
        now = time.time()
        if (not motor_time or not ctrl_time or
                now - motor_time > MOTOR_STALE_SECONDS or
                now - ctrl_time > MOTOR_STALE_SECONDS or
                ctrl.get("global_fault") or ctrl.get("maintenance_busy") or
                ctrl.get("network_job_active")):
            raise ValueError("Fresh idle/healthy controller status required")
        for row in motor_rows:
            try:
                row_motor = int(row.get("motor"))
                reason = int(row.get("fault_reason") or 0)
            except (TypeError, ValueError):
                continue
            if row_motor == motor and row.get("fault_latched") is True and reason in R3_REMOTE_SAFE_REASONS:
                return
        raise ValueError("No locally verified software-recoverable motor fault")

    def send_operator_recovery(
        self,
        pos: int,
        action: str,
        motor: int | None = None,
        inspected_hardware: bool = False,
        *,
        request_id: str | None = None,
        controller: str = "r3",
    ) -> dict:
        request_id = self._validate_request_id(request_id)
        action = str(action or "").strip()
        controller = str(controller or "r3").strip().lower()

        endpoint = self._endpoint_for_controller(controller)
        target_ip = endpoint["ip"]
        target_port = endpoint["port"]
        token = endpoint["token"]

        if controller != "r3":
            raise ValueError("Operator motor recovery is currently supported only for R3")
        if int(pos) != 1:
            raise ValueError("R3 recovery requires panel_position=1")

        expected = [ip for ip, mapped in self.position_for_ip.items() if mapped == 1]
        if len(expected) != 1 or expected[0] != target_ip:
            raise ValueError("Configured R3 IP does not match the verified module mapping")

        allowed = {
            "remote_recovery_status",
            "remote_recovery_resync",
            "remote_recovery_led_refresh",
            "remote_motor_status",
            "remote_motor_stop",
            "remote_motor_recover",
            "remote_motor_start",
            "remote_motor_reinit",
            "remote_motor_quarantine",
            "remote_motor_clear_fault",
            "remote_motor_clear_global",
        }
        if action not in allowed:
            raise ValueError("Unsupported R3 recovery action")

        if action in R3_GROUP_ACTIONS:
            if motor not in (7, 10):
                raise ValueError("This recovery action requires motor 7 or 10")
        elif motor is not None:
            raise ValueError("This recovery action does not accept a motor argument")

        if inspected_hardware and action not in R3_INSPECTION_ALLOWED_ACTIONS:
            raise ValueError("inspected_hardware is not valid for this recovery action")

        payload = {
            "type": action,
            "request_id": request_id,
            "token": token,
        }
        if motor is not None:
            payload["motor"] = int(motor)
        if inspected_hardware:
            payload["inspected_hardware"] = True

        source_ip = str(self._load_recovery_config().get("pi_ip") or
                        os.environ.get("WA_PI_MANAGEMENT_IP", "192.168.1.100"))
        timeout_s = 35.0 if action.startswith("remote_motor_") and action != "remote_motor_status" else 7.0

        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(timeout_s)
            sock.bind((source_ip, 0))
            sock.sendto(json.dumps(payload).encode("utf-8"), (target_ip, target_port))
            deadline = time.monotonic() + timeout_s
            while time.monotonic() < deadline:
                sock.settimeout(max(0.1, deadline - time.monotonic()))
                try:
                    data, sender = sock.recvfrom(16384)
                except socket.timeout:
                    break
                if sender != (target_ip, target_port):
                    continue
                try:
                    ack = json.loads(data.decode("utf-8"))
                except (ValueError, UnicodeDecodeError):
                    continue
                if ack.get("request_id") != request_id:
                    continue
                if action.startswith("remote_motor_"):
                    if ack.get("type") != "remote_motor_ack":
                        continue
                elif ack.get("type") not in ("recovery_ack", "remote_recovery_ack"):
                    continue
                result = dict(ack)
                result.setdefault("ok", ack.get("ok") is True)
                result.update({
                    "request_id": request_id,
                    "action": action,
                    "motor": motor,
                    "position": int(pos),
                    "target_ip": target_ip,
                    "controller_state": "controller_accepted" if ack.get("ok") is True else "controller_rejected",
                    "rotation_verified": False,
                    "error_code": str(ack.get("error") or "")[:120],
                })
                return result
        raise TimeoutError("No matching recovery acknowledgement from " + target_ip)

    def send_maintenance_command(
        self,
        action: str,
        *,
        motor: int | None = None,
        inspected_hardware: bool = False,
        inspection_note: str = "",
        request_id: str | None = None,
    ) -> dict:
        """Local attended R3 maintenance path.

        This method is intentionally separate from the backend/mobile path.
        The CLI is responsible for requiring an interactive operator and the
        physical-inspection confirmation. The ESP32 still performs its own
        door/TMC/encoder/electrical safety preflight.
        """
        action = str(action or "").strip()
        allowed = frozenset({
            "remote_recovery_status",
            "remote_recovery_resync",
            "remote_recovery_led_refresh",
            "remote_motor_status",
            "remote_motor_stop",
            "remote_motor_recover",
            "remote_motor_start",
            "remote_motor_reinit",
            "remote_motor_quarantine",
            "remote_motor_clear_fault",
            "remote_motor_clear_global",
        })
        motor_actions = frozenset({
            "remote_motor_recover",
            "remote_motor_start",
            "remote_motor_reinit",
            "remote_motor_quarantine",
            "remote_motor_clear_fault",
        })
        inspection_eligible = R3_INSPECTION_ALLOWED_ACTIONS
        if action not in allowed:
            raise ValueError("Unsupported R3 maintenance action")
        if type(inspected_hardware) is not bool:
            raise ValueError("Inspection declaration must be boolean")
        if action in motor_actions:
            if type(motor) is not int or motor not in (7, 10):
                raise ValueError("This command requires motor 7 or 10")
        elif motor is not None:
            raise ValueError("Motor field is forbidden for this action")
        if inspected_hardware and action not in inspection_eligible:
            raise ValueError("Inspection declaration forbidden for this action")
        if action == "remote_motor_clear_global" and not inspected_hardware:
            raise ValueError("Global fault clearing requires physical inspection")
        if inspected_hardware:
            if not isinstance(inspection_note, str) or len(inspection_note.strip()) < 12:
                raise ValueError("A specific physical-inspection note is required")
        elif inspection_note:
            raise ValueError("Inspection note requires inspected_hardware=true")

        # Fresh controller-side status before operations that may start a motor
        # or clear a fault/latch. This is intentionally not based only on cache.
        preflight_actions = frozenset({
            "remote_motor_recover",
            "remote_motor_start",
            "remote_motor_reinit",
            "remote_motor_clear_fault",
            "remote_motor_clear_global",
        })
        if action in preflight_actions:
            status = self.send_operator_recovery(
                1,
                "remote_motor_status",
                request_id="pre-" + uuid.uuid4().hex,
                controller="r3",
            )
            if status.get("ok") is not True:
                raise ValueError("Controller refused preflight status request")
            if status.get("maintenance_busy") or status.get("network_job_active") or status.get("service_busy"):
                raise ValueError("Controller has an active maintenance, purchase or positioning job")
            rows = status.get("motors")
            if action == "remote_motor_clear_global":
                if status.get("global_fault") is not True:
                    raise ValueError("No current global fault to clear")
                if not isinstance(rows, list) or len(rows) != 2:
                    raise ValueError("Global clear requires both motor status rows")
                for row in rows:
                    if not isinstance(row, dict):
                        raise ValueError("Invalid controller motor status")
                    if row.get("door_closed_verified") is not True or row.get("door_cycle_pending") is True:
                        raise ValueError("Global clear requires both doors confirmed closed with no pending access")
            else:
                if status.get("global_fault") is True:
                    raise ValueError("Global motor fault must be resolved separately")
                row = next((r for r in rows or [] if isinstance(r, dict) and r.get("motor") == motor), None)
                if not row:
                    raise ValueError("Controller omitted target motor status")
                if row.get("door_cycle_pending") is True:
                    raise ValueError("Pending customer door cycle prevents recovery")
                if row.get("door_closed_verified") is not True:
                    raise ValueError("Controller cannot confirm the selected motor door is closed")
                latched = row.get("fault_latched") is True
                try:
                    reason = int(row.get("fault_reason") or 0)
                except (TypeError, ValueError):
                    reason = -1
                if latched and reason in (2, 4, 6, 7) and not inspected_hardware:
                    raise ValueError("This mechanical/electrical fault requires physical inspection")
                if action == "remote_motor_start" and latched:
                    raise ValueError("Start cannot clear a latched motor fault; use recovery first")

        result = self.send_operator_recovery(
            1,
            action,
            motor=motor,
            inspected_hardware=inspected_hardware,
            request_id=request_id,
            controller="r3",
        )
        result = dict(result or {})
        result["inspection_note_supplied"] = bool(inspection_note.strip())
        return result

    def send_backend_recovery(
        self,
        pos: int,
        action: str,
        *,
        request_id: str | None = None,
        motor: int | None = None,
        inspected_hardware: bool = False,
    ) -> dict:
        """Remote/mobile recovery path: never accepts physical inspection.

        The backend may request status, stop/quarantine, resync/LED refresh, and
        bounded recovery for software-safe fault reasons 1/3/5. Inspection-
        required maintenance is deliberately local-Pi only.
        """
        if inspected_hardware:
            raise ValueError(
                "Physical-inspection recovery is local-Pi maintenance only"
            )
        raw_action = str(action or "").strip()
        normalized = BACKEND_ACTION_ALIASES.get(raw_action, raw_action)

        # Backward compatibility with the first Android/backend contract.
        if raw_action == "remote_motor_recover_7":
            normalized, motor = "remote_motor_recover", 7
        elif raw_action == "remote_motor_recover_10":
            normalized, motor = "remote_motor_recover", 10

        if normalized not in R3_BACKEND_REMOTE_ACTIONS:
            raise ValueError(
                "This R3 maintenance action requires local Pi operator access"
            )

        if normalized in ("remote_motor_recover", "remote_motor_quarantine"):
            if motor not in (7, 10):
                raise ValueError("This backend action requires motor 7 or 10")
        elif motor is not None:
            raise ValueError("This backend action does not accept a motor")

        # Remote recovery is intentionally limited to fresh software-safe
        # reasons 1/3/5. Mechanical/electrical reasons 2/4/6/7 never cross
        # the mobile/backend inspection boundary.
        if normalized == "remote_motor_recover":
            self._r3_local_safe_recovery_allowed(int(motor))

        return self.send_operator_recovery(
            int(pos),
            normalized,
            motor=motor,
            inspected_hardware=False,
            request_id=request_id,
            controller="r3",
        )

    def send_safe_recovery(self, pos: int, action: str, *, request_id: str | None = None) -> dict:
        if action not in SAFE_BACKEND_ACTIONS:
            raise ValueError("Backend action is not allowed by the current safe recovery policy")
        return self.send_backend_recovery(
            int(pos),
            action,
            request_id=request_id,
            inspected_hardware=False,
        )

