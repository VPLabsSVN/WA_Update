#!/usr/bin/env python3
"""Read-only validation and staging of exact Pi recovery source; never restart services."""
import argparse,hashlib,json,pathlib,py_compile,shutil,sys
ROOT=pathlib.Path('/home/wa_stopshop_mb/WA/Main_program/Fis')
HERE=pathlib.Path(__file__).resolve().parent
TABLE=json.loads((HERE/'source_fingerprints.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(stage=False):
 for fn,expected in TABLE['original'].items():
  f=ROOT/fn
  if not f.is_file() or sha(f)!=expected:raise RuntimeError('LIVE SOURCE HAS CHANGED: '+fn+'; no copy performed')
 for fn,expected in TABLE['staged'].items():
  f=HERE/fn
  if not f.is_file() or sha(f)!=expected:raise RuntimeError('Package hash mismatch: '+fn)
  py_compile.compile(str(f),doraise=True)
 print('PASS: all 3 original Pi files match the supplied archive; patch files compile and match their hashes')
 if not stage:return
 dest=ROOT/'.wa_recovery_v2_staging'
 if dest.exists():raise RuntimeError('Staging directory already exists; refusing to overwrite')
 dest.mkdir(mode=0o700)
 try:
  for fn in TABLE['staged']:
   shutil.copy2(HERE/fn,dest/fn)
   if sha(dest/fn)!=TABLE['staged'][fn]:raise RuntimeError('Copy verification failed')
 except BaseException:
  shutil.rmtree(dest);raise
 print('PASS: staged code at '+str(dest)+'; live Pi files and services NOT changed')
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true');parser.add_argument('--stage',action='store_true')
 args=parser.parse_args()
 if args.check==args.stage:parser.error('Choose exactly one of --check or --stage')
 try:run(args.stage)
 except (RuntimeError,OSError,ValueError,py_compile.PyCompileError) as exc:print('STOP:',exc,file=sys.stderr);sys.exit(1)
