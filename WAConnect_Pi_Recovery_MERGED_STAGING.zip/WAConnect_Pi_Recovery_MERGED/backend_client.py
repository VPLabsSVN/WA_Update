from __future__ import annotations

import socket
from typing import Any

import requests


class PanelBackendClient:
    def __init__(
        self,
        *,
        base_url: str,
        panel_id: str,
        panel_name: str,
        panel_type: str,
        position: int,
        software_version: str = "0.1.0",
        panel_key: str = "",
        timeout: float = 5.0,
    ):
        self.base_url = base_url.rstrip("/")
        self.panel_id = panel_id
        self.panel_name = panel_name
        self.panel_type = panel_type
        self.position = int(position)
        self.software_version = software_version
        self.panel_key = panel_key or ""
        self.timeout = float(timeout)
        self.last_command_version = 0
        self.session = requests.Session()

    @property
    def headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.panel_key:
            headers["X-Panel-Key"] = self.panel_key
        return headers

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _local_ip(self) -> str:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.connect(("8.8.8.8", 80))
            ip = sock.getsockname()[0]
            sock.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def register(self) -> dict[str, Any]:
        payload = {
            "panel_id": self.panel_id,
            "panel_name": self.panel_name,
            "panel_type": self.panel_type,
            "position": self.position,
            "local_ip": self._local_ip(),
            "software_version": self.software_version,
        }
        r = self.session.post(
            self._url("/api/panels/register"),
            json=payload,
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def heartbeat(
        self,
        *,
        status: str = "online",
        current_screen: str | None = None,
        cart_count: int = 0,
        payment_terminal_ready: bool = False,
    ) -> dict[str, Any]:
        payload = {
            "status": status,
            "current_screen": current_screen,
            "cart_count": int(cart_count),
            "payment_terminal_ready": bool(payment_terminal_ready),
        }
        r = self.session.post(
            self._url(f"/api/panels/{self.panel_id}/heartbeat"),
            json=payload,
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def get_config(self) -> dict[str, Any]:
        r = self.session.get(
            self._url(f"/api/panels/{self.panel_id}/config"),
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def sync_items(self, items: list[dict[str, Any]], *, replace_missing: bool = True) -> dict[str, Any]:
        payload = {
            "replace_missing": bool(replace_missing),
            "items": [
                {
                    "item_id": int(it["id"]),
                    "label": str(it.get("label", it["id"])),
                    "price": float(it.get("price", 0.0)),
                    "tax_pct": float(it.get("tax_pct", 0.0)),
                    "enabled": bool(it.get("enabled", True)),
                }
                for it in items
                if it is not None and it.get("id") is not None
            ],
        }
        r = self.session.post(
            self._url(f"/api/panels/{self.panel_id}/items/sync"),
            json=payload,
            headers=self.headers,
            timeout=max(self.timeout, 10.0),
        )
        r.raise_for_status()
        return r.json()

    def post_event(self, event_type: str, *, severity: str = "info", payload: dict[str, Any] | None = None) -> dict[str, Any]:
        body = {
            "panel_id": self.panel_id,
            "event_type": event_type,
            "severity": severity,
            "payload": payload or {},
        }
        r = self.session.post(
            self._url("/api/events"),
            json=body,
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def post_sale(
        self,
        *,
        invoice_number: str,
        issue_datetime_iso: str,
        total_amount: float,
        payment_status: str,
        fiscal_status: str,
        items: list[dict[str, Any]],
        currency: str = "EUR",
    ) -> dict[str, Any]:
        body = {
            "panel_id": self.panel_id,
            "invoice_number": invoice_number,
            "issue_datetime_iso": issue_datetime_iso,
            "currency": currency,
            "total_amount": float(total_amount),
            "payment_status": payment_status,
            "fiscal_status": fiscal_status,
            "items": [
                {
                    "item_id": int(it["id"]),
                    "panel_position": int(it.get("panel_position", self.position)),
                    "label": str(it.get("label", it["id"])),
                    "quantity": int(it.get("quantity", 1)),
                    "unit_price": float(it.get("price", 0.0)),
                    "tax_pct": float(it.get("tax_pct", 0.0)),
                }
                for it in items
                if it is not None and it.get("id") is not None
            ],
        }
        r = self.session.post(
            self._url("/api/sales"),
            json=body,
            headers=self.headers,
            timeout=max(self.timeout, 10.0),
        )
        r.raise_for_status()
        return r.json()

    def post_door_event(
        self,
        *,
        item_id: int,
        panel_position: int,
        action: str,
        success: bool,
        error_text: str | None = None,
    ) -> dict[str, Any]:
        body = {
            "panel_id": self.panel_id,
            "item_id": int(item_id),
            "panel_position": int(panel_position),
            "action": action,
            "success": bool(success),
            "error_text": error_text,
        }
        r = self.session.post(
            self._url("/api/door-events"),
            json=body,
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def poll_commands(self) -> dict[str, Any]:
        r = self.session.get(
            self._url(f"/api/panels/{self.panel_id}/commands"),
            params={"since_version": int(self.last_command_version)},
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        data = r.json()
        self.last_command_version = int(data.get("latest_version", self.last_command_version) or self.last_command_version)
        return data

    def ack_commands(self, versions: list[int]) -> dict[str, Any]:
        body = {"command_versions": [int(v) for v in versions]}
        r = self.session.post(
            self._url(f"/api/panels/{self.panel_id}/commands/ack"),
            json=body,
            headers=self.headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()
