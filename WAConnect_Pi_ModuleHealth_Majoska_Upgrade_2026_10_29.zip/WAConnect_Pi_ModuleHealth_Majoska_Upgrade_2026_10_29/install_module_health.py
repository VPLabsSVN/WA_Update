#!/usr/bin/env python3
from pathlib import Path
import argparse
import datetime
import os
import secrets
import shutil
import subprocess
import sys

ap = argparse.ArgumentParser()
ap.add_argument("--directory", default="/home/wa_stopshop_mb/WA/Main_program/Fis")
ap.add_argument("--apply", action="store_true")
args = ap.parse_args()

root = Path(args.directory)
panel = root / "Panel.py"
backend = root / "Panel_backend_merged.py"
bridge_src = Path(__file__).with_name("wa_module_health_bridge.py")
for f in (panel, backend, bridge_src):
    if not f.exists():
        raise SystemExit(f"Missing required file: {f}")

a = panel.read_text(encoding="utf-8")
b = backend.read_text(encoding="utf-8")

if "self._module_monitor = ModuleHealthBridge()" not in a:
    needle = "        self._esp_sensor_last_ts = 0.0\n"
    if a.count(needle) != 1:
        raise SystemExit(f"REFUSED: expected one sensor init hook, found {a.count(needle)}")
    a = a.replace(needle, needle +
        "        # Per-controller health cache / future ESP diagnostics.\n"
        "        from wa_module_health_bridge import ModuleHealthBridge\n"
        "        self._module_monitor = ModuleHealthBridge()\n"
        "        self._module_monitor.start()\n", 1)
else:
    print("Panel.py monitor initialization already present")

needle = "                self._esp_sensor_last_ts = time.time()\n"
if "self._module_monitor.record_sensor(addr[0], payload)" not in a:
    if a.count(needle) != 1:
        raise SystemExit(f"REFUSED: expected one sensor receive hook, found {a.count(needle)}")
    a = a.replace(needle, needle +
        "                try:\n"
        "                    self._module_monitor.record_sensor(addr[0], payload)\n"
        "                except Exception as exc:\n"
        "                    print(\"[MODULE_HEALTH] sensor cache error:\", exc)\n", 1)
else:
    print("Panel.py sensor record hook already present")

if 'statuses["module_health"] = monitor.heartbeat_health()' not in b:
    needle = "        return statuses\n"
    idx = b.find(needle)
    if idx < 0:
        raise SystemExit("REFUSED: heartbeat return hook not found")
    replacement = (
        "        monitor = getattr(self, \"_module_monitor\", None)\n"
        "        if monitor is not None:\n"
        "            try:\n"
        "                statuses[\"module_health\"] = monitor.heartbeat_health()\n"
        "            except Exception as exc:\n"
        "                print(\"[MODULE_HEALTH] heartbeat build error:\", exc)\n\n"
        "        return statuses\n"
    )
    b = b[:idx] + replacement + b[idx + len(needle):]
else:
    print("Backend heartbeat hook already present")

if 'elif command_type == "module_recovery":' not in b:
    needle = '        elif command_type == "side_panel_refresh":\n'
    if b.count(needle) != 1:
        raise SystemExit(f"REFUSED: expected one command hook, found {b.count(needle)}")
    block = '''        elif command_type == "module_recovery":
            # Current backend contract permits only safe R3 resync/LED refresh.
            def run_module_recovery():
                try:
                    monitor = getattr(self, "_module_monitor", None)
                    if monitor is None:
                        raise RuntimeError("Module health bridge unavailable")
                    result = monitor.send_safe_recovery(
                        int(payload.get("panel_position")),
                        str(payload.get("action") or ""),
                    )
                    self.backend_post_event_async(
                        "module_recovery_applied" if result.get("ok") else "module_recovery_failed",
                        severity="info" if result.get("ok") else "warning",
                        payload=result,
                    )
                    print("[MODULE_HEALTH] backend recovery", result.get("action"), "ok=", bool(result.get("ok")))
                except Exception as exc:
                    try:
                        self.backend_post_event_async(
                            "module_recovery_failed",
                            severity="warning",
                            payload={
                                "panel_position": payload.get("panel_position"),
                                "action": payload.get("action"),
                                "error": str(exc)[:150],
                            },
                        )
                    except Exception:
                        pass
                    print("[MODULE_HEALTH] recovery request failed:", exc)
            threading.Thread(target=run_module_recovery, daemon=True, name="module-recovery").start()

        elif command_type == "side_panel_refresh":
'''
    b = b.replace(needle, block, 1)
else:
    print("Backend module_recovery handler already present")

compile(a, str(panel), "exec")
compile(b, str(backend), "exec")
compile(bridge_src.read_text(encoding="utf-8"), str(bridge_src), "exec")
print("PASS: candidate Panel.py, Panel_backend_merged.py and bridge compile")

if not args.apply:
    print("DRY RUN ONLY: no files changed")
    print("Run again with --apply after reviewing this result.")
    sys.exit(0)

stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup = root / f"module-health-backup-{stamp}"
backup.mkdir(mode=0o700)
shutil.copy2(panel, backup / panel.name)
shutil.copy2(backend, backup / backend.name)
shutil.copy2(bridge_src, root / "wa_module_health_bridge.py")
panel.write_text(a, encoding="utf-8")
backend.write_text(b, encoding="utf-8")

env_dir = Path.home() / ".config"
env_dir.mkdir(parents=True, exist_ok=True)
env_file = env_dir / "bouquetmat-health.env"
token = None
if env_file.exists():
    for line in env_file.read_text(encoding="utf-8").splitlines():
        if line.startswith("RECOVERY_TOKEN_R3="):
            token = line.split("=", 1)[1].strip()
            break
if not token or len(token) < 24:
    token = secrets.token_urlsafe(36)

env_text = f"""WA_MODULE_HEALTH_ENABLED=1
WA_SENSOR_POSITION_MAP=192.168.1.200:0,192.168.1.201:1
WA_PI_MANAGEMENT_IP=192.168.1.100
WA_R3_STATUS_PORT=48557
WA_R3_RECOVERY_PORT=48556
WA_SENSOR_STALE_SECONDS=90
WA_MOTOR_STALE_SECONDS=90
RECOVERY_TOKEN_R3={token}
"""
env_file.write_text(env_text, encoding="utf-8")
os.chmod(env_file, 0o600)

dropin_dir = Path.home() / ".config/systemd/user/bouquetmat.service.d"
dropin_dir.mkdir(parents=True, exist_ok=True)
dropin = dropin_dir / "98-module-health.conf"
dropin.write_text("[Service]\n" + f"EnvironmentFile=-{env_file}\n", encoding="utf-8")
subprocess.run(["systemctl", "--user", "daemon-reload"], check=True)

print("PASS: module health upgrade installed")
print("Backup:", backup)
print("Bridge:", root / "wa_module_health_bridge.py")
print("Private environment:", env_file)
print("Systemd drop-in:", dropin)
print("IMPORTANT: recovery token was NOT printed.")
print("Use the same RECOVERY_TOKEN_R3 value when configuring the future R3 firmware.")
print("Restart bouquetmat.service only when ready to activate the change.")
