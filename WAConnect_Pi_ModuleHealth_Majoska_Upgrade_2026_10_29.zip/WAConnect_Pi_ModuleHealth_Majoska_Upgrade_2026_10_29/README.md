# Majoska Pi module-health upgrade

Tailored mapping:
- Pi `192.168.1.100`
- Main ESP `192.168.1.200` -> position `0`
- R3 ESP `192.168.1.201` -> position `1`
- sensor UDP `5000`
- future R3 status UDP `48557`
- R3 recovery UDP `48556`

The current backend policy authorizes only `remote_recovery_resync` and
`remote_recovery_led_refresh`. The included local `wa_recovery_cli.py` supports
the broader existing authenticated R3 maintenance protocol over SSH/Pi.

## Install

```bash
cd /home/wa_stopshop_mb/WA/Main_program/Fis
python3 /path/to/install_module_health.py --directory "$PWD"
```

The first run is dry-run. If PASS:

```bash
python3 /path/to/install_module_health.py --directory "$PWD" --apply
./venv/bin/python /path/to/offline_contract_check.py "$PWD"
systemctl --user restart bouquetmat.service
systemctl --user status bouquetmat.service --no-pager -l
```

Verify:

```bash
journalctl --user -u bouquetmat.service --since "5 minutes ago" --no-pager \
  | grep -Ei 'MODULE_HEALTH|ESP|heartbeat|command'
```

The installer creates `~/.config/bouquetmat-health.env` mode `0600` and a
private `RECOVERY_TOKEN_R3`; it does not print the token. Use that same token
when configuring the future R3 firmware.
