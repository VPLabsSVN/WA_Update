#!/usr/bin/env python3
import argparse
import json
import os
import socket
import uuid

READ_ONLY = {"remote_recovery_status", "remote_motor_status"}
SAFE = {"remote_recovery_resync", "remote_recovery_led_refresh", "remote_motor_stop", "remote_motor_quarantine"}
INSPECTION_REQUIRED = {"remote_motor_reinit", "remote_motor_recover", "remote_motor_clear_fault", "remote_motor_clear_global"}
ALL = READ_ONLY | SAFE | INSPECTION_REQUIRED | {"remote_motor_start"}

p = argparse.ArgumentParser()
p.add_argument("action", choices=sorted(ALL))
p.add_argument("--ip", default="192.168.1.201")
p.add_argument("--port", type=int, default=48556)
p.add_argument("--motor", type=int, choices=(7, 10))
p.add_argument("--inspected-hardware", action="store_true")
p.add_argument("--timeout", type=float, default=8.0)
args = p.parse_args()

if args.action in {"remote_motor_quarantine", "remote_motor_reinit", "remote_motor_recover", "remote_motor_start", "remote_motor_clear_fault"} and args.motor is None:
    raise SystemExit("--motor 7 or --motor 10 is required for this action")
if args.action in INSPECTION_REQUIRED and not args.inspected_hardware:
    raise SystemExit("REFUSED: this action requires --inspected-hardware after physical inspection")

token = os.environ.get("RECOVERY_TOKEN_R3", "")
if len(token) < 24:
    env = os.path.expanduser("~/.config/bouquetmat-health.env")
    if os.path.exists(env):
        for line in open(env, encoding="utf-8"):
            if line.startswith("RECOVERY_TOKEN_R3="):
                token = line.split("=", 1)[1].strip()
                break
if len(token) < 24:
    raise SystemExit("RECOVERY_TOKEN_R3 is not configured")

payload = {"type": args.action, "request_id": "pi-cli-" + uuid.uuid4().hex, "token": token}
if args.motor is not None and args.action != "remote_motor_clear_global":
    payload["motor"] = args.motor
if args.action in INSPECTION_REQUIRED:
    payload["inspected_hardware"] = True

source_ip = os.environ.get("WA_PI_MANAGEMENT_IP", "192.168.1.100")
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
    s.settimeout(args.timeout)
    s.bind((source_ip, 0))
    s.sendto(json.dumps(payload).encode(), (args.ip, args.port))
    while True:
        data, sender = s.recvfrom(16384)
        if sender[0] != args.ip:
            continue
        try:
            ack = json.loads(data.decode())
        except Exception:
            continue
        if ack.get("request_id") == payload["request_id"]:
            ack.pop("token", None)
            print(json.dumps(ack, indent=2))
            break
