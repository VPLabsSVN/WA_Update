"""WA Connect Pi module-health bridge.

- Keeps sensor data separate by ESP source IP.
- Accepts current SHT3x packets immediately.
- Accepts R3 motor telemetry on UDP 48557 when firmware is upgraded.
- Produces backend-compatible component_statuses.module_health.
- Backend-triggered recovery is deliberately limited to safe resync/LED refresh.
"""
from __future__ import annotations

import json
import os
import socket
import threading
import time
import uuid
from datetime import datetime, timezone

R3_STATUS_PORT = int(os.environ.get("WA_R3_STATUS_PORT", "48557"))
R3_RECOVERY_PORT = int(os.environ.get("WA_R3_RECOVERY_PORT", "48556"))
SENSOR_STALE_SECONDS = float(os.environ.get("WA_SENSOR_STALE_SECONDS", "90"))
MOTOR_STALE_SECONDS = float(os.environ.get("WA_MOTOR_STALE_SECONDS", "90"))

SAFE_BACKEND_ACTIONS = frozenset({
    "remote_recovery_resync",
    "remote_recovery_led_refresh",
})

OPTIONAL_NUMERIC_FIELDS = {
    "fan_rpm": (0, 20000),
    "fan_pwm_pct": (0, 100),
    "uptime_s": (0, 10**9),
    "recovery_count": (0, 10**9),
}
OPTIONAL_BOOL_FIELDS = {
    "ethernet_ok", "i2c_ok", "mcp20_ok", "mcp21_ok", "mcp22_ok",
    "fan_ok", "heater_on", "cooler_on", "uv_on", "as5600_ok",
    "tmc_uart_ok", "maintenance_busy", "network_job_active",
}


class ModuleHealthBridge:
    def __init__(self):
        mapping = os.environ.get(
            "WA_SENSOR_POSITION_MAP",
            "192.168.1.200:0,192.168.1.201:1",
        ).strip()
        self.position_for_ip = {}
        for entry in mapping.split(","):
            entry = entry.strip()
            if not entry:
                continue
            ip, sep, pos = entry.rpartition(":")
            if not sep or not ip:
                raise ValueError("WA_SENSOR_POSITION_MAP must be IP:position,IP:position")
            pos = int(pos)
            if pos < -20 or pos > 20:
                raise ValueError("Invalid module position")
            self.position_for_ip[ip] = pos

        self.lock = threading.RLock()
        self.sensor = {}
        self.controller = {}
        self.motors = {}
        self.motor_listener_running = False

    @staticmethod
    def _number(packet, key, lo, hi):
        try:
            n = float(packet[key])
            return n if n == n and lo <= n <= hi else None
        except (TypeError, KeyError, ValueError):
            return None

    def record_sensor(self, ip: str, packet: dict):
        if ip not in self.position_for_ip or not isinstance(packet, dict):
            return
        online = self._number(packet, "online", 0, 20)
        value = {
            "temperature_c": self._number(packet, "temp_c", -50, 90) if online and online > 0 else None,
            "humidity_rh": self._number(packet, "hum_rh", 0, 100) if online and online > 0 else None,
            "sensors_online": int(online) if online is not None else None,
            "s44_online": bool(packet.get("s44_online")),
            "s45_online": bool(packet.get("s45_online")),
        }
        for key, (lo, hi) in OPTIONAL_NUMERIC_FIELDS.items():
            if key in packet:
                value[key] = self._number(packet, key, lo, hi)
        for key in OPTIONAL_BOOL_FIELDS:
            if key in packet:
                value[key] = bool(packet.get(key))
        for key in ("reset_reason", "last_error", "controller_state"):
            if key in packet:
                value[key] = str(packet.get(key) or "")[:160]
        with self.lock:
            self.sensor[ip] = (time.time(), value)

    def _status_listener(self):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("0.0.0.0", R3_STATUS_PORT))
                sock.settimeout(2.0)
                self.motor_listener_running = True
                while True:
                    try:
                        data, sender = sock.recvfrom(16384)
                    except socket.timeout:
                        continue
                    ip = sender[0]
                    if ip not in self.position_for_ip:
                        continue
                    try:
                        packet = json.loads(data.decode("utf-8"))
                    except (ValueError, UnicodeDecodeError):
                        continue
                    if not isinstance(packet, dict):
                        continue
                    expected_pos = self.position_for_ip[ip]
                    try:
                        packet_pos = int(packet.get("position", expected_pos))
                    except (TypeError, ValueError):
                        continue
                    if packet_pos != expected_pos:
                        continue
                    ptype = str(packet.get("type") or "")
                    if ptype == "r3_motor_status":
                        motors = packet.get("motors") or []
                        if not isinstance(motors, list):
                            continue
                        clean = [dict(m) for m in motors if isinstance(m, dict) and m.get("motor") in (7, 10)][:2]
                        controller = {
                            "uptime_s": packet.get("uptime_s"),
                            "idle_enabled": packet.get("idle_enabled"),
                            "global_fault": packet.get("global_fault"),
                            "has_fault": packet.get("has_fault"),
                            "maintenance_busy": packet.get("maintenance_busy"),
                            "network_job_active": packet.get("network_job_active"),
                            "event": packet.get("event"),
                        }
                        with self.lock:
                            now = time.time()
                            self.motors[ip] = (now, clean)
                            self.controller[ip] = (now, controller)
                    elif ptype in ("module_status", "controller_status"):
                        with self.lock:
                            self.controller[ip] = (time.time(), dict(packet))
        except OSError as exc:
            print("[MODULE_HEALTH] status listener not started:", exc)
        finally:
            self.motor_listener_running = False

    def start(self):
        if self.position_for_ip and not self.motor_listener_running:
            threading.Thread(target=self._status_listener, daemon=True, name="wa-module-health-status").start()

    @staticmethod
    def _issue(code, title, description, severity="warning", requires_inspection=False, recovery_action=None):
        row = {
            "code": str(code)[:60],
            "title": str(title)[:100],
            "description": str(description)[:500],
            "severity": "error" if severity == "error" else "warning",
            "requires_inspection": bool(requires_inspection),
        }
        if recovery_action:
            row["recovery_action"] = recovery_action
        return row

    def heartbeat_health(self) -> dict:
        now = time.time()
        result = {}
        with self.lock:
            sensors = dict(self.sensor)
            motors = dict(self.motors)
            controllers = dict(self.controller)

        for ip, pos in self.position_for_ip.items():
            sensor_time, sensor = sensors.get(ip, (0, {}))
            motor_time, motor_rows = motors.get(ip, (0, []))
            ctrl_time, _ctrl = controllers.get(ip, (0, {}))
            last = max(sensor_time, motor_time, ctrl_time)
            issues = []

            if not sensor_time:
                issues.append(self._issue("TELEMETRY_MISSING", "No sensor telemetry", "No sensor packet has been received from this module."))
            elif now - sensor_time > SENSOR_STALE_SECONDS:
                issues.append(self._issue("SENSOR_STALE", "No recent SHT3x measurements", "The last sensor packet is stale. Check controller, LAN and sensor wiring.", "warning", True))
            elif sensor.get("sensors_online") == 0:
                issues.append(self._issue("SENSOR_OFFLINE", "SHT3x sensors offline", "No SHT3x sensors are reporting.", "error", True))
            elif sensor.get("sensors_online") == 1:
                issues.append(self._issue("SENSOR_DEGRADED", "One SHT3x sensor offline", "Climate values are based on one sensor; inspect the second sensor.", "warning", True))

            checks = (
                ("ethernet_ok", "ETHERNET_FAULT", "Controller Ethernet/link problem"),
                ("i2c_ok", "I2C_FAULT", "Controller I2C bus problem"),
                ("mcp20_ok", "MCP20_FAULT", "MCP23017 0x20 unavailable"),
                ("mcp21_ok", "MCP21_FAULT", "MCP23017 0x21 unavailable"),
                ("mcp22_ok", "MCP22_FAULT", "MCP23017 0x22 unavailable"),
                ("fan_ok", "FAN_FAULT", "Fan/tachometer indicates a fan problem"),
                ("as5600_ok", "AS5600_FAULT", "AS5600 encoder problem"),
                ("tmc_uart_ok", "TMC_UART_FAULT", "TMC2209 UART communication problem"),
            )
            for field, code, title in checks:
                if sensor_time and field in sensor and sensor.get(field) is False:
                    issues.append(self._issue(code, title, title + ".", "error", True))

            if pos == 1:
                if motor_time and now - motor_time > MOTOR_STALE_SECONDS:
                    issues.append(self._issue("R3_STATUS_OUT_OF_SYNC", "R3 status updates stopped", "Motor telemetry is stale. A safe status resync can be requested.", "warning", False, "remote_recovery_resync"))
                elif sensor_time and not motor_time and now - sensor_time > MOTOR_STALE_SECONDS:
                    issues.append(self._issue("R3_STATUS_MISSING", "R3 motor telemetry missing", "R3 climate telemetry is live but motor-status telemetry has not been received.", "warning", False, "remote_recovery_resync"))
                elif motor_time:
                    for row in motor_rows:
                        if row.get("fault_latched"):
                            motor = row.get("motor")
                            fault = str(row.get("fault_name") or row.get("fault_reason") or "unknown")
                            issues.append(self._issue(f"R3_MOTOR_{motor}_FAULT", f"R3 motor {motor} fault", f"Controller reports {fault}. Physical inspection may be required before motor recovery.", "error", True))

            result[str(pos)] = {
                "position": pos,
                "temperature_c": sensor.get("temperature_c") if sensor_time and now - sensor_time <= SENSOR_STALE_SECONDS else None,
                "humidity_rh": sensor.get("humidity_rh") if sensor_time and now - sensor_time <= SENSOR_STALE_SECONDS else None,
                "sensors_online": sensor.get("sensors_online") if sensor_time else None,
                "reported_at": datetime.fromtimestamp(last, timezone.utc).isoformat() if last else None,
                "issues": issues,
            }
        return result

    def send_safe_recovery(self, pos: int, action: str) -> dict:
        if action not in SAFE_BACKEND_ACTIONS:
            raise ValueError("Backend action is not allowed by the current safe recovery policy")
        addresses = [ip for ip, p in self.position_for_ip.items() if p == int(pos)]
        if len(addresses) != 1:
            raise ValueError("Module position requires exactly one verified IP mapping")
        if int(pos) != 1:
            raise ValueError("Current backend recovery contract supports the R3 side module only")
        token = os.environ.get("RECOVERY_TOKEN_R3", "")
        if len(token) < 24:
            raise ValueError("RECOVERY_TOKEN_R3 is not configured")
        request_id = "pi-" + uuid.uuid4().hex
        payload = {"type": action, "request_id": request_id, "token": token}
        source_ip = os.environ.get("WA_PI_MANAGEMENT_IP", "192.168.1.100")
        target_ip = addresses[0]
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(7.0)
            sock.bind((source_ip, 0))
            sock.sendto(json.dumps(payload).encode("utf-8"), (target_ip, R3_RECOVERY_PORT))
            deadline = time.time() + 7.0
            while time.time() < deadline:
                data, sender = sock.recvfrom(16384)
                if sender[0] != target_ip:
                    continue
                try:
                    ack = json.loads(data.decode("utf-8"))
                except (ValueError, UnicodeDecodeError):
                    continue
                if ack.get("request_id") == request_id:
                    return {
                        "ok": ack.get("ok") is True,
                        "action": action,
                        "position": int(pos),
                        "error": str(ack.get("error") or "")[:150],
                    }
        raise TimeoutError("No matching recovery acknowledgement")
