#!/usr/bin/env python3
from pathlib import Path
import py_compile
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else "/home/wa_stopshop_mb/WA/Main_program/Fis")
for name in ("Panel.py", "Panel_backend_merged.py", "wa_module_health_bridge.py"):
    p = root / name
    if not p.exists():
        raise SystemExit(f"MISSING: {p}")
    py_compile.compile(str(p), doraise=True)
    print("COMPILE OK:", p)
panel = (root / "Panel.py").read_text(encoding="utf-8")
backend = (root / "Panel_backend_merged.py").read_text(encoding="utf-8")
assert "self._module_monitor = ModuleHealthBridge()" in panel
assert "record_sensor(addr[0], payload)" in panel
assert 'statuses["module_health"] = monitor.heartbeat_health()' in backend
assert 'elif command_type == "module_recovery":' in backend
print("INTEGRATION HOOKS OK")
