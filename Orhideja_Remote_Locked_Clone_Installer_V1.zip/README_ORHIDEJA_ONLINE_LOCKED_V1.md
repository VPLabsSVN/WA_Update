# Orhideja – protected remote clone installation with Wi-Fi and SSH ON

**Prepared 2026-11-28.** This utility is a separate, guarded fork of the verified Jagodic V1 clone apply logic. It is for the *third* Raspberry Pi (`hostname = wa-third`), which is reachable as `192.168.1.107`, and the already-prepared staged tree `/var/lib/wa-jagodic-clone/stage-001`.

## What it does

- Copies the staged WA application, ads, legal texts, images and purple theme, selected per-user scripts and configurations, cloned application tokens/certificates/state, user systemd unit files **without** enablement symlinks, and matching root-owned kiosk unit definitions.
- Does **not** copy the source Pi's `/etc/hostname`, `/etc/hosts`, NetworkManager/Wi-Fi, `/etc/ssh`, Raspberry Pi Connect identity, physical device/boot config, or installed Debian packages.
- Does not enable, start or restart kiosk, ads, inverter, watchdog, daily reboot, fiscalization or payment processes.
- Does not disconnect Wi-Fi or change the default network route; Pi Connect and SSH remain usable.
- Backs up overwritten existing files in `/var/lib/wa-jagodic-clone/backups/<timestamp>/`, like the original importer, and refuses to run if an application tree is already installed on the third Pi.

**Important:** The copied production credentials are present on disk. The service guards are not a sandbox against someone manually executing the Python application or starting another unguarded script. DO NOT run the kiosk or change the commissioning marker until all unique hardware, fiscal, payment and backend settings are verified. The current POS flag and Slovenian FURS gate are off; other integrations and certificate/receipt details still need review.

## Preconditions

- The original Jagodic encrypted backup was verified against its source SHA-256 and staged.
- Orhideja patch and photo/legal/theme patches have already succeeded. The final staged `Panel.py` SHA-256 is `ec1e7975402ebcb9ac333cf6a1decc1e04a10b9a9006b949892e47887e96ecb2`.
- `/etc/wa-third-production-ready` **does not exist**.
- The 5 protected user units and 3 protected root units have `99-third-commissioning-guard.conf` drop-ins with `ConditionPathExists=/etc/wa-third-production-ready`.
- No cloned WA tree or related services/processes are running on the third Pi; the target hostname is `wa-third`.
- The reviewed staged labwc/autostart contains only the display-layout script; any other command blocks this remote mode.

## Installation commands (on the third Pi; Wi-Fi remains ON)

Upload the file `orhideja_clone_remote_locked_v1.py` (contained in the toolkit ZIP) to your public repository, **not** the backup, certificates, secrets or `bp_sent.txt`. This script contains no production credentials.

```bash
cd /home/pi
curl -fL --retry 3 \
  'https://raw.githubusercontent.com/VPLabsSVN/WA_Update/main/orhideja_clone_remote_locked_v1.py' \
  -o orhideja_clone_remote_locked_v1.py

python3 -m py_compile orhideja_clone_remote_locked_v1.py
sudo python3 orhideja_clone_remote_locked_v1.py --online-check \
  /var/lib/wa-jagodic-clone/stage-001
```

The check is **read-only**. If it reports STOP, do not try to bypass it; investigate the exact issue first.

If all checks pass and the correct stage is identified:

```bash
sudo python3 orhideja_clone_remote_locked_v1.py --apply-online-locked \
  /var/lib/wa-jagodic-clone/stage-001
```

Enter **`ONLINE-LOCKED`** when asked. This confirms online *inactive* copying, not authorisation to start the kiosk or permit payments.

## After applying: verify via SSH (do NOT start the program)

```bash
hostname -I
sudo test ! -e /etc/wa-third-production-ready && echo 'LOCK ACTIVE'

systemctl --user daemon-reload
sudo systemctl daemon-reload

systemctl --user is-active bouquetmat.service
systemctl --user is-enabled bouquetmat.service
systemctl --user is-active inverter-udp-bridge.service
systemctl --user is-enabled wa-r3-watchdog.timer
sudo systemctl is-enabled bouquetmat-daily-reboot.timer

systemctl --user cat bouquetmat.service | grep -F ConditionPathExists
systemctl --user cat wa-r3-watchdog.timer | grep -F ConditionPathExists
sudo systemctl cat bouquetmat-daily-reboot.timer | grep -F ConditionPathExists

ls -l /home/wa_stopshop_mb/WA/Main_program/Fis/Panel.py
```

`inactive` / `disabled` are expected. Do not treat a nonzero exit code from `is-active` or `is-enabled` as an installation failure if the stated unit is inactive or disabled.

## Further commissioning

The next phase is to resolve all cloned backend/system IDs, controller IPs, fiscal certificate/account/invoice numbering, receipts and the purchase path with POS disabled. Keep the services guarded and inactive until these differences are resolved. The `--apply-online-locked` action is for first-time installation only; it refuses to overwrite an already installed tree.
