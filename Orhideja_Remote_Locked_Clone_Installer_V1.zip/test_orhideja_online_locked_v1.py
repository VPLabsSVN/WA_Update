#!/usr/bin/env python3
"""Tests for online-locked migration preflight (no writes to live filesystem)."""
import importlib.util
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import hashlib

src=Path(__file__).with_name('orhideja_clone_remote_locked_v1.py')
spec=importlib.util.spec_from_file_location('online_clone',src)
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def make_stage(root):
    stage=root/'stage'
    app=stage/'home/wa_stopshop_mb/WA/Main_program/Fis'
    app.mkdir(parents=True)
    panel=app/'Panel.py'
    panel.write_text("PANEL_TYPE = 'A'\nPAYMENT_ENABLED = False\n" +
        ''.join(f'TERMS_BODY_{x} = "Legal text"\n' for x in ('SI','EN','DE','HR')))
    (app/'Panel_backend_merged.py').write_text("BACKEND_PANEL_ID_OVERRIDE = 'Orhideja'\nBACKEND_PANEL_NAME_OVERRIDE = 'Videm pri Ptuju'\n")
    (app/'bp_sent.txt').write_text('bp_sent=0\nallowed=0\n')
    cfg=stage/'home/pi/.config/bouquetmat-inverter.env'
    cfg.parent.mkdir(parents=True)
    cfg.write_text('INVERTER_PANEL_ID=Orhideja\nINVERTER_SHARED_KEY=secret-test-only\n')
    ads=stage/'home/wa_stopshop_mb/WA/Main_program/Ads'
    ads.mkdir(parents=True)
    for i in range(901,915):
        (ads/f'IMG_{i}.png').write_bytes(b'PNG')
    (ads/'Minimalist World Automatics Logo Wallpaper.png').write_bytes(b'PNG')
    bg=stage/'home/wa_stopshop_mb/WA/Main_program/Panel'
    bg.mkdir(parents=True)
    (bg/'back.png').write_bytes(b'PNG')
    (bg/'back2.png').write_bytes(b'PNG')
    auto=stage/'home/pi/.config/labwc/autostart'
    auto.parent.mkdir(parents=True)
    auto.write_text('# Bouquetmat production Wayland session\n\n/home/pi/bin/bouquetmat-display-layout.sh &\n')
    meta=stage/'clone_metadata/source.json'
    meta.parent.mkdir(parents=True)
    meta.write_text('{"hostname":"raspberrypi"}')
    return stage,panel,app

with tempfile.TemporaryDirectory() as tmp:
    stage,panel,app=make_stage(Path(tmp))
    sha=hashlib.sha256(panel.read_bytes()).hexdigest()
    with patch.object(mod,'EXPECTED_STAGE_PANEL_SHA256',sha),\
         patch.object(mod.os,'uname',return_value=SimpleNamespace(nodename='wa-third')),\
         patch.object(mod,'_has_guard',return_value=True),\
         patch.object(mod,'_user_unit_state',return_value=None),\
         patch.object(mod,'_system_unit_state',return_value=None),\
         patch.object(mod,'_check_enabled_state',return_value=None),\
         patch.object(mod,'_check_no_live_kiosk_processes',return_value=None):
        assert mod.remote_preflight(stage)
        (app/'bp_sent.txt').write_text('bp_sent=0\nallowed=1\n')
        try: mod.remote_preflight(stage)
        except SystemExit as e: assert 'fiscalization gates' in str(e)
        else: raise AssertionError('Failed to detect enabled fiscalization')
        (app/'bp_sent.txt').write_text('bp_sent=0\nallowed=0\n')
        with patch.object(mod,'_has_guard',return_value=False):
            try: mod.remote_preflight(stage)
            except SystemExit as e: assert 'Missing user service guard' in str(e)
            else: raise AssertionError('Failed to detect missing guard')
        (app/'Panel_backend_merged.py').write_text("BACKEND_PANEL_ID_OVERRIDE = 'Jagodic'\nBACKEND_PANEL_NAME_OVERRIDE = 'Videm pri Ptuju'\n")
        try: mod.remote_preflight(stage)
        except SystemExit as e: assert 'not' in str(e)
        else: raise AssertionError('Failed to detect wrong ID')
        (app/'Panel_backend_merged.py').write_text("BACKEND_PANEL_ID_OVERRIDE = 'Orhideja'\nBACKEND_PANEL_NAME_OVERRIDE = 'Videm pri Ptuju'\n")
    with patch.object(mod,'EXPECTED_STAGE_PANEL_SHA256','0'*64),\
         patch.object(mod.os,'uname',return_value=SimpleNamespace(nodename='wa-third')):
        try: mod.remote_preflight(stage)
        except SystemExit as e: assert 'hash' in str(e)
        else: raise AssertionError('Failed to detect source hash drift')
print('PASS: online preflight allows valid stage and rejects fiscal-enabled, missing guards, wrong identity, changed hash')
