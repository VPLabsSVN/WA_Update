# Fin Reservation V2 — staged, fail-closed patch

**Target:** Fin machine `/home/wa_stopshop_mb/WA/Main_program/Fis`, deployed Fin Performance V1 only.

## Purpose

- A reservation with an **explicit `PLA` marker in trusted backend metadata** follows the **existing pre-paid claim → door → confirm** flow. A customer-entered code containing the letters `PLA` is **not** proof of payment.
- A reservation without a marker (including a structured empty `payload`) enters the **existing payment-terminal flow** for its **one local reserved item**. Normal shopping/cart payment remains unchanged, and reserved products remain blocked from normal cart checkout.
- Declined/cancelled payment: no door opens; claim is released.
- A **committed** payment: confirm the server claim before scheduling the existing purchase, fiscalisation and local door command. This is intentionally different from the PLA path, to guard against an expired claim during long terminal checkout.
- Unknown/conflicting marker, missing/short server claim lease, remote-module reserved item, payment uncertainty, or confirmation failure: **fail closed**, no automatic new charge/door command; require review.
- Keep a mode-0600 local `.fin_reservation_v2_recovery.json` when a payment is in-flight. A restart with an unresolved record blocks new unpaid reservation payments until manually reconciled. Do **not** delete this record or roll back blindly if a payment may have been authorized.
- Kivy messages are translated into SI/EN/DE/HR. The V1 performance improvements stay in place.

## Critical integration assumptions to confirm before production use

**This is a staged release, not a proven end-to-end payment integration.** The actual server's claim response schema and paid marker representation have **not** been validated with a PLA reservation. `--check` proves only source compatibility and offline invariants; it does not contact the payment terminal or open a door.

1. The claim response must contain `reservation.payload`, or another explicit payment marker field, and a verified `claim_expires_at`, `hold_expires_at`, or `claimed_until` at least **180 seconds in the future**. The patch first calls read-only `/verify` to select a hold: **60 seconds for PLA** (original behavior), **600 seconds for unpaid**, and checks consistency again after claiming. If the backend does not report the hold expiry, **unpaid checkout will stop before charging**. That is intentional; extending/returning the lease may require a backend update.
2. Explicit `PLA` is recognized as `payload="PLA"`, or as exact `"PLA"` in fields named `marker`, `payment_marker`, `payment_code`, `payment_type`, `reservation_marker` in backend metadata. Other payment-marker formats are blocked instead of guessing. The backend must be authoritative; this code cannot independently prove someone paid online.
3. **Unpaid remote-panel reservations are not enabled in this first release**; only local compartments are eligible. The existing PLA remote path is unchanged.
4. After paid confirmation, the normal Kivy purchase path launches the local door command. The recovery ledger clears on the **relay command's success callback**, not on confirmed physical door opening. For actual door-sensor verification and refunds, further controller/backend work is required.
5. Payment committed but backend confirmation fails, local door command fails, or Pi restarts mid-payment: no blind retry, no automatic refund. Reconcile terminal transaction/invoice, server reservation state and physical stock with the operator.
6. Use authorized test reservations and terminal test mode first. Never run a paid test unattended.

## Installation procedure

First run from the downloaded package directory:

```bash
bash fin_reservation_v2_apply.sh --check
```

The check validates exact Fin V1 file hashes, patch applicability, Python syntax and offline routing tests, without changing the app. **Do not apply until the server marker + claim-expiry contract is checked**.

Only during a supervised maintenance window with no customer payment in progress:

```bash
bash fin_reservation_v2_apply.sh --apply
# after noting the newly printed backup directory, when fully idle:
systemctl --user restart bouquetmat.service
systemctl --user status bouquetmat.service --no-pager -l
journalctl --user -u bouquetmat.service --since '10 minutes ago' -p warning..alert --no-pager
```

### Backups / rollback

Existing Fin Performance V1 backups are untouched. The V2 installer also saves `Panel.py`, `Panel_backend_merged.py`, `backend_client.py`, `Ads.py` in:

`~/fin_reservation_v2_backups/YYYYMMDD_HHMMSS/`

Use the **exact printed path** after checking no payment is in-flight:

```bash
bash fin_reservation_v2_apply.sh --rollback /home/pi/fin_reservation_v2_backups/YYYYMMDD_HHMMSS
# when fully idle, restart:
systemctl --user restart bouquetmat.service
```

**Rollback refuses if `.fin_reservation_v2_recovery.json` exists.** This prevents reverting to V1, which opens unpaid reservations, while a payment's status is unknown. Reconcile any outstanding payment with a responsible operator first. Neither installer nor rollback restarts the service automatically.

### Post-install supervised test checklist

1. Normal nonreserved item: checkout, authorized payment, opening, fiscalisation and receipt unchanged.
2. Valid PLA marker: existing door collection once, no terminal charge.
3. Valid unpaid local reservation: checkout screen shows exact item/price; door remains closed until terminal outcome `committed` and backend confirm; one fiscal sale and one door command.
4. Declined/cancelled: no door; reservation remains eligible after release.
5. Claim-expiry absent/short: show payment-unavailable **without a charge or door operation**.
6. Remote unpaid or unknown marker: blocked pending integration.
7. Test failure and rollback, then restart only when idle.
8. Recheck Fin V1 performance and running process after the update.

**Security:** Do not upload actual `Panel.py`/`Panel_backend_merged.py` to public GitHub: the production backend snapshot contains embedded email credentials. The V2 source patch and helper do not include those credentials. Rotate compromised embedded credentials separately.
