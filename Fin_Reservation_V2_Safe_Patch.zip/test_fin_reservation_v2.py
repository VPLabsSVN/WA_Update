#!/usr/bin/env python3
"""Offline/side-effect-free tests; no Pi hardware, Kivy, backend, or payment calls."""
import ast
import importlib.util
import pathlib
import textwrap
from types import SimpleNamespace
import unittest
from datetime import datetime, timedelta, timezone

HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("fin_reservation_v2_logic", HERE/"fin_reservation_v2_logic.py")
logic=importlib.util.module_from_spec(spec)
spec.loader.exec_module(logic)

class MarkerTests(unittest.TestCase):
    def test_explicit_pla(self):
        for item in ({"payload":"PLA"}, {"payload":{"payment_marker":"PLA"}},
                     {"payment_marker":"PLA"}, {"payload":'{"marker":"PLA"}'}):
            with self.subTest(item=item):
                self.assertEqual(logic.reservation_route(item), "pla")
    def test_no_marker_is_unpaid(self):
        for item in ({"payload":None}, {"payload":""},
                     {"payload":{"note":"rose"}}, {"payload":'{"note":"rose"}'},
                     {"payload":{"payment_marker":""}},
                     {"payload":{"payment_status":"unpaid"}}):
            with self.subTest(item=item):
                self.assertEqual(logic.reservation_route(item), "unpaid")
    def test_customer_code_not_paid_proof(self):
        self.assertEqual(logic.reservation_route({"code":"AB-PLA-CD","payload":None}),"unpaid")
    def test_block_ambiguous_or_conflicting(self):
        for item in ({"payload":{"payment_marker":"UNKNOWN"}},
                     {"payload":"unexpected raw text"},
                     {"payload":{"paid":True}},
                     {"payload":{"payment_marker":"PLA","paid":False}},
                     {"payload":{"payment_status":"paid"}},
                     {"payload":{"marker":"PLA","payment_type":"CARD"}},
                     {"payload":"{invalid json"}):
            with self.subTest(item=item):
                self.assertEqual(logic.reservation_route(item), "blocked")
    def test_paid_record_must_have_pla(self):
        self.assertEqual(logic.reservation_route({"payload":{"payment_marker":"PLA","paid":True}}),"pla")

class LeaseTests(unittest.TestCase):
    def test_claim_lease_required(self):
        now=datetime(2026,11,18,tzinfo=timezone.utc)
        self.assertIsNone(logic.claim_seconds_remaining({"reservation":{"expires_at":"2026-12-01T00:00:00Z"}}, now))
        delta=timedelta(minutes=10)
        t=(now+delta).isoformat()
        self.assertEqual(int(logic.claim_seconds_remaining({"claim_expires_at":t},now)),600)
        self.assertEqual(int(logic.claim_seconds_remaining({"reservation":{"claim_expires_at":t}},now)),600)
        self.assertIsNone(logic.claim_seconds_remaining({"claim_expires_at":"invalid"},now))

class StaticSafetyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source=(HERE/"Panel_backend_merged.py").read_text(encoding="utf-8")
        cls.tree=ast.parse(cls.source)
        cls.app_class=next(n for n in cls.tree.body if isinstance(n,ast.ClassDef) and n.name=="PanelBackendReservationApp")
        cls.methods={n.name:n for n in cls.app_class.body if isinstance(n,ast.FunctionDef)}
    def test_functions_unique(self):
        names=[n.name for n in self.app_class.body if isinstance(n,ast.FunctionDef)]
        self.assertEqual(len(names),len(set(names)), 'Duplicate method overrides must be resolved')
    def test_v2_never_opens_door_in_unpaid_start(self):
        method=self.methods['_reservation_v2_start_checkout']
        code=ast.get_source_segment(self.source,method)
        for forbidden in ("open_doors_sequential(","remote_purchase", "_complete_successful_purchase_standard("):
            self.assertNotIn(forbidden,code)
        self.assertIn('claim_seconds_remaining(',code)
        self.assertIn('_reservation_v2_store_recovery(ctx, "terminal_started")',code)
    def test_terminal_result_and_paid_confirmation_are_mandatory(self):
        complete=ast.get_source_segment(self.source,self.methods['_complete_successful_purchase'])
        finish=ast.get_source_segment(self.source,self.methods['_reservation_v2_finish_paid'])
        self.assertIn('ctx.get("phase") != "committed"',complete)
        self.assertIn('_reservation_confirm_async(',complete)
        self.assertIn('_complete_successful_purchase_standard(',finish)
    def test_remote_unpaid_not_supported(self):
        start=ast.get_source_segment(self.source,self.methods['_reservation_v2_start_checkout'])
        self.assertIn('remote reserved-item payments not enabled in V2',start)
    def test_door_failure_recorded(self):
        source=ast.get_source_segment(self.source,self.methods['open_doors_sequential'])
        self.assertIn('paid_door_command_failed_manual_review',source)
        self.assertIn('reservation_paid_door_command_ok',source)

class RuntimeRoutingTests(unittest.TestCase):
    """Execute the actual V2 methods with fake UI/client; never touch hardware."""
    @classmethod
    def setUpClass(cls):
        cls.source=(HERE/"Panel_backend_merged.py").read_text(encoding="utf-8")
        tree=ast.parse(cls.source)
        app=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="PanelBackendReservationApp")
        cls.methods={n.name:n for n in app.body if isinstance(n,ast.FunctionDef)}

    def method(self,name,globals_=None):
        ns={"reservation_route":logic.reservation_route,
            "claim_seconds_remaining":logic.claim_seconds_remaining,
            "base": SimpleNamespace(PANEL_POSITION=0,DOOR_PULSE_MS=50,DOOR_GAP_MS=50),
            "time":__import__('time'), "datetime": datetime, "os":__import__('os')}
        if globals_: ns.update(globals_)
        code=textwrap.dedent(ast.get_source_segment(self.source,self.methods[name]))
        exec('from __future__ import annotations\n'+code,ns)
        return ns[name]

    def dummy(self):
        status=SimpleNamespace(text='')
        btn=SimpleNamespace(disabled=False)
        screen=SimpleNamespace(ids=SimpleNamespace(reservation_status=status,reservation_collect_btn=btn))
        traces=[]
        class App:
            _verified_reservation=None
            _reservation_claim_token=None
            server_reservation_codes=[]
            root=SimpleNamespace(get_screen=lambda _n:screen)
            def _reservation_v2_start_checkout(self,*args):
                traces.append(('checkout',args))
            def _reservation_release_async(self,**kw):
                traces.append(('release',kw))
            def backend_post_event_async(self,*args,**kw):
                traces.append(('event',args[0]))
            def open_doors_sequential(self,items,**kw):
                traces.append(('door',items))
            def t(self,key):return key
        return App(),traces

    def test_claimed_unpaid_never_opens(self):
        app,events=self.dummy()
        m=self.method('_reservation_collect_claimed')
        r={'payload':None,'item_id':3,'panel_position':0}
        m(app,'UNPAID-CODE','claimtoken',r,{'claimed':True})
        self.assertTrue(any(x[0]=='checkout' for x in events))
        self.assertFalse(any(x[0]=='door' for x in events))

    def test_claimed_pla_existing_door_path(self):
        app,events=self.dummy()
        m=self.method('_reservation_collect_claimed')
        r={'payload':{'payment_marker':'PLA'},'item_id':3,'panel_position':0}
        m(app,'PAID-CODE','claimtoken',r,{'claimed':True})
        self.assertTrue(any(x[0]=='door' for x in events))
        self.assertFalse(any(x[0]=='checkout' for x in events))

    def test_claim_and_config_disagreement_blocks_both_routes(self):
        app,events=self.dummy()
        app.server_reservation_codes=[{'code':'CASE-1','payload':{'payment_marker':'PLA'}}]
        m=self.method('_reservation_collect_claimed')
        m(app,'CASE-1','claimtoken',{'code':'CASE-1','payload':None,'item_id':3,'panel_position':0})
        self.assertTrue(any(x[0]=='release' for x in events))
        self.assertFalse(any(x[0] in ('door','checkout') for x in events))

    def test_reservation_verify_controls_claim_hold(self):
        from types import SimpleNamespace
        class ImmediateThread:
            def __init__(self,target,daemon=False): self.target=target
            def start(self): self.target()
        clock=SimpleNamespace(schedule_once=lambda cb, delay: cb(0))
        for payload, expected in (({"payment_marker":"PLA"},60), ({"note":"unpaid"},600)):
            with self.subTest(payload=payload):
                calls=[]
                record={'code':'TEST','payload':payload,'item_id':3,'panel_position':0}
                class Client:
                    def verify(self,**kw):
                        calls.append(('verify',kw))
                        return {'valid':True,'reservation':record}
                    def claim(self,**kw):
                        calls.append(('claim',kw))
                        return {'claimed':True,'reservation':record,'claim_token':'dummy'}
                app,events=self.dummy()
                app.reservation_client=Client()
                app._reservation_v2_pending=None
                app._checkout_in_progress=False
                app.root.get_screen('reservation').ids.reservation_code_input=SimpleNamespace(text='TEST')
                app._reservation_collect_claimed=lambda *args,**kw:calls.append(('claimed',kw))
                method=self.method('reservation_collect',{'Clock':clock,'threading':SimpleNamespace(Thread=ImmediateThread),
                                                            'BACKEND_PANEL_ID':'Fin','RESERVATION_HOLD_SECONDS':60,
                                                            'RESERVATION_PAYMENT_HOLD_SECONDS':600})
                method(app)
                self.assertEqual(calls[0][0],'verify')
                self.assertEqual(calls[1][1]['hold_seconds'],expected)
                self.assertEqual(calls[-1][1]['pre_route'],'pla' if expected==60 else 'unpaid')

    def test_unpaid_preflight_requires_valid_claim_lease(self):
        app,events=self.dummy()
        app._reservation_v2_recovery_path='/tmp/fin_v2_nonexistent_unit_test_file'
        app._checkout_in_progress=False
        app._reservation_v2_pending=None
        app._get_panel_item=lambda pos,iid:{'id':iid,'price':12.5,'tax_pct':22,'enabled':True,'label':'Test item'}
        app._reservation_v2_store_recovery=lambda ctx,phase:events.append(('ledger',phase))
        app._reservation_v2_error=lambda msg:events.append(('error',msg))
        app._start_payment_for_items=lambda *args: events.append(('payment',args))
        env={'base': SimpleNamespace(PANEL_POSITION=0,DEFAULT_TAX_PERCENT=22,next_invoice_number=lambda:'INVOICE-1'), 'claim_seconds_remaining':lambda d: 600}
        method=self.method('_reservation_v2_start_checkout',env)
        method(app,'UNPAID','claimtoken',{'item_id':3,'panel_position':0},{'claim_expires_at':'2026-12-01T00:00:00+00:00'})
        self.assertTrue(any(x[0]=='payment' for x in events))
        self.assertFalse(any(x[0]=='door' for x in events))
        self.assertTrue(any(x[0]=='ledger' for x in events))
        app2,events2=self.dummy()
        app2._reservation_v2_recovery_path='/tmp/fin_v2_nonexistent_unit_test_file'
        app2._reservation_v2_error=lambda msg:events2.append(('error',msg))
        self.method('_reservation_v2_start_checkout',{'claim_seconds_remaining':lambda d: None})(app2,'UNPAID','claimtoken',{'item_id':3,'panel_position':0},{})
        self.assertFalse(any(x[0]=='payment' for x in events2))
        self.assertTrue(any(x[0]=='release' for x in events2))

if __name__ == '__main__':
    unittest.main(verbosity=2)
