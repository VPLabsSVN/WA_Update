"""Pure reservation routing/lease checks for Fin V2.

No network, payment, hardware, or Kivy dependencies. A marker is NEVER
inferred from a customer-entered reservation code. Only backend data is used.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
from typing import Any

PLA_FIELDS = ("payment_marker", "payment_code", "payment_type", "marker", "reservation_marker")
PAID_FIELDS = ("is_paid", "paid", "payment_status")


def _scalar(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, str):
        return v.strip().upper()
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    return "?"


def _metadata_values(record: dict) -> tuple[list[str], list[str], bool]:
    """Return marker values, paid indicators, and whether opaque data is present."""
    markers: list[str] = []
    paid: list[str] = []
    opaque = False
    def visit(obj, *, depth=0, is_payload=False):
        nonlocal opaque
        if depth > 5:
            opaque = True
            return
        if isinstance(obj, str) and is_payload:
            raw = obj.strip()
            if not raw:
                return
            if raw.upper() == "PLA":
                markers.append("PLA")
                return
            try:
                obj = json.loads(raw)
            except (ValueError, TypeError):
                opaque = True
                return
        if isinstance(obj, dict):
            for key, value in obj.items():
                if key in PLA_FIELDS:
                    if not isinstance(value, (str, type(None))):
                        opaque = True
                    else:
                        markers.append(_scalar(value))
                elif key in PAID_FIELDS:
                    paid.append(_scalar(value))
                elif key == "payload":
                    visit(value, depth=depth + 1, is_payload=True)
                elif isinstance(value, (dict, list)):
                    visit(value, depth=depth + 1)
        elif isinstance(obj, list):
            for value in obj[:20]:
                visit(value, depth=depth + 1)
            if len(obj) > 20:
                opaque = True
        elif obj is not None:
            opaque = True
    visit(record)
    return markers, paid, opaque


def reservation_route(record: dict) -> str:
    """Return 'pla', 'unpaid' or 'blocked'. Never treat the user's code as proof."""
    if not isinstance(record, dict):
        return "blocked"
    markers, paid_states, opaque = _metadata_values(record)
    recognized_empty = ("", "NONE", "UNPAID", "NOT_PAID", "NO", "FALSE")
    if any(m not in (*recognized_empty, "PLA") for m in markers):
        return "blocked"
    if any(p in ("TRUE", "PAID", "YES", "COMMITTED", "SETTLED") for p in paid_states):
        # Paid but no explicit PLA must never be charged again.
        return "pla" if "PLA" in markers else "blocked"
    if any(p not in ("", "FALSE", "UNPAID", "NOT_PAID", "PENDING", "NONE") for p in paid_states):
        return "blocked"
    if "PLA" in markers:
        # Contradictory unpaid proof -> do not dispense or charge.
        if any(p in ("FALSE", "UNPAID", "NOT_PAID") for p in paid_states):
            return "blocked"
        return "pla"
    return "blocked" if opaque else "unpaid"


def claim_seconds_remaining(claim_result: dict, now: datetime | None = None) -> float | None:
    """Compute seconds left from an explicit server claim expiry; never from reservation expiry."""
    if not isinstance(claim_result, dict):
        return None
    obj = claim_result.get("reservation") or {}
    for container in (claim_result, obj if isinstance(obj, dict) else {}):
        for key in ("claim_expires_at", "hold_expires_at", "claimed_until"):
            raw = container.get(key)
            if not raw:
                continue
            try:
                stamp = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
                if stamp.tzinfo is None:
                    return None
                return (stamp - (now or datetime.now(timezone.utc))).total_seconds()
            except (ValueError, TypeError, OverflowError):
                return None
    return None
