#!/usr/bin/env python3
"""Offline-only V12 contract tests: no systemd, hardware or live network use."""
from __future__ import annotations
import copy
import json
import os
import tempfile
import time
from pathlib import Path
from unittest.mock import patch
import wa_r3_fault_watchdog_v12 as wd
import wa_r3_v12_activate as activate


def sample(fault=4):
    d={k:False for k in wd.BLOCK_FLAGS}
    d.update(boot_id=54321,firmware='V4.9.72 R3 V8.3.7 V7HW AFTER_INSPECTION',
        position=1,motor_hardware_ready=True,tmc_both_configured=True,
        pending_wait_open_mask=0,pending_wait_close_mask=0,motors=[])
    for n in (7,10):
        d['motors'].append({'motor':n,'fault_latched':n==7,
            'fault_reason':fault if n==7 else 0,'door_closed_verified':True,
            'door_cycle_pending':False,'enn_disabled_verified':True,
            'step_output_active':False,'auto_recovery_budget_exhausted':False,
            'encoder_valid':True,'enn_readback_available':True,'enn_readback_error':0,
            'enn_iodir_output':True,'enn_olat_high':True,'enn_gpio_high':True,
            'tmc_drv_status':0x110000,'tmc_gstat':1,
            'stop_reason_code':12,'stop_reason_age_s':130.0,
            'recovery_verification':'not_requested'})
    return d


def set_grant(path, d):
    t=time.time()
    record={'version':6,'grant_id':'r3v6-0123456789abcdefghijklm',
            'inspected_current_fault':True,'motor':7,'fault_reason':4,
            'boot_id':d['boot_id'],'firmware':d['firmware'],
            'issued_at':t,'expires_at':t+200,
            'note':'Checked THIS FAULT onsite; door/lock/driver safe',
            'stop_anchor':wd.stop_anchor(d,7,now=t)}
    path.write_text(json.dumps(record))
    os.chmod(path,0o600)


def test_rpc_payload():
    # Capture the actual wire JSON composed by V12, without opening any real socket.
    class Sock:
        sent=None
        def __enter__(self):return self
        def __exit__(self,*a):pass
        def bind(self,*args):pass
        def settimeout(self,*args):pass
        def sendto(self,raw,where):
            self.sent=json.loads(raw)
            self.dest=where
        def recvfrom(self,n):
            result={'type':'remote_motor_ack','request_id':self.sent['request_id'],'ok':True}
            return json.dumps(result).encode(), self.dest
    s=Sock()
    with patch.object(wd.socket,'socket',return_value=s):
        a=wd.rpc(('192.168.1.100','192.168.1.201',48556,'z'*32),
                 'remote_motor_recover',motor=7,inspected=True)
        assert a['ok'] is True
        assert s.sent['inspected_hardware'] is True and s.sent['motor']==7
        assert s.sent['type']=='remote_motor_recover'
        assert len(s.sent['request_id'])>20 and len(s.sent['token'])==32
        wd.rpc(('192.168.1.100','192.168.1.201',48556,'z'*32),
               'remote_motor_recover',motor=7,inspected=False)
        assert 'inspected_hardware' not in s.sent
    print('PASS: inspected_hardware=true appears in actual generated UDP JSON only when requested')


def test_once():
    with tempfile.TemporaryDirectory() as t:
        base=Path(t)
        old={k:getattr(wd,k) for k in ('LOCK','LOG','STATE','GRANT')}
        wd.LOCK=base/'lock';wd.LOG=base/'log';wd.STATE=base/'state';wd.GRANT=base/'grant'
        snapshot=sample(4)
        calls=[]
        def fake_rpc(ep, action, motor=None, timeout=None, inspected=False):
            calls.append({'action':action,'motor':motor,'inspected':inspected})
            return {'ok':False,'error':'simulated_rejection'}
        try:
            with patch.object(wd,'status',side_effect=lambda ep: copy.deepcopy(snapshot)),\
                 patch.object(wd,'endpoint',return_value='no-network'),\
                 patch.object(wd,'kiosk_idle',return_value=(True,'simulated idle')),\
                 patch.object(wd,'rpc',side_effect=fake_rpc),\
                 patch.object(wd.time,'sleep',return_value=None):
                set_grant(wd.GRANT,snapshot)
                assert wd.once(auto=True,extended_auto=True)==0
                assert calls==[{'action':'remote_motor_recover','motor':7,'inspected':True}],calls
                assert not wd.GRANT.exists(),'One-use grant must be consumed before UDP'
                # Same fault after reboot with changed identity must not use a previous grant.
                wd.STATE.unlink(missing_ok=True)
                calls.clear()
                set_grant(wd.GRANT,snapshot)
                snapshot['boot_id']+=1
                assert wd.once(auto=True,extended_auto=True)==0
                assert calls[0]['inspected'] is False
                assert wd.GRANT.exists(), 'Stale grant is not the same as consumed grant'
                # A global fault must never issue a motor recovery.
                wd.STATE.unlink(missing_ok=True)
                calls.clear()
                snapshot['global_fault']=True
                assert wd.once(auto=True,extended_auto=True)==0
                assert calls==[],calls
                # Pending access must never issue a motor recovery.
                wd.STATE.unlink(missing_ok=True)
                snapshot['global_fault']=False
                snapshot['pending_wait_open_mask']=1
                assert wd.once(auto=True,extended_auto=True)==0
                assert calls==[],calls
        finally:
            for k,v in old.items():setattr(wd,k,v)
    print('PASS: current-fault grant consumed before request; wrong boot cannot attest; global/pending blocked')


def main():
    wd.self_test()
    activate.self_test()
    test_rpc_payload()
    test_once()
    import wa_r3_pending_monitor_v12 as pending
    import wa_r3_v12_commissioning as commissioning
    pending.self_test()
    commissioning.self_test()
    print('PASS: V12 guarded recovery + pending read-only monitoring + commissioning record; NO controller command sent')

if __name__=='__main__':main()
