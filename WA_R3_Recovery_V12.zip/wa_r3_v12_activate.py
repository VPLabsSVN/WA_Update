#!/usr/bin/env python3
"""V12: enable V8/V9 guarded extended R3 fault requests independent of firmware VERSION LABEL.

This switches the Pi watchdog to V12 while retaining extended recovery.
A current-fault operator grant may cause inspected_hardware=true. It never
falsely attests inspection, clears customer pending cycles unattended, reopens
doors, or bypasses a controller rejection.

Usage: --self-test | --check | --stage | --enable-extended | --rollback
"""
from __future__ import annotations

import argparse
import importlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

APP = Path(__file__).resolve().parent
HOME = Path.home()
UNIT = 'wa-r3-watchdog.service'
TIMER = 'wa-r3-watchdog.timer'
OVERRIDE_DIR = HOME / '.config/systemd/user' / (UNIT + '.d')
OVERRIDE = OVERRIDE_DIR / 'auto.conf'
BACKUP = OVERRIDE_DIR / 'auto.conf.before_v12'
SENTINEL = OVERRIDE_DIR / '.auto.conf.was_missing_before_v12'
PYTHON = APP / 'venv/bin/python'


def systemctl(*args, capture=True, check=True):
    p = subprocess.run(['systemctl', '--user', *args], text=True,
                       stdout=subprocess.PIPE if capture else None,
                       stderr=subprocess.PIPE if capture else None,
                       check=False)
    if check and p.returncode:
        raise RuntimeError(f"systemctl --user {' '.join(args)} failed: {(p.stderr or p.stdout or '').strip()[:300]}")
    return (p.stdout or '').strip()


def watchdog():
    if str(APP) not in sys.path:
        sys.path.insert(0, str(APP))
    wd = importlib.import_module('wa_r3_fault_watchdog_v12')
    return wd


def verify_controller(d, wd):
    """Existing contract, not firmware identity/marketing string or elapsed time."""
    reason = wd.safe_snapshot(d)
    if reason:
        return f'ESP32 unsafe or incomplete: {reason}'
    if set(wd.motor_map(d)) != {7, 10}:
        return 'Both R7/R10 motor rows required'
    # safe_snapshot verifies global/guard/busy/pending/door/hardware flags.
    return None


def live_check():
    wd = watchdog()
    d1 = wd.status(wd.endpoint())  # correlated authenticated motor+identity status, same boot
    fault = verify_controller(d1, wd)
    if fault:
        raise RuntimeError(fault)
    idle, why = wd.kiosk_idle()
    if not idle:
        raise RuntimeError('Kiosk is not positively idle: ' + why)
    time.sleep(0.35)
    d2 = wd.status(wd.endpoint())
    fault = verify_controller(d2, wd)
    if fault:
        raise RuntimeError('Second ESP32 read blocked: ' + fault)
    if d1.get('boot_id') != d2.get('boot_id') or d1.get('firmware') != d2.get('firmware'):
        raise RuntimeError('Controller identity/boot changed during validation')
    idle2, why2 = wd.kiosk_idle()
    if not idle2:
        raise RuntimeError('Kiosk changed activity during validation: '+why2)
    return {'firmware': d2['firmware'], 'boot_id': d2['boot_id'], 'idle': why2,
            'global_fault': d2['global_fault'],
            'pending_open': d2['pending_wait_open_mask'],
            'pending_close': d2['pending_wait_close_mask'],
            'notice': 'Version LABEL is not an authorization; ESP must approve every recovery.'}


def runner():
    # V12 runner always exists and optionally executes installed V9 monitor.
    return APP/'wa_r3_v12_run.py'


def assert_install_files():
    for path in (PYTHON, APP/'wa_r3_fault_watchdog_v12.py', APP/'wa_r3_pending_monitor_v12.py', runner()):
        if not path.is_file():
            raise RuntimeError('Required file not found: '+str(path))
    subprocess.run([str(PYTHON),'-m','py_compile', str(APP/'wa_r3_fault_watchdog_v12.py'),str(APP/'wa_r3_pending_monitor_v12.py'),str(runner())],check=True)


def atomic_override(contents):
    OVERRIDE_DIR.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.wa_r3_v12_', dir=str(OVERRIDE_DIR))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            stream.write(contents)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temp, 0o600)
        os.replace(temp, OVERRIDE)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def write_backup_once():
    if BACKUP.exists() or SENTINEL.exists():
        return
    OVERRIDE_DIR.mkdir(parents=True, exist_ok=True)
    if OVERRIDE.exists():
        shutil.copy2(OVERRIDE, BACKUP)
        os.chmod(BACKUP, 0o600)
    else:
        SENTINEL.write_text('The watchdog had no auto.conf override before V12.\n', encoding='utf-8')
        os.chmod(SENTINEL, 0o600)


def make_override(extended):
    args = '--once --auto-recover' + (' --extended-auto' if extended else '')
    return ('[Service]\nExecStart=\n'
            f'ExecStart={PYTHON} {runner()} {args}\n'
            'TimeoutStartSec=130\n')


def change(mode):
    assert_install_files() if mode != 'rollback' else None
    if mode == 'enable-extended':
        print('Live guard checks:',json.dumps(live_check(),sort_keys=True))
    original_timer_state=systemctl('is-active',TIMER,check=False)
    systemctl('stop',TIMER)
    try:
        state=systemctl('show','-p','ActiveState','--value',UNIT)
        if state not in ('inactive','failed'):
            raise RuntimeError('Watchdog service is running; will not replace ExecStart while it is active')
        if mode=='rollback':
            if BACKUP.is_file():
                shutil.copy2(BACKUP, OVERRIDE)
            elif SENTINEL.is_file():
                OVERRIDE.unlink(missing_ok=True)
            else:
                raise RuntimeError('No V12 saved override for rollback')
        else:
            write_backup_once()
            atomic_override(make_override(mode=='enable-extended'))
        systemctl('daemon-reload')
    finally:
        # Do not silently enable a timer that was previously inactive.
        if original_timer_state == 'active':
            systemctl('start',TIMER,check=False)
    return {'mode':mode,'timer':systemctl('is-active',TIMER,check=False),
            'runner':str(runner()),
            'exec_start':systemctl('show','-p','ExecStart','--value',UNIT)}


def self_test():
    fake = SimpleNamespace(safe_snapshot=lambda d: None if (d.get('global_fault') is False
        and d.get('pending_wait_open_mask')==0 and d.get('pending_wait_close_mask')==0) else 'blocked',
        motor_map=lambda d:{7: {},10: {}})
    sample={'firmware':'V4.9.72 R3 V8.3.7 V7HW AFTER_INSPECTION 1000mA',
            'global_fault':False,'pending_wait_open_mask':0,'pending_wait_close_mask':0}
    assert verify_controller(sample,fake) is None  # same version string is acceptable
    for k,v in (('global_fault',True),('pending_wait_open_mask',1),('pending_wait_close_mask',2)):
        corrupted=dict(sample,**{k:v})
        assert verify_controller(corrupted,fake)
    assert '--extended-auto' in make_override(True)
    assert '--extended-auto' not in make_override(False)
    assert 'wa_r3_v12_run.py' in make_override(True)
    assert 'remote_motor_clear_pending_cycle' not in make_override(True)
    print('PASS: firmware label independent; global/pending blocked; ESP safety rules retained')
    print('PASS: extended mode launches V12; single-use grants are validated at runtime; no door pulses')
    return 0


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    group=p.add_mutually_exclusive_group(required=True)
    for option in ('self-test','check','stage','enable-extended','rollback'):
        group.add_argument('--'+option,action='store_true')
    a=p.parse_args(argv)
    try:
        if a.self_test:
            return self_test()
        if a.check:
            assert_install_files()
            print('STATUS:',json.dumps(live_check(),indent=2))
            print('RUNNER:',runner())
            print('CURRENT:',systemctl('show','-p','ExecStart','--value',UNIT))
            print('READ-ONLY: no config changed and no recovery transmitted')
            return 0
        mode='rollback' if a.rollback else 'stage' if a.stage else 'enable-extended'
        print('UPDATED:',json.dumps(change(mode),indent=2))
        print('Controller recovery requests are still guarded and can be refused by ESP firmware.')
        return 0
    except (OSError,ValueError,RuntimeError,subprocess.CalledProcessError,TimeoutError) as exc:
        print('STOP: '+str(exc),file=sys.stderr)
        return 3

if __name__=='__main__':
    raise SystemExit(main())
