#!/usr/bin/env python3
"""Document a completed initial R3 machine inspection.

This records what a human says about an earlier site visit; it is NOT
proof that a later motor stall or electrical fault was inspected and must
NEVER be used to set inspected_hardware in a motor-recovery request.
"""
from __future__ import annotations
import argparse, json, os, sys, tempfile, time
from pathlib import Path
import wa_r3_fault_watchdog_v12 as wd
RECORD=Path(__file__).resolve().parent/'wa_r3_v12_commissioning.json'

def record(note):
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        raise ValueError('Commissioning record requires interactive terminal confirmation')
    if not 20 <= len(note.strip()) <= 500:
        raise ValueError('Specify a 20..500 character note recording what was actually inspected')
    d=wd.status(wd.endpoint())
    if wd.safe_snapshot(d) is not None:
        raise ValueError('ESP status not healthy at time of record: '+str(wd.safe_snapshot(d)))
    print('This records an earlier inspection; it does NOT authorize a future fault inspection attestation.')
    print('Machine:',d.get('firmware'),'boot',d.get('boot_id'))
    if input('Type RECORD PREVIOUS INSPECTION: ').strip() != 'RECORD PREVIOUS INSPECTION':
        raise ValueError('Canceled')
    data={'version':12,'recorded_at':time.strftime('%Y-%m-%dT%H:%M:%S%z'),
          'controller_boot_at_record':d['boot_id'],'firmware_at_record':d['firmware'],
          'site_visit_note':note.strip(),
          'purpose':'history_only_not_a_future_fault_inspection_attestation',
          'future_inspected_hardware_authorized':False}
    fd, tmp=tempfile.mkstemp(prefix='.r3_v12_commissioning_',dir=str(RECORD.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(data,f,indent=2,sort_keys=True);f.flush();os.fsync(f.fileno())
        os.chmod(tmp,0o600);os.replace(tmp,RECORD)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    print('RECORDED:',RECORD)
    print('The current-fault authorization mechanism remains unchanged.')
    return 0

def get_record():
    try: return json.loads(RECORD.read_text(encoding='utf-8'))
    except (OSError,ValueError):return None

def self_test():
    assert get_record() is None or 'future_inspected_hardware_authorized' in get_record()
    import inspect
    src=inspect.getsource(record)
    assert 'future_inspected_hardware_authorized' in src and 'False' in src
    assert 'remote_motor_recover' not in src and 'inspected_hardware=True' not in src
    print('PASS: commissioning record does not grant current fault inspection or actuate hardware')
    return 0

def main():
    p=argparse.ArgumentParser(description=__doc__)
    g=p.add_mutually_exclusive_group(required=True)
    for x in ('record','status','revoke','self-test'):g.add_argument('--'+x,action='store_true')
    p.add_argument('--inspection-note',default='')
    a=p.parse_args()
    try:
        if a.self_test:return self_test()
        if a.status:
            print(json.dumps(get_record() or {'commissioning_record':None},indent=2));return 0
        if a.revoke:
            RECORD.unlink(missing_ok=True);print('Removed commissioning history record only');return 0
        return record(a.inspection_note)
    except (ValueError,OSError,TimeoutError) as e:
        print('STOP:',str(e),file=sys.stderr);return 3
if __name__=='__main__':raise SystemExit(main())
