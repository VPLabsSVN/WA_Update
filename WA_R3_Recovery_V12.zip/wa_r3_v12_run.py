#!/usr/bin/env python3
"""V12 systemd timer entrypoint: guarded recovery and optional read-only V9 pending monitor."""
from __future__ import annotations
import argparse
import subprocess
import sys
from pathlib import Path
APP=Path(__file__).resolve().parent

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--once',action='store_true',required=True)
    p.add_argument('--auto-recover',action='store_true')
    p.add_argument('--extended-auto',action='store_true')
    a=p.parse_args(argv)
    if a.extended_auto and not a.auto_recover:p.error('--extended-auto requires --auto-recover')
    cmd=[sys.executable,str(APP/'wa_r3_fault_watchdog_v12.py'),'--once']
    if a.auto_recover:cmd.append('--auto-recover')
    if a.extended_auto:cmd.append('--extended-auto')
    result=subprocess.run(cmd,cwd=APP,check=False)
    if (APP/'wa_r3_pending_monitor_v12.py').is_file():
        mon=subprocess.run([sys.executable,str(APP/'wa_r3_pending_monitor_v12.py'),'--once'],cwd=APP,check=False)
        return result.returncode or mon.returncode
    return result.returncode

if __name__=='__main__':raise SystemExit(main())
