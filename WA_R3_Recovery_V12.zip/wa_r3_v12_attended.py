#!/usr/bin/env python3
"""WA R3 V12 attended recoveries for documented V8.3.7 UDP protocol.

This is not an autonomous inspection attestation. A human physically inspecting
R3 must initiate each command and explicitly confirm conditions. No global
clear, purchase command, door pulse, inventory update or automatic resends.
"""
from __future__ import annotations

import json
import sys
import time
import uuid
from typing import Any

import wa_r3_fault_watchdog_v12 as wd

ATTENDED = {'recover': 'remote_motor_recover',
            'clear-fault': 'remote_motor_clear_fault',
            'verify-disable': 'remote_motor_verify_disable',
            'clear-pending': 'remote_motor_clear_pending_cycle'}
INSPECTED = {'recover', 'clear-fault', 'clear-pending'}
NO_ACTIVE = ('network_job_active', 'service_busy', 'maintenance_busy',
             'network_job_stalled', 'service_stalled', 'order_stall_latched')
CRITICAL = ('global_fault', 'guard_latched', 'unsafe_maintenance_stop',
            'guard_owner_conflict', 'idle_worker_stalled')

class Refusal(Exception):
    pass


def validate_note(note: str) -> str:
    note = str(note or '').strip()
    if not 20 <= len(note) <= 140:
        raise Refusal('Inspection note must be 20..140 characters, describing actual inspection')
    return note


def kiosk_no_active_work() -> None:
    """Fresh Pi heartbeat and no known checkout/door/admin operation.

    No minimum wait since last purchase is inferred; explicit operator approval
    is separately required for customer-cycle reconciliation.
    """
    try:
        d = json.loads(wd.HEARTBEAT.read_text(encoding='utf-8'))
    except (ValueError, OSError) as exc:
        raise Refusal('No current kiosk heartbeat') from exc
    now = time.time()
    if d.get('version') != 1 or not isinstance(d.get('ts'),(int,float)) or not (0 <= now-d['ts'] <= 12):
        raise Refusal('Kiosk heartbeat not fresh')
    if type(d.get('pid')) is not int or not __import__('pathlib').Path('/proc', str(d['pid'])).exists():
        raise Refusal('Kiosk not running as expected')
    if d.get('screen') != 'menu':
        raise Refusal('Kiosk must be on customer Home with no customer operation underway')
    if any(d.get(k) is not False for k in ('checkout_busy','remote_busy','admin_door_busy')):
        raise Refusal('Kiosk checkout, remote or admin work active/unverified')


def base_preflight(d:dict, *, allow_pending:bool=False, allow_guard:bool=False) -> None:
    if type(d.get('boot_id')) is not int or d.get('position') != 1:
        raise Refusal('Controller boot_id/position unavailable or unexpected')
    if any(d.get(k) is not False for k in NO_ACTIVE):
        raise Refusal('ESP customer, service or maintenance work active/unknown')
    flags = ('global_fault',) if allow_guard else CRITICAL
    if any(d.get(k) is not False for k in flags):
        raise Refusal('ESP global or safety guard condition active/unknown')
    if d.get('motor_hardware_ready') is not True and not allow_guard:
        raise Refusal('ESP motor hardware readiness not verified')
    if not allow_pending and (d.get('pending_wait_open_mask') != 0 or d.get('pending_wait_close_mask') != 0):
        raise Refusal('Customer door cycle pending; cannot do motor restart/clear-fault')
    try:
        rows = wd.motor_map(d)
    except ValueError as exc:
        raise Refusal(str(exc)) from exc
    for n,row in rows.items():
        if row.get('door_closed_verified') is not True:
            raise Refusal(f'R{n} door is not positively verified closed')
    if not allow_pending and any(row.get('door_cycle_pending') is not False for row in rows.values()):
        raise Refusal('Motor door cycle pending/unknown')


def preflight(d:dict, action:str, motor:int) -> dict:
    if action not in ATTENDED or motor not in (7,10):
        raise Refusal('Unsupported action/motor')
    if action == 'clear-pending':
        base_preflight(d,allow_pending=True)
        rows=wd.motor_map(d)
        if d.get('pending_wait_open_mask') not in range(4) or d.get('pending_wait_close_mask') not in range(4):
            raise Refusal('Pending masks missing or invalid')
        bit=1 if motor==7 else 2
        if not ((d['pending_wait_open_mask']|d['pending_wait_close_mask']) & bit):
            raise Refusal('Selected motor has no pending door cycle')
        for n,row in rows.items():
            if row.get('enn_disabled_verified') is not True or row.get('step_output_active') is not False:
                raise Refusal(f'R{n} must be verified ENN disabled and STEP off')
        row=rows[motor]
        age=row.get('door_cycle_pending_observed_age_s')
        if type(age) not in (int,float) or age < 120:
            raise Refusal('Pending customer access not observed for >=120s')
        if row.get('door_cycle_pending') is not True:
            raise Refusal('Selected motor pending state not verified')
        return {'reason': 'pending', 'pending_age_s':age}
    if action == 'verify-disable':
        # This firmware operation attempts a safe disable only; it does NOT
        # clear fault/guard latches or restart motors. It is allowed even
        # when the unsafe-stop flag is set, provided ownership is idle.
        base_preflight(d,allow_guard=True)
        return {'reason':'verified_disable_only'}
    base_preflight(d)
    row=wd.motor_map(d)[motor]
    if row.get('fault_latched') is not True or type(row.get('fault_reason')) is not int or row['fault_reason'] not in range(1,8):
        raise Refusal('Selected motor has no known latched fault 1..7')
    if row.get('step_output_active') is not False or row.get('enn_disabled_verified') is not True:
        raise Refusal('Selected motor must be STEP stopped and ENN disabled')
    # Fault reason 2: mechanical disable already verified; reason 7:
    # independently recheck live TMC electrical condition.
    code=row['fault_reason']
    if code==2:
        if any(row.get(k) is not True for k in ('enn_readback_available','enn_iodir_output','enn_olat_high','enn_gpio_high')) or row.get('enn_readback_error') != 0:
            raise Refusal('Fault 2 lacks safe ENN HIGH physical readback; try attended verify-disable first')
    if code==7:
        drv,gs=row.get('tmc_drv_status'),row.get('tmc_gstat')
        if type(drv) is not int or type(gs) is not int or drv&0x3f or gs&0x6:
            raise Refusal('Fault 7 live TMC electrical condition active/unverified')
    return {'reason':code}


def same_preflight(before:dict, after:dict, action:str, motor:int) -> dict:
    if before.get('boot_id') != after.get('boot_id') or before.get('firmware') != after.get('firmware'):
        raise Refusal('Controller rebooted or changed firmware between snapshots')
    info = preflight(after,action,motor)
    old = preflight(before,action,motor)
    if info['reason'] != old['reason']:
        raise Refusal('Selected motor fault changed during confirmation')
    for k in ('pending_wait_open_mask','pending_wait_close_mask'):
        if before.get(k) != after.get(k):
            raise Refusal('Pending customer state changed between snapshots')
    a,b=wd.motor_map(before),wd.motor_map(after)
    for m in (7,10):
        for k in ('fault_latched','fault_reason','door_closed_verified',
                  'door_cycle_pending','enn_disabled_verified','step_output_active'):
            if a[m].get(k) != b[m].get(k):
                raise Refusal(f'R{m} changed state ({k}) between snapshots')
    return info


def request_payload(action:str, motor:int, d:dict, note:str) -> dict:
    p={'type':ATTENDED[action],'request_id':'r3v6-'+uuid.uuid4().hex,
       'motor':int(motor)}
    if action in INSPECTED:
        p['inspected_hardware']=True
        # A motor recovery on V8.3.7 does not use inspection_note;
        # still keep a specific operator note in local structured logs.
        if action=='clear-pending':
            p.update(inspection_note=validate_note(note),
                     customer_access_finished_confirmed=True,
                     no_active_customer_transaction_confirmed=True,
                     expected_boot_id=d['boot_id'],
                     expected_pending_wait_open_mask=d['pending_wait_open_mask'],
                     expected_pending_wait_close_mask=d['pending_wait_close_mask'])
    return p


def rpc_attended(ep, payload, timeout=38.0):
    import socket
    src,dst,port,token=ep
    p=dict(payload)
    p['token']=token
    rid=p['request_id']
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
        sock.bind((src,0))
        sock.settimeout(timeout)
        sock.sendto(json.dumps(p,separators=(',',':')).encode('utf-8'),(dst,port))
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            sock.settimeout(max(0.05,deadline-time.monotonic()))
            data,addr=sock.recvfrom(65535)
            if addr!=(dst,port): continue
            try:reply=json.loads(data)
            except (UnicodeDecodeError,ValueError): continue
            if (isinstance(reply,dict) and reply.get('type')=='remote_motor_ack'
                    and reply.get('request_id')==rid):
                return reply
    raise TimeoutError('No correlated final ACK; result unknown; do not resend')


def demand(exact:str, msg:str) -> None:
    print('\n'+msg,flush=True)
    if input(f'Type exactly {exact!r}: ').strip()!=exact:
        raise Refusal('Operator confirmation not supplied; no command sent')


def attended(action:str,motor:int,note:str, *, dry_run:bool=False) -> int:
    if action not in ATTENDED: raise Refusal('Unsupported action')
    note=validate_note(note)
    if not dry_run and not sys.stdin.isatty():
        raise Refusal('Interactive human terminal required; no cron/systemd/non-interactive inspection attestation')
    # Serialize attended maintenance against the watchdog's normal lock.
    import fcntl
    with wd.LOCK.open('a+') as lock:
        try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:raise Refusal('Watchdog or another maintenance session is active')
        ep=wd.endpoint()
        kiosk_no_active_work()
        first=wd.status(ep)
        info=preflight(first,action,motor)
        print('Controller:',first.get('firmware'),'boot_id:',first.get('boot_id'))
        print('Proposed:',ATTENDED[action],'R'+str(motor),'reason:',info['reason'])
        print('No invoice, payment, lock pulse or item inventory command is sent by this tool.')
        if dry_run:
            print('READ ONLY: payload ready, attended command not sent')
            return 0
        if action in INSPECTED:
            demand('PHYSICALLY INSPECTED R'+str(motor),
                   'Confirm an on-site person has actually inspected the selected motor and access hardware, with no person exposed to unexpected movement.')
        if action=='clear-pending':
            demand('CUSTOMER ACCESS FINISHED R'+str(motor),
                   'Confirm the specific customer door/access is finished and physically reconciled, including the product-delivery outcome.')
            demand('NO ACTIVE PAID ORDER R'+str(motor),
                   'Confirm from the Pi payment/order records that no customer transaction, retry, collection or refund is in progress. A door warning alone is not proof.')
        else:
            demand('NO ACTIVE OPERATION R'+str(motor),
                   'Confirm no customer/order/service operation is in progress and the machine is safe to service.')
        kiosk_no_active_work()
        second=wd.status(ep)
        same_preflight(first,second,action,motor)
        payload=request_payload(action,motor,second,note)
        demand('SEND '+action.upper()+' R'+str(motor),
               'Final authorization: the following action may alter safety and motor state. No automatic retry will occur.')
        kiosk_no_active_work()
        third=wd.status(ep)
        same_preflight(second,third,action,motor)
        payload=request_payload(action,motor,third,note)
        wd.stamp('ATTENDED_REQUEST',action=action,motor=motor,reason=info['reason'],
                 boot_id=third['boot_id'],inspection_attested=action in INSPECTED,
                 operator_note=note,request_id=payload['request_id'])
        try:
            reply=rpc_attended(ep,payload)
        except (TimeoutError,OSError) as exc:
            wd.stamp('ATTENDED_OUTCOME_UNKNOWN',action=action,motor=motor,error=str(exc)[:130])
            print('OUTCOME UNKNOWN. Never resend blindly; review fresh status and purchase ledger.')
            return 6
        wd.stamp('ATTENDED_ACK',action=action,motor=motor,ok=reply.get('ok'),
                 error=reply.get('error'),request_id=payload['request_id'],boot_id=reply.get('boot_id'))
        if reply.get('ok') is not True:
            print('CONTROLLER REFUSED:',reply.get('error'));return 7
        try:
            post=wd.status(ep)
            row=wd.motor_map(post)[motor]
            wd.stamp('ATTENDED_POST',action=action,motor=motor,
                     global_fault=post.get('global_fault'),
                     pending=[post.get('pending_wait_open_mask'),post.get('pending_wait_close_mask')],
                     fault_latched=row.get('fault_latched'),
                     recovery_verification=row.get('recovery_verification'),
                     rotation_verified_after_recovery=row.get('rotation_verified_after_recovery'))
        except Exception as exc:
            print('Post-status unavailable:',type(exc).__name__,str(exc)[:130]);return 8
        print('ACK received; read post-status. This does not verify product delivery.')
        if action=='clear-pending':
            print('Pending clear does NOT restart the motor or change inventory. Reconcile sale manually.')
        return 0


def self_test():
    import copy
    d={key:False for key in wd.BLOCK_FLAGS}
    d.update(boot_id=123,firmware='V4.9.72 R3 V8.3.7 V7HW AFTER_INSPECTION',position=1,
             motor_hardware_ready=True,tmc_both_configured=True,
             pending_wait_open_mask=0,pending_wait_close_mask=0,motors=[])
    for n in (7,10):
        d['motors'].append({'motor':n,'fault_latched':n==7,'fault_reason':4 if n==7 else 0,
                            'door_closed_verified':True,'door_cycle_pending':False,
                            'step_output_active':False,'enn_disabled_verified':True,
                            'door_cycle_pending_observed_age_s':-1,'encoder_valid':True,
                            'enn_readback_available':True,'enn_readback_error':0,
                            'enn_iodir_output':True,'enn_olat_high':True,'enn_gpio_high':True,
                            'tmc_drv_status':0x110000,'tmc_gstat':1})
    assert preflight(d,'recover',7)['reason']==4
    assert request_payload('recover',7,d,'Inspected motor R7 onsite, wiring and door safe')['inspected_hardware'] is True
    assert 'inspected_hardware' not in request_payload('verify-disable',7,d,'A valid detailed physical check note')
    for k in ('global_fault','service_busy','guard_latched'):
        a=copy.deepcopy(d);a[k]=True
        try:preflight(a,'recover',7)
        except Refusal:pass
        else:raise AssertionError(k+' must refuse')
    for key in ('door_closed_verified','enn_disabled_verified'):
        a=copy.deepcopy(d);a['motors'][0][key]=False
        try:preflight(a,'recover',7)
        except Refusal:pass
        else:raise AssertionError(key+' must refuse')
    p=copy.deepcopy(d)
    p['pending_wait_open_mask']=1
    p['motors'][0].update(door_cycle_pending=True,door_cycle_pending_observed_age_s=125)
    assert preflight(p,'clear-pending',7)['reason']=='pending'
    payload=request_payload('clear-pending',7,p,'Onsite inspection; paid order and door complete')
    assert set(('inspected_hardware','inspection_note','customer_access_finished_confirmed',
                'no_active_customer_transaction_confirmed','expected_boot_id',
                'expected_pending_wait_open_mask','expected_pending_wait_close_mask')).issubset(payload)
    assert payload['expected_boot_id']==123 and payload['expected_pending_wait_open_mask']==1
    for field in ('pending_wait_open_mask','boot_id'):
        b=copy.deepcopy(p);b[field]=2 if field=='pending_wait_open_mask' else 124
        try:same_preflight(p,b,'clear-pending',7)
        except Refusal:pass
        else:raise AssertionError(field+' change must refuse')
    # Never permit clearing pending for a motor without that bit.
    try:preflight(p,'clear-pending',10)
    except Refusal:pass
    else:raise AssertionError('wrong motor pending must refuse')
    print('PASS: verified on-site inspection attestation payload for fault 1..7')
    print('PASS: pending includes exact boot ID, both masks, three operator attestations')
    print('PASS: no global clear, no unattended inspection, no automatic pending clear')
    return 0


if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser(description=__doc__)
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--self-test',action='store_true')
    g.add_argument('--attended',choices=tuple(ATTENDED))
    ap.add_argument('--motor',type=int,choices=(7,10))
    ap.add_argument('--inspection-note',default='')
    ap.add_argument('--dry-run',action='store_true')
    a=ap.parse_args()
    if a.self_test:sys.exit(self_test())
    if a.motor is None:ap.error('--motor 7 or 10 required')
    try:sys.exit(attended(a.attended,a.motor,a.inspection_note,dry_run=a.dry_run))
    except (Refusal,ValueError,OSError) as exc:
        print('REFUSED: no command sent:',exc,file=sys.stderr);sys.exit(4)
