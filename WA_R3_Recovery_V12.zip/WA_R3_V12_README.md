# WA R3 V12 — Persistent Commissioning Record + Unattended Guarded Recovery

## Scope and limitation

This package **does not** set `inspected_hardware=true` for a new fault merely
because a previous commissioning inspection occurred. That field asserts a
*physical inspection of the current incident* in the existing ESP protocol.
Using it without one would bypass the controller's safety attestation for
motor stalls, ENN/driver electrical faults and door access.

V12 preserves the real V11 capability: automatic guarded recovery attempts for
fault codes 1–7 using the existing authenticated `remote_motor_recover` opcode.
Fault codes 2/4/6/7 can be enabled in extended mode with the old V8.3.7
**version label**; the actual ESP firmware still decides whether to accept the
request. A separate, recent, single-use grant for an inspected CURRENT fault
may send `inspected_hardware=true`. There is no new per-fault firmware field.

V12 additionally records a past machine inspection as commissioning **history**
(not as authorization for future current faults) and includes the V9 read-only
pending-cycle monitor by default in the 150-second watchdog runner.

## Unfinished customer door cycles

**Monitor:** YES. V12 reads `pending_wait_open_mask`, `pending_wait_close_mask`,
per-door `door_cycle_pending`, boot ID and closure flags on each watchdog run.
It records transitions, unresolved/rebooted states and escalates after 600 seconds.

**Auto-clear by Pi:** NO. V12 does not send `remote_motor_clear_pending_cycle`.
The inspected V8.3.7 ESP source itself can clear certain fresh WAIT_OPEN states
after its own timeout with repeated door-closed samples, ENN disabled and relay
output OFF; WAIT_CLOSE clears when the door closes. Stale/reboot-restored states
may remain. An ESP status ACK or cleared mask does not establish that the
paid item was *not* accessed. A second unlock without transaction-specific
proof of no delivery could cause duplicate customer access.

**Auto-reopen:** NO if an unlock may already have occurred. The existing V8
five-attempt purchase patch retries only **confirmed failures before the first
lock pulse**. A pending mask and timeout are not enough proof to retry. This
package does not modify the installed `Panel.py`, POS/FURS or inventory.

## Install on the Pi

Upload `WA_R3_Recovery_V12.zip` to your GitHub repository main branch. Then:

```bash
cd /home/wa_stopshop_mb/WA/Main_program/Fis
curl -fL --retry 3 'https://raw.githubusercontent.com/VPLabsSVN/WA_Update/main/WA_R3_Recovery_V12.zip' -o WA_R3_Recovery_V12.zip
unzip -o WA_R3_Recovery_V12.zip
./venv/bin/python wa_r3_fault_watchdog_v12.py --self-test
./venv/bin/python wa_r3_pending_monitor_v12.py --self-test
./venv/bin/python wa_r3_v12_commissioning.py --self-test
./venv/bin/python test_wa_r3_v12_sim.py
./venv/bin/python wa_r3_v12_activate.py --check
```

When the machine is *idle*, enable guarded automatic attempts for faults 1–7:

```bash
./venv/bin/python wa_r3_v12_activate.py --enable-extended
systemctl --user show -p ExecStart wa-r3-watchdog.service
systemctl --user list-timers --all wa-r3-watchdog.timer
```

You may optionally document the completed prior site visit (informational only):

```bash
./venv/bin/python wa_r3_v12_commissioning.py --record --inspection-note 'Both R7 and R10 inspected onsite, doors, motor wiring and driver safety checked'
./venv/bin/python wa_r3_v12_commissioning.py --status
```

To monitor customer cycles:

```bash
./venv/bin/python wa_r3_pending_monitor_v12.py --last
journalctl --user -u wa-r3-watchdog.service --since '30 minutes ago' --no-pager -l | tail -80
```

For *actual current-fault physical inspection* (if needed for fault 2/4/6/7):

```bash
./venv/bin/python wa_r3_v12_grant.py --authorize --motor 7 --inspection-note 'Inspected current R7 fault onsite: door, relay, motor and wiring safe'
```

Rollback watchdog systemd override:

```bash
./venv/bin/python wa_r3_v12_activate.py --rollback
```

V12 reuses your existing 150-second timer and idle heartbeat. It changes only
the watchdog execution target through an additive user-systemd drop-in; it does
not auto-apply the included purchase patch and does not change `Panel.py`.

## Validation and fail-closed boundaries

- Never assert an unperformed physical inspection, or send an unattended
  pending-cycle clear or new unlock after uncertain previous pulse.
- Hard block global fault, unsafe guard, ambiguous snapshot, active sale,
  pending door state, ENN not disabled or unsafe TMC bits.
- Rate limit at most one recovery request per motor per hour and two per day;
  consume budget before sending; avoid duplicate on ACK timeout.
- Record motor recovery ACK but require subsequent measured status; a motor ACK
  does not prove a paid item was handed over.
- Controller firmware may reject attempts, especially on the known older
  implementation that requires an inspection attestation for 2/4/6/7.
- Tests are simulated/offline only. No live ESP/Pi validation occurred.
