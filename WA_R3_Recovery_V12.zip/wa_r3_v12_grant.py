#!/usr/bin/env python3
"""V12 per-incident inspection authorization for an already inspected CURRENT fault.

NEVER confirms physical inspection from remote telemetry or a previous service
visit. Requires an on-site operator to physically check THIS fault, then issue
one short-lived authorization bound to one motor, fault, boot, and stop event.
The watchdog consumes this authorization before sending inspected_hardware=true.
It does not independently clear any fault, pending cycle, or global safety stop.
"""
from __future__ import annotations
import argparse
import fcntl
import json
import os
import sys
import tempfile
import time
import uuid
from pathlib import Path
import wa_r3_fault_watchdog_v12 as wd


def record_permission(d):
    # 'No global fault' is not proof that a stall/electrical fault was physically
    # inspected; this utility requires both the interlock checks and a human.
    candidates, why = wd.candidates(d)
    if why:
        raise ValueError('Controller not in an eligible recovery state: '+why)
    return candidates


def explicit_confirmation(motor, reason):
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        raise ValueError('Must use a local interactive operator terminal; no automation')
    expected = f'INSPECTED R{motor} FAULT {reason}'
    print('\nBefore proceeding, an on-site person must have inspected THIS CURRENT')
    print('fault, ruled out mechanical obstruction/electrical hazards, checked')
    print('door closed and lock inactive, and confirmed no customer is waiting.')
    print('The earlier commissioning inspection is NOT sufficient.')
    return input(f'Type {expected!r} to attest this inspection: ').strip() == expected


def authorize(motor, note):
    note = note.strip()
    if not 20 <= len(note) <= 140:
        raise ValueError('Current-fault physical inspection note must be 20..140 characters')
    if motor not in (7,10):
        raise ValueError('Motor must be 7 or 10')
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        raise ValueError('Noninteractive authorization is prohibited')
    with wd.LOCK.open('a+') as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise ValueError('Watchdog is currently running; retry after it completes') from exc
        first_idle, why = wd.kiosk_idle()
        if not first_idle:
            raise ValueError('Kiosk is not verified idle: '+why)
        ep = wd.endpoint()
        first = wd.status(ep)
        available = record_permission(first)
        matches = [(m,reason) for m,reason in available if m == motor and reason in wd.EXTENDED_CODES]
        if len(matches) != 1:
            raise ValueError('Selected motor has no active, telemetry-safe extended fault 2/4/6/7')
        _, reason = matches[0]
        print('Current controller boot:', first['boot_id'])
        print('Current firmware:', first['firmware'])
        print('Selected motor: R'+str(motor),' fault:',reason)
        print('Reported door closed:', wd.motor_map(first)[motor].get('door_closed_verified'))
        print('Reported ENN disabled:', wd.motor_map(first)[motor].get('enn_disabled_verified'))
        first_anchor = wd.stop_anchor(first, motor)
        if first_anchor is None:
            raise ValueError('Current controller STOP event identity is not available')
        if not explicit_confirmation(motor,reason):
            raise ValueError('Attestation not provided; no grant created')
        second_idle, why = wd.kiosk_idle()
        if not second_idle:
            raise ValueError('Kiosk activity changed: '+why)
        second=wd.status(ep)
        if not wd.same_status(first,second,motor,reason):
            raise ValueError('Motor fault/state changed during inspection confirmation')
        second_anchor=wd.stop_anchor(second,motor)
        if (second_anchor is None or first_anchor['code']!=second_anchor['code'] or
                abs(first_anchor['epoch']-second_anchor['epoch']) > 6):
            raise ValueError('Motor STOP event changed during inspection confirmation')
        now=time.time()
        grant={
            'version':6,'grant_id':'r3v6-'+uuid.uuid4().hex,
            'inspected_current_fault':True,
            'motor':motor,'fault_reason':reason,
            'boot_id':second['boot_id'],'firmware':second['firmware'],
            'issued_at':now,'expires_at':now+wd.GRANT_TTL_SECONDS,
            'note':note,'stop_anchor':second_anchor,
        }
        fd,tmp=tempfile.mkstemp(prefix='.wa_r3_v6_grant_',dir=str(wd.APP))
        try:
            with os.fdopen(fd,'w',encoding='utf-8') as out:
                json.dump(grant,out,sort_keys=True,indent=2)
                out.flush();os.fsync(out.fileno())
            os.chmod(tmp,0o600)
            os.replace(tmp,wd.GRANT)
        finally:
            if os.path.exists(tmp):os.unlink(tmp)
        verified,why = wd.inspection_grant(second,motor,reason,path=wd.GRANT)
        if verified is None:
            wd.GRANT.unlink(missing_ok=True)
            raise ValueError('Could not verify freshly written grant: '+why)
        wd.stamp('CURRENT_FAULT_INSPECTED',motor=motor,fault_reason=reason,
                 grant_id=grant['grant_id'],boot_id=grant['boot_id'],
                 valid_for_seconds=wd.GRANT_TTL_SECONDS,
                 note='an operator physically inspected THIS CURRENT motor fault')
        print('AUTHORIZED: one guarded inspected recovery request for current R'+str(motor))
        print('Expires in',wd.GRANT_TTL_SECONDS,'seconds. Start the configured V12 extended watchdog once,')
        print('or wait for its next 150-second timer invocation.')
        print('No motor command was sent by this authorization utility.')
        return 0


def status():
    try:
        # This is descriptive only; actual authorization needs fresh ESP status.
        g=json.loads(wd.GRANT.read_text(encoding='utf-8'))
    except (OSError,ValueError):
        print('No inspection grant pending')
        return 0
    print(json.dumps({k:g.get(k) for k in
        ('grant_id','motor','fault_reason','boot_id','issued_at','expires_at')},indent=2))
    print('Seconds remaining:',max(0,round(float(g.get('expires_at',0))-time.time())))
    print('This record alone never authorizes a motor command without fresh status checks.')
    return 0


def self_test():
    assert wd.GRANT_TTL_SECONDS <= 240
    assert wd.EXTENDED_CODES == frozenset({2,4,6,7})
    import inspect
    source=inspect.getsource(authorize)
    assert 'explicit_confirmation' in source and 'wd.same_status' in source
    assert 'wd.kiosk_idle' in source and 'wd.GRANT' in source
    assert "inspected_current_fault':True" in source
    print('PASS: interactive-only current-fault inspection grant; one-time, max four minutes')
    print('PASS: no broad commissioning attestation, no pending clear, no motor command')
    return 0


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    mode=ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--authorize',action='store_true')
    mode.add_argument('--status',action='store_true')
    mode.add_argument('--revoke',action='store_true')
    mode.add_argument('--self-test',action='store_true')
    ap.add_argument('--motor',type=int,choices=(7,10))
    ap.add_argument('--inspection-note',default='')
    args=ap.parse_args(argv)
    if args.self_test:return self_test()
    if args.status:return status()
    if args.revoke:
        wd.GRANT.unlink(missing_ok=True)
        print('Revoked any pending current-fault inspection grant. No motor command sent.')
        return 0
    if args.motor is None:ap.error('Specify --motor 7 or --motor 10')
    try:return authorize(args.motor,args.inspection_note)
    except (ValueError,OSError,TimeoutError) as exc:
        print('REFUSED:',str(exc),file=sys.stderr)
        return 4


if __name__=='__main__':raise SystemExit(main())
