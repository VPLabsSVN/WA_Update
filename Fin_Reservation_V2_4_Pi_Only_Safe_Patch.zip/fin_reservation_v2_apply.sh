#!/usr/bin/env bash
# Fin reservation V2.4 (Pi-only bounded unpaid checkout + PLA/Wolt): version-locked, reversible deployment. Does not restart kiosk.
set -euo pipefail
umask 077
APPDIR="${FIN_APPDIR:-/home/wa_stopshop_mb/WA/Main_program/Fis}"
BACKUP_ROOT="$HOME/fin_reservation_v2_backups"
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
V1_PANEL_SHA='a8c52a48602596d198c78025654275a368cd03c412259c368a9a51d2b0ed8da7'
V1_BACKEND_SHA='b46796c0aacf44b91f40f571b9eda7e85687777e92fb8790cb36e0f2de52c450'
V2_BACKEND_SHA='1c2581115695a6c8353d730217d3400293be7b74a3cae4ef77dd21151e91b886'
V2_HELPER_SHA='ddf6cc75bbe90bccdddc3b8fd558ec7887d2394db07007a66ffe3ae0837d7ebe'
V2_TEST_SHA='ae8f51370a2a0d985217c6f18289d8315610acc90f6a076556958647369abd78'
PROOF_TEST_SHA='7c97ad5b1b3a85cb402ac82fc977ec1ea7623effa651641009c841ac60c33392'
mode="${1:---check}"

hashfile() { sha256sum "$1" | awk '{print $1}'; }
verify_hash() {
  local file="$1" expected="$2" actual
  [[ -f "$file" ]] || { echo "MISSING: $file" >&2; return 1; }
  actual="$(hashfile "$file")"
  if [[ "$actual" != "$expected" ]]; then
    echo "VERSION MISMATCH: $(basename "$file")" >&2
    echo "Expected: $expected" >&2
    echo "Actual:   $actual" >&2
    return 1
  fi
}

if [[ "$mode" == '--rollback' ]]; then
  backup="${2:-}"
  [[ -n "$backup" && -d "$backup" ]] || { echo 'Provide existing automatic backup directory.' >&2; exit 1; }
  [[ "$backup" == "$BACKUP_ROOT/"* ]] || { echo "For safety, backups must be under $BACKUP_ROOT" >&2; exit 1; }
  [[ -f "$backup/SHA256SUMS" && -f "$backup/Panel_backend_merged.py" ]] || { echo 'Invalid backup.' >&2; exit 1; }
  if [[ -e "$APPDIR/.fin_reservation_v2_recovery.json" ]]; then
    echo 'STOP: A reservation payment recovery record exists.' >&2
    echo 'Reconcile payment/door status before rolling back to V1, which lacks V2 payment gates.' >&2
    exit 1
  fi
  verify_hash "$APPDIR/Panel_backend_merged.py" "$V2_BACKEND_SHA"
  ( cd "$backup" && sha256sum -c SHA256SUMS )
  printf 'Type ROLLBACK-FIN-V2 to restore V1 backend: '
  read -r answer
  [[ "$answer" == 'ROLLBACK-FIN-V2' ]] || { echo 'Cancelled.'; exit 1; }
  temp_out="$(mktemp "$APPDIR/.fin_v2_restore.XXXXXXXX")"
  trap 'rm -f -- "$temp_out"' EXIT
  cp -p -- "$backup/Panel_backend_merged.py" "$temp_out"
  mv -f -- "$temp_out" "$APPDIR/Panel_backend_merged.py"
  if [[ -f "$backup/fin_reservation_v2_logic.py" ]]; then
    cp -p -- "$backup/fin_reservation_v2_logic.py" "$APPDIR/fin_reservation_v2_logic.py"
  else
    rm -f -- "$APPDIR/fin_reservation_v2_logic.py"
  fi
  echo 'V1 backend restored on disk. Kiosk NOT restarted.'
  echo 'When idle: systemctl --user restart bouquetmat.service'
  exit 0
fi

[[ "$mode" == '--check' || "$mode" == '--apply' ]] || { echo "Usage: $0 --check | --apply | --rollback BACKUP_PATH" >&2; exit 2; }
for f in Fin_Reservation_V2_4.patch fin_reservation_v2_logic.py test_fin_reservation_v2.py fin_v24_observe_claim_hold.py; do
  [[ -r "$HERE/$f" ]] || { echo "Package missing $f" >&2; exit 1; }
done
verify_hash "$HERE/fin_reservation_v2_logic.py" "$V2_HELPER_SHA"
verify_hash "$HERE/test_fin_reservation_v2.py" "$V2_TEST_SHA"
verify_hash "$HERE/fin_v24_observe_claim_hold.py" "$PROOF_TEST_SHA"
verify_hash "$APPDIR/Panel.py" "$V1_PANEL_SHA"
verify_hash "$APPDIR/Panel_backend_merged.py" "$V1_BACKEND_SHA"
[[ ! -e "$APPDIR/.fin_reservation_v2_recovery.json" ]] || { echo 'Recovery ledger already exists; deployment refused.' >&2; exit 1; }

TEMP="$(mktemp -d "$HOME/.fin_v2_check.XXXXXXXX")"
trap 'rm -rf -- "$TEMP"' EXIT
cp -p -- "$APPDIR/Panel_backend_merged.py" "$TEMP/Panel_backend_merged.py"
cp -p -- "$HERE/fin_reservation_v2_logic.py" "$TEMP/fin_reservation_v2_logic.py"
cp -p -- "$HERE/test_fin_reservation_v2.py" "$TEMP/test_fin_reservation_v2.py"
( cd "$TEMP" && patch -p1 --fuzz=0 < "$HERE/Fin_Reservation_V2_4.patch" )
verify_hash "$TEMP/Panel_backend_merged.py" "$V2_BACKEND_SHA"
( cd "$TEMP" && python3 -B test_fin_reservation_v2.py )
python3 - "$TEMP" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1])
for name in ('Panel_backend_merged.py', 'fin_reservation_v2_logic.py'):
    compile((root/name).read_bytes(), name, 'exec')
    print('Syntax OK:',name)
PY
printf '\nPASS: exact Fin V1 hashes, V2 patch, syntax and offline tests.\n'
if [[ "$mode" == '--check' ]]; then
  echo 'DRY RUN: No production files or services changed.'
  echo 'Pi-only 200s claim observation proof is required separately before --apply.'
  exit 0
fi

echo
printf 'Before --apply: validating recent 200-second backend claim observation proof...\n'
python3 "$HERE/fin_v24_observe_claim_hold.py" --validate-proof
printf 'WARNING: --apply installs Fin V2.4 (Pi-only bounded unpaid checkout) to TWO files.\n' 
echo 'No kiosk restart is performed; apply only with Fin idle and no terminal payments running.'
read -r -p 'Type APPLY-FIN-RESERVATION-V2-4 to proceed: ' answer
[[ "$answer" == 'APPLY-FIN-RESERVATION-V2-4' ]] || { echo 'Cancelled.'; exit 1; }
mkdir -p -m 700 "$BACKUP_ROOT"
BACKUP="$BACKUP_ROOT/$(date +%Y%m%d_%H%M%S)"
mkdir -m 700 "$BACKUP"
for f in Panel.py Panel_backend_merged.py backend_client.py Ads.py; do
  [[ -r "$APPDIR/$f" ]] && cp -p -- "$APPDIR/$f" "$BACKUP/$f"
done
[[ -e "$APPDIR/fin_reservation_v2_logic.py" ]] && cp -p -- "$APPDIR/fin_reservation_v2_logic.py" "$BACKUP/fin_reservation_v2_logic.py"
( cd "$BACKUP"; sha256sum ./*.py > SHA256SUMS; sha256sum -c SHA256SUMS )
echo "Automatic rollback backup: $BACKUP"
# Copy helper first so the application can import it after restart.
install -m 0644 "$TEMP/fin_reservation_v2_logic.py" "$APPDIR/fin_reservation_v2_logic.py"
TEMP_BACKEND="$(mktemp "$APPDIR/.fin_v2_backend.XXXXXXXX")"
cp -p -- "$TEMP/Panel_backend_merged.py" "$TEMP_BACKEND"
verify_hash "$TEMP_BACKEND" "$V2_BACKEND_SHA"
mv -f -- "$TEMP_BACKEND" "$APPDIR/Panel_backend_merged.py"
verify_hash "$APPDIR/Panel_backend_merged.py" "$V2_BACKEND_SHA"
echo 'FIN RESERVATION V2.4 PATCH INSTALLED ON DISK.'
echo 'No services, payments, motors or remote recovery were restarted.'
echo "Backup: $BACKUP"
echo 'Review the READ ME before restarting. When Fin is idle:'
echo '  systemctl --user restart bouquetmat.service'
echo "Rollback (after reconciling any payment ledger): bash '$HERE/fin_reservation_v2_apply.sh' --rollback '$BACKUP'"
