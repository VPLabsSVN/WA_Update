# Fin Reservation V2.4 — Pi-only claim-hold compatibility (NO BACKEND UPDATE)

This supersedes V2.3. It preserves all V2.3 PLA (`reserved_for: PLA`), Wolt and
unpaid routing, and is built on Fin Performance V1. **The WA backend is untouched.**

## Why this exists

Live claim responses have `ok`, `claimed`, `claim_token`, `reservation`, but NO
`claim_expires_at` / `hold_expires_at` / `claimed_until`. A reservation's
`expires_at=None` is normal and is not used as a claim duration.

An older backend source showed a hold_seconds-based server claim, but it does
NOT prove the current server's hold duration. Therefore V2.4 requires a live,
controlled **200+ second hold observation** of a DEDICATED unpaid test code.
Only after passing the observation can the Pi use a conservative 120-second
*local checkout-start window* for legacy responses without an expiry. A fresh
proof expires after 7 days, so the controlled test must be renewed periodically
while unpaid reservations are used. **No time is invented as a server expiry.**

The server's `/confirm` with the original claim token remains REQUIRED after
terminal commitment and BEFORE opening any door. If the server rejects an
expired claim after payment, the door stays closed; the recovery ledger
requires staff reconciliation (possible refund). This Pi-only fix reduces,
but cannot eliminate, that risk without an authoritative expiry or
payment-authorization/capture integration. No automatic second charge.

## Restrictions and preserved behavior

- `PLA` (including backend `reserved_for: PLA`) and Wolt: existing no-terminal
  reservation collection; 60-second holds. Verified route consistency required.
- Unmarked reservation: terminal payment for one LOCAL reserved item only.
- Normal retail checkout, POS, fiscalisation, motor control, remote recovery,
  UI responsiveness improvements from Performance V1: untouched.
- Remote unpaid reservations, conflicting metadata or mismatched claim tokens:
  blocked. All uncertain payments require manual reconciliation.
- Existing operator recovery journal `.fin_reservation_v2_recovery.json` remains
  mandatory; never delete it if a payment or door status is uncertain.
- If the proof is missing, stale, mismatched to backend URL/panel ID, claim fails,
  or more than 30 seconds pass before the checkout callback: FAIL CLOSED, no charge.

## Procedure

1. Leave Fin Performance V1 running. Download, unzip, check the SHA256SUMS.
2. From the package directory (without touching production files):

   `bash fin_reservation_v2_apply.sh --check`

3. With Fin IDLE, prepare a dedicated UNPAID test reservation that no customer
   will use for the duration. Run:

   `python3 fin_v24_observe_claim_hold.py --claim-test`

   The script verifies unpaid status, claims with `hold_seconds=600`, checks
   `/verify` after ~65 and ~205 seconds, requiring `valid=False` with
   `reason=status_claimed`, RELEASES the claim, and then requires a successful
   post-release `valid=True`. It writes a small local proof in
   `~/.config/bouquetmat/fin_v24_hold_proof.json` (mode 0600) ONLY if all
   checks pass. No passwords, codes, or tokens are stored in the proof. The
   wait is part of a test, not an ongoing background process. Do not use a
   customer code; release failure requires manual resolution before reuse.

   `python3 fin_v24_observe_claim_hold.py --validate-proof`

4. After a valid proof, run `--check` again. **Before installing, verify that
   no customer purchase or motor operation is underway.** `--apply` itself
   validates the local proof and creates an automatic backup.

   `bash fin_reservation_v2_apply.sh --apply`

   It requires an explicit confirmation phrase. Neither install nor rollback
   restarts the kiosk. When idle:

   `systemctl --user restart bouquetmat.service`

5. Supervised operator tests required before customer release:
   `PLA` collection; Wolt collection; ordinary purchase; a terminal test-mode
   unpaid reservation purchase; rejected/cancelled payment; fiscalisation;
   door acknowledgment; payment ledger recovery. Never exercise a real card
   or unattended door until controlled tests pass.

## Rollback

Installer prints an exact backup directory in
`~/fin_reservation_v2_backups/YYYYMMDD_HHMMSS`. It preserves the original
Panel.py, Panel_backend_merged.py, backend_client.py, Ads.py. If no payment
is in flight and no recovery ledger exists:

`bash fin_reservation_v2_apply.sh --rollback /home/pi/fin_reservation_v2_backups/ACTUAL_TIMESTAMP`

Then restart the user service when idle. The installer refuses rollback if a
recovery ledger exists; reconcile payments before disabling the V2 gates.

**Do not upload actual production Python files to public GitHub**; they
contain embedded credentials. This package includes only a diff + safe tools.
