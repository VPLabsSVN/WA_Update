#!/usr/bin/env python3
"""Fin V2.4: supervised claim-duration test, no backend changes.

Only a dedicated UNPAID test reservation, no real customer. POST verify,
POST claim, later POST verify, POST release. Does not charge, confirm,
redeem, fiscalize or open any door. Stores no code, token or credential.
"""
from __future__ import annotations
import argparse
import ast
from datetime import datetime, timezone
import getpass
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import urllib.error
import urllib.request

APPDIR = Path('/home/wa_stopshop_mb/WA/Main_program/Fis')
HERE = Path(__file__).resolve().parent
PROOF_PATH = Path.home() / '.config' / 'bouquetmat' / 'fin_v24_hold_proof.json'
OBSERVE_SECONDS = 205  # must observe more than 200 actual elapsed seconds


def parse_config():
    tree=ast.parse((APPDIR / 'Panel_backend_merged.py').read_text(encoding='utf-8'))
    fields={'BACKEND_BASE_URL','BACKEND_PANEL_KEY','BACKEND_PANEL_ID_OVERRIDE'}
    found={}
    for node in tree.body:
        if isinstance(node,ast.Assign):
            for target in node.targets:
                if isinstance(target,ast.Name) and target.id in fields:
                    try: value=ast.literal_eval(node.value)
                    except (TypeError,ValueError,SyntaxError): continue
                    if isinstance(value,str): found[target.id]=value
    if not found.get('BACKEND_BASE_URL'):
        raise RuntimeError('Backend configuration could not be read safely')
    return found


def request(base, path, headers, body):
    req=urllib.request.Request(base.rstrip('/')+path,
           data=json.dumps(body).encode('utf-8'), headers=headers, method='POST')
    try:
        with urllib.request.urlopen(req,timeout=9) as resp:
            obj=json.load(resp)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f'HTTP {exc.code}; response body withheld') from None
    except urllib.error.URLError:
        raise RuntimeError('Connection to reservation API failed') from None
    if not isinstance(obj,dict):
        raise RuntimeError('Unexpected JSON response')
    return obj


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--claim-test',action='store_true',
                        help='Claim a dedicated unpaid TEST reservation for ~205 seconds, then release it')
    parser.add_argument('--proof-status',action='store_true',
                        help='Print only whether the existing local proof file exists')
    parser.add_argument('--validate-proof',action='store_true',
                        help='Offline validation of stored hold proof and backend fingerprint')
    args=parser.parse_args()
    if args.proof_status:
        print('Proof file present:',PROOF_PATH.is_file())
        print('Proof path:',PROOF_PATH)
        return 0
    if args.validate_proof:
        helper=HERE / 'fin_reservation_v2_logic.py'
        spec=importlib.util.spec_from_file_location('fin_v24_policy',helper)
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        cfg=parse_config()
        try:
            st=PROOF_PATH.stat()
            if st.st_uid!=os.getuid() or (st.st_mode & 0o077):
                raise RuntimeError('Proof file permissions/owner incorrect')
            proof=json.loads(PROOF_PATH.read_text(encoding='utf-8'))
        except OSError:
            print('HOLD PROOF: MISSING. No unpaid terminal payments enabled.')
            return 1
        now=time.monotonic()
        example={'ok':True,'claimed':True,'claim_token':'OFFLINE-TEST-NOT-REAL',
                 '_fin_v24_requested_hold':600,
                 '_fin_v24_claim_received_monotonic':now}
        remaining=module.validated_unreported_claim_window(
            example,proof=proof,backend_url=cfg['BACKEND_BASE_URL'],
            panel_id=cfg.get('BACKEND_PANEL_ID_OVERRIDE') or 'Fin',
            now_monotonic=now)
        print('HOLD PROOF VALID:', remaining is not None and remaining>=90)
        print('No live server request made.')
        return 0 if remaining is not None and remaining>=90 else 1
    if not args.claim_test:
        print('No live actions performed. Use --claim-test for a dedicated TEST reservation.')
        return 0
    helper=HERE / 'fin_reservation_v2_logic.py'
    if not helper.is_file():
        raise RuntimeError('Missing Fin V2.4 routing helper')
    spec=importlib.util.spec_from_file_location('fin_reservation_v2_logic',helper)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    cfg=parse_config()
    panel=cfg.get('BACKEND_PANEL_ID_OVERRIDE') or 'Fin'
    base=cfg['BACKEND_BASE_URL']
    headers={'Content-Type':'application/json'}
    if cfg.get('BACKEND_PANEL_KEY'):
        headers['X-Panel-Key']=cfg['BACKEND_PANEL_KEY']
    print('FIN V2.4 CONTROLLED CLAIM-HOLD TEST (no backend modifications)')
    print('Use ONLY a dedicated UNPAID TEST reservation while Fin is idle.')
    print('No customer payment, redemption, invoice, or door operation.')
    code=getpass.getpass('Numeric TEST reservation code (hidden): ').strip()
    if not code.isascii() or not code.isdigit():
        raise RuntimeError('Use a numeric dedicated test reservation code')
    verify=request(base,'/api/reservations/verify',headers,{'code':code,'panel_id':panel})
    if verify.get('valid') is not True or module.reservation_route(verify.get('reservation'))!='unpaid':
        raise RuntimeError('Test reservation not valid/unpaid; nothing claimed')
    print('Unpaid test reservation verified: YES')
    marker=input('Type OBSERVE-CLAIM-205 to claim and hold test reservation: ').strip()
    if marker != 'OBSERVE-CLAIM-205':
        print('Cancelled, no claim made.')
        return 1
    token=None
    passed=False
    release_ok=False
    observed=0.0
    try:
        claim=request(base,'/api/reservations/claim',headers,{
            'code':code,'panel_id':panel,'claimed_by':'panel','hold_seconds':600})
        token=claim.get('claim_token')
        if claim.get('claimed') is not True or claim.get('ok') is not True or not isinstance(token,str) or not token:
            raise RuntimeError('No authoritative claim/token received; manual state check may be needed')
        if module.reservation_route(claim.get('reservation'))!='unpaid':
            raise RuntimeError('Claim marker mismatch; release will be attempted')
        started=time.monotonic()
        print('Claim accepted. Observing server claim availability for at least 205 seconds.')
        for checkpoint in (65, OBSERVE_SECONDS):
            time.sleep(max(0.0, checkpoint-(time.monotonic()-started)))
            check=request(base,'/api/reservations/verify',headers,{'code':code,'panel_id':panel})
            elapsed=time.monotonic()-started
            if check.get('valid') is not False or check.get('reason')!='status_claimed':
                raise RuntimeError(f'Server did not report active claim at {round(elapsed)} seconds')
            print(f'Claim still held at {round(elapsed)} seconds: YES')
        observed=time.monotonic()-started
        passed=observed>=200
    finally:
        if token:
            try:
                answer=request(base,'/api/reservations/release',headers,{
                    'code':code,'claim_token':token,'panel_id':panel,
                    'released_by':'panel','release_reason':'fin_v24_test'})
                if answer.get('released') is True and answer.get('ok') is True:
                    final=request(base,'/api/reservations/verify',headers,{'code':code,'panel_id':panel})
                    release_ok=final.get('valid') is True
            except Exception:
                release_ok=False
            print('Release and post-release verification:', 'PASS' if release_ok else 'NOT CONFIRMED')
        else:
            print('WARNING: No claim token; release not possible. Check server state.')
    if not passed or not release_ok:
        raise RuntimeError('Hold proof failed; no fallback activated. Verify test reservation state.')
    proof={
        'schema':'fin-v24-observed-claim-hold-v1',
        'backend_url_sha256':hashlib.sha256(base.rstrip('/').encode('utf-8')).hexdigest(),
        'panel_id':panel, 'requested_hold_seconds':600,
        'observed_held_seconds':round(observed,2), 'release_confirmed':True,
        'tested_at_utc':datetime.now(timezone.utc).isoformat(),
    }
    PROOF_PATH.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    os.chmod(PROOF_PATH.parent,0o700)
    fd,name=tempfile.mkstemp(prefix='.fin_hold_',dir=PROOF_PATH.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as fp:
            os.fchmod(fp.fileno(),0o600)
            json.dump(proof,fp)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(name,PROOF_PATH)
    finally:
        if os.path.exists(name): os.unlink(name)
    print('PASS: observed claim held >=200s and released successfully.')
    print('Short local checkout policy proof saved:',PROOF_PATH)
    print('Proof expires after 7 days; repeat this controlled test to renew.')
    print('No backend code, customer transaction, or kiosk service changed.')
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except KeyboardInterrupt:
        print('Stopped by operator; check that test claim was released.',file=sys.stderr)
        raise SystemExit(1)
    except Exception as exc:
        print('STOP:',type(exc).__name__,str(exc) if isinstance(exc,RuntimeError) else '',file=sys.stderr)
        raise SystemExit(1)
